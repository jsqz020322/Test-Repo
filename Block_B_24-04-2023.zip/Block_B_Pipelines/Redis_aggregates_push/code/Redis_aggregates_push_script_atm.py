import pandas as pd
import numpy as np
import requests
import json
import os
import sys
import time

import multiprocessing
from multiprocessing import Process

from SparkUtils.spark_utils import decrypt_column,create_spark_context
import warnings

warnings.filterwarnings('ignore')

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

config_json_path = curr_dir + "/config/Redis_aggregates_push_pandas.json"
conf = json.load(open(config_json_path, "r"))



ra_url = conf["ra_url"]

headers = {"Content-Type":"application/json; charset=utf-8"}

def push_default_key():
    res = False
    try:
        def_agg_json = curr_dir + conf["default_agg_json_path"]
        json_str = open(def_agg_json,"r").read()
        json_val = {"default":json_str}
        res = requests.post(ra_url,json=json_val,headers=headers,verify=False)
        res_json = res.json()
        print(" Default key is pushed to redis ",str(res_json['Status']))
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        print(exc_val)
    return res
    
def call_ra_url(json_data,start,end):
    json_data.index=json_data["SD_PAN"]
    val = json_data[["aggregate_val"]].to_dict()
    conf = val['aggregate_val']
    headers = {"Content-Type":"application/json; charset=utf-8"}
    res = requests.post(ra_url,json=conf,headers=headers,verify=False)
    res_json = res.json()
    print("Aggregates updated in redis for cards : start : "+ str(start)+" : end : ",str(end))
    print(res_json['Status'])
    return res
    
def push_aggregates():
    
    res_li = []
    sc = None
    try:
        key1 = conf["credential_key1"]
        key2 = conf["credential_key2"]
        
        #spark, sc = create_spark_context(conf,conf["appName"])
        
#         print(key1,key2)
        
        sdf = pd.read_parquet(conf["aggregate_path_loc"])
        sdf = sdf.head(100000)
        
        sdf['SD_PAN'] = sdf['SD_PAN'].apply(lambda x:decrypt_column(x,key1,key2))
        

        
        df_count = len(sdf)
        print(df_count)
        
        
        start_time = time.perf_counter()
        
        subset_2 = range(0, len(sdf), 10000)

        df = sdf[:]
        
        temp_li = []

        for each_iter in range(len(subset_2)):

            start_2 = subset_2[each_iter]
            if each_iter == len(subset_2) - 1:
                end_2 = len(df)
            else:
                end_2 = subset_2[each_iter + 1]

            sub_df = df[start_2:end_2]

            temp_li.append([sub_df,start_2,end_2])

        pool = multiprocessing.Pool(conf["thread_count"])
        processes = [pool.apply_async(call_ra_url,args=(x[0],x[1],x[2],)) for x in temp_li]
        res_li = [p.get() for p in processes]
          
        
        finish_time = time.perf_counter()
        time_diff = finish_time-start_time
        
        print(" Aggregates to redis are pushed in seconds ",time_diff)
        

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        print(exc_val)
 
    if sc is not None:
        sc.stop()
    return res_li

if __name__ == '__main__':
    res = push_default_key()
    res_li = push_aggregates()
    
