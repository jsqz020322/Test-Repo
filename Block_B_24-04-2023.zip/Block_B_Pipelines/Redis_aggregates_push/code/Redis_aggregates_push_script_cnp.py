import pandas as pd
import numpy as np
import requests
import json
import os
import sys
import time

import multiprocessing
from multiprocessing import Process

from SparkUtils.spark_utils import decrypt_column,create_spark_context
import warnings

import jpype
import jpype.imports


warnings.filterwarnings('ignore')

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

config_json_path = curr_dir + "/config/Redis_aggregates_push_cnp.json"
conf = json.load(open(config_json_path, "r"))

ra_url = conf["ra_url"]

headers = {"Content-Type":"application/json; charset=utf-8"}

atm_col_df = pd.read_csv(curr_dir + "/config/ATM_NRT_Pruned_feature_set_15_02_2023.csv")
pos_short_key_map = pd.read_csv(curr_dir + "/config/POS_Features_With_Short_Keys_15_12_2022.csv")
pos_short_key_map.columns = ['feature','short_key']

cnpsec_short_key_map = pd.read_csv(curr_dir + "/config/CNP_secured_Base_model_Features_short_mapping.csv")
cnpsec_short_key_map.columns = ['index','feature','short_key']

cnpunsec_short_key_map = pd.read_csv(curr_dir + "/config/CNP_Unsecured_Base_Model_Features_with_Short_keys.csv")
cnpunsec_short_key_map.columns = ['feature','short_key']

shortkey_df = pd.concat([pos_short_key_map,cnpsec_short_key_map[["feature","short_key"]], cnpunsec_short_key_map[["feature","short_key"]],atm_col_df[["feature","short_key"]]])

shortkey_df = shortkey_df.drop_duplicates()
merchant_df = shortkey_df[shortkey_df['feature'].str.contains("days_merchant")]
card_short_key_df = shortkey_df[~shortkey_df['feature'].str.contains("days_merchant")]

mapped_dict=dict(zip(card_short_key_df['feature'],card_short_key_df['short_key']))
req_keys = list(mapped_dict.keys())
req_cols = list(mapped_dict.values())

req_keys = [r for r in req_keys if r!="tran_cde_type_CNPSECURED_Purchase_count_prev30days"]
req_cols = list(set(req_cols))

mer_mapped_dict=dict(zip(merchant_df['feature'],merchant_df['short_key']))

mer_req_keys = list(mer_mapped_dict.keys())
mer_req_cols = list(mer_mapped_dict.values())

fill_na = {'prev_date': 0,
'prev_term_location': 'NA',
'prev_term_city': 'NA',
'prev_term_state': 'NA',
'prev_term_cntry': 'NA',
'prev_postal_code': 'NA',
'prev_term_city_channelwise': 'NA',
'prev_term_state_channelwise': 'NA',
'prev_term_cntry_channelwise': 'NA'}

def_card_agg_json = curr_dir + conf["default_card_agg_json_path"]
def_card_json_val = json.loads(open(def_card_agg_json,"r").read())


def_mer_agg_json = curr_dir + conf["default_merchant_agg_json_path"]
def_mer_json_val = json.loads(open(def_mer_agg_json,"r").read())

def convert_timestamp(dat_val):
    try:
        dat_val = int(dat_val.timestamp())
        return dat_val
    except:
        return 0

def push_default_key():
    res = False
    try:
        def_card_agg_json = curr_dir + conf["default_card_agg_json_path"]
        card_json_str = open(def_card_agg_json,"r").read()
        
        def_mer_agg_json = curr_dir + conf["default_merchant_agg_json_path"]
        mer_json_str = open(def_mer_agg_json,"r").read()
        
        json_val = {"default":card_json_str,"default_merchant":mer_json_str}
        res = requests.post(ra_url,json=json_val,headers=headers,verify=False)
        res_json = res.json()
        print(" Default key is pushed to redis ",str(res_json['Status']))
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        print(exc_val)
    return res
    
def call_ra_url(json_data,start,end):
    res = None
    print("Came to ra url - start: "+str(start)+" end: "+str(end))
    try:
        headers = {"Content-Type":"application/json; charset=utf-8"}
        res = requests.post(ra_url,json=json_data,headers=headers,verify=False)
        print(res)
        res_json = res.json()
        print("Aggregates updated in redis for cards : start : "+ str(start)+" : end : ",str(end))
        print(res_json['Status'])
    except Exception as e:
        print(" Exception occured while calling RA url : "+str(e))
    return res

def create_json_conf(sub_df):

    json_conf = {}
    sd_tie_li = sub_df['SD_TIEBREAKER'].values.tolist()

    try:
        for each_tiebreaker in sd_tie_li:
            sd_tie = each_tiebreaker
            temp_df = sub_df[sub_df['SD_TIEBREAKER']==sd_tie].reset_index(drop=True)

            sd_pan = temp_df.iloc[0]['SD_PAN']

            mer_key = temp_df.iloc[0]['SD_TERM_ID']

            key = sd_pan

            temp_df_new = temp_df[req_keys]
            temp_df_new.columns = req_cols
            temp_df_new = temp_df_new.dropna(axis=1)

#             temp_df_new = temp_df_new.fillna(0.0)

            temp_df_new['M_L_30'] = temp_df.iloc[0]['SD_RETL_ID']
            temp_df_new['M_S_60'] = mer_key

            temp_df_new = temp_df_new.reset_index(drop=True)

            val = json.loads(temp_df_new.iloc[0].to_json())

            val_new = {}

            for each_key in def_card_json_val.keys():
                if each_key in val.keys():
                    val_new.update({each_key:val[each_key]})
                else:

                    agg_val = def_card_json_val[each_key]
                    val_new.update({each_key:agg_val})

            val_new = str(val_new) 
            val_new = val_new.replace("'",'"')
            mer_temp_df_new = temp_df[mer_req_keys]
            mer_temp_df_new.columns = mer_req_cols
            
            mer_temp_df_new = mer_temp_df_new.dropna(axis=1)
            
            mer_val = json.loads(mer_temp_df_new.iloc[0].to_json())
            
            
            mer_val_new = {}
            
            for each_key in def_mer_json_val.keys():
                if each_key in mer_val.keys():
                    mer_val_new.update({each_key:mer_val[each_key]})
                else:

                    agg_val = def_mer_json_val[each_key]
                    mer_val_new.update({each_key:agg_val})

            mer_val_new = str(mer_val_new) 
            mer_val_new = mer_val_new.replace("'",'"')
            json_conf.update({key:val_new})
            json_conf.update({mer_key:mer_val_new})

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        print(exc_val)
        pass

    return json_conf
    
    
def push_aggregates():
    
    res_li = []
    sc = None
    try:
        sdf = pd.read_parquet(conf["aggregate_path_loc"])
        
        if conf["all_cards_flag"] == "False":
            sdf = sdf.head(conf["keys_no"])
            
        sdf['prev_date'] = sdf['prev_date'].apply(lambda x: convert_timestamp(x))
        
#         sdf = sdf.fillna(fill_na)
#         sdf = sdf.fillna(0.0)

        df_count = len(sdf)
        print(df_count)
        
        start_time = time.perf_counter()
        
        subset_2 = range(0, len(sdf), 10000)

        df = sdf[:]
        print(df['SD_PAN'].head())
        
        temp_li = []
        
        

        for each_iter in range(len(subset_2)):

            start_2 = subset_2[each_iter]
            if each_iter == len(subset_2) - 1:
                end_2 = len(df)
            else:
                end_2 = subset_2[each_iter + 1]

            sub_df = df[start_2:end_2]
            sub_conf = create_json_conf(sub_df)
            
            print("Json config created for start : "+str(start_2)+" end: "+str(end_2))
            

            temp_li.append([sub_conf,start_2,end_2])

        
        print(temp_li)
        print(len(temp_li))
            
        pool = multiprocessing.Pool(conf["thread_count"])
        processes = [pool.apply_async(call_ra_url,args=(x[0],x[1],x[2],)) for x in temp_li]
        res_li = [p.get() for p in processes]
          
        
        finish_time = time.perf_counter()
        time_diff = finish_time-start_time
        
        print(" Aggregates to redis are pushed in seconds ",time_diff)
        

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        print(exc_val)
 
    if sc is not None:
        sc.stop()
    return res_li

if __name__ == '__main__':
    #res = push_default_key()
    res_li = push_aggregates()
    
