# encoding : utf-8
# Author : BVSS Ravikanth
# Last modified Date : 12-07-2022

import os
import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType
import json
import logging
from flask import Flask, jsonify
from SparkUtils.spark_utils import create_spark_context, read_table, delete_hdfs_file, \
    write_weekly_agg_intermediary_tables, exception_block
from DataBaseUtils.weekly_agg_pipeline_queries import read_derived_table_status
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

import warnings
warnings.filterwarnings("ignore")

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


def temp_blk_card(sd_fiid, sd_crd_stat, sd_card_bk_cde):
    ret_val = 0
    if (sd_fiid == 'HDFC') and (sd_crd_stat is not None):
        sd_crd_stat = sd_crd_stat.strip()
        if sd_crd_stat in ['3', 'A', 'C']:
            ret_val = 1

    if (sd_fiid == 'HDFB') and (sd_card_bk_cde is not None):
        sd_card_bk_cde = sd_card_bk_cde.strip()
        if sd_card_bk_cde not in ['0', 'P', 'B']:
            ret_val = 1

    return ret_val


def channel_type_val(channel):
    ret_val = 5
    if channel == "POS":
        ret_val = 1
    elif channel == "ATM":
        ret_val = 2
    elif channel == "CNP SECURED":
        ret_val = 3
    elif channel == "CNP UNSECURED":
        ret_val = 4

    return ret_val


def amount_bins_val(amt_bins):
    ret_val = 0
    if amt_bins == "0":
        ret_val = 1
    elif amt_bins == "0_1":
        ret_val = 2
    elif amt_bins == "1_500":
        ret_val = 3
    elif amt_bins == "501_2000":
        ret_val = 4
    elif amt_bins == "2001_5000":
        ret_val = 5
    elif amt_bins == "5001_10000":
        ret_val = 6
    elif amt_bins == "10001_20000":
        ret_val = 7
    elif amt_bins == "20001_30000":
        ret_val = 8
    elif amt_bins == "30001_50000":
        ret_val = 9
    elif amt_bins == "50001_100000":
        ret_val = 10
    elif amt_bins == "100001_500000":
        ret_val = 11
    elif amt_bins == "500001_1000000":
        ret_val = 12
    elif amt_bins == "gt10,00,000":
        ret_val = 13
    return ret_val


def hour_type_val(hour):
    ret_val = 4
    if hour == "earlyMrng":
        ret_val = 1
    elif hour == "busHrs":
        ret_val = 2
    elif hour == "close_midnight":
        ret_val = 3
    return ret_val


def age_val(age,user_dob):
    ret_val = 0
    
    if user_dob is None:
        ret_val = 0
    elif age == '19-25':
        ret_val = 1
    elif age == '26-28':
        ret_val = 2
    elif age == '29-33':
        ret_val = 3
    elif age == '34-39':
        ret_val = 4
    elif age == '40-45':
        ret_val = 5
    elif age == '46-60':
        ret_val = 6
    elif age == '61-65':
        ret_val = 7
    elif age == '66-70':
        ret_val = 8
    elif age == '71-75':
        ret_val = 9
    elif age == '76-79':
        ret_val = 10
    elif age == '80-84':
        ret_val = 11
    elif age == 'above85':
        ret_val = 12
    return ret_val


def auth_val(auth_src):
    ret_val = 2
    if auth_src == "B":
        ret_val = 0
    elif auth_src == "H":
        ret_val = 1
    return ret_val


def blk_cde_val(blk_cde):
    ret_val = 2
    if blk_cde == "CNB":
        ret_val = 0
    elif blk_cde == "NotApplicable":
        ret_val = 1
    return ret_val


age_udf = f.udf(lambda x,y: age_val(x,y), IntegerType())

amtbins_udf = f.udf(lambda x: amount_bins_val(x), IntegerType())

channel_udf = f.udf(lambda x: channel_type_val(x),
                    IntegerType())

mon_udf = f.udf(lambda x: 1 if x == 'M' else 0, IntegerType())

fiid_udf = f.udf(lambda x: 1 if x == 'HDFB' else 0, IntegerType())

auth_udf = f.udf(lambda x: auth_val(x), IntegerType())

trantyp_udf = f.udf(lambda x: 1 if x == 'ON_US' else 0, IntegerType())

cntrytyp_udf = f.udf(lambda x: 1 if x == 'Domestic' else 0, IntegerType())

hourtyp_udf = f.udf(lambda x: hour_type_val(x), IntegerType())

blkcde_udf = f.udf(lambda x: blk_cde_val(x), IntegerType())


# @app.route('/num_indexing', methods=["POST"])
def numerical_indexing():
    sc = None
    try:

        config_json_path = curr_dir + "/config/numerical_indexing.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        spark, sc = create_spark_context(conf, conf["appName"])

        conn_string = os.getenv("BLOCK_B_CONN")
        status_df, current_date, last_week_date, previous_date = read_derived_table_status(conn_string)

        temp_path = conf["temp_path"]
        req_cols = conf['req_cols']
        sel_cols = conf['sel_cols']

        tab_path_1 = status_df.loc[0]['OutputTablePath']

        ## reading monthly tables
        df1 = read_table(spark, tab_path_1)

        temp_blk_card_udf = f.udf(temp_blk_card, IntegerType())

        df3 = df1.select(req_cols)

        numind_temp_file = temp_path + 'numindtemp.parquet'

#         delete_hdfs_file(numind_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(numind_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(numind_temp_file)

        df3.write.parquet(numind_temp_file)

        df = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(numind_temp_file)

        df = df.cache()

        df = df.withColumn('channel_Index', channel_udf('ChannelType'))

        df = df.withColumn('tran_cde_numIndex', f.col('SD_TRAN_CDE').cast("integer"))

        df = df.withColumn('msg_typ_numIndex', f.col('SD_MSG_TYP').cast("integer"))

        df = df.withColumn('cond_cde_numIndex', f.col('SD_PT_SRV_COND_CDE').cast("integer"))

        df = df.withColumn('entry_mde_numIndex', f.col('SD_PT_SRV_ENTRY_MDE').cast("integer"))

        df = df.withColumn('pinind_Index', f.col('SD_PIN_IND').cast("integer"))

        df = df.withColumn('monetary_tran', mon_udf('sd_monetary'))

        df = df.withColumn('credit_card_flag', fiid_udf('SD_FIID'))

        df = df.withColumn('crd_stat_Index', f.col('SD_CRD_STAT').cast("integer"))

        df = df.withColumn('auth_src', auth_udf('SD_AUTH_SRC'))

        df = df.withColumn('acct_type_Index', f.col('SD_PRI_ACCT_TYP').cast("integer"))

        df = df.withColumn('amount_bins_Index', amtbins_udf('Amount_bins'))

        df = df.withColumn('on_us_tran_flag', trantyp_udf('tran_type'))

        df = df.withColumn('dom_tran_flag', cntrytyp_udf('CntryType'))

        df = df.withColumn('hour_type_Index', hourtyp_udf('hour_type'))

        df = df.withColumn('blkcde_Index', blkcde_udf('crd_blk_cde'))

        df = df.withColumn('age_bins_Index', age_udf('age_bins','DM_USER_DOB_um'))

        df = df.withColumn('hostpsot_country_flag_ind', f.col('hostpsot_country_flag').cast("integer"))

        df = df.withColumn('temp_blk_status', temp_blk_card_udf('SD_FIID', 'SD_CRD_STAT', 'SD_CRD_BLK_CDE'))
        df_final = df.select(sel_cols)

        final_root_path = conf["intermediary_path"]
        name_of_file = "NumInd_ATM_table_W"
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

#         delete_hdfs_file(numind_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(numind_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(numind_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e, app)

    if sc is not None:
        sc.stop()

    ins_status = insert_weekly_agg_pipeline_status("Numerical_indexing_api",resp["output_table_path"],resp["Error"][:250])
    return resp

class NumericalIndexApi(Resource):
    def post(self):
        resp = numerical_indexing()
        return jsonify(resp)
        

api.add_resource(NumericalIndexApi,'/', '/num_indexing')


if __name__ == '__main__':
    app.run("0.0.0.0", port="9008", debug=False)
