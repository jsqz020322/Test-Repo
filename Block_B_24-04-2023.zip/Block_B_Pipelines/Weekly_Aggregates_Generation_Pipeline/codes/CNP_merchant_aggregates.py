# Author Name : B Ravikanth
# Last update : 28-06-2022
# Import required libraries and packages


import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")

import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block, grouped_agg_days_temporal

from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))



def update_sd_term_id(sd_term_id):
    if not sd_term_id is None:
        if sd_term_id.strip()=="":
            return "others"
        else:
            return sd_term_id
    else:
        if sd_term_id=="":
            return "others"
        else:
            return sd_term_id
    

def cnp_merchant_agg():
    sc = None
    try:
        config_json_path = curr_dir + "/config/CNP_merchant_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        ddf3 = df3
        
        ddf3 = ddf3.filter(ddf3.ChannelType.isin(conf["channel"]))
        
        
        req_cols = conf['req_cols']

        ddf3 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'cnp_mertemp.parquet'
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        ### Write temp agg to hdfs
        app.logger.info("writing data to temporary parquet")
        ddf3.write.parquet(card_temp_file)
        

        ddf2 = spark.read.format('parquet')\
                .option("inferSchema","true")\
                .load(temp_path + 'cnp_mertemp.parquet')
        
        sd_term_id_udf = f.udf(update_sd_term_id,StringType())
        app.logger.info("updated sd_term_id_udf")
        
        ddf2 = ddf2.withColumn('SD_TERM_ID',sd_term_id_udf('SD_TERM_ID'))
        
        app.logger.info("updated completed sd_term_id_udf")
        ddf2_pdf = ddf2.repartition('SD_TERM_ID').to_pandas_on_spark()
        
        ddf2_pdf['DD_DATE_conv'] = ddf2_pdf['DD_DATE'].apply(lambda x:x.date())
        
        #### md_tran_amt aggregates###
        
        
        ddf2_pdf_mean_amt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv'])['MD_TRAN_AMT1'].mean().reset_index()
        ddf2_pdf_mean_amt.columns = ['SD_TERM_ID','DD_DATE_conv','MD_TRAN_AMT1_mean_day']
        ddf2_pdf_mean_amt = ddf2_pdf_mean_amt.sort_values(['SD_TERM_ID','DD_DATE_conv'],ascending=True).reset_index(drop=True)

        ###Mean Aggregates Columns
        mean_agg_30d = ddf2_pdf_mean_amt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['MD_TRAN_AMT1_mean_day'].rolling(30,min_periods=2).mean().reset_index()
        mean_agg_30d.columns = ['SD_TERM_ID','DD_DATE_conv','md_tran_amt1_M_mean_prev30days_merchant']
        ddf2_pdf_merge = ddf2_pdf.merge(mean_agg_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
        ddf2_pdf_min_amt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv'])['MD_TRAN_AMT1'].min().reset_index()
        ddf2_pdf_min_amt.columns = ['SD_TERM_ID','DD_DATE_conv','MD_TRAN_AMT1_min_day']
        ddf2_pdf_min_amt = ddf2_pdf_min_amt.sort_values(['SD_TERM_ID','DD_DATE_conv'],ascending=True).reset_index(drop=True)

        ###Mean Aggregates Columns
        min_agg_30d = ddf2_pdf_min_amt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['MD_TRAN_AMT1_min_day'].rolling(30,min_periods=2).min().reset_index()
        min_agg_30d.columns = ['SD_TERM_ID','DD_DATE_conv','md_tran_amt1_M_min_prev30days_merchant']
        ddf2_pdf_merge = ddf2_pdf_merge.merge(min_agg_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
        
        ddf2_pdf_max_amt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv'])['MD_TRAN_AMT1'].max().reset_index()
        ddf2_pdf_max_amt.columns = ['SD_TERM_ID','DD_DATE_conv','MD_TRAN_AMT1_min_day']
        ddf2_pdf_max_amt = ddf2_pdf_max_amt.sort_values(['SD_TERM_ID','DD_DATE_conv'],ascending=True).reset_index(drop=True)

        ###Mean Aggregates Columns
        max_agg_30d = ddf2_pdf_max_amt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['MD_TRAN_AMT1_min_day'].rolling(30,min_periods=2).max().reset_index()
        max_agg_30d.columns = ['SD_TERM_ID','DD_DATE_conv','md_tran_amt1_M_max_prev30days_merchant']
        ddf2_pdf_merge = ddf2_pdf_merge.merge(max_agg_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
        
        
        ##### Fraud Count #####
        ddf2_pdf_fraud_cnt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv'])['Fraud'].sum().reset_index()
        ddf2_pdf_fraud_cnt.columns = ['SD_TERM_ID','DD_DATE_conv','fraud_count_day']
        ddf2_pdf_fraud_cnt = ddf2_pdf_fraud_cnt.sort_values(['SD_TERM_ID','DD_DATE_conv'],ascending=True).reset_index(drop=True)

        # Fraud count 3 days
        fraud_cnt_3d = ddf2_pdf_fraud_cnt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['fraud_count_day'].rolling(3,min_periods=2).sum().reset_index()
        fraud_cnt_3d.columns = ['SD_TERM_ID','DD_DATE_conv','fraud_count_at_merchant_prev3days']
        
        # Fraud count 7 days
        fraud_cnt_7d = ddf2_pdf_fraud_cnt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['fraud_count_day'].rolling(7,min_periods=2).sum().reset_index()
        fraud_cnt_7d.columns = ['SD_TERM_ID','DD_DATE_conv','fraud_count_at_merchant_prev7days']

        # Fraud count 30 days
        fraud_cnt_30d = ddf2_pdf_fraud_cnt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['fraud_count_day'].rolling(30,min_periods=2).sum().reset_index()
        fraud_cnt_30d.columns = ['SD_TERM_ID','DD_DATE_conv','fraud_count_at_merchant_prev30days']


        ddf2_pdf_merge = ddf2_pdf_merge.merge(fraud_cnt_3d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(fraud_cnt_7d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(fraud_cnt_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')

        
        ##### Transaction Count####
        
        
        ddf2_pdf_tran_cnt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv'])['SD_TIEBREAKER'].count().reset_index()
        ddf2_pdf_tran_cnt.columns = ['SD_TERM_ID','DD_DATE_conv','transaction_count_day']
        # ddf2_pdf_tran_cnt = ddf2_pdf_tran_cnt.sort_values(['SD_TERM_ID','DD_DATE_conv'],ascending=True).reset_index(drop=True)

        # Transaction count 1 days
        tran_cnt_1d = ddf2_pdf_tran_cnt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['transaction_count_day'].rolling(1,min_periods=1).sum().reset_index()
        tran_cnt_1d.columns = ['SD_TERM_ID','DD_DATE_conv','transaction_count_prev1days_merchant']

        # Fraud count 30 days
        tran_cnt_7d = ddf2_pdf_tran_cnt.set_index('DD_DATE_conv').groupby("SD_TERM_ID")['transaction_count_day'].rolling(7,min_periods=1).sum().reset_index()
        tran_cnt_7d.columns = ['SD_TERM_ID','DD_DATE_conv','transaction_count_prev7days_merchant']


        ddf2_pdf_merge = ddf2_pdf_merge.merge(tran_cnt_1d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(tran_cnt_7d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
        
        
        ##### Hour Type aggregates 
        
        ddf2_pdf_hourtype_cnt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv','hour_type'])['SD_TIEBREAKER'].count().reset_index()
        ddf2_pdf_hourtype_cnt.columns = ['SD_TERM_ID','DD_DATE_conv','hour_type','hour_type_count_day']
        
        
        
       # Bus Hrs count 30 days
        bushr_cnt_30d = ddf2_pdf_hourtype_cnt[ddf2_pdf_hourtype_cnt['hour_type']=="busHrs"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['hour_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        bushr_cnt_30d.columns = ['SD_TERM_ID','DD_DATE_conv','hour_type_bushrs_count_merchant_prev30days']


        # Bus Hrs count 30 days
        midngt_cnt_30d = ddf2_pdf_hourtype_cnt[ddf2_pdf_hourtype_cnt['hour_type']=="close_midnight"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['hour_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        midngt_cnt_30d.columns = ['SD_TERM_ID','DD_DATE_conv','hour_type_close_midnight_count_merchant_prev30days']


        # Bus Hrs count 30 days
        mrng_cnt_30d = ddf2_pdf_hourtype_cnt[ddf2_pdf_hourtype_cnt['hour_type']=="earlyMrng"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['hour_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        mrng_cnt_30d.columns = ['SD_TERM_ID','DD_DATE_conv','hour_type_earlymrng_count_merchant_prev30days']


        # Bus Hrs count 30 days
        latenight_cnt_30d = ddf2_pdf_hourtype_cnt[ddf2_pdf_hourtype_cnt['hour_type']=="lateNight"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['hour_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        latenight_cnt_30d.columns = ['SD_TERM_ID','DD_DATE_conv','hour_type_latenight_count_merchant_prev30days']


        ddf2_pdf_merge = ddf2_pdf_merge.merge(bushr_cnt_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(midngt_cnt_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(mrng_cnt_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(latenight_cnt_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
       
        
        
        ####### Tran_Type_Aggregates#####
        
        ddf2_pdf_tran_type_cnt = ddf2_pdf.groupby(['SD_TERM_ID','DD_DATE_conv','tran_type'])['SD_TIEBREAKER'].count().reset_index()
        ddf2_pdf_tran_type_cnt.columns = ['SD_TERM_ID','DD_DATE_conv','tran_type','tran_type_count_day']
        
        # Bus Hrs count 30 days
        onus_30d = ddf2_pdf_tran_type_cnt[ddf2_pdf_tran_type_cnt['tran_type']=="ON-US"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['tran_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        onus_30d.columns = ['SD_TERM_ID','DD_DATE_conv','tran_type_on_us_count_merchant_prev30days']

        # Bus Hrs count 30 days
        remote_onus_30d = ddf2_pdf_tran_type_cnt[ddf2_pdf_tran_type_cnt['tran_type']=="REMOTE ON-US"].set_index('DD_DATE_conv').groupby("SD_TERM_ID")['tran_type_count_day'].rolling(30,min_periods=1).sum().reset_index()
        remote_onus_30d.columns = ['SD_TERM_ID','DD_DATE_conv','tran_type_remote_on_us_count_merchant_prev30days']

        ddf2_pdf_merge = ddf2_pdf_merge.merge(onus_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        ddf2_pdf_merge = ddf2_pdf_merge.merge(remote_onus_30d,on=['SD_TERM_ID','DD_DATE_conv'],how='left')
        
        
        agg_cols = ddf2_pdf_merge.columns
        agg_cols = [c for c in agg_cols if c not in req_cols] + ['SD_TERM_ID','SD_TIEBREAKER']
        
        app.logger.info("Aggregates : ")
        
        app.logger.info(agg_cols)
        
        ##### Convert pandas into spark ######
        df_spark = ddf2_pdf_merge[agg_cols].to_spark()
        
        df_final = get_relavant_date_range_df(df_spark,'DD_DATE_conv',strtdate,enddate)
        
        #### Missing value handling #####
        
        missing_value_col = {}
        for col in df_final.columns:
            if col not in ("DD_DATE_conv", "SD_TIEBREAKER", "SD_TERM_ID"):
                missing_value_col[col] = 0
                
        df_final = df_final.fillna(missing_value_col)
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])
        
        ###### Final File writing ######
        
        name_of_file = "Cnp_Merchant_table_W"
        
        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)
        

        card_temp_file = temp_path + 'cnp_mertemp.parquet'
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)


        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
    
    ins_status = insert_weekly_agg_pipeline_status("CNP_merchant_agg_creation",resp["output_table_path"],resp["Error"][:250])
      
    return resp


class CNPMerAggregatesApi(Resource):
    def post(self):
        resp = cnp_merchant_agg()
        return jsonify(resp)

api.add_resource(CNPMerAggregatesApi,'/', '/cnp_mer_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9017", debug=False)