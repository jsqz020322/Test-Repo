# encoding : utf-8 
# Author : BVSS Ravikanth
# Last modified Date : 12-07-2022

import pandas.io.sql as psql
import pyspark.sql.functions as f
from pyspark.sql.window import Window
from pyspark.sql.types import StringType
import json
import os
import sys
import datetime
from datetime import timedelta
from SparkUtils.spark_utils import create_spark_context, delete_hdfs_file, write_weekly_agg_intermediary_tables, exception_block
from DataBaseUtils.db_utils import mysql_conn
import logging
from flask import Flask, jsonify
import warnings
warnings.filterwarnings('ignore')
from All_Tables_Join import read_tables
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

date_format = "%Y-%m-%d"

def create_card_no(sd_fiid,sd_uan,aan,action_level_key):
    card_no = "NA"
    if sd_fiid.strip() == "HDFB":
        card_no = aan.strip()
    else:
        card_no = sd_uan.strip()+action_level_key.strip()[-4:]
    return card_no

card_no_udf = f.udf(create_card_no,StringType())

def load_init_config(config_json_path, app):
    conf = json.load(open(config_json_path, "r"))
    app.logger.info(conf)

    spark, sc = create_spark_context(conf, conf["appName"])
    sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
    app.logger.info(sql_conn)

    current_date = datetime.datetime.now()
    current_date = current_date.strftime(date_format)
    previous_week_date = datetime.datetime.now() - timedelta(days=8)
    previous_week_date = previous_week_date.strftime(date_format)

    previous_date = datetime.datetime.now() - timedelta(days=2)
    previous_date = previous_date.strftime(date_format)

    return spark, sc, sql_conn, current_date, previous_week_date, previous_date, conf


# @app.route('/act_block_status', methods=["POST"])
def create_act_blk_status():
    sc = None
    try:
        config_json_path = curr_dir + "/config/Act_block_status.json"

        spark, sc, sql_conn, current_date, previous_week_date, previous_date , conf = load_init_config(config_json_path, app)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        spark.sql("set spark.sql.parquet.int96RebaseModeInWrite=CORRECTED")
        
#         strtdate = conf["start_date"]
#         enddate = conf["end_date"]

#         query1 = """SELECT * from data_ingestion_status where CreatedTime >=""" + "'" + previous_week_date + "'" + " and Status=1"
#         data_ingestion_df = psql.read_sql_query(query1, sql_conn)
#         app.logger.info(data_ingestion_df['FileName'])
        
#         act_df = data_ingestion_df[data_ingestion_df['FileName'] == "prm_act"]
#         act_df = act_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        
#         act_path = act_df.loc[0][
#             'SavePathLocation']
#         act_root_path = "/".join(act_path.split("/")[:-1]) + "/*"

        query1 = """SELECT * from sqoop_dataingestion_logs_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1"
        sqoop_data_ingestion_df = psql.read_sql_query(query1, sql_conn)
        sqoop_data_ingestion_df = sqoop_data_ingestion_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        
        act_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="act"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(act_path_loc)
        
        t_paths = [['act',act_path_loc,'DTACTDATEKEY']]
        s_path = curr_dir + conf['selected_cols_json_path']
        sel_cols= json.load(open(s_path,"r"))
        
        dtype= json.load(open(curr_dir+conf["dtypes_file_path"],"r"))
        
        source_tab_cols = json.load(open(curr_dir+conf["source_table_cols_path"],"r"))
        
        tables_li = read_tables(spark,t_paths,dtype,source_tab_cols)
        act = tables_li[0]


        query2 = """SELECT * from weekly_aggregates_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1  and TaskName='Derived_tables_creation'"
        status_df = psql.read_sql_query(query2, sql_conn)
        status_df = status_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        app.logger.info(status_df.loc[0])

        month_last_date = current_date
        dt = datetime.datetime.strptime(month_last_date, date_format)
        req_month_num = [dt.month - 1, dt.month]
        blk_code_list = conf["blk_code_list"]
        BLK_CDE = conf["BLK_CDE"]

#         act = spark.read.format('parquet') \
#             .option("inferSchema", "true") \
#             .load(act_root_path)
        
#         act = act.withColumn("SM_PAN",card_no_udf("SD_FIID","SD_UAN","AAN","ACTION_LEVEL_KEY"))

        act = act.withColumn("SM_PAN",f.col("ACTION_LEVEL_KEY"))

        app.logger.info("Act table read")
        act = act.filter(f.col("ACTION_LEVEL_ID") == 1)

        app.logger.info("Act table filtered with action level id 1")
        app.logger.info(act.count())

        act = act.withColumn("TDDATEKEY1", f.to_timestamp("TDDATEKEY", "yyyyMMdd HH:mm:ss.SSS"))
        # Month Filter
        act = act.filter(f.month("TDDATEKEY1").isin(req_month_num))
        act = act.filter(f.col("SACTACTION").isin(blk_code_list))
        app.logger.info("SACTION filtered")
        app.logger.info(act.count())
        act_sub = act.select(["ACTION_LEVEL_KEY", "TDDATEKEY1", "SACTACTION","SM_PAN"])

        window = Window.partitionBy("ACTION_LEVEL_KEY").orderBy("TDDATEKEY1")
        act_sub = act_sub.withColumn("next_date", f.lead(act_sub.TDDATEKEY1).over(window))
        act_sub = act_sub.filter(f.col("SACTACTION") == BLK_CDE)
        act_sub = act_sub.fillna({"next_date": month_last_date})

        monthly_file_path = status_df.loc[0]['OutputTablePath']
        details = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(monthly_file_path)

        app.logger.info("Detail table read")

        temp_path = conf["temp_path"]
        
        filepath = temp_path + "detail_temp.parquet"

#         delete_hdfs_file(temp_path + "detail_temp.parquet")
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(filepath,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(filepath)

        details.select(["SD_TIEBREAKER", "SD_PAN", "DD_DATE"]).write.parquet(temp_path + "detail_temp.parquet")
        details_df = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(temp_path + 'detail_temp.parquet')

        det_act_join = details_df.join(act_sub, ((details_df.SD_PAN == act_sub.SM_PAN) &
                    (details_df.DD_DATE > act_sub.TDDATEKEY1) & (details_df.DD_DATE <= act_sub.next_date)), how="left")
        det_act_join = det_act_join.fillna({"SACTACTION": 0})
        det_act_join = det_act_join.withColumn("act_blk_st", (f.col("SACTACTION") / BLK_CDE).cast("int"))
        df_final = det_act_join.select(["SD_TIEBREAKER", "act_blk_st"])
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        app.logger.info("Act blk status created")
        app.logger.info(det_act_join.count())

        final_root_path = conf["intermediary_path"]
        name_of_file = "ACT_block_status_table_W"
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as ex:
        resp = exception_block(ex,app)

    if sc is not None:
        sc.stop()
        
    ins_status = insert_weekly_agg_pipeline_status("Act_block_status_creation",resp["output_table_path"],resp["Error"][:250])
    return resp


class ActBlockStatusApi(Resource):
    def post(self):
        resp = create_act_blk_status()
        return jsonify(resp)
        

api.add_resource(ActBlockStatusApi,'/', '/act_block_status')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9007", debug=False)
