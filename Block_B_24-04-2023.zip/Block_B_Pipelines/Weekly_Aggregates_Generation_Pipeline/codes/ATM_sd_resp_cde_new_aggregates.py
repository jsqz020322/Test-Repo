# Author Name : B Ravikanth
# Last update : 28-06-2022

import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")
import pyspark.sql.functions as f
from pyspark.sql.types import StringType
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, \
    write_weekly_agg_intermediary_tables, exception_block
from SparkUtils.card_agg_utils import add_aggregates_n_days
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


def sd_resp_code_type(channel,sd_resp_cde):
    sd_resp_cde = int(sd_resp_cde)
    ret_val = "otherDeclines"
    if sd_resp_cde == 50:
        if channel=="ATM":
            ret_val = "Restricted_Card"
        if channel=="POS":
            ret_val = "Host_Decline"
    elif sd_resp_cde == 51:
        ret_val = "Expired_Card"
    elif sd_resp_cde == 52:
        ret_val = "Invalid_Card_Number"
    elif sd_resp_cde == 53:
        ret_val = "Invalid_PIN"
    elif sd_resp_cde == 54:
        ret_val = "System_Issue"
    elif sd_resp_cde == 55:
        ret_val = "Invalid_Transaction"
    elif sd_resp_cde == 56:
        ret_val = "Transaction_Not_Permitted_to_Cardholder"
    elif sd_resp_cde == 57:
        ret_val = "Transaction_Not_Supported"
    elif sd_resp_cde == 58:
        if channel=="ATM":
            ret_val = "Not_Sufficient_Funds"
        if channel=="POS":
            ret_val = "Invalid_Card_Number"
    elif sd_resp_cde == 59:
        ret_val = "Not_Sufficient_Funds"
    elif sd_resp_cde == 61:
        if channel=="ATM":
            ret_val = "Exceeds_Withdrawal_amount_limit"
        if channel=="POS":
            ret_val = "No_PBF"
    elif sd_resp_cde == 63:
        ret_val = "Exceeds_Withdrawal_amount_limit"
    elif sd_resp_cde == 64:
        ret_val = "Bad_Track_Data"
    elif sd_resp_cde == 67:
        ret_val = "Invalid_transaction_date"
    elif sd_resp_cde == 68:
        ret_val = "External_Decline"
    elif sd_resp_cde == 70:
        ret_val = "System_Issue"
    elif sd_resp_cde == 72:
        ret_val = "Issuer_or_Switch_is_inoperative"
    elif sd_resp_cde == 74:
        if channel=="ATM":
            ret_val = "Format_Error"
        if channel=="POS":
            ret_val = "Unable_to_authorize"
    elif sd_resp_cde == 76:
        ret_val = "Not_Sufficient_Funds"
    elif sd_resp_cde == 77:
        ret_val = "INTL_Limit_Exceeded"
    elif sd_resp_cde == 78:
        if channel=="ATM":
            ret_val = "Invalid_Country_code"
        if channel=="POS":
            ret_val = "Duplicate_Transaction"
    elif sd_resp_cde == 87:
        ret_val = "TVR_Decline"
    elif sd_resp_cde == 88:
        ret_val = "PRM_Decline"
    elif sd_resp_cde == 89:
        ret_val = "CAF_Status_0_or_9"
    elif sd_resp_cde == 97:
        ret_val = "Mod_10_Check"
    elif sd_resp_cde == 100:
        ret_val = "Unable_to_process_transaction"
    elif sd_resp_cde == 105:
        ret_val = "Card_not_supported"
    elif sd_resp_cde == 150:
        ret_val = "Restricted_Card"
    elif sd_resp_cde == 151:
        ret_val = "Expired_Card"
    elif sd_resp_cde == 162:
        ret_val = "PIN_Tries_Exceeded"
    elif sd_resp_cde == 168:
        ret_val = "External_Decline"
    elif sd_resp_cde == 201:
        ret_val = "Invalid_PIN"
    elif sd_resp_cde == 204:
        ret_val = "Enter_Lesser_Amount"
    elif sd_resp_cde == 206:
        ret_val = "CAF_not_found"
    elif sd_resp_cde == 213:
        ret_val = "Merchant_PIN_Bypass"
    elif sd_resp_cde == 216:
        ret_val = "INTL_Limit_Exceeded"
    elif sd_resp_cde == 217:
        ret_val = "INTL_Flag_not_Enabled"
    elif sd_resp_cde == 218:
        ret_val = "PRM_Decline"
    elif sd_resp_cde == 400:
        ret_val = "REQ_CRYPTOGRAM_FAILURE"
    elif sd_resp_cde == 401:
        ret_val = "HSM_Param_Error"
    elif sd_resp_cde == 900:
        ret_val = "PIN_Tries_Exceeded"
    elif sd_resp_cde == 901:
        ret_val = "Expired_Card"
    elif sd_resp_cde == 903:
        ret_val = "Stolen_Card_or_pickup"
    elif sd_resp_cde == 909:
        ret_val = "Capture"
    elif sd_resp_cde in range(0,10):
        ret_val = 'Approved'
    return ret_val

    agg_list = []



agg_list_sd_resp_cde = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',['INTL_Flag_not_Enabled',
'Invalid_Card_Number',
'System_Issue',
'TVR_Decline',
],'N','integer']]

agg_list_sd_resp_cde1 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'otherDeclines',
'Format_Error',
'Capture',
'Invalid_PIN',],'N','integer']]

agg_list_sd_resp_cde2 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'Invalid_Country_code',
'PRM_Decline',
'CAF_not_found',
'Invalid_Transaction'],'N','integer']]

agg_list_sd_resp_cde3 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'Not_Sufficient_Funds',
'Transaction_Not_Permitted_to_Cardholder',
'PIN_Tries_Exceeded',
'Exceeds_Withdrawal_amount_limit'],'N','integer']]

agg_list_sd_resp_cde4 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'Restricted_Card',
'External_Decline',
'Issuer_or_Switch_is_inoperative',
'Expired_Card'] ,'N','integer']]

agg_list_sd_resp_cde5 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'Bad_Track_Data',
'Transaction_Not_Supported',
'INTL_Limit_Exceeded',
'Stolen_Card_or_pickup'] ,'N','integer']]

agg_list_sd_resp_cde6 = [['sd_resp_cde_type_new',f.sum,"count",'All','sd_resp_cde_type_new',[
'REQ_CRYPTOGRAM_FAILURE',
'Enter_Lesser_Amount',
'Merchant_PIN_Bypass',
'Unable_to_process_transaction',
'Invalid_transaction_date'] ,'N','integer']]

## aggregates to be calculated


def sd_resp_cde_agg(app, spark, temp_path, card_temp_file,conf, strtdate, enddate):
    agg_df, df_list = None, None
    try:
        agg_list = [agg_list_sd_resp_cde,agg_list_sd_resp_cde1,agg_list_sd_resp_cde2,agg_list_sd_resp_cde3,
                   agg_list_sd_resp_cde4,agg_list_sd_resp_cde5,agg_list_sd_resp_cde6]
        
        final_path = temp_path + 'atm_sd_resp_cardtemp_'

        agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    return agg_df, df_list


def sd_resp_cde_card_agg():
    sc = None
    try:
        config_json_path = curr_dir + "/config/atm_sdresp_card_day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)

        ddf2 = df3
        
        sd_resp_code_type_udf = f.udf(sd_resp_code_type,StringType())
        
        ddf2 = ddf2.withColumn('sd_resp_cde_type_new',sd_resp_code_type_udf(f.col('ChannelType'),f.col('SD_RESP_CDE')))

        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])

        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType==conf["channel"])
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp','sd_resp_cde_type_new']

        ddf2 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'atm_sd_resp_cardtemp.parquet'

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        ### Write temp agg to hdfs
        app.logger.info("writing data to temporary parquet")
        ddf2.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None

        df, df_list = sd_resp_cde_agg(app, spark, temp_path,card_temp_file, conf, strtdate, enddate)
        name_of_file = "SD_Resp_Cde_Card30day_ATM_table_W"


        ## saving the final parquet

        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)
        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()        
       
    ins_status = insert_weekly_agg_pipeline_status("SD_Resp_Cde_ATM_Card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    
    return resp


class SdRespCdeCardAggregatesApi(Resource):
    def post(self):
        resp = sd_resp_cde_card_agg()
        return jsonify(resp)

api.add_resource(SdRespCdeCardAggregatesApi,'/', '/atm_sd_resp_cde_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9015", debug=False)