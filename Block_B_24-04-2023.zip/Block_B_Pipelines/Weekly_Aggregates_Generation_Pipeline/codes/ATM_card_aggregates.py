# Author Name : B Ravikanth
# Last update : 28-06-2022

import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")
import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, \
    write_weekly_agg_intermediary_tables, exception_block
from SparkUtils.card_agg_utils import add_aggregates_n_days
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


agg_list_Amtbins_ch_1 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins',
                        ["0","0_1","1_500", "501_2000", "2001_5000"], 'Y', 'integer']]

agg_list_Amtbins_ch_2 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins',
                        ["5001_10000","10001_20000", "20001_30000","30001_50000", "50001_100000"], 'Y', 'integer']]

agg_list_sd_resp_cde_ch_1 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type',
                            ["PRM_Declined", "InvalidData", "ExpiredCard", "RestrictedCard","WithdrawalLimitExceeded"], 'Y', 'integer']]

agg_list_sd_resp_cde_ch_2 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type',
                            [ "Pickup_Capture", "InsuffFunds", "IntlLimitExceeded_NA",
                             "Block_Decline_H", "OtherDeclines"], 'Y', 'integer']]

agg_list_cntry_tran_ch = [
    ['CntryType', f.sum, "count", 'All', 'CntryType', ['Domestic', 'International'], 'Y', 'integer']]

agg_list_trancde_ch = [
    ['tran_cde_type', f.sum, "count", 'All', 'tran_cde_type',['BalInquiry', 'PinChange', 'PinInquiry'], 'Y', 'integer']]

agg_list_hrtype_ch = [
    ['hour_type', f.sum, "count", 'All', 'hour_type', ['busHrs', 'close_midnight', 'lateNight', 'earlyMrng'], 'Y',
     'integer']]

agg_list_metro_flag_ch = [['metro_city', f.sum, "count", 'All', 'metro_city', ['Metro_city'], 'Y', 'integer']]


## aggregates to be calculated


def card_aggregates_3days(app, spark, temp_path, card_temp_file,conf, strtdate, enddate):
    agg_df, df_list = None, None
    try:
        agg_list = [agg_list_Amtbins_ch_1, agg_list_Amtbins_ch_2, agg_list_sd_resp_cde_ch_1, 
                    agg_list_sd_resp_cde_ch_2,agg_list_cntry_tran_ch, agg_list_trancde_ch,
                    agg_list_hrtype_ch, agg_list_metro_flag_ch]

        
        final_path = temp_path + 'atm_card_3d_temp_'

        agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 3)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    return agg_df, df_list


def card_aggregates_30days(app, spark, temp_path, card_temp_file,conf, strtdate, enddate):

    agg_list = [agg_list_Amtbins_ch_1, agg_list_Amtbins_ch_2, agg_list_sd_resp_cde_ch_1, 
                    agg_list_sd_resp_cde_ch_2,agg_list_cntry_tran_ch, agg_list_trancde_ch,
                    agg_list_hrtype_ch, agg_list_metro_flag_ch]
    
    final_path = temp_path + 'atm_card_30d_temp_'

    agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    return agg_df, df_list


def atm_card_agg():
    apiconf = json.loads(request.data)
    flag_val = apiconf["flag_val"]
    sc = None
    try:
        config_json_path = curr_dir + "/config/atm_card_day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)

        ddf2 = df3

        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])

        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType==conf["channel"])
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp']

        ddf2 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'atm_cardtemp.parquet'

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        ### Write temp agg to hdfs
        app.logger.info("writing data to temporary parquet")
        ddf2.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None

        if flag_val == "3days":
            df, df_list = card_aggregates_3days(app, spark, temp_path,card_temp_file, conf, strtdate, enddate)
            name_of_file = "Card3day_ATM_table_W"

        if flag_val == "30days":
            df, df_list = card_aggregates_30days(app, spark, temp_path,card_temp_file, conf, strtdate, enddate)
            name_of_file = "Card30day_ATM_table_W"

        ## saving the final parquet

        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()        
       
    if flag_val == "3days":
        ins_status = insert_weekly_agg_pipeline_status("ATM_Card_3day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("ATM_Card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    
    return resp


class CardAggregatesApi(Resource):
    def post(self):
        resp = atm_card_agg()
        return jsonify(resp)

api.add_resource(CardAggregatesApi,'/', '/atm_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9012", debug=False)