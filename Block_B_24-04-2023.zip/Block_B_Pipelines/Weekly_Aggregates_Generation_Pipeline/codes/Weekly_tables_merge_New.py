# encoding : utf-8 
# Author : B Ravikanth
# Last modified Date : 13-07-2022

import warnings

## Create SparkContext , Spark Session
import pyspark.sql.functions as f

warnings.filterwarnings("ignore")

from Act_block_status import load_init_config
import os
import sys
from SparkUtils.spark_utils import delete_hdfs_file, write_weekly_agg_intermediary_tables
import logging
from flask import Flask, jsonify
import pandas.io.sql as psql
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from pyspark.sql.functions import broadcast
from pyspark.sql.types import IntegerType, StringType, DoubleType

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

def fc_bin(x):
    val = 0 
    try:
        if int(x)>5:
            val = 1
    except:
        val = 0
    return val

fc_bin_udf = udf(lambda x:fc_bin(x),IntegerType())

def weekly_tables():
    sc = None
    sql_conn = None
    try:

        config_json_path = curr_dir + "/config/weekly_aggregates_merge.json"

        spark, sc, sql_conn, current_date, previous_week_date, previous_date, conf = load_init_config(config_json_path,
                                                                                                      app)
        
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        query1 = """SELECT * from weekly_aggregates_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1  and TaskName='Derived_tables_creation'"
        status_df = psql.read_sql_query(query1, sql_conn)
        status_df = status_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        app.logger.info(status_df.loc[0])

        tab_path_1 = status_df.loc[0]['OutputTablePath']

        query2 = """SELECT * from weekly_aggregates_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1"
        agg_status_df = psql.read_sql_query(query2, sql_conn)

        temp_path = conf["temp_path"]

        agg_tb = conf['agg_tables_names']
        raw_cols = conf["raw_table_cols"]

        df = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(tab_path_1)

        df_sub = df.select(raw_cols)
        
        temp_merge_file = temp_path + 'weekly_mergetemp.parquet'

#             delete_hdfs_file(temp_merge_file)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(temp_merge_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(temp_merge_file)

        df_sub.write.parquet(temp_merge_file)

        df_sub = spark.read.format('parquet').option("inferSchema", "true").load(
                temp_merge_file)

        df_list = []

        for each_task in agg_tb:
            app.logger.info(each_task)
            joindf = df_sub

            tmp_status_df = agg_status_df[agg_status_df["TaskName"] == each_task]
            app.logger.info(tmp_status_df)
            tmp_status_df = tmp_status_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
            app.logger.info(tmp_status_df.loc[0])

            tempdf = spark.read.format('parquet') \
                .option("inferSchema", "true") \
                .load(tmp_status_df.loc[0]['OutputTablePath'])
            
            if each_task in ["All_channel_card_30day_agg_creation","All_channel_card_3day_agg_creation",
                            "POS_Card_30day_agg_creation","POS_Card_3day_agg_creation",
                            "ATM_Card_30day_agg_creation","ATM_Card_3day_agg_creation",
                            "SD_Resp_Cde_ATM_Card_30day_agg_creation","CNP_Additional_agg_table",
                            "CNP_Secured_Card_3day_agg_creation","CNP_Secured_Card_30day_agg_creation",
                             "CNP_UNSecured_Card_3day_agg_creation","CNP_UNSecured_Card_30day_agg_creation"]:
                
                othercols = [c for c in tempdf.columns if c not in ['SD_PAN','DD_DATE_conv'] and c not in joindf.columns]
                selcols = [f.col('SD_PAN').alias('SD_PAN_B'),f.col('DD_DATE_conv').alias('DD_DATE_conv_B')] + othercols

                tempdf2 = tempdf.select(selcols)
                df_sub = joindf.join(tempdf2, (joindf.SD_PAN == tempdf2.SD_PAN_B) & (joindf.DD_DATE_conv == tempdf2.DD_DATE_conv_B), 'left')
                df_sub = df_sub.drop(*['SD_PAN_B','DD_DATE_conv_B'])
                df_sub = df_sub.dropDuplicates(["SD_TIEBREAKER"])
                
            else:

                othercols = [c for c in tempdf.columns if c not in ['SD_TIEBREAKER'] and c not in joindf.columns]
                selcols = [f.col('SD_TIEBREAKER').alias('SD_TIEBREAKER_B')] + othercols

                tempdf2 = tempdf.select(selcols)
                df_sub = joindf.join(tempdf2, joindf.SD_TIEBREAKER == tempdf2.SD_TIEBREAKER_B, 'left')
                df_sub = df_sub.drop(*['SD_TIEBREAKER_B'])
                df_sub = df_sub.dropDuplicates(["SD_TIEBREAKER"])

            del tempdf, tempdf2

            temp_merge_file = temp_path + each_task + '_mergetemp.parquet'

#             delete_hdfs_file(temp_merge_file)
            
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(temp_merge_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(temp_merge_file)

            df_sub.write.parquet(temp_merge_file)

            df_sub = spark.read.format('parquet').option("inferSchema", "true").load(
                temp_merge_file)

            df_list.append(temp_merge_file)
            app.logger.info("Merging with {} has completed:".format(each_task))

        df_sub = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(df_list[-1])
        
        df_sub = df_sub.dropDuplicates(["SD_TIEBREAKER"])
        
        df_sub = df_sub.withColumn('fraud_count_prev7days_merchant',fc_bin_udf('fraud_count_at_merchant_prev7days'))

        app.logger.info(" Weekly aggregates are merged")

        final_root_path = conf["intermediary_path"]
        name_of_file = "Weekly_aggregates_table_W"
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_sub)

        for i in df_list:
            
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        resp = {"status": 400, "Error": str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e),
                "output_table_path": "NA"}
    if sc is not None:
        sc.stop()
    if sql_conn is not None:
        sql_conn.close()
        
    ins_status = insert_weekly_agg_pipeline_status("weekly_aggregates_merge_api",resp["output_table_path"],resp["Error"][:250])
    return resp

class WeeklyTablesApi(Resource):
    def post(self):
        resp = weekly_tables()
        return jsonify(resp)
        
api.add_resource(WeeklyTablesApi,'/', '/weekly_agg_merge')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9010", debug=False)
