# Author Name : B Ravikanth
# Last update : 28-06-2022
# Import required libraries and packages


import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")

import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block, grouped_agg_days_temporal
from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


    

def mcc_type(SD_RETL_SIC_CDE,mcc_li):
    try:
        if SD_RETL_SIC_CDE.strip() in mcc_li:
            return SD_RETL_SIC_CDE
        else:
            return "Others"
    except:
        return "NA"


def stnl(SD_TERM_NAME_LOC, stnl_dict):
    try:

        res = "Others"
        for key in stnl_dict.keys():
            val = stnl_dict[key]
            if type(val)==str:
                val = [val]
            #print(k,v)
            for each_v in val:
                if each_v.lower() in SD_TERM_NAME_LOC.strip().lower():
                    res = key
                    break
            if res!="Others":
                break

        return res
    except:
        return "NA"

# List of 30 Day Aggregates

agg_list_amt_30D = [
                        ['MD_TRAN_AMT1',f.mean,"mean",'M','NA','NA','Y','double'],
                        ['MD_TRAN_AMT1',f.max,"max",'M','NA','NA','Y','double'],
                        ['MD_TRAN_AMT1',f.min,"min",'M','NA','NA','Y','double']
               ]

agg_list_amt_split1_30D=[['Amount_bins',f.sum,"count",'M','Amount_bins',["501_2000","2001_5000","5001_10000"],'Y','integer']]
agg_list_amt_split2_30D=[['Amount_bins',f.sum,"count",'M','Amount_bins',["10001_20000","20001_30000","30001_50000","50001_100000"],'Y','integer']]



agg_list_sd_resp_cde_ch_split1_30D=[['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type',
                                 ["PRM_Declined","InvalidData","ExpiredCard","RestrictedCard"],'Y','integer']]
        
agg_list_sd_resp_cde_ch_split2_30D=[['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', 
                                 ["WithdrawalLimitExceeded","Pickup_Capture","InsuffFunds"],'Y','integer']]
agg_list_sd_resp_cde_ch_split3_30D=[['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', 
                                 ["IntlLimitExceeded_NA","Block_Decline_H","OtherDeclines"],'Y','integer']]



agg_list_cntry_tran_30D = [['CntryType',f.sum,"count",'All','CntryType',['Domestic','International'],'Y','integer']]

agg_list_trancde_30D = [['tran_cde_type',f.sum,"count",'All','tran_cde_type',['Purchase'],'Y','integer']]

agg_list_hrtype_30D = [['hour_type',f.sum,"count",'All','hour_type',['busHrs','close_midnight','lateNight','earlyMrng'],'Y','integer']]

agg_list_mcc_split1_30D = [['mcc',f.sum,"count",'All','mcc',["5399","6540","4814"],'Y','integer']]
agg_list_mcc_split2_30D = [['mcc',f.sum,"count",'All','mcc',["7311","6012","4900"],'Y','integer']]
agg_list_mcc_split3_30D = [['mcc',f.sum,"count",'All','mcc',["4899","4121","5699","4722"],'Y','integer']]
agg_list_mcc_split4_30D = [['mcc',f.sum,"count",'All','mcc',["5735","5732","5968"],'Y','integer']]


def cnp_sec_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate, flag_val):
    agg_df, df_list = None, None
    
    try:
        agg_list_3d = [agg_list_mcc_split1_30D, agg_list_mcc_split2_30D, agg_list_mcc_split3_30D,
                       agg_list_mcc_split4_30D]
        
        agg_list_30d = [agg_list_amt_30D, agg_list_amt_split1_30D, agg_list_amt_split2_30D, agg_list_sd_resp_cde_ch_split1_30D,
                       agg_list_sd_resp_cde_ch_split2_30D, agg_list_sd_resp_cde_ch_split3_30D, agg_list_cntry_tran_30D,
                        agg_list_trancde_30D,
                       agg_list_hrtype_30D, agg_list_mcc_split1_30D, agg_list_mcc_split2_30D, agg_list_mcc_split3_30D,
                       agg_list_mcc_split4_30D]
        
        
        final_path = temp_path + 'cnp_sec_card_3d_temp_'
    
        if flag_val == "3days":
            agg_df, df_list = create_agg_list(agg_list_3d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 3)

        if flag_val == "30days":
            agg_df, df_list = create_agg_list(agg_list_30d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        
    return agg_df, df_list


def cnp_sec_card_agg(flag_val):
    sc = None
    try:
        config_json_path = curr_dir + "/config/CNP_Secured_card_30day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        ddf2 = df3
        
        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])
        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType==conf["channel"])
        
        
        # Create "mcc" - Newly added
        mcc_li = conf["mcc_li"]
        mcc_udf = f.udf(lambda x:mcc_type(x,mcc_li),StringType())
        ddf3 = ddf3.withColumn("mcc", mcc_udf("SD_RETL_SIC_CDE"))
        
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp','mcc']

        ddf3 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'cnp_sec_cardtemp.parquet'

        delete_hdfs_file(card_temp_file)

        # Write temp agg to HDFS
        app.logger.info("Writing data to temporary parquet")
        ddf3.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None
        
        df, df_list = cnp_sec_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate,flag_val)
        

        if flag_val == "3days":
            name_of_file = "CNP_SEC_Card3day_POS_table_W"

        if flag_val == "30days":
            name_of_file = "CNP_SEC_Card30day_POS_table_W"

        # saving the final parquet
        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            delete_hdfs_file(i)

        delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
       
    if flag_val == "3days":
        ins_status = insert_weekly_agg_pipeline_status("CNP_Secured_Card_3day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("CNP_Secured_Card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
        
    return resp


class CNPSecuredCardAggregatesApi(Resource):
    def post(self):
        apiconf = json.loads(request.data)
        flag_val = apiconf["flag_val"]
        resp = cnp_sec_card_agg(flag_val)
        return jsonify(resp)

api.add_resource(CNPSecuredCardAggregatesApi,'/', '/cnp_secured_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9016", debug=False)