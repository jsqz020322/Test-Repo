# Author Name : B Ravikanth
# Last update : 28-06-2022

import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")
import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, \
    write_weekly_agg_intermediary_tables, exception_block
from SparkUtils.card_agg_utils import add_aggregates_n_days
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list


app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
agg_list_fraud_count = [['Fraud', f.sum, "count", 'All', 'NA', 'NA', 'N', 'integer']]

agg_list_hrtype = [['hour_type',f.sum,"count",'All','hour_type',['lateNight'],'Y','integer']]

agg_list_entry_mde_type = [['entry_mde_type',f.sum,"count",'All','entry_mde_type',['contactlesscard'],'N','integer']]

agg_list = [agg_list_fraud_count, agg_list_hrtype, agg_list_entry_mde_type]

## aggregates to be calculated


def merchant_aggregates_ndays(app, spark, temp_path, card_temp_file, conf, strtdate, enddate,flag_val):
    agg_df, df_list = None, None
    try:
        agg_list = [agg_list_fraud_count, agg_list_hrtype, agg_list_entry_mde_type]

#         agg_list = [agg_list_Amtbins,agg_list_Amtbins_ch]
        final_path = temp_path + 'merchant_7d_temp_'

        if flag_val == "7days":
            agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 7)
        if flag_val == "30days":
            agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    return agg_df, df_list


# @app.route('/card_3day_agg', methods=["POST"])
def pos_merchant_agg(flag_val):
    sc = None
    try:
        config_json_path = curr_dir + "/config/POS_merchant_7day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        
        #strtdate = conf['start_date']
        #enddate = conf['end_date']

        ddf2 = df3

        ddf2 = ddf2.withColumn("SD_PAN", f.col("SD_TERM_ID"))

        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType=="POS")
         
        req_cols = conf['req_cols']
        req_cols = req_cols + ['SD_PAN','date_timestamp']

        ddf2 = ddf3.select(req_cols)
        merchant_temp_file = temp_path + 'pos_mertemp.parquet'

#         delete_hdfs_file(merchant_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(merchant_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(merchant_temp_file)

        ### Write temp agg to hdfs
        app.logger.info("writing data to temporary parquet")
        ddf2.write.parquet(merchant_temp_file)

        df_list = []
        name_of_file = None

        
        df, df_list = merchant_aggregates_ndays(app, spark, temp_path,merchant_temp_file, conf, strtdate, enddate,flag_val)
        if flag_val == "7days":
            name_of_file = "Merchant_7day_POS_table_W"

        if flag_val == "30days":
            name_of_file = "Merchant_30day_POS_table_W"

        ## saving the final parquet

        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        for each_col in df_final.columns:
            if each_col != "SD_TIEBREAKER":
                df_final = df_final.withColumnRenamed(each_col,each_col+"_merchant")

        final_root_path = conf["intermediary_path"]
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])
        
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(merchant_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(merchant_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
        
       
    if flag_val == "7days":
        ins_status = insert_weekly_agg_pipeline_status("POS_Merchant_7day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("POS_Merchant_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    return resp


class PosMerchantAggregatesApi(Resource):
    def post(self):
        apiconf = json.loads(request.data)
        flag_val = apiconf["flag_val"]
        resp = pos_merchant_agg(flag_val)
        return jsonify(resp)

api.add_resource(PosMerchantAggregatesApi,'/', '/pos_merchant_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9014", debug=False)