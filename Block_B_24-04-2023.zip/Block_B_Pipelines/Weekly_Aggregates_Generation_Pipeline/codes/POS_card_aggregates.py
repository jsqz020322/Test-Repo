# Author Name : B Ravikanth
# Last update : 28-06-2022

# Import required libraries and packages
import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")
import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block, grouped_agg_days_temporal
from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


# List of 3 Day Aggregates

agg_list_tokenserviceflag_3D = [['token_service_flg',f.sum,"count",'All','token_service_flg',['TokenService_SamsungPay'],'Y','integer']]

agg_list_mcc_1 = [['mcc',f.sum,"count",'All','mcc',["5541", "5411","5812","5995","5921"],'Y','integer']]

agg_list_mcc_2 = [['mcc',f.sum,"count",'All','mcc',["5814","5813","5499","5912","4812"],'Y','integer']]

agg_list_mcc_3 = [['mcc',f.sum,"count",'All','mcc',["4111","5944","5542","5399","5699"],'Y','integer']]

agg_list_mcc_4 = [['mcc',f.sum,"count",'All','mcc',["5732","5310","5311","5691","5661"],'Y','integer']]

agg_list_amt_contactless_3D = [['MD_TRAN_AMT1', f.mean, "mean", 'M', 'entry_mde_type', ["contactlesscard"], 'Y', 'double'],['MD_TRAN_AMT1', f.max, "max", 'M', 'entry_mde_type', ["contactlesscard"], 'Y', 'double']]

agg_list_Amtbins_ch_3D_1 = [['Amount_bins',f.sum,"count",'M','Amount_bins',["0_1","1_500","501_2000","2001_5000","5001_10000"],'Y','integer']]

agg_list_Amtbins_ch_3D_2 = [['Amount_bins',f.sum,"count",'M','Amount_bins',["10001_20000","20001_30000","30001_50000","50001_100000"],'Y','integer']]

agg_list_sd_resp_cde_ch_3D = [['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', ["PRM_Declined","IntlLimitExceeded_NA"],'Y','integer']] 

# List of 30 Day Aggregates

agg_list_Amtbins_ch_30D_1 = [['Amount_bins',f.sum,"count",'M','Amount_bins',["1_500","501_2000","2001_5000","5001_10000"],'Y','integer']]

agg_list_Amtbins_ch_30D_2 = [['Amount_bins',f.sum,"count",'M','Amount_bins',["10001_20000","20001_30000","50001_100000"],'Y','integer']]

agg_list_channeltype_ch_30D = [['ChannelType',f.sum,"count",'All','ChannelType',['POS'],'Y','integer']]

agg_list_cntrytype_ch_30D = [['CntryType',f.sum,"count",'All','CntryType',['International'],'Y','integer']]

agg_list_hourtype_ch_30D = [['hour_type',f.sum,"count",'All','hour_type',['close_midnight', 'lateNight'],'Y','integer']]

agg_list_amt_30D = [['MD_TRAN_AMT1', f.mean, "mean", 'M', 'NA', 'NA', 'Y', 'double'],['MD_TRAN_AMT1', f.min, "min", 'M', 'NA', 'NA', 'Y', 'double']]

agg_list_sd_resp_cde_30D_1 = [['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', ["ExpiredCard","InsuffFunds","InvalidData"],'Y','integer']] 

agg_list_sd_resp_cde_30D_2 = [['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', ["OtherDeclines","Pickup_Capture","RestrictedCard"],'Y','integer']] 


def pos_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate, flag_val):
    agg_df, df_list = None, None
    
    try:
        agg_list_3d = [agg_list_Amtbins_ch_3D_1, agg_list_Amtbins_ch_3D_2, agg_list_amt_contactless_3D, agg_list_sd_resp_cde_ch_3D, agg_list_tokenserviceflag_3D, agg_list_mcc_1, agg_list_mcc_2, agg_list_mcc_3, agg_list_mcc_4]
        
#         agg_list_30d = [agg_list_amt_30D,agg_list_Amtbins_ch_30D_1]
        
        agg_list_30d = [agg_list_Amtbins_ch_30D_1, agg_list_Amtbins_ch_30D_2, agg_list_channeltype_ch_30D, agg_list_cntrytype_ch_30D, agg_list_hourtype_ch_30D, agg_list_mcc_1, agg_list_mcc_2, agg_list_mcc_3, agg_list_mcc_4 ,agg_list_amt_30D ,agg_list_tokenserviceflag_3D ,agg_list_amt_contactless_3D,agg_list_sd_resp_cde_30D_1, agg_list_sd_resp_cde_30D_2]
        
        
        final_path = temp_path + 'pos_card_3d_temp_'
    
        if flag_val == "3days":
            agg_df, df_list = create_agg_list(agg_list_3d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 3)

        if flag_val == "30days":
            agg_df, df_list = create_agg_list(agg_list_30d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        
    return agg_df, df_list

    
# Create "mcc" - Newly added
def mcc_type(SD_RETL_SIC_CDE,mcc_li):
    try:
        if SD_RETL_SIC_CDE.strip() in mcc_li:
            return SD_RETL_SIC_CDE
        else:
            return "Others"
    except:
        return "NA"


def pos_card_agg(flag_val):
    sc = None
    try:
        config_json_path = curr_dir + "/config/POS_card_30day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        ddf2 = df3
        
        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])
        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType==conf["channel"])
        
        
        # Create "mcc" - Newly added
        mcc_li = conf["mcc_li"]
        mcc_udf = f.udf(lambda x:mcc_type(x,mcc_li),StringType())
        ddf3 = ddf3.withColumn("mcc", mcc_udf("SD_RETL_SIC_CDE"))
        
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp','mcc']

        ddf3 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'pos_cardtemp.parquet'

#         delete_hdfs_file(card_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        # Write temp agg to HDFS
        app.logger.info("Writing data to temporary parquet")
        ddf3.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None
        
        df, df_list = pos_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate,flag_val)
        

        if flag_val == "3days":
            name_of_file = "Card3day_POS_table_W"

        if flag_val == "30days":
            name_of_file = "Card30day_POS_table_W"

        # saving the final parquet
        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
       
    if flag_val == "3days":
        ins_status = insert_weekly_agg_pipeline_status("POS_Card_3day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("POS_Card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
        
    return resp


class POSCardAggregatesApi(Resource):
    def post(self):
        apiconf = json.loads(request.data)
        flag_val = apiconf["flag_val"]
        resp = pos_card_agg(flag_val)
        return jsonify(resp)

api.add_resource(POSCardAggregatesApi,'/', '/pos_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9013", debug=False)