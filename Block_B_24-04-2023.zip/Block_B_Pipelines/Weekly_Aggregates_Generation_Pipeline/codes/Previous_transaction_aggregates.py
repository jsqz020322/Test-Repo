# encoding : utf-8
# Author : B Ravikanth
# Last modified Date : 13-07-2022


## Create SparkContext , Spark Session
import json
import logging
import os

import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, delete_hdfs_file, prev_field, \
    get_relavant_date_range_df, write_weekly_agg_intermediary_tables, exception_block
from flask import Flask, jsonify
from pyspark.sql.types import IntegerType

from ATM_additional_aggregates_New import read_derived_table
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


# def diff_time(day1, day2):
#     ret_val = -1
#     try:
#         ret_val = int((day1 - day2).total_seconds() / 60)
#     except Exception as e:
#         print("Exception in diff_time func : " + str(e))

#     return ret_val

def diff_time(day1, day2):
    
    ret_val = -1
    try:
        ret_val = int((day1 - day2) / 60)
    except Exception as e:
        print("Exception in diff_time func : " + str(e))

    return ret_val

# ------------------------CHANGE DATA TYPES---------------------


def prev_tran_cde_type(tran_cde_type):
    ret_val = 0
    if tran_cde_type == "BalInquiry":
        ret_val = 1
    elif tran_cde_type == "PinChange":
        ret_val = 2
    elif tran_cde_type == "PinInquiry":
        ret_val = 3
    elif tran_cde_type == "Purchase":
        ret_val = 4
    elif tran_cde_type == "MailOrder":
        ret_val = 5
    else:
        ret_val = 6

    return ret_val


def prev_channel_type_val(channel):
    ret_val = 5
    if channel == "POS":
        ret_val = 1
    elif channel == "ATM":
        ret_val = 2
    elif channel == "CNP SECURED":
        ret_val = 3
    elif channel == "CNP UNSECURED":
        ret_val = 4

    return ret_val


def prev_hour_type_val(hour):
    ret_val = 4
    if hour == "earlyMrng":
        ret_val = 1
    elif hour == "busHrs":
        ret_val = 2
    elif hour == "close_midnight":
        ret_val = 3
    return ret_val

def prev_sd_resp_cde_type(prev_sd_resp_cde_type):
    try:

        if(prev_sd_resp_cde_type=="Approved"):
            return 1
        elif(prev_sd_resp_cde_type=="PRM_Declined"):
            return 2
        elif(prev_sd_resp_cde_type=="InvalidData"):
            return 3
        elif(prev_sd_resp_cde_type=="ExpiredCard"):
            return 4
        elif(prev_sd_resp_cde_type=="RestrictedCard"):
            return 5
        elif(prev_sd_resp_cde_type=="InsuffFunds"):
            return 6
        elif(prev_sd_resp_cde_type=="WithdrawalLimitExceeded"):
            return 7
        elif(prev_sd_resp_cde_type=="IntlLimitExceeded_NA"):
            return 8
        elif(prev_sd_resp_cde_type=="Pickup_Capture"):
            return 9
        elif(prev_sd_resp_cde_type=="Block_Decline_H"):
            return 10
        else:
            return 0

    except:
        return 0

# @app.route('/prev_agg', methods=["POST"])
def previous_aggregates():
    sc = None
    try:

        config_json_path = curr_dir + "/config/previous_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        
        spark, sc = create_spark_context(conf, conf["appName"])

        temp_path, status_df, current_date, last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(
            conf, spark)

        ddf3 = df3

        prev_temp_file = temp_path + 'prevtemp.parquet'

#         delete_hdfs_file(prev_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(prev_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(prev_temp_file)

        ddf3.write.parquet(prev_temp_file)

        ddf3 = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(prev_temp_file)
        
        
        ddf3 = ddf3.orderBy('DD_DATE',ascending=[1])
        
        

        ddf3 = ddf3.withColumn('date_timestamp', ddf3.DD_DATE.astype('Timestamp').cast('long'))
        
        ddf3_pdf = ddf3.to_pandas_on_spark()
        
        
        prev_req_cols = ['SD_TIEBREAKER','DD_DATE','SD_PAN','date_timestamp','ChannelType','fall_back_status',
                         'CntryType','hour_type','tran_cde_type','Amount_bins','sd_resp_cde_type',
                         'MD_TRAN_AMT1','sd_monetary','key_entry_tx_flag','pin_entered_dom_flag',
                         'SD_TERM_NAME_LOC','SD_TERM_CITY','SD_TERM_ST','SD_TERM_CNTRY','SD_TERM_POSTAL_CDE']

        prev_tran_fields = ddf3_pdf[prev_req_cols].set_index(['SD_TIEBREAKER','DD_DATE']).groupby('SD_PAN').shift(1)

        prev_tran_fields.columns = ['prev_date','prev_tran_channel_type', 'prev_tran_fall_back_flag','prev_tran_cntry_type',
                            'prev_hour_type','prev_tran_cde_type','prev_Amount_bins','prev_sd_resp_cde_type',
                            'prev_tran_amt','prev_tran_monetary_type','prev_tran_keyentry_flag','prev_tran_pinentered_flag',
                            'prev_term_location','prev_term_city','prev_term_state',
                           'prev_term_cntry','prev_postal_code']
        
        
        prev_tran_fields.reset_index(inplace=True)
        
        prev_tran_fields['prev_term_city_channelwise'] = prev_tran_fields['prev_term_city']
        prev_tran_fields['prev_term_state_channelwise'] = prev_tran_fields['prev_term_state']
        prev_tran_fields['prev_term_cntry_channelwise'] = prev_tran_fields['prev_term_cntry']
        
        prev_tran_fields_spark = prev_tran_fields.to_spark()
        
        prev_temp_file_new = temp_path + 'prevtemp_prev_values.parquet'

#         delete_hdfs_file(prev_temp_file_new)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(prev_temp_file_new,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(prev_temp_file_new)

        prev_tran_fields_spark.write.parquet(prev_temp_file_new)

        df = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(prev_temp_file_new)
        
        

        df = df.withColumn('dd_date_timestamp', df.DD_DATE.astype('Timestamp').cast('long'))
        
        diff_time_udf = f.udf(diff_time, IntegerType())

        df = df.withColumn('prev_tran_time_diff_mins', diff_time_udf('dd_date_timestamp', 'prev_date'))


        prev_tran_cde_type_udf = f.udf(prev_tran_cde_type, IntegerType())
        prev_tran_channel_type_udf = f.udf(lambda x : prev_channel_type_val(x),
                                           IntegerType())
        prev_tran_cntry_type_udf = f.udf(lambda x: 0 if x == 'Domestic' else 1, IntegerType())
        prev_hour_type_udf = f.udf(
            lambda x: prev_hour_type_val(x),
            IntegerType())
        
        prev_Amount_bins_udf = f.udf(lambda x:1 if x=="0" else 2 if x=="0_1" else 3 if x=='1_500' else 4 if x=='501_2000' \
                                     else 5 if x=='2001_5000' \
                      else 6 if x=='5001_10000' else 7 if x=='10001_20000' else 8 if x=='20001_30000' \
                      else 9 if x=='30001_50000' else 10 if x=='50001_100000' else 11 if x=='100001_500000' \
                      else 12 if x=='gt10,00,000' else 0,IntegerType())

        prev_sd_resp_cde_type_udf  = f.udf(prev_sd_resp_cde_type,IntegerType())
        prev_tran_keyentry_flag_udf = f.udf(lambda x:0 if x=='non_key_entry_tx' else 1,IntegerType())
        prev_tran_monetary_type = f.udf(lambda x:1 if x=='M' else 0,IntegerType())
        prev_tran_cntry_type_udf = f.udf(lambda x:0 if x=='Domestic' else 1,IntegerType())
        prev_tran_pinentered_flag_udf = f.udf(lambda x:1 if x=='entered' else 0,IntegerType())
        
        # ----------------CONVERTING CATEGORICAL COLUMNS TO NUMERICAL COLUMNS
        df = df.withColumn('prev_tran_channel_type', prev_tran_channel_type_udf('prev_tran_channel_type'))
        df = df.withColumn('prev_tran_cntry_type', prev_tran_cntry_type_udf('prev_tran_cntry_type'))
        df = df.withColumn('prev_hour_type', prev_hour_type_udf('prev_hour_type'))
        df = df.withColumn('prev_tran_cde_type', prev_tran_cde_type_udf('prev_tran_cde_type'))
        
        ## Added for pos
        df = df.withColumn('prev_Amount_bins',prev_Amount_bins_udf('prev_Amount_bins'))
        df = df.withColumn('prev_sd_resp_cde_type',prev_sd_resp_cde_type_udf('prev_sd_resp_cde_type'))
        df = df.withColumn('prev_tran_keyentry_flag',prev_tran_keyentry_flag_udf('prev_tran_keyentry_flag'))
        df = df.withColumn('prev_tran_monetary_type',prev_tran_monetary_type('prev_tran_monetary_type'))
        df = df.withColumn('prev_tran_pinentered_flag',prev_tran_pinentered_flag_udf('prev_tran_pinentered_flag'))
        

        added_cols = ['prev_date', 'prev_tran_time_diff_mins', 'prev_tran_fall_back_flag', 'prev_tran_channel_type',
                      'prev_tran_cntry_type','prev_tran_keyentry_flag','prev_tran_monetary_type','prev_tran_pinentered_flag',
                      'prev_hour_type', 'prev_tran_cde_type', 'prev_Amount_bins','prev_sd_resp_cde_type','prev_tran_amt',
                      'prev_term_location', 'prev_term_city', 'prev_term_state', 'prev_term_cntry', 'prev_postal_code', 
                      'prev_term_city_channelwise', 'prev_term_state_channelwise', 'prev_term_cntry_channelwise']

        added_cols = added_cols + ['SD_TIEBREAKER', 'DD_DATE']

        temp_df = df.select(added_cols)
        temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)
        df_final = temp_df2.drop('DD_DATE')

        final_root_path = conf["intermediary_path"]
        name_of_file = "PrevAgg_ATM_table_W"
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(prev_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(prev_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e, app)

    if sc is not None:
        sc.stop()

    ins_status = insert_weekly_agg_pipeline_status("Previous_aggregates_api",resp["output_table_path"],resp["Error"][:250])
    return resp


class PrevAggApi(Resource):
    def post(self):
        resp = previous_aggregates()
        return jsonify(resp)
        

api.add_resource(PrevAggApi,'/', '/prev_tran_agg')


if __name__ == '__main__':
    app.run("0.0.0.0", port="9009", debug=False)
