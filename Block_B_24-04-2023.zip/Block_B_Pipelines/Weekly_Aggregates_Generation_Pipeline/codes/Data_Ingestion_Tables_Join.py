# encoding : utf-8 
# Author : BVSS Ravikanth
# Last modified Date : 27-06-2022


import warnings
from datetime import timedelta

import pandas.io.sql as psql
import pyspark.sql.functions as f

warnings.filterwarnings("ignore")
import json
import os,sys
import datetime
from SparkUtils.spark_utils import create_spark_context, write_weekly_agg_intermediary_tables
from DataBaseUtils.db_utils import mysql_conn
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status

import warnings
warnings.filterwarnings('ignore')

import logging
from flask import Flask, jsonify
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

# joining detail table and fraud detail to populate fraud col
def det_fd_join(det, fd):
    fd_2 = fd.select(f.col('SD_TIEBREAKER').alias('FD_TIEBREAKER'), 'ND_MARK_TYPE')
    fd_2 = fd_2.withColumn('Fraud', f.lit(1))

    ta = det.alias('ta')
    tb = fd_2.alias('tb')

    df_fd_join = ta.join(tb, ta.SD_TIEBREAKER == tb.FD_TIEBREAKER, how='left')

    fill_col_vals = {'Fraud': 0}

    df_fd_join = df_fd_join.na.fill(fill_col_vals)

    del fd_2, ta, tb

    return df_fd_join


## joining detail table and card master
def det_cm_join(det, cm):
    rcols = cm.columns
    app.logger.info(rcols)

    rcols2 = [c + '_cm' for c in rcols]

    cm2 = cm.toDF(*rcols2)

    ta = det.alias('ta')
    tb = cm2.alias('tb')

    det_cm_join = ta.join(tb, ta.SD_PAN == tb.SM_PAN_cm, how='left')
    det_cm_join = ta.join(tb, ta.SD_PAN == tb.SM_PAN_hashed_cm, how='left')

    del cm2, ta, tb

    return det_cm_join

# @app.route('/join_tables', methods=["POST"])
def join_dataingestion_tables():
    sc = None
    sql_conn = None
    try:

        config_json_path = curr_dir + "/config/data_ingestion_tables_join.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)

        spark, sc = create_spark_context(conf,conf["appName"])
        sql_conn = mysql_conn(os.getenv("WEEKLY_AGG_CONN"))
        app.logger.info(sql_conn)

        current_date = datetime.datetime.now()
        current_date = current_date.strftime("%Y-%m-%d")
        previous_date = datetime.datetime.now() - timedelta(days=7)
        previous_date = previous_date.strftime("%Y-%m-%d")

        query1 = """SELECT * from data_ingestion_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1"
        data_ingestion_df = psql.read_sql_query(query1, sql_conn)
#         app.logger.info(data_ingestion_df)

        query2 = """SELECT * from kafka_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1"
        transaction_df = psql.read_sql_query(query2, sql_conn)
        transaction_df = transaction_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        
        # Reading Detail Table
        det_path_loc = transaction_df.loc[0]['RootPathLocation']+ "/*"
        app.logger.info(det_path_loc)
        det = spark.read.parquet(det_path_loc + "*")
        app.logger.info("Detail table read and records count is")
        app.logger.info(det.count())

        # Fraud Detail Table
        fd_df_data_ingestion = data_ingestion_df.copy()[data_ingestion_df['FileName'] == "prm_fraud_detail_flag"]
        fd_df_data_ingestion = fd_df_data_ingestion.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        fd_df_path = fd_df_data_ingestion.loc[0][
            'SavePathLocation']
        fd_df_root_path = "/".join(fd_df_path.split("/")[:-1]) + "/*"
        app.logger.info(fd_df_root_path)
        fddf = spark.read.parquet(fd_df_root_path)
        fddf = fddf.filter(~(fddf.ND_MARK_TYPE.isin(conf["nd_marktype_li"])))
        app.logger.info("Fraud Detail table read and records count is")
        app.logger.info(fddf.count())

        det_fd = det_fd_join(det, fddf)
        app.logger.info("Detail Fraud Detail joined")

#         cm_data_ingestion = data_ingestion_df.copy()[data_ingestion_df['FileName'] == "prm_cm"]
# #         app.logger.info(cm_data_ingestion)
#         cm_data_ingestion = cm_data_ingestion.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
#         cm_path = cm_data_ingestion.loc[0][
#             'SavePathLocation']
#         cm_root_path = "/".join(cm_path.split("/")[:-1]) + "/*"
#         app.logger.info(cm_root_path)
        cm_root_path= conf["card_master_path"]
        cm = spark.read.parquet(cm_root_path)

        det_fd = det_cm_join(det_fd, cm)
        app.logger.info("Detail Card Master joined")

        final_root_path = conf["intermediary_path"]
        name_of_file = "Data_ingestion_joint_table_W"

        final_path = write_weekly_agg_intermediary_tables(final_root_path,name_of_file,det_fd)

        sc.stop()
        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        tb_exc_type, exc_obj, exc_tb = sys.exc_info()
        tb_fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        tb_exc_val = "Exception occured : " + str(tb_exc_type) + " " + str(tb_fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(tb_exc_val)
        resp = {"status": 400, "Error": str(tb_exc_val), "output_table_path": "NA"}
        if sc is not None:
            sc.stop()
    if sql_conn is not None:
        sql_conn.close()
        
    
    insert_weekly_agg_pipeline_status("Data_ingestion_tables_join",resp["output_table_path"],resp["Error"])
        
    return jsonify(resp)

class DataIngestionTablesApi(Resource):
    def post(self):
        resp = join_dataingestion_tables()
        return jsonify(resp)
        
api.add_resource(DataIngestionTablesApi,'/', '/dataingestion_join_tables')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9001", debug=False)