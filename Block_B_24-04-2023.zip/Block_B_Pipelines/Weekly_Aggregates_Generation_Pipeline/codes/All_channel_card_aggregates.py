# Author Name : B Ravikanth
# Last update : 28-06-2022

import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")
import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block
from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


agg_list_amt_30d = [
                        ['MD_TRAN_AMT1',f.mean,"mean",'M','NA','NA','N','double'],
                        ['MD_TRAN_AMT1',f.max,"max",'M','NA','NA','N','double'],
                        ['MD_TRAN_AMT1',f.min,"min",'M','NA','NA','N','double']
                       ]


agg_list_Amtbins_1 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins',
                         ["0","0_1","1_500", "501_2000"], 'N', 'integer']]

agg_list_Amtbins_2 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins',
                         [  "2001_5000","5001_10000","10001_20000", "20001_30000"
                           ], 'N', 'integer']]


agg_list_Amtbins_3 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins',
                         [ "30001_50000",
                           "50001_100000","100001_500000","500001_1000000"], 'N', 'integer']]

agg_list_bal_ch_m = [
    ['ChannelType', f.sum, "count", 'All', 'ChannelType', ['ATM','POS', 'CNP SECURED', 'CNP UNSECURED'], 'N', 'integer'],
    ['sd_monetary', f.sum, "count", 'All', 'sd_monetary', ['M','NM'], 'N', 'integer']
]

agg_list_sd_resp_cde_1 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type',
                         ["Pickup_Capture", "InsuffFunds", "IntlLimitExceeded_NA"], 'N',
                         'integer']]

agg_list_sd_resp_cde_2 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type',
                         ["Block_Decline_H","OtherDeclines",
                         "ExpiredCard","InvalidData"], 'N',
                         'integer']]

agg_list_sd_resp_cde_3 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type',
                         ["PRM_Declined","RestrictedCard","WithdrawalLimitExceeded"], 'N',
                         'integer']]


agg_list_cntry_tran = [
    ['CntryType', f.sum, "count", 'All', 'CntryType', ['Domestic','International'], 'N', 'integer']
]

agg_list_entrymde_fallback = [
    ['entry_mde_type', f.sum, "count", 'All', 'entry_mde_type', ['magstripe', 'chipvalidated', 'contactlesscard'],
     'N', 'integer'],
    ['fall_back_status', f.sum, "count", 'All', 'NA', 'NA', 'N', 'integer']
]

agg_list_keyentry_hotspot = [
    ['key_entry_tx_flag', f.sum, "count", 'All', 'key_entry_tx_flag', ['key_entry_tx'], 'N', 'integer']]

agg_list_pinent_ecom_dom = [
    ['real_time_rule_status', f.sum, "count", 'All', 'real_time_rule_status', ["Allow over limit", "Authorized",'Declined'], 'N',
     'integer']]

agg_list_trancde = [['tran_cde_type', f.sum, "count", 'All', 'tran_cde_type', ['Purchase','MailOrder','BalInquiry','PinChange','PinInquiry'], 'N', 'integer']]

agg_list_hrtype = [
    ['hour_type', f.sum, "count", 'All', 'hour_type', ['busHrs','close_midnight', 'earlyMrng','lateNight'], 'N', 'integer']]



## aggregates to be calculated

def create_agg_list(agg_list, app, spark, temp_path,card_temp_path, conf, final_path, strtdate, enddate, n_val):
    df, df_list = None, None
    try:
        df_list = []
        i = 0

        for agg in agg_list:

            app.logger.info(agg)

            ddf2 = spark.read.format('parquet') \
                .option("inferSchema", "true") \
                .load(card_temp_path)
            
            
            ddf2_pdf = ddf2.to_pandas_on_spark()
            ddf2_pdf['DD_DATE_conv'] = ddf2_pdf['DD_DATE'].apply(lambda x:x.date())
            group_col = "SD_PAN"
            order_col = "DD_DATE_conv"
            agg_list = agg
            
            ddf4_pdf, added_cols = add_aggregates_n_days(ddf2_pdf, group_col,order_col,agg_list, n_val,conf,app)
            ddf4 = ddf4_pdf.to_spark()

            nc = ['SD_TIEBREAKER', 'DD_DATE',"SD_PAN","DD_DATE_conv"] + added_cols
            temp_df = ddf4.select(nc)
            temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)

            par_path = final_path + str(i) + '.parquet'
            
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(par_path)

#             delete_hdfs_file(par_path)
            
            temp_df2.write.parquet(par_path)
            
            df_list.append(par_path)
            del temp_df, temp_df2
            i = i + 1

        ## reading temp files and merging them
        
        if len(df_list) > 5:
            df1 = join_temp_tables(df_list[:5], spark)
            df2 = join_temp_tables(df_list[5:], spark)
            
        

        else:
            df1 = join_temp_tables(df_list[:1], spark)
            df2 = join_temp_tables(df_list[1:], spark)
            
            
            

        df1 = df1.persist()
        df2 = df2.persist()

        joindf = df1
        tempdf = df2
        othercols = [c for c in tempdf.columns if c not in ['SD_TIEBREAKER', 'DD_DATE',"SD_PAN","DD_DATE_conv"]]
        selcols = [f.col('SD_TIEBREAKER').alias('SD_TIEBREAKER_B'), f.col('DD_DATE').alias('DD_DATE_B')] + othercols

        tempdf2 = tempdf.select(selcols)
        df = joindf.join(tempdf2, joindf.SD_TIEBREAKER == tempdf2.SD_TIEBREAKER_B, 'left')
        df = df.na.fill(0)
        df = df.drop(*['SD_TIEBREAKER_B', 'DD_DATE_B'])
        
        df = df.dropDuplicates(["SD_TIEBREAKER"])
        
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    return df, df_list


def card_aggregates_3days(app, spark, temp_path,card_temp_file, conf, strtdate, enddate):
    agg_df, df_list = None, None
    try:
        agg_list = [agg_list_Amtbins_1,agg_list_Amtbins_2,agg_list_Amtbins_3, agg_list_bal_ch_m, agg_list_sd_resp_cde_1,
                    agg_list_sd_resp_cde_2,agg_list_sd_resp_cde_3,
                    agg_list_cntry_tran, agg_list_entrymde_fallback, agg_list_keyentry_hotspot, 
                    agg_list_pinent_ecom_dom, agg_list_trancde, agg_list_hrtype]

        final_path = temp_path + 'all_ch_card_3d_temp_'

        agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 3)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    return agg_df, df_list


def card_aggregates_30days(app, spark, temp_path, card_temp_file,conf, strtdate, enddate):

#     agg_list = [agg_list_amt_30d, agg_list_Amtbins_1]
    
    
    agg_list = [agg_list_amt_30d, agg_list_Amtbins_1,agg_list_Amtbins_2,agg_list_Amtbins_3, agg_list_bal_ch_m, agg_list_sd_resp_cde_1,
                    agg_list_sd_resp_cde_2,agg_list_sd_resp_cde_3,
                    agg_list_cntry_tran, agg_list_entrymde_fallback, agg_list_keyentry_hotspot, 
                    agg_list_pinent_ecom_dom, agg_list_trancde, agg_list_hrtype]

    final_path = temp_path + 'all_ch_card_30d_temp_'

    agg_df, df_list = create_agg_list(agg_list, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    return agg_df, df_list

# Create "mcc" - Newly added
def mcc_type(SD_RETL_SIC_CDE,mcc_li):
    try:
        if SD_RETL_SIC_CDE.strip() in mcc_li:
            return SD_RETL_SIC_CDE
        else:
            return "Others"
    except:
        return "NA"

def atm_card_agg():
    apiconf = json.loads(request.data)
    flag_val = apiconf["flag_val"]
    sc = None
    try:
        config_json_path = curr_dir + "/config/all_channel_card_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)

        ddf2 = df3

        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])

        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        
        mcc_li = conf["mcc_li"]
        mcc_udf = f.udf(lambda x:mcc_type(x,mcc_li),StringType())
        ddf3 = ddf3.withColumn("mcc", mcc_udf("SD_RETL_SIC_CDE"))
        
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp','mcc']
        

        ddf2 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'all_ch_cardtemp.parquet'

#         delete_hdfs_file(card_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        ### Write temp agg to hdfs
        app.logger.info("writing data to temporary parquet")
        ddf2.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None

        if flag_val == "3days":
            df, df_list = card_aggregates_3days(app, spark, temp_path,card_temp_file, conf, strtdate, enddate)
            name_of_file = "All_ch_Card3day_table_W"

        if flag_val == "30days":
            df, df_list = card_aggregates_30days(app, spark, temp_path, card_temp_file,conf, strtdate, enddate)
            name_of_file = "All_ch_Card30day_table_W"

        ## saving the final parquet

        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()        
       
    if flag_val == "3days":
        ins_status = insert_weekly_agg_pipeline_status("All_channel_card_3day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("All_channel_card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
        
    app.logger.info(ins_status)
    
    return resp


class CardAggregatesApi(Resource):
    def post(self):
        resp = atm_card_agg()
        return jsonify(resp)

api.add_resource(CardAggregatesApi,'/', '/all_channel_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9003", debug=False)