# encoding : utf-8 
# Author : BVSS Ravikanth
# Last modified Date : 07-12-2022

import os
import sys
import pandas as pd
import numpy as np
import pyspark

from pyspark.sql.types import *
from pyspark.sql.functions import *
## Create SparkContext , Spark Session
from pyspark.sql import SparkSession
from pyspark import SparkContext
import warnings
warnings.filterwarnings("ignore")
import os
import sys
import json
import logging

import datetime
from datetime import timedelta
import pandas.io.sql as psql

from DataBaseUtils.db_utils import mysql_conn
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, convert_df_types, write_weekly_agg_intermediary_tables, delete_hdfs_file
from flask import Flask, request, jsonify
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status

import warnings
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect


warnings.filterwarnings('ignore')

app = Flask(__name__)
app.logger.setLevel(logging.INFO)
csrf_protect = CSRFProtect(app)


api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

## function to read data tables provided the table paths and start date and end date of months considered
def read_tables(spark,t_paths,dtype,source_tab_cols):
    tb_li = []
    for each_path in t_paths:
        
        app.logger.info(each_path)
        
        req_cols = source_tab_cols[each_path[0]]
        
        tmp = spark.read.format('parquet').option("inferSchema","true").load(each_path[1])
        
        tmp = tmp.select(req_cols)
        
        tmp = convert_df_types(tmp,each_path[0],dtype)
        
        tmp_sub = tmp
            
        tb_li.append(tmp_sub)
    
    del tmp,tmp_sub
    return tb_li

def create_key_detail(DD_DATE,SD_PAN,SD_APPRV_CDE):
    if(SD_APPRV_CDE==None):
        SD_APPRV_CDE='null'
    return(SD_PAN+"-"+str(DD_DATE)+"-"+SD_APPRV_CDE)

create_key_detail_udf=udf(create_key_detail,StringType())

## joining detail table rec src id 2 and 3
def det_rec_src_id_2_3_join(det):
    
    det_rs_2 = det.filter(det.RECORD_SOURCE_ID==2)
    det_rs_3 = det.filter(det.RECORD_SOURCE_ID==3)
    
    det_rs_2 = det_rs_2.withColumn('rsid_key_2',create_key_detail_udf('DD_DATE','SD_PAN','SD_APPRV_CDE'))
    det_rs_3 = det_rs_3.withColumn('rsid_key_3',create_key_detail_udf('DD_DATE','SD_PAN','SD_APPRV_CDE'))
    
    ddf2 = det_rs_2.alias('ddf2')
    ddf3 = det_rs_3.select(col('SD_RETL_ID').alias('SD_RETL_ID_M'),'rsid_key_3').alias('ddf3')

    det_2_3_join = ddf2.join(ddf3,ddf2.rsid_key_2==ddf3.rsid_key_3,how="left")
    
    det_2_3_join = det_2_3_join.drop(*['rsid_key_2','rsid_key_3'])
    
    det_2_3_join = det_2_3_join.repartition('SD_PAN')
    
    del det_rs_2,det_rs_3,ddf2,ddf3
    
    return det_2_3_join

## joining detail flag table and fraud detail to populate ND_MARK_TYPE col
def fraud_df_join(fdf,deflag,marktype_list):
    deflag_sub = deflag.select(col('SD_TIEBREAKER').alias('DF_TIEBREAKER'),'ND_MARK_TYPE')
    app.logger.info("Deflag join created")
    ta = fdf.alias('ta')
    tb = deflag_sub.alias('tb')

    fraud_join = ta.join(tb,ta.SD_TIEBREAKER==tb.DF_TIEBREAKER,how='left')
#     fraud_join_final = fraud_join.filter(~(fraud_join.ND_MARK_TYPE.isin([42,46,47,49,50,58,60,61])))
    app.logger.info("Fraud df joined")
    app.logger.info(fraud_join.count())
    fraud_join_final = fraud_join.filter(~(fraud_join.ND_MARK_TYPE.isin(marktype_list)))
    
    app.logger.info("Cross sell rows removed")
    app.logger.info(fraud_join_final.count())
    del deflag_sub,ta,tb,fraud_join
    return fraud_join_final

## joining detail table and fraud detail to populate fraud col
def det_fd_join(det,fd):
    
    fd_2=fd.select(col('SD_TIEBREAKER').alias('FD_TIEBREAKER'),'ND_MARK_TYPE')
    fd_2 = fd_2.withColumn('Fraud',lit(1))
    
    ta = det.alias('ta')
    tb = fd_2.alias('tb')
    
    df_fd_join = ta.join(tb,ta.SD_TIEBREAKER==tb.FD_TIEBREAKER,how='left')
    
    fill_col_vals ={'Fraud':0}
    
    df_fd_join =df_fd_join.na.fill(fill_col_vals)
    
    del fd_2,ta,tb
    
    return df_fd_join


#business_rules = ['14997','11754','11752','10547','10545','14529','12492','14743','14741','12498','13492','13888','13890','10556']
####New Rules list With SMS alerted rules 

def rem_bus_rules(sd_rule,business_rules):
    rules2 = sd_rule.split('.')
    rules = [i for i in rules2 if i != '']
    x=1
    for rule in rules:
        if(rule not in business_rules):
            x=0
            return x
    return x


## joining detail table and detail alerted to populate alerted col
def det_dar_join(det,dar,business_rules):


    dar = dar.filter(dar.RECORD_SOURCE_ID==2)
    app.logger.info("Record source id filtered")
    rem_bus_rulesfunc = udf(lambda x:rem_bus_rules(x,business_rules),IntegerType())
    
    dar = dar.withColumn('busruleremove',rem_bus_rulesfunc('SD_RULES'))
    app.logger.info("Business rules removed")
    dar = dar.filter(dar.busruleremove==0) 
    app.logger.info(dar.count())
    dartiebreaker = dar.select('SD_TIEBREAKER')
    dartiebreaker = dartiebreaker.withColumn('Alerted',lit(1))

    dartiebreaker2 = dartiebreaker.select(col('SD_TIEBREAKER').alias('Alert_TIEBREAKER'),'Alerted')

    dar2 = dartiebreaker2.alias('dar2')
    ddf2 = det.alias('ddf2')

    ddf_alert_join = ddf2.join(dar2,ddf2.SD_TIEBREAKER==dar2.Alert_TIEBREAKER,how="left")

    fill_col_vals = {
        'Alerted' : 0,
        'Alert_TIEBREAKER':'NA'
    }

    ddf_alert_join = ddf_alert_join.na.fill(fill_col_vals)


    del ddf2,dartiebreaker,dartiebreaker2,dar2
    
    return ddf_alert_join


## joining detail table and card master
def det_cm_join(det,cm):
    
    rcols = cm.columns
    
    rcols2 = [c+'_cm' for c in rcols]
    
    cm2 = cm.toDF(*rcols2)
    
    ta = det.alias('ta')
    tb = cm2.alias('tb')
    
    det_cm_join = ta.join(tb,ta.SD_PAN==tb.SM_PAN_cm,how='left')
    
    del cm2,ta,tb
    
    return det_cm_join


## joining detail table and merchant master
def det_mm_join(det,mm):
    
    rcols = mm.columns
    
    rcols2 = [c+'_mm' for c in rcols]
    
    mm2 = mm.toDF(*rcols2)
    
    ta = det.alias('ta')
    tb = mm2.alias('tb')
    
    det_mm_join = ta.join(tb,ta.SD_RETL_ID_M==tb.SM_RETL_ID_mm,how='left')
    
    del mm2,ta,tb
    
    return det_mm_join


## joining detail table and uan master
def det_um_join(det,um):
    
    rcols = um.columns
    
    rcols2 = [c+'_um' for c in rcols]
    
    um2 = um.toDF(*rcols2)
    
    ta = det.alias('ta')
    tb = um2.alias('tb')
    
    det_um_join = ta.join(tb,ta.SD_UAN==tb.SM_UAN_um,how='left')
    
    del um2,ta,tb
    
    return det_um_join

# @app.route('/all_tables_join', methods=["POST"])
def join_all_tables():
    sc = None
    sql_conn = None
    try:
        
        config_json_path = curr_dir + "/config/all_tables_join_script_conf.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        spark, sc = create_spark_context(conf,conf["appName"])
        app.logger.info("Spark context created")
        
        sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
        app.logger.info(sql_conn)

        current_date = datetime.datetime.now()
        current_date = current_date.strftime("%Y-%m-%d")
        previous_date = datetime.datetime.now() - timedelta(days=7)
        previous_date = previous_date.strftime("%Y-%m-%d")
        
        ## Day-0 Paths 
        
        
        query1 = """SELECT * from sqoop_dataingestion_logs_status where Status=1"""
        sqoop_data_ingestion_df = psql.read_sql_query(query1, sql_conn)
        sqoop_data_ingestion_df = sqoop_data_ingestion_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        
        
        cm_day0_flag_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="card_master_day0"].reset_index(drop=True).loc[0]['SavePathLocation']+ "*"
        app.logger.info(cm_day0_flag_path_loc)
       
        
        query1 = """SELECT * from sqoop_dataingestion_logs_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1"
        sqoop_data_ingestion_df = psql.read_sql_query(query1, sql_conn)
        sqoop_data_ingestion_df = sqoop_data_ingestion_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        app.logger.info(sqoop_data_ingestion_df)
        
        
        
        
        uan_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="uan_master"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(uan_path_loc)
        
        
        
        
        det_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="detail"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(det_path_loc)
        
        fruad_det_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="fraud_detail"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(fruad_det_path_loc)
        
        dar_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="detail_alerted_rule"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(dar_path_loc)
        
        act_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="act"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(act_path_loc)
        
        det_flag_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="detail_flag"].reset_index(drop=True).loc[0]['RootPathLocation']+ "*"
        app.logger.info(det_flag_path_loc)
        
        cm_flag_path_loc = sqoop_data_ingestion_df[sqoop_data_ingestion_df['FileName']=="card_master"].reset_index(drop=True).loc[0]['RootPathLocation']
        
        
        cm_flag_path_loc = "/".join(cm_flag_path_loc.split("/")[:-2])+"/*/*"
        app.logger.info(cm_flag_path_loc)
        
        
        
        
#         uan_path_loc = conf["UAN_master_path"]

        
        business_rules = conf['business_rules']
        marktype_li = conf["nd_marktype_li"]
        spark_conf = conf['spark_conf']
        temp_path = conf["temp_path"]

#         ## provide table paths in hdfs for joining

        t_paths = [['detail',det_path_loc,'DD_DATE'],
                   ['frauddetail',fruad_det_path_loc,'DD_DATE'],
                   ['detail_alerted_rule',dar_path_loc,'DD_PARTITION_DATE'],
                   ['act',act_path_loc,'DTACTDATEKEY'],
                   ['detail_flag',det_flag_path_loc,'DD_PARTITION_DATE'],
                   ['card_master',cm_flag_path_loc,'None'],
                   ['card_master',cm_day0_flag_path_loc,'None'],
                   ['uan_master',uan_path_loc,'None']]

#         ## start date and end date of months considered
#         strtdate = conf["start_date"]
#         enddate = conf["end_date"]


#         # app.logger.info(s_path)
        s_path = curr_dir + conf['selected_cols_json_path']
        sel_cols= json.load(open(s_path,"r"))
        
#         app.logger.info(spark_conf)

        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        spark.sql("set spark.sql.parquet.int96RebaseModeInWrite=CORRECTED")
        
        
        dtype= json.load(open(curr_dir+conf["dtypes_file_path"],"r"))
        
        source_tab_cols = json.load(open(curr_dir+conf["source_table_cols_path"],"r"))
        
#         app.logger.info(dtype)

        tables_li = read_tables(spark,t_paths,dtype,source_tab_cols)
    
        det,fd,dar,act,df,cm,cm_day0,um = tables_li[0],tables_li[1],tables_li[2],tables_li[3],tables_li[4],tables_li[5],tables_li[6],tables_li[7]

        try:
            temp_tables_li = ['det_temp.parquet','det_temp_23.parquet','fd_temp.parquet','dar_temp.parquet','deflag_temp.parquet','cm_temp.parquet','cm_day_0temp.parquet','um_temp.parquet']

            for i in temp_tables_li:
                if conf["kerberos_flag"] == "True":
                    delete_hdfs_file(temp_path+i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
                else:
                    delete_hdfs_file(temp_path+i)
#                 delete_hdfs_file(temp_path+i)

        except:
            pass

        det_temp = det.select(sel_cols['DETAIL'])
        det_temp.write.option("compression","gzip").parquet(temp_path+'det_temp.parquet',compression="gzip")
        
        app.logger.info("Detail temp table written successfully")

        fd.write.option("compression","gzip").parquet(temp_path+'fd_temp.parquet',compression="gzip")
        app.logger.info("Fraud Detail temp table written successfully")

        dar_temp = dar.select(sel_cols['DETAIL_ALERTED_RULE'])
        dar_temp.write.option("compression","gzip").parquet(temp_path+'dar_temp.parquet',compression="gzip")

        app.logger.info("DAR temp table written successfully")
        
        df_temp = df.select(sel_cols['DETAIL_FLAG'])
        df_temp.write.option("compression","gzip").parquet(temp_path+'deflag_temp.parquet',compression="gzip")

        app.logger.info("Detail Flag temp table written successfully")
        
        cm_temp = cm.select(sel_cols['CARD_MASTER'])
        cm_temp.write.option("compression","gzip").parquet(temp_path+'cm_temp.parquet',compression="gzip")
        app.logger.info("Card Master temp table written successfully")
        
        cm_day_0_temp = cm_day0.select(sel_cols['CARD_MASTER'])
        cm_day_0_temp.write.option("compression","gzip").parquet(temp_path+'cm_day_0temp.parquet',compression="gzip")
        app.logger.info("Card Master temp table written successfully")


        um_temp = um.select(sel_cols['UAN_MASTER'])
        um_temp.write.option("compression","gzip").parquet(temp_path+'um_temp.parquet',compression="gzip")
        
        app.logger.info("UAN Master temp table written successfully")


        del det,fd,dar,df,cm,um

        det_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'det_temp.parquet')
        
        app.logger.info(det_temp.count())

        app.logger.info("All tables read")

        det_23 = det_rec_src_id_2_3_join(det_temp)               ## joining recsrcid 2 & 3 to map retlid

        det_23 = det_23.dropDuplicates(['SD_TIEBREAKER'])

        app.logger.info("Detail Recsrcid 2 and 3 joined")

        det_23.write.option("compression","gzip").parquet(temp_path+'det_temp_23.parquet',compression="gzip")


        det_23 = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'det_temp_23.parquet')
        
        app.logger.info(det_23.count())
        
        fd_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'fd_temp.parquet')
        dar_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'dar_temp.parquet')
        df_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'deflag_temp.parquet')
        cm_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'cm_temp.parquet')
        cm_day_0_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'cm_day_0temp.parquet')
        um_temp = spark.read.format('parquet').option("inferSchema","true").load(temp_path+'um_temp.parquet')

        # os.system('hdfs dfs -rm -R -skipTrash det_temp.parquet')+
        app.logger.info("Data loaded")

        fd_df_join = fraud_df_join(fd_temp,df_temp,marktype_li)                           ## removing cross sell rows from fd
        app.logger.info("Fraud Detail and Detail Flag joined")
        
        det_fd = det_fd_join(det_23,fd_df_join)

        app.logger.info("Detail and Fraud Detail joined")

        det_dar = det_dar_join(det_fd,dar_temp,business_rules)

        app.logger.info("Detail and DAR joined")
        
        sm_pan_li = cm_temp.select('SM_PAN').collect()
        sm_pan_li = [s['SM_PAN'] for s in sm_pan_li]
        
        cm_temp_new = cm_temp.select(['SM_PAN'])
        cm_temp_new = cm_temp_new.withColumnRenamed('SM_PAN','SM_PAN_N')
        cm_temp_new = cm_temp_new.withColumn('new_flag',lit(1))
        
        cm_temp_join = cm_day_0_temp.join(cm_temp_new,cm_day_0_temp.SM_PAN==cm_temp_new.SM_PAN_N,how='left')
        cm_temp_join = cm_temp_join.fillna({'new_flag':0})
        cm_temp_join_old = cm_temp_join.filter(cm_temp_join.new_flag==0)
        cm_temp_new = cm_temp.union(cm_temp_join_old.select(cm_temp.columns))
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(temp_path+'cm_temp_join.parquet',kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(temp_path+'cm_temp_join.parquet')
        
#         delete_hdfs_file(temp_path+'cm_temp_join.parquet')
        
        cm_temp_new.write.parquet(temp_path+'cm_temp_join.parquet')
        
        cm_temp_new = spark.read.parquet(temp_path+'cm_temp_join.parquet')
        det_cm = det_cm_join(det_dar,cm_temp_new)
        det_um = det_um_join(det_cm,um_temp)

        app.logger.info("Detail and master tables joined")

        det_final = det_um.dropDuplicates(['SD_TIEBREAKER'])


#         det_final_sub = get_relavant_date_range_df(det_final,'DD_DATE',strtdate,enddate)
        
        app.logger.info(det_final.count())
        
        
#         ## final hdfs path where monthly tables needed to be stored
        final_root_path = conf['intermediary_path']

        
        name_of_file = "All_tables_join_table_W"

        final_path = write_weekly_agg_intermediary_tables(final_root_path,name_of_file,det_final)
        app.logger.info('saving parquet: ')
        app.logger.info(final_path)
        

        app.logger.info("done")

        del det_23,fd_df_join,det_fd,det_cm,det_um,det_final

        temp_tables_li = ['det_temp.parquet','det_temp_23.parquet','fd_temp.parquet','dar_temp.parquet','deflag_temp.parquet','cm_temp.parquet','um_temp.parquet','cm_temp_join.parquet','cm_day_0temp.parquet']

        for i in temp_tables_li:
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(temp_path+i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(temp_path+i)
            
        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        

    except Exception as e:
        tb_exc_type, exc_obj, exc_tb = sys.exc_info()
        tb_fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        tb_exc_val = "Exception occured : " + str(tb_exc_type) + " " + str(tb_fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(tb_exc_val)
        resp = {"status": 400, "Error": str(tb_exc_val), "output_table_path": "NA"}
    if sc is not None:
        sc.stop()
    if sql_conn is not None:
        sql_conn.close()
        
    out = insert_weekly_agg_pipeline_status("Data_ingestion_tables_join",resp["output_table_path"],resp["Error"])
    app.logger.info(out)
        
    return resp

class AllTablesJoin(Resource):
    def post(self):
        resp = join_all_tables()
        return resp

api.add_resource(AllTablesJoin,'/', '/all_tables_join')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9000", debug=False)