# encoding : utf-8 
# Author : B Ravikanth
# Last modified Date : 30-06-2022


import os
import warnings

warnings.filterwarnings('ignore')

from pyspark.sql.types import IntegerType, StringType
import pyspark.sql.functions as f
import json
import pickle
from geopy.distance import geodesic
from SparkUtils.spark_utils import create_spark_context, read_table, delete_hdfs_file, \
    freq_loc, prev_field, join_temp_tables, write_final_df, exception_block, get_relavant_date_range_df

from DataBaseUtils.weekly_agg_pipeline_queries import read_derived_table_status
import logging
from flask import Flask, jsonify
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from ATM_additional_aggregates_New import read_derived_table
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)
csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

def clean_post_cde_rem_char(sd_term_postal_cde, country_type):
    postal_cde_clean = "NA"

    if (country_type != 'Domestic') and (sd_term_postal_cde is not None):
        sd_term_postal_cde = sd_term_postal_cde.strip()
        postal_cde_clean = "".join([m for m in sd_term_postal_cde if m.isdigit()])
        len_post_cde = len(postal_cde_clean)
        if (len_post_cde == 6) and (postal_cde_clean[0] == "0"):
            postal_cde_clean = "NA"
        if len_post_cde > 6:
            sub_str = postal_cde_clean[:len_post_cde - 6]
            check_z = '0' * (len_post_cde - 6)
            if (sub_str == check_z) and (postal_cde_clean[len_post_cde - 6:][0] != '0'):
                postal_cde_clean = postal_cde_clean[len_post_cde - 6:]
    
    return postal_cde_clean


def check_postal_cde(postal_cde_cleaned, country_type, post_cde_dict):
    ret_val = postal_cde_cleaned

    if country_type == 'Domestic':
        pc_len = len(postal_cde_cleaned)
        if (pc_len == 6) and (postal_cde_cleaned not in post_cde_dict.keys()):
            ret_val = 'NA'
            
    return ret_val


def locmapping(x, y):
    ret_val = 0
    
    if len(x) > 0:
        y = y.strip()
        x = [i.strip() for i in x]
        if y in x:
            ret_val = 1

    return ret_val


def fill_postal_cde(sd_term_city, postal_cde_cleaned, country_type, city_post_cdes_dict):
    ret_val = postal_cde_cleaned

    if (country_type == 'Domestic') and (postal_cde_cleaned == 'NA'):
        if sd_term_city in city_post_cdes_dict.keys():
            ret_val = city_post_cdes_dict[sd_term_city]
        elif 'BANGALORE' in sd_term_city:
            ret_val = '560001'
        elif 'MUM' in sd_term_city:
            ret_val = '400004'
        elif 'DEL' in sd_term_city:
            ret_val = '110003'
    
    return ret_val


def fill_lat_long(postal_cde_cleaned, country_type, post_cde_dict):
    ret_val = 'NA-NA'

    if (country_type == 'Domestic') and (postal_cde_cleaned in post_cde_dict.keys()):
        ret_val = post_cde_dict[postal_cde_cleaned]

    return ret_val


def distance_prevloc(loc1, loc2):
    ret_val = -1
    if loc1 != 'NA-NA' and loc2 != 'NA-NA':
        lat1 = loc1.split('-')[0]
        long1 = loc1.split('-')[1]
        lat2 = loc2.split('-')[0]
        long2 = loc2.split('-')[1]
        l1 = (float(lat1), float(long1))
        l2 = (float(lat2), float(long2))

        d = geodesic(l1, l2).km

        ret_val = int(d)

    return ret_val


# @app.route('/loc_aggregates', methods=["POST"])
def location_aggregates():
    sc = None
    try:
        config_json_path = curr_dir + "/config/location_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)

        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
            
        spark, sc = create_spark_context(conf, conf["appName"])

        ## providing spark configuration No. of executors,executor memory etc.,
        temp_path = conf["temp_path"]
       
        req_cols = conf["req_cols"]
        
        post_cde_dict_path = curr_dir + conf['postal_cde_dict_path']
        city_post_cdes_dict_path = curr_dir + conf['city_pst_cde_fill_dict_path']

        post_cde_dict = pickle.load(open(post_cde_dict_path, 'rb'))
        city_post_cdes_dict = pickle.load(open(city_post_cdes_dict_path, 'rb'))
        
        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)

        app.logger.info("Data read")
        

        ddf2 = df3.withColumn("sd_pan_linked", df3["SD_PAN"])

        loc_temp_file = temp_path + 'loctemp.parquet'

#         delete_hdfs_file(loc_temp_file)
        
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(loc_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(loc_temp_file)

        ddf2.write.parquet(loc_temp_file)

        app.logger.info("Locationtemp table created")

        ###### LOADING SAVED TEMP DATA  #########
        df = read_table(spark, loc_temp_file)

        app.logger.info("Locationtemp table read")
        app.logger.info(df.count())
        added_cols = []

        strip_df = f.udf(lambda x: str.upper(x.strip()) if x != None else "NA", StringType())
        df = df.withColumn('SD_TERM_CITY', strip_df('SD_TERM_CITY'))
        df = df.withColumn('SD_TERM_ST', strip_df('SD_TERM_ST'))
        df = df.withColumn('SD_TERM_CNTRY', strip_df('SD_TERM_CNTRY'))
        df = df.withColumn('SD_TERM_POSTAL_CDE', strip_df('SD_TERM_POSTAL_CDE'))
        df = df.withColumn('SD_TERM_ID', strip_df('SD_TERM_ID'))

        
        

        app.logger.info("String cols stripped")

        ############### USER DEFINED FUNCTIONS  FOR  POSTAL CODE AND LOCATION MAPPING AGGREGATES ########################
        clean_post_cde_rem_char_udf = f.udf(clean_post_cde_rem_char, StringType())
        distance_prevloc_udf = f.udf(distance_prevloc, IntegerType())
        fill_postal_cde_udf = f.udf(lambda x, y, z: fill_postal_cde(x, y, z, city_post_cdes_dict), StringType())
        fill_lat_long_udf = f.udf(lambda x, y: fill_lat_long(x, y, post_cde_dict), StringType())
        check_postal_cde_udf = f.udf(lambda x, y: check_postal_cde(x, y, post_cde_dict), StringType())
        locmapping_udf = f.udf(locmapping, IntegerType())

        df = df.withColumn('postal_cde_cleaned', clean_post_cde_rem_char_udf('SD_TERM_POSTAL_CDE', 'CntryType'))
        df = df.withColumn('postal_cde_cleaned', check_postal_cde_udf('postal_cde_cleaned', 'CntryType'))
        df = df.withColumn('postal_cde_cleaned', fill_postal_cde_udf('SD_TERM_CITY', 'postal_cde_cleaned', 'CntryType'))
        df = df.withColumn('loc_lat_long', fill_lat_long_udf('postal_cde_cleaned', 'CntryType'))

        df = df.withColumn('user_postal_cde_cleaned', clean_post_cde_rem_char_udf('SM_USER_POSTAL_CDE_um', 'CntryType'))
        df = df.withColumn('user_postal_cde_cleaned', check_postal_cde_udf('user_postal_cde_cleaned', 'CntryType'))
        df = df.withColumn('user_loc_lat_long', fill_lat_long_udf('user_postal_cde_cleaned', 'CntryType'))

        df = df.withColumn('distance_homeloc', distance_prevloc_udf('loc_lat_long', 'user_loc_lat_long'))

        ############################################################################
        df2 = df.withColumn('date_timestamp', df.DD_DATE.astype('Timestamp').cast('long'))

        app.logger.info("postal_cde_cleaned")

        df2 = prev_field(df2, ['SD_PAN'], 'date_timestamp', 'loc_lat_long', 1, 'prev_lat_long', f.lag, 'string')
        fill_na_cols = {'prev_lat_long': 'NA-NA'}
        df2 = df2.na.fill(fill_na_cols)
        df2 = df2.cache()
        df2 = df2.persist()
        df2 = df2.withColumn('distance_prevloc', distance_prevloc_udf('loc_lat_long', 'prev_lat_long'))
        df2 = freq_loc(df2, ['SD_PAN'], 'date_timestamp', 'postal_cde_cleaned', 30 * 24 * 60 * 60, 'tmp_col',
                       f.collect_set, 'set')
        df2 = df2.withColumn('postal_code_mapping_prev30days', locmapping_udf('tmp_col', 'postal_cde_cleaned'))
        df2 = freq_loc(df2, ['SD_PAN'], 'date_timestamp', 'SD_TERM_CITY', 30 * 24 * 60 * 60, 'tmp_col', f.collect_set,
                       'set')
        df2 = df2.withColumn('loc_city_mapping_prev30days', locmapping_udf('tmp_col', 'SD_TERM_CITY'))

        app.logger.info("loc_city_mapping_prev30days")
        df2 = freq_loc(df2,['SD_PAN'],'date_timestamp','SD_TERM_ID',60*24*60*60,'tmp_col',f.collect_set,'set')
        df2 = df2.withColumn('freq_merchant_mapping_prev60days',locmapping_udf(f.col('tmp_col'),f.col('SD_TERM_ID')))
        add_cols_freq_merchant = ["freq_merchant_mapping_prev60days"]

        ########################### AGGREGATES CREATION ################################

        tempudf = f.udf(lambda x, y: 1 if x == y else 0, IntegerType())

        add_dist_homeloc = ["distance_homeloc"]
        add_cols_postlcde_dis = ['distance_prevloc', 'postal_code_mapping_prev30days', 'loc_city_mapping_prev30days']
        df2 = prev_field(df2, groupcol=['SD_PAN', 'ChannelType'], ordercol='date_timestamp', reqcol='SD_TERM_NAME_LOC',
                         nlag=1, newcolname='temploc', func1=f.lag, coltype='string')
        df2 = df2.withColumn('prev_term_name_loc_matching', tempudf('SD_TERM_NAME_LOC', 'temploc'))
        df2 = df2.drop('temploc')
        df2 = prev_field(df2, groupcol=['SD_PAN'], ordercol='date_timestamp', reqcol='postal_cde_cleaned', nlag=1,
                         newcolname='temppostcde', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_postalcde_matching', tempudf('postal_cde_cleaned', 'temppostcde'))
        df2 = df2.drop('temppostcde')
        df2 = prev_field(df2, groupcol=['SD_PAN'], ordercol='date_timestamp', reqcol='SD_TERM_CITY', nlag=1,
                         newcolname='tempcity', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_term_city_matching', tempudf('SD_TERM_CITY', 'tempcity'))
        df2 = df2.drop('tempcity')
        df2 = prev_field(df2, groupcol=['SD_PAN'], ordercol='date_timestamp', reqcol='SD_TERM_ST', nlag=1,
                         newcolname='tempst', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_term_state_matching', tempudf('SD_TERM_ST', 'tempst'))
        df2 = df2.drop('tempst')
        df2 = prev_field(df2, groupcol=['SD_PAN'], ordercol='date_timestamp', reqcol='SD_TERM_CNTRY', nlag=1,
                         newcolname='tempcntry', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_term_cntry_matching', tempudf('SD_TERM_CNTRY', 'tempcntry'))
        df2 = df2.drop('tempcntry')
        ############### ADDING COLUMNS BASED ON CARD LOCATION #############
        add_cols_loc_card = ['prev_term_name_loc_matching', 'prev_postalcde_matching', 'prev_term_city_matching',
                             'prev_term_state_matching', 'prev_term_cntry_matching']
        df2 = prev_field(df2, groupcol=['SD_PAN', 'ChannelType'], ordercol='date_timestamp', reqcol='SD_TERM_CNTRY',
                         nlag=1, newcolname='tempcntry', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_term_cntry_matching_channelwise', tempudf('SD_TERM_CNTRY', 'tempcntry'))
        df2 = df2.drop('tempcntry')
        df2 = prev_field(df2, groupcol=['SD_PAN', 'ChannelType'], ordercol='date_timestamp', reqcol='SD_TERM_CITY',
                         nlag=1, newcolname='tempcity', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_term_city_matching_channelwise', tempudf('SD_TERM_CITY', 'tempcity'))
        df2 = df2.drop('tempcity')
        df2 = prev_field(df2, groupcol=['SD_PAN', 'ChannelType'], ordercol='date_timestamp', reqcol='SD_TERM_ST',
                         nlag=1, newcolname='tempst', func1=f.lag, coltype='string')
        df2 = df2.withColumn('prev_term_state_matching_channelwise', tempudf('SD_TERM_ST', 'tempst'))
        df2 = df2.drop('tempst')
        ########################### ADD COLUMNS BASED ON LOCATION OF CARD AND CHANNEL WISE ##############################
        add_cols_loc_card_ch = ['prev_term_cntry_matching_channelwise', 'prev_term_city_matching_channelwise',
                                'prev_term_state_matching_channelwise']
        df2 = prev_field(df2, groupcol=['SD_PAN'], ordercol='date_timestamp', reqcol='sd_resp_cde_type', nlag=1,
                         newcolname='temprespcde', func1=f.lag, coltype='string')

        tempudf = f.udf(lambda x: 0 if x == 'Approved' else 1, IntegerType())

        df2 = df2.withColumn('prev_tran_declined_flag_card', tempudf('temprespcde'))
        df2 = df2.drop('temprespcde')
        df2 = prev_field(df2, groupcol=['SD_PAN', 'SD_TERM_NAME_LOC'], ordercol='date_timestamp',
                         reqcol='sd_resp_cde_type', nlag=1, newcolname='temprespcde', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_tran_declined_flag_loc_card', tempudf('temprespcde'))
        df2 = df2.drop('temprespcde')

        df2 = prev_field(df2, groupcol=['SD_TERM_NAME_LOC'], ordercol='date_timestamp', reqcol='sd_resp_cde_type',
                         nlag=1, newcolname='temprespcde', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_tran_declined_flag_termloc', tempudf('temprespcde'))
        df2 = df2.drop('temprespcde')

        df2 = prev_field(df2, groupcol=['SD_PAN', 'SD_RETL_ID'], ordercol='date_timestamp', reqcol='sd_resp_cde_type',
                         nlag=1, newcolname='temprespcde', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_tran_declined_flag_mer_card', tempudf('temprespcde'))
        df2 = df2.drop('temprespcde')

        df2 = prev_field(df2, groupcol=['SD_RETL_ID'], ordercol='date_timestamp', reqcol='sd_resp_cde_type', nlag=1,
                         newcolname='temprespcde', func1=f.lag, coltype='string')

        df2 = df2.withColumn('prev_tran_declined_flag_mer', tempudf('temprespcde'))
        df2 = df2.drop('temprespcde')

        ################## ADDING COLUMNS BASED ON TRNXN"S DECLINED CARDS ###################################

        add_cols_trandec_card = ['prev_tran_declined_flag_card', 'prev_tran_declined_flag_loc_card',
                                 'prev_tran_declined_flag_mer_card']

        add_cols_othr_dec = ['prev_tran_declined_flag_mer', 'prev_tran_declined_flag_termloc']
        
        
        ############### ADDING COLUMNS BASED ON CARD LOCATION #############

        df2 = prev_field(df2,groupcol=['SD_PAN','ChannelType'],ordercol='date_timestamp',reqcol='SD_RETL_SIC_CDE',nlag=1,newcolname='tempsic',func1=f.lag,coltype='string')
        tempudf = f.udf(lambda x,y:1 if x==y  else 0,IntegerType())
        df2 = df2.withColumn('prev_mcctype_matching_channelwise',tempudf('SD_RETL_SIC_CDE','tempsic'))
        df2 = df2.drop('tempsic')
        app.logger.info("Adding feature - prev_mcctype_matching_channelwise")
        ########################### ADD COLUMNS BASED ON LOCATION OF CARD AND CHANNEL WISE ##############################        
        df2 = prev_field(df2,groupcol=['SD_PAN','ChannelType'],ordercol='date_timestamp',reqcol='sd_resp_cde_type',nlag=1,newcolname='temprespcde',func1=f.lag,coltype='string')
        tempudf = f.udf(lambda x:0 if x=='Approved'  else 1,IntegerType())
        df2 = df2.withColumn('prev_tran_declined_flag_channelwise',tempudf('temprespcde'))
        app.logger.info("Creating feature - prev_tran_declined_flag_channelwise")
###########################################
        
        df2 = prev_field(df2,groupcol=['SD_PAN','SD_RETL_SIC_CDE'],ordercol='date_timestamp',reqcol='sd_resp_cde_type',nlag=1,newcolname='temprespcde',func1=f.lag,coltype='string')
        tempudf = f.udf(lambda x:0 if x=='Approved'  else 1,IntegerType())
        df2 = df2.withColumn('prev_tran_declined_flag_mcc_card',tempudf('temprespcde'))
        app.logger.info("Creating final feature - prev_tran_declined_flag_mcc_card")
        
        ################## ADDING COLUMNS BASED ON TRNXN"S DECLINED CARDS ###################################
        
        add_cols_mcc_card = ['prev_tran_declined_flag_mcc_card', 'prev_tran_declined_flag_channelwise', 'prev_mcctype_matching_channelwise']


        ########################### LIST OF ALL ADDED  COLUMNS #############################################
        added_cols = [add_dist_homeloc, add_cols_loc_card_ch, add_cols_postlcde_dis, add_cols_loc_card,
                      add_cols_trandec_card, add_cols_othr_dec, add_cols_mcc_card,add_cols_freq_merchant]

        delete_hdfs_file(conf['temp_tables_path'] + 'loc_temp_*.parquet')

        final_path = conf['temp_tables_path']
        df_list = []
        i = 21
        for add_col in added_cols:
            app.logger.info(add_col)
            nc = ['SD_TIEBREAKER', 'DD_DATE'] + add_col
            temp_df = df2.select(nc)
            temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)
            par_path = final_path + str(i) + '.parquet'
            delete_hdfs_file(par_path)
            temp_df2.write.parquet(par_path)
            df_list.append(par_path)
            del temp_df, temp_df2
            i = i + 1

        df1 = join_temp_tables(df_list, spark)

        name_of_file = "Location_agg_ATM_table_W"
        
        df1 = df1.dropDuplicates(["SD_TIEBREAKER"])

        final_path = write_final_df(df1, strtdate, enddate, name_of_file, conf)

        for i in df_list:
#             delete_hdfs_file(i)
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)

#         delete_hdfs_file(loc_temp_file)
        
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(loc_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(loc_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e, app)

    if sc is not None:
        sc.stop()

    ins_status = insert_weekly_agg_pipeline_status("Loc_agg_creation",resp["output_table_path"],resp["Error"][:250])
    return resp


class LocationAggApi(Resource):
    def post(self):
        resp = location_aggregates()
        return jsonify(resp)
        
api.add_resource(LocationAggApi,'/', '/loc_aggregates')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9004", debug=False)
