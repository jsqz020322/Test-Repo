# encoding : utf-8 
# Author : BVSS Ravikanth
# Last modified Date : 13-07-2022

import datetime
import os
import warnings

import pandas as pd
import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType, StringType, DoubleType

warnings.filterwarnings("ignore")
import json
from datetime import timedelta
import pandas.io.sql as psql

from SparkUtils.spark_utils import create_spark_context, grouped_agg_days_temporal, \
    write_weekly_agg_intermediary_tables, exception_block
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from DataBaseUtils.db_utils import mysql_conn
import logging
from flask import Flask, jsonify
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])
curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

config_json_path = curr_dir + "/config/derived_cols.json"
conf = json.load(open(config_json_path, "r"))
app.logger.info(conf)


ex_path = curr_dir + conf["blk_cde_master_path"]

blk_cde_df = pd.read_excel(ex_path)
blk_cde_list = blk_cde_df[['Block code', 'Narration']].values.tolist()



# udf for pin entry domestic transaction


def pin_entered_dom_flag(sd_pin_ind):
    ret_val = "NA"
    try:
        if int(sd_pin_ind) == 1:
            ret_val = 'entered'
        elif int(sd_pin_ind) == 0:
            ret_val = 'notentered'
    except Exception as e:
        print("Error in func pin_entered_dom_flag : ",str(e))

    return ret_val


def secured_or_not(channel_type, sd_ecom_flag, nd_cavv_avv, conf):
    ret_val = "NA"
    try:
        if "CNP" in channel_type:
            nd_cavv_avv = str(nd_cavv_avv)
            if (nd_cavv_avv in conf["ecom_sec_flag_li"]) and (sd_ecom_flag in conf["ecom_sec_flag_li"]):
                ret_val = "Secured"
            else:
                ret_val = "Unsecured"
    except Exception as e:
        print("Error in func secured_or_not : ",str(e))
    return ret_val


def cntry_type(sd_term_cntry):
    ret_val = 'Domestic'
    try:
        if (sd_term_cntry.strip() == '') or (sd_term_cntry.strip() == 'IN'):
            ret_val = 'Domestic'
        else:
            ret_val = "International"
    except Exception as e:
        print("Error in func cntry_type : ",str(e))
    return ret_val


def token_service_flg(sd_prod_ind, sd_retl_sic_cde, sd_pt_entry_mde, sd_sec_act_num, conf):
    ret_val = "NA"
    try:
        if (sd_prod_ind == "02" and sd_retl_sic_cde not in conf["atm_sd_retl_li"] and sd_pt_entry_mde[:2] in conf[
            "pos_sd_entry_mde_li"]):
            if (sd_pt_entry_mde in conf["tokenpay_entry_mde_li"]) and (sd_sec_act_num in conf["spay_acct_li"]):
                ret_val = "TokenService_SamsungPay"
            elif (sd_pt_entry_mde in conf["tokenpay_entry_mde_li"]) and (sd_sec_act_num in conf["gpay_acct_li"]):
                ret_val = "TokenService_GPay"
            elif (sd_pt_entry_mde in conf["tokenpay_entry_mde_li"]) and (sd_sec_act_num in conf["jpay_acct_li"]):
                ret_val = "TokenService_JioPay"
    except Exception as e:
        print("Error in func token_service_flg : ",str(e))
    return ret_val


def msg_type(sd_msg_typ):
    ret_val = "NA"
    try:
        if sd_msg_typ.strip() == "0200":
            ret_val = "prmRT"
        elif sd_msg_typ.strip() == "0210":
            ret_val = "prmNRTonly"
        elif sd_msg_typ.strip() == "0220":
            ret_val = "AdviceAndInformationalTrans"
        elif sd_msg_typ.strip() == "0420":
            ret_val = "ReversalTrans"
    except Exception as e:
        print("Error in func msg_type : ",str(e))
    return ret_val


# Metro / Non-Metro feature:

def metro_city(sd_term_name_loc):
    ret_val = "Non-Metro_city"
    try:
        if sd_term_name_loc[:1] == "+":
            ret_val = "Metro_city"
        else:
            ret_val = "Non-Metro_city"
    except Exception as e:
        print("Error in func metro_city : ",str(e))
    return ret_val



## Card Entry Mode function:
def card_entry_mde(sd_pt_srv_entry_mde, sd_emv_user_filler, sd_resp_cde, sd_auth_src):
    ret_val = "NA"
    try:
        if ((sd_pt_srv_entry_mde.strip() in ["020", "021", "022"]) and (
                sd_emv_user_filler.strip()[:2] in ["10", "12", "15", "16", "18", "19"])):
            ret_val = "fallbacktransactions"
        elif ((sd_pt_srv_entry_mde.strip() in ["020", "021", "022", "901"]) and (
                sd_emv_user_filler.strip()[:2] not in ["10", "12", "15", "16", "18", "19"])):
            ret_val = "magstripetransn"
        elif sd_pt_srv_entry_mde.strip() in ["050", "051", "052"]:
            ret_val = "emvcomplianttransn"
        elif sd_pt_srv_entry_mde.strip()[:2] in ["07", "09"]:
            ret_val = "contactlesstransn"
    except Exception as e:
        print("Error in func card_entry_mde : ",str(e))
    return ret_val


## Account type function:
def acc_type(sd_pri_acct_type):
    ret_val = "NA"
    try:
        if sd_pri_acct_type.strip() == "011":
            ret_val = "savings"
        elif sd_pri_acct_type.strip() == "001":
            ret_val = "current"
        elif sd_pri_acct_type.strip() == "000":
            ret_val = "default"
        elif sd_pri_acct_type.strip() == "031":
            ret_val = "credit"
    except Exception as e:
        print("Error in func acc_type : ",str(e))
    return ret_val


## cvv2 present flag function:

def cvv2_present_flg(sd_cvd_present_flag):
    ret_val = "notpresent"
    try:
        if int(sd_cvd_present_flag) == 1:
            ret_val = "present"
        else:
            ret_val = "notpresent"
    except Exception as e:
        print("Error in func cvv2_present_flg : ",str(e))
    return ret_val


## cvv2 verified flag function:

def cvv2_verified_flg(sd_crd_verify_flag):
    ret_val = "NA"
    try:
        if sd_crd_verify_flag.strip() == "Y":
            ret_val = "verified"
        elif sd_crd_verify_flag.strip() == "D":
            ret_val = "invalid"
        elif sd_crd_verify_flag.strip() == "C":
            ret_val = "notvalidbutallowed"
        elif sd_crd_verify_flag.strip() == "":
            ret_val = "notverified"
    except Exception as e:
        print("Error in func cvv2_verified_flg : ",str(e))
    return ret_val


## payment gateway function:

def payment_gateway(sd_term_id):
    ret_val = "Others"
    try:
        if sd_term_id is None:
            sd_term_id = "NA"
        sd_term_id = sd_term_id.strip()
        if sd_term_id in ["78001922", "78003890"]:
            ret_val = "amazonIVR"
        elif sd_term_id in ["70008442", "78200784", "89050526"]:
            ret_val = "flipkartIVR"
        elif sd_term_id in ["78003628"]:
            ret_val = "bpsbillpayIVR"
        elif sd_term_id in ["70025623", "70025624"]:
            ret_val = "paytmwalletexpireddec19"
        elif sd_term_id in ["70020753", "70025453", "70025752"]:
            ret_val = "paytmIVRtravel"
        elif sd_term_id in ["70020747", "70025454", "70025754"]:
            ret_val = "paytmIVRutility"
        elif sd_term_id in ["70020748", "70025447", "70025747"]:
            ret_val = "paytmIVRecommerce"
        elif sd_term_id in ["70021926", "70020806"]:
            ret_val = "paytmIVRinsurance"
        elif sd_term_id in ["70022015", "70020754"]:
            ret_val = "paytmIVReducation"
        elif sd_term_id in ["70020752"]:
            ret_val = "paytmIVRentertainment"
        elif sd_term_id in ["70020757"]:
            ret_val = "paytmIVRrecharge"
        elif sd_term_id in ["70002093", "70027569"]:
            ret_val = "MMT"
        elif sd_term_id in ["70028329"]:
            ret_val = "IBIBO"
        else:
            ret_val = "Others"
    except Exception as e:
        print("Error in func payment_gateway : ",str(e))
    return ret_val


def tranfunc(sd_acq_inst_id_num, conf):
    ret_val = "NA"
    try:
        if sd_acq_inst_id_num in conf["on_us_acq_li"]:
            ret_val = "ON-US"
        elif sd_acq_inst_id_num not in conf["on_us_acq_li"]:
            ret_val = "REMOTE ON-US"
    except Exception as e:
        print("Error in func tranfunc : ",str(e))
    return ret_val


def amount_bins(md_tran_amt1, sd_monetary):
    ret_val = "NA"
    try:
        if sd_monetary == 'M':
            if md_tran_amt1 <= 0:
                ret_val = "0"
            elif md_tran_amt1 <= 1:
                ret_val = "0_1"
            elif 1 < md_tran_amt1 <= 500:
                ret_val = "1_500"
            elif 500 < md_tran_amt1 <= 2000:
                ret_val = "501_2000"
            elif 2000 < md_tran_amt1 <= 5000:
                ret_val = "2001_5000"
            elif 5000 < md_tran_amt1 <= 10000:
                ret_val = "5001_10000"
            elif 10000 < md_tran_amt1 <= 20000:
                ret_val = "10001_20000"
            elif 20000 < md_tran_amt1 <= 30000:
                ret_val = "20001_30000"
            elif 30000 < md_tran_amt1 <= 50000:
                ret_val = "30001_50000"
            elif 50000 < md_tran_amt1 <= 100000:
                ret_val = "50001_100000"
            elif 100000 < md_tran_amt1 <= 500000:
                ret_val = "100001_500000"
            elif 500000 < md_tran_amt1 <= 1000000:
                ret_val = "500001_1000000"
            elif md_tran_amt1 > 1000000:
                ret_val = "gt10,00,000"
    except Exception as e:
        print("Error in func amount_bins : ",str(e))
    return ret_val


def bal_not_available(md_tran_amt1, md_cust_tran_amt1, sd_monetary):
    ret_val = "NA"
    try:
        if sd_monetary == 'M':
            if md_cust_tran_amt1 - md_tran_amt1 >= 0:
                ret_val = "SuffBal"
            else:
                ret_val = "InSuffBal"
    except Exception as e:
        print("Error in func bal_not_available : ",str(e))
    return ret_val


def apprv_status(sd_apprv_cde):  #### Remove this field
    try:
        if (sd_apprv_cde is None) or (sd_apprv_cde.strip() == '999998'):
            ret_val = "Declined"
        else:
            ret_val = "Approved"
    except Exception as e:
        print("Error in func apprv_status : ",str(e))
    return ret_val


## fallback status udf
def fall_back_status(sd_pt_srv_entry_mode, sd_emv_user_filler):
    ret_val = 0
    try:
        if sd_pt_srv_entry_mode in ['020', '021', '022'] and sd_emv_user_filler.strip()[:2] == '15':
            ret_val = 1
        else:
            ret_val = 0
    except Exception as e:
        print("Error in func fall_back_status : ",str(e))
    return ret_val

def sd_resp_cde_type_auth_b(x):
    ret_val = "OtherDeclines"
    try:
        if x is not None:
            if (int(x) in [50, 68, 88, 218]):
                ret_val = "PRM_Declined"
            elif (int(x) in [53, 55, 67, 78, 201]):
                ret_val = "InvalidData"
            elif (int(x) in [64, 105, 150]):
                ret_val = "RestrictedCard"
            elif (int(x) in [61, 63]):
                ret_val = "WithdrawalLimitExceeded"
            elif (int(x) in [77, 216, 217]):
                ret_val = "IntlLimitExceeded_NA"
            elif (int(x) in [909, 903, 168, 162]):
                ret_val = "Pickup_Capture"
    except Exception as e:
        print("Error in func sd_resp_cde_type_auth_b : ",str(e))
    return ret_val
def sd_resp_cde_type(sd_resp_cde, sd_auth_src):
    ret_val = "OtherDeclines"
    try:
        sd_auth_src = sd_auth_src.strip()
        x = sd_resp_cde
        if (int(x) in list(range(10))):
            ret_val = "Approved"
        elif (int(x) in [51, 151, 901]):
            ret_val = "ExpiredCard"
        elif (int(x) in [58, 59, 76, 204]):
            ret_val = "InsuffFunds"
        elif (sd_auth_src == 'B') and (x != None):
            ret_val = sd_resp_cde_type_auth_b(x)
        elif (sd_auth_src == 'H') and (x != None):
            if (int(x) in [50, 56, 68]):
                ret_val = "Block_Decline_H"
            elif (int(x) in [52, 58, 78]):
                ret_val = "InvalidData"
    except Exception as e:
        print("Error in func sd_resp_cde_type : ",str(e))
    return ret_val


def entry_mde_type(sd_pt_entry_mde):  ###Need to updated as per new logic . 901 is also magstripe
    ret_val = "NA"
    try:
        if sd_pt_entry_mde in ['010', '011', '012']:
            ret_val = "cnp"
        elif sd_pt_entry_mde in ['020', '021', '022', '901']:
            ret_val = "magstripe"
        elif sd_pt_entry_mde in ['050', '051', '052']:
            ret_val = "chipvalidated"
        elif sd_pt_entry_mde in ['070', '071', '072']:
            ret_val = "contactlesscard"
    except Exception as e:
        print("Error in func entry_mde_type : ",str(e))
    return ret_val


def real_time_rule_status(sd_real_time_rule_disposition):
    ret_val = "NA"
    try:
        if sd_real_time_rule_disposition.strip() in ['A']:
            ret_val = "Authorized"
        elif sd_real_time_rule_disposition.strip() in ['R']:
            ret_val = "Allow over limit"
        elif sd_real_time_rule_disposition.strip() in ['C', 'D']:
            ret_val = "Declined"
    except Exception as e:
        print("Error in func real_time_rule_status : ",str(e))
    return ret_val


def tran_cde_type(sd_tran_cde):
    ret_val = "Others"
    try:
        if sd_tran_cde.strip() in ['17']:
            ret_val = "BalInquiry"
        elif sd_tran_cde.strip() in ['81']:
            ret_val = "PinChange"
        elif sd_tran_cde.strip() in ['85']:
            ret_val = "PinInquiry"
        elif sd_tran_cde.strip() in ['10']:
            ret_val = "Purchase"
        elif sd_tran_cde.strip() in ['13']:
            ret_val = "MailOrder"
        else:
            ret_val = "Others"
    except Exception as e:
        print("Error in func tran_cde_type : ",str(e))
    return ret_val


def hour_classify(dt_hr):
    ret_val = "earlyMrng"
    try:
        if dt_hr in [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22]:
            ret_val = "busHrs"
        elif dt_hr in [23, 0, 1]:
            ret_val = "close_midnight"
        elif dt_hr in [2, 3, 4]:
            ret_val = "lateNight"
        else:
            ret_val = "earlyMrng"
    except Exception as e:
        print("Error in func hour_classify : ",str(e))
    return ret_val


def open_market_type(uan, pan):
    ret_val = 'accountPresent'
    try:
        if (uan.strip() == pan.strip()) or len(uan.strip()) > 10:
            ret_val = 'openMarket'
    except Exception as e:
        print("Error in func open_market_type : ",str(e))
    return ret_val


def diff_days(day1, day2):
    ret_val = -1
    try:
        days = (day2 - day1).days
        if (days > 0):
            ret_val = days
    except Exception as e:
        print("Error in func diff_days : ",str(e))
    return ret_val


def crd_blk_cde(sd_fiid, sd_crd_blk_cde, blk_cde_list):
    ret_val = 'NA'
    try:
        if sd_fiid == 'HDFB':
            if sd_crd_blk_cde is None or sd_crd_blk_cde == 'P' or sd_crd_blk_cde == 'B':
                ret_val = 'CNB'
            else:
                for cde in blk_cde_list:
                    if sd_crd_blk_cde == cde[0]:
                        ret_val = cde[1]

        elif sd_fiid == 'HDFC':
            ret_val = 'NotApplicable'
    except Exception as e:
        print("Error in func crd_blk_cde : ",str(e))
    return ret_val


def crd_stat_cde(sd_fiid, sd_crd_stat, sd_crd_blk_cde):
    ret_val = "NA"
    try:
        if sd_fiid == 'HDFC':
            if sd_crd_stat == '0':
                ret_val = 'ActiveButTranNA'
            elif sd_crd_stat == '1':
                ret_val = 'Active'
            elif sd_crd_stat == '3':
                ret_val = 'Hotlisted'
            elif sd_crd_stat == 'A':
                ret_val = 'TempBlock'
            elif sd_crd_stat == 'C':
                ret_val = 'Closed'

        elif sd_fiid == 'HDFB':
            if sd_crd_blk_cde in ['P', '', 'B']:
                ret_val = 'Active'
            elif sd_crd_blk_cde in ["H", "Q"]:
                ret_val = 'TempDeliquencyBlock'
            elif sd_crd_blk_cde == 'L':
                ret_val = 'LostAndReissued'
            elif sd_crd_blk_cde == 'A':
                ret_val = 'InactiveBlock1'
            elif (sd_crd_blk_cde in ["C", "D", "E", "F", "G", "I", "J", "K", "M", "N", "O", "R", "S", "T", "U", "V", "W",
                                     "X",
                                     "Y", "Z"]):
                ret_val = 'InactiveBlock2'
    except Exception as e:
        print("Error in func crd_stat_cde : ",str(e))
    return ret_val


def acc_dormant_active(x, y):
    try:
        if (0 < x < 30) and y < 3:
            return 'd'
        else:
            return 'a'
    except Exception as e:
        print("Error in func acc_dormant_active : ",str(e))
        return 'a'

def netbanking_reg(sm_cust_mstr_fld2_cm):
    ret_val = 2
    try:
        if sm_cust_mstr_fld2_cm.strip() in ['N~Y*', 'N~N*']:
            ret_val = 0
        elif sm_cust_mstr_fld2_cm.strip() in ['Y~Y*', 'Y~N*']:
            ret_val = 1
    except Exception as e:
        print("Error in func netbanking_reg : ",str(e))
    return ret_val


def vbv_reg(sm_cust_mstr_fld2_cm):
    ret_val = 2
    try:
        if sm_cust_mstr_fld2_cm.strip() in ['N~Y*', 'Y~Y*']:
            return 0
        elif sm_cust_mstr_fld2_cm.strip() in ['Y~N*', 'N~N*']:
            return 1
    except Exception as e:
        print("Error in func vbv_reg : ",str(e))
    return ret_val


def age_bins(dm_user_pri_dob_cm, dm_user_dob_cm, dd_date):
    ret_val = "above85"
    try:
        dobdays = (dd_date - dm_user_pri_dob_cm).days
        age = dobdays / 365
        if (age <= 18):
            ret_val = "lte18"
        elif (18 < age <= 25):
            ret_val = "19-25"
        elif (25 < age <= 28):
            ret_val = "26-28"
        elif (28 < age <= 33):
            ret_val = "29-33"
        elif (33 < age <= 39):
            ret_val = "34-39"
        elif (39 < age <= 45):
            ret_val = "40-45"
        elif (45 < age <= 60):
            ret_val = "46-60"
        elif (60 < age <= 65):
            ret_val = "61-65"
        elif (65 < age <= 70):
            ret_val = "66-70"
        elif (70 < age <= 75):
            ret_val = "71-75"
        elif (75 < age <= 79):
            ret_val = "76-79"
        elif (79 < age <= 84):
            ret_val = "80-84"
        else:
            ret_val = "above85"
    except Exception as e:
        print("Error in func age_bins : ",str(e))
    return ret_val

def channel_type(sd_prod_ind, sd_ecom_flag, sd_retl_sic_code, sd_pt_entry_mde, conf):
    ret_val = "UNKNOWN"
    try:
        if ((sd_prod_ind == "01") or (
                sd_retl_sic_code in conf["atm_sd_retl_li"] and sd_pt_entry_mde[:2] in conf["atm_sd_entry_mde_li"])):
            ret_val = "ATM"
        elif (sd_prod_ind == "02" and sd_retl_sic_code not in conf["atm_sd_retl_li"] and sd_pt_entry_mde[:2] in conf[
            "pos_sd_entry_mde_li"]):
            ret_val = "POS"
        elif (sd_prod_ind == "02" and sd_ecom_flag in conf["ecom_sec_flag_li"] and sd_pt_entry_mde[:2] in conf[
            "ecom_sec_sd_entry_mde_li"]):
            ret_val = "CNP SECURED"
        elif (sd_prod_ind == "02" and sd_ecom_flag not in conf["ecom_sec_flag_li"] and sd_pt_entry_mde[:2] in conf[
            "ecom_unsec_sd_entry_mde_li"]):
            ret_val = "CNP UNSECURED"
    except Exception as e:
        print("Error in func channel_type : ",str(e))
    return ret_val


def monetary_or_not(sd_tran_cde,conf):
    ret_val = "NA"
    try:
        if (sd_tran_cde is not None) and (sd_tran_cde.strip() in (conf["non_mon_tran_cde_li"])):
            ret_val = "NM"  ##NonMonetary
        if (sd_tran_cde is not None) and (sd_tran_cde.strip() not in (conf["non_mon_tran_cde_li"])):
            ret_val = "M"  ##Monetary
    except Exception as e:
        print("Error in func monetary_or_not : ",str(e))
    return ret_val

# PRM Response Type function:

def prm_response_type(sd_msg_typ, sd_real_time_rule_disposition, nd_real_time_rule_fired, sd_resp_cde, sd_auth_src):
    ret_val = 'NA'
    try:
        if sd_real_time_rule_disposition.strip() in ["A", "R"]:
            ret_val = "prmRTapproved"
        elif ((sd_msg_typ.strip() in ["0200", "0210"]) and (
                (nd_real_time_rule_fired.strip() == "") or (nd_real_time_rule_fired.strip() == "0")) and (
                      sd_resp_cde.strip() in ["000", "001", "002", "003", "004", "005", "006", "007", "008", "009"])):
            ret_val = "prmNRTapproved"
        elif sd_real_time_rule_disposition.strip() in ["C", "D"]:
            ret_val = "prmRTdeclined"
        elif ((sd_msg_typ.strip() in ["0200", "0210"]) and (
                (nd_real_time_rule_fired.strip() != "") or (nd_real_time_rule_fired.strip() == "0"))
              and (sd_resp_cde.strip() not in ["000", "001", "002", "003", "004", "005", "006", "007", "008", "009"])):
            ret_val = "prmNRTalerted"
        elif ((sd_auth_src.strip() == "B") and (sd_resp_cde.strip() not in
                                                ["000", "001", "002", "003", "004", "005", "006", "007", "008", "009",
                                                 "050", "068", "088", "218"])):
            ret_val = "base24declined"
        elif ((sd_auth_src.strip() == "H") and (
                sd_resp_cde.strip() not in ["000", "001", "002", "003", "004", "005", "006", "007", "008", "009"])):
            ret_val = "hostdecline"
        elif ((sd_auth_src.strip() == "S") and (
                sd_resp_cde.strip() not in ["000", "001", "002", "003", "004", "005", "006", "007", "008", "009"])):
            ret_val = "standindecline"
    except Exception as e:
        print("Error in func prm_response_type : ",str(e))
    return ret_val


def pin_change_func(sd_tran_cde,sd_term_id):
    ret_val = "NA"
    try:
        if int(sd_tran_cde) == 81:
            if sd_term_id.strip()=="NB":
                ret_val = "NB_MB"
            elif sd_term_id.strip()=="IVR":
                ret_val = "IVR"
            else:
                ret_val = "physical_change"
                
    except Exception as e:
        print("Error in func pin_change_func : ",str(e))
    return ret_val


### ATM new derived features
def card_type(SD_BIN,SD_FIID):
    
    SD_BIN = str(SD_BIN).strip()
    SD_FIID = str(SD_FIID).strip()
    try :
        if SD_FIID=="HDFC":
            if SD_BIN == "421491":
                return  "Infiniti_Debit_card" 
            elif SD_BIN in ["416021","436303","421340","512967","512968","607802","652166"]:
                return "Platinum_Debit_card"
            elif SD_BIN in ["485605","541919"]:
                return "Times_Debit_Card"
            elif SD_BIN in ["435584","526099"]:
                return "Millenia_Debit_card"
            elif SD_BIN in ["405988","517725"]:
                return "Rewards_Debit_Card"
            elif SD_BIN in ["433502","533136"]:
                return "Jet_Privilage_Debit_card"
            elif SD_BIN in ["419188","531209"]:
                return "MoneyBack_Debit_card"
            elif SD_BIN == "403875":
                return "Business_Debit_card"
            elif SD_BIN =="438624":
                return "Womens_Advantage_Debit_card"
            elif SD_BIN == "652156":
                return "Rupay_Premium_Debit_Card"
            elif SD_BIN == "652400":
                return "Rupay_NRO_Debit_Card"
            else :
                return "Other_Debit_Card"
        else :
            return "CreditCard"
    except :
          return "NA"


def Limits(category,MD_CUST_TRAN_AMT1):
    if category == "Infiniti_Debit_card":
        return 200000.00
    elif category ==  "Platinum_Debit_card":
        return 100000.00
    elif category ==  "Times_Debit_Card":
        return 100000.00
    elif category ==  "Millenia_Debit_card":
        return 50000.00
    elif category ==  "Rewards_Debit_Card":
        return 50000.00
    elif category ==  "Jet_Privilage_Debit_card":
        return 100000.00
    elif category ==  "MoneyBack_Debit_card":
        return 25000.00
    elif category == "Business_Debit_card":
        return 100000.00
    elif category == "Womens_Advantage_Debit_card":
        return 25000.00
    elif category ==  "Rupay_Premium_Debit_Card":
        return 25000.00
    elif category ==  "Rupay_NRO_Debit_Card":
        return 25000.00
    elif category==  "Other_Debit_Card":
        return 25000.00
    else :
        if (MD_CUST_TRAN_AMT1)>0 :
            return (MD_CUST_TRAN_AMT1)*0.4
        else :
            return 0.0
def card_type_index(card_category):
    if card_category == 'Infiniti_Debit_card':
        return 1
    elif card_category=='Platinum_Debit_card':
        return 2
    elif card_category == 'Times_Debit_Card':
        return 3
    elif card_category == 'Millenia_Debit_card':
        return 4
    elif card_category == 'Rewards_Debit_Card':
        return 5
    elif card_category == 'Jet_Privilage_Debit_card':
        return 6
    elif card_category == 'MoneyBack_Debit_card':
        return 7
    elif card_category == 'Business_Debit_card':
        return 8
    elif card_category == 'Womens_Advantage_Debit_card':
        return 9
    elif card_category == 'Rupay_Premium_Debit_Card':
        return 10
    elif card_category == 'Rupay_NRO_Debit_Card':
        return 11
    elif card_category == 'Other_Debit_Card':
        return 12
    elif card_category == 'CreditCard':
        return 13
    else :
        return 0

def bal_amount(MD_TRAN_AMT1,MD_CUST_TRAN_AMT1,sd_monetary):
    try:
        if(sd_monetary=='M'):
            if(MD_CUST_TRAN_AMT1-MD_TRAN_AMT1>=0):
                return MD_CUST_TRAN_AMT1-MD_TRAN_AMT1
            else:
                return MD_CUST_TRAN_AMT1-MD_TRAN_AMT1
        else:
            if MD_CUST_TRAN_AMT1>0:
                return MD_CUST_TRAN_AMT1
            else :
                 return 0
    except:
        return "NA"
def bal_Amount_bins(bal_amt,sd_monetary):
    try:
        if(sd_monetary=='M'):
            if -5001<=bal_amt<0:
                return "-(0_5000)"
            elif -10001<=bal_amt<=-5001:
                return "-(5000_10000)"
            elif -30000<=bal_amt<=-10001:
                return "-(10000_30000)"
            elif -50000<=bal_amt<=-30001:
                return "-(30000_50000)"
            elif -100000<=bal_amt<=-50001:
                return "-(50000_100000)"  
            elif bal_amt <= -100001:
                return '-(gt1,00,000)'      
            elif(bal_amt==0):
                return "0"
            elif(0<bal_amt<=1):
                return "0_1"
            elif(1<bal_amt<=500):
                return "1_500"
            elif(500<bal_amt<=2000):
                return "501_2000"
            elif(2000<bal_amt<=5000):
                return "2001_5000"
            elif(5000<bal_amt<=10000):
                return "5001_10000"
            elif(10000<bal_amt<=20000): 
                return "10001_20000"
            elif(20000<bal_amt<=30000):
                return "20001_30000"
            elif(30000<bal_amt<=50000):
                return "30001_50000"
            elif(50000<bal_amt<=100000):
                return "50001_100000"
            elif(100000<bal_amt<=500000):
                return "100001_500000"
            elif(500000<bal_amt<=1000000):
                return "500001_1000000"
            elif(bal_amt>1000000):
                return "gt10,00,000"
            return "NA"
        else:
            return "NM"
    except:
        return "NA"
    
def balance_amount_bins_index(balance_amount_bins):
    if (balance_amount_bins==0):
        return 0
    elif (balance_amount_bins=="-(0_5000)"):
        return 1
    elif (balance_amount_bins=="-(5000_10000)"):
        return 2
    elif (balance_amount_bins=="-(10000_30000)"):
          return 3
    elif (balance_amount_bins=="-(30000_50000)"):
          return 4
    elif (balance_amount_bins=="-(50000_100000)"):
          return 5
    elif (balance_amount_bins=="-(gt1,00,000)"):
          return 6
    elif (balance_amount_bins=="0_1"):
          return 7
    elif (balance_amount_bins=="1_500"):
          return 8
    elif (balance_amount_bins=="501_2000"):
          return 9
    elif (balance_amount_bins=="2001_5000"):
          return 10
    elif (balance_amount_bins=="5001_10000"):
          return 11
    elif (balance_amount_bins=="10001_20000"):
          return 13
    elif (balance_amount_bins=="20001_30000"):
          return 14
    elif (balance_amount_bins=="30001_50000"):
          return 15
    elif (balance_amount_bins=="50001_100000"):
          return 16
    elif (balance_amount_bins=="100001_500000"):
          return 17
    elif (balance_amount_bins=="500001_1000000"):
          return 18
    elif (balance_amount_bins=="gt10,00,000"):
          return 19
    elif (balance_amount_bins=="NM"):
          return 20

    else :
          return 21

def derived_cols_table():
    sc = None

    try:


        sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
        app.logger.info(sql_conn)

        current_date = datetime.datetime.now()
        current_date = current_date.strftime("%Y-%m-%d")
        previous_date = datetime.datetime.now() - timedelta(days=1)
        previous_date = previous_date.strftime("%Y-%m-%d")

        query1 = """SELECT * from weekly_aggregates_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + " and Status=1  and TaskName='Data_ingestion_tables_join'"
        status_df = psql.read_sql_query(query1, sql_conn)
        status_df = status_df.sort_values(by=['CreatedTime'], ascending=False).reset_index(drop=True)
        app.logger.info(status_df.loc[0])

        ini_path = status_df.loc[0]['OutputTablePath']
        app.logger.info(ini_path)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        spark, sc = create_spark_context(conf, conf["appName"])
        app.logger.info("Spark context created")

        pin_entered_dom_flag_udf = f.udf(pin_entered_dom_flag, StringType())
        
        
        
        channeltype_udf = f.udf(lambda a, b, c, d: channel_type(a, b, c, d, conf), StringType())
        monetary_or_not_udf = f.udf(lambda x: monetary_or_not(x, conf), StringType())
        secured_or_not_udf = f.udf(lambda a, b, c: secured_or_not(a, b, c, conf), StringType())
        cntryfunc = f.udf(cntry_type, StringType())
        msg_type_udf = f.udf(msg_type, StringType())
        metro_city_udf = f.udf(metro_city, StringType())
        prm_response_type_udf = f.udf(prm_response_type, StringType())
        card_entry_mde_udf = f.udf(card_entry_mde, StringType())
        acc_type_udf = f.udf(acc_type, StringType())
        cvv2_present_flg_udf = f.udf(cvv2_present_flg, StringType())
        cvv2_verified_flg_udf = f.udf(cvv2_verified_flg, StringType())
        payment_gateway_udf = f.udf(payment_gateway, StringType())
        trancfunc_udf = f.udf(lambda x: tranfunc(x, conf), StringType())
        amount_bins_udf = f.udf(amount_bins, StringType())
        bal_not_available_udf = f.udf(bal_not_available, StringType())
        apprv_status_udf = f.udf(apprv_status, StringType())
        fall_back_status_udf = f.udf(fall_back_status, IntegerType())
        sd_resp_cde_type_udf = f.udf(sd_resp_cde_type, StringType())
        entry_mde_type_udf = f.udf(entry_mde_type, StringType())
        real_time_rule_status_udf = f.udf(real_time_rule_status, StringType())
        tran_cde_type_udf = f.udf(tran_cde_type, StringType())
        hour_classify_udf = f.udf(hour_classify, StringType())
        open_market_type_udf = f.udf(open_market_type, StringType())
        diff_days_udf = f.udf(diff_days, IntegerType())
        crd_blk_cde_udf = f.udf(lambda x, y: crd_blk_cde(x, y, blk_cde_list), StringType())
        crd_stat_cde_udf = f.udf(crd_stat_cde, StringType())
        acc_dormant_active_udf = f.udf(acc_dormant_active, StringType())
        netbanking_reg_udf = f.udf(netbanking_reg, IntegerType())
        vbv_reg_udf = f.udf(vbv_reg, IntegerType())
        age_bins_udf = f.udf(age_bins, StringType())
        token_service_flg_udf = f.udf(lambda a, b, c, d: token_service_flg(a, b, c, d, conf), StringType())

        df = spark.read.format('parquet') \
            .option("inferSchema", "true") \
            .load(ini_path)

        ddf3 = df.withColumn("DM_USER_DOB_um", df["DM_USER_PRI_DOB_cm"])

        app.logger.info("Data read")
        app.logger.info(ddf3.count())
        
        
        ddf3 = ddf3.withColumn('prm_response_type',prm_response_type_udf(f.col('SD_MSG_TYP'), f.col('SD_REAL_TIME_RULE_DISPOSITION'),f.col('ND_REAL_TIME_RULE_FIRED'), f.col('SD_RESP_CDE'),f.col('SD_AUTH_SRC')))

        ddf3 = ddf3.withColumn('card_entry_mde',card_entry_mde_udf(f.col('SD_PT_SRV_ENTRY_MDE'), f.col('SD_EMV_USER_FILLER'),f.col('SD_RESP_CDE'), f.col('SD_AUTH_SRC')))
        
        app.logger.info(ddf3.count())

        ddf3 = ddf3.withColumn('ChannelType',
                               channeltype_udf(f.col('SD_PROD_IND'), f.col('SD_E_COM_FLG'), f.col('SD_RETL_SIC_CDE'),
                                               f.col('SD_PT_SRV_ENTRY_MDE')))

        app.logger.info("Channel type created")
        app.logger.info(ddf3.groupBy("ChannelType").count().show())

        ddf3 = ddf3.withColumn('msg_type', msg_type_udf(f.col('SD_MSG_TYP')))
        
        ddf3 = ddf3.withColumn('sd_monetary', monetary_or_not_udf(f.col('SD_TRAN_CDE')))
        

        ddf3 = ddf3.withColumn('acc_type', acc_type_udf(f.col('SD_PRI_ACCT_TYP')))

        ddf3 = ddf3.withColumn('cvv2_present_flg', cvv2_present_flg_udf(f.col('SD_CVD_PRESENT_FLG')))

        ddf3 = ddf3.withColumn('cvv2_verified_flg', cvv2_verified_flg_udf(f.col('SD_CRD_VRFY_FLG')))

        ddf3 = ddf3.withColumn('payment_gateway', payment_gateway_udf(f.col('SD_TERM_ID')))

        ddf3 = ddf3.withColumn('metro_city', metro_city_udf(f.col('SD_TERM_NAME_LOC')))

        ddf3 = ddf3.withColumn('token_service_flg', token_service_flg_udf(f.col('SD_PROD_IND'), f.col('SD_RETL_SIC_CDE'),
                                                                          f.col('SD_PT_SRV_ENTRY_MDE'),
                                                                          f.col('SD_SEC_ACCT_NUM')))

        

        ddf3 = ddf3.withColumn('apprv_status', apprv_status_udf(f.col('SD_APPRV_CDE')))

        ddf3 = ddf3.withColumn('Amount_bins', amount_bins_udf(f.col('MD_TRAN_AMT1'), 'sd_monetary'))

        ddf3 = ddf3.withColumn('tran_type', trancfunc_udf(f.col('SD_ACQ_INST_ID_NUM')))

        ddf3 = ddf3.withColumn('CntryType', cntryfunc(f.col('SD_TERM_CNTRY')))

        ddf3 = ddf3.withColumn('ecom_secured',
                               secured_or_not_udf(f.col('ChannelType'), f.col('SD_E_COM_FLG'), f.col('ND_CAVV_AAV')))

        ddf3 = ddf3.withColumn('sd_resp_cde_type', sd_resp_cde_type_udf(f.col('SD_RESP_CDE'), f.col('SD_AUTH_SRC')))

        ddf3 = ddf3.withColumn('dt_hour', f.hour(ddf3.DD_DATE))

        ddf3 = ddf3.withColumn('dt_day_week', f.dayofweek(ddf3.DD_DATE))

        ddf3 = ddf3.withColumn('hour_type', hour_classify_udf('dt_hour'))

        ddf3 = ddf3.withColumn('tran_cde_type', tran_cde_type_udf(f.col('SD_TRAN_CDE')))

        ddf3 = ddf3.withColumn('real_time_rule_status', real_time_rule_status_udf(f.col('SD_REAL_TIME_RULE_DISPOSITION')))

        ddf3 = ddf3.withColumn('entry_mde_type', entry_mde_type_udf(f.col('SD_PT_SRV_ENTRY_MDE')))

        ddf3 = ddf3.withColumn('fall_back_status', fall_back_status_udf('SD_PT_SRV_ENTRY_MDE', 'SD_EMV_USER_FILLER'))

        ddf3 = ddf3.withColumn('bal_Check',
                               bal_not_available_udf(f.col('MD_TRAN_AMT1'), f.col('MD_CUST_TRAN_AMT1'), f.col('sd_monetary')))

        ddf3 = ddf3.withColumn('age_bins',
                               age_bins_udf(f.col('DM_USER_PRI_DOB_cm'), f.col('DM_USER_DOB_um'), f.col('DD_DATE')))

        ddf3 = ddf3.withColumn('open_market_type', open_market_type_udf('SD_UAN', 'SD_PAN'))

        ddf3 = ddf3.withColumn('pinchangedays', diff_days_udf(f.col('DD_CRD_PIN_CHNG'), f.col('DD_DATE')))
        ddf3 = ddf3.withColumn('addrchangedays', diff_days_udf(f.col('DD_CRD_LAST_ADDR_CHNG'), f.col('DD_DATE')))

        ddf3 = ddf3.withColumn('crd_blk_cde', crd_blk_cde_udf('SD_FIID', 'SD_CRD_BLK_CDE'))
        ddf3 = ddf3.withColumn('crd_stat_cde', crd_stat_cde_udf('SD_FIID', 'SD_CRD_STAT', 'SD_CRD_BLK_CDE'))

        app.logger.info("Card block code created")

        ddf3 = ddf3.withColumn('cardopendate_cm', diff_days_udf(f.col('DM_OPN_DAT_cm'), f.col('DD_DATE')))

        cardage3daysudf = f.udf(lambda x: 1 if 0 < x < 4 else 0, IntegerType())
        ddf3 = ddf3.withColumn('cardageprev3daysflag_cm', cardage3daysudf(f.col('cardopendate_cm')))

        cardage30daysudf = f.udf(lambda x: 1 if 0 < x < 31 else 0, IntegerType())
        ddf3 = ddf3.withColumn('cardageprev30daysflag_cm', cardage30daysudf(f.col('cardopendate_cm')))

        ddf3 = ddf3.withColumn('date_timestamp', ddf3.DD_DATE.astype('Timestamp').cast('long'))

        ddf3 = grouped_agg_days_temporal(ddf3, ['SD_PAN'], 'date_timestamp', 'SD_TIEBREAKER', 30 * 24 * 60 * 60,
                                         'trancount_prev30days_cm', f.count, 'integer')

        ddf3 = ddf3.withColumn('card_dormant_active_status',
                               acc_dormant_active_udf(f.col('cardopendate_cm'), f.col('trancount_prev30days_cm')))
        ddf3 = ddf3.withColumn('netbanking_reg_card_flag', netbanking_reg_udf(f.col('SM_CUST_MSTR_FLD2_cm')))
        ddf3 = ddf3.withColumn('vbv_reg_card_flag', vbv_reg_udf(f.col('SM_CUST_MSTR_FLD2_cm')))

        ## trimming cols
        ddf3 = ddf3.withColumn("SD_TRAN_CDE", f.trim(ddf3['SD_TRAN_CDE']))
        ddf3 = ddf3.withColumn("SD_TERM_ID", f.trim(ddf3['SD_TERM_ID']))
        pin_change_udf = f.udf(pin_change_func,StringType())
        ## adding pinchange column
        ddf3 = ddf3.withColumn("pin_change",pin_change_udf("SD_TRAN_CDE","SD_TERM_ID"))

        ddf3 = ddf3.withColumn('pin_entered_dom_flag', pin_entered_dom_flag_udf('SD_PIN_IND'))

        ## primary or addon card
        primary_add_on_udf = f.udf(lambda x: 0 if str(x).strip() in ['001','000'] else 1, IntegerType())
        ddf3 = ddf3.withColumn('mbr_num_cardtype', primary_add_on_udf('SD_MBR_NUM'))
        app.logger.info("Primary or addon card")

        ## hotspot country flag
        ddf3 = ddf3.withColumn("hostpsot_country_flag",
                               f.when(f.col("SD_TERM_CNTRY").isin(conf["hotspot_cntry_li"]), "1") \
                               .otherwise("0"))

        app.logger.info("hostpsot_country_flag")
        ## key entry transaction flag
        ddf3 = ddf3.withColumn("key_entry_tx_flag",
                               f.when((f.col("SD_PT_SRV_COND_CDE") == "00") & (f.col("SD_PT_SRV_ENTRY_MDE") == "012"),
                                    "key_entry_tx") \
                               .otherwise("non_key_entry_tx"))
        
        ## ATM New features
        
        baludf = f.udf(bal_amount,DoubleType()) 
        ddf3 = ddf3.withColumn('balance_amount',baludf(f.col('MD_TRAN_AMT1'),f.col('MD_CUST_TRAN_AMT1'),f.col('sd_monetary')))

        bal_amt_binsudf = f.udf(bal_Amount_bins,StringType()) 
        ddf3 = ddf3.withColumn('balance_amount_bins',bal_amt_binsudf(f.col('balance_amount'),f.col('sd_monetary')))

        bal_bins_indexudf = f.udf(balance_amount_bins_index,IntegerType()) 
        ddf3 = ddf3.withColumn('balance_amount_bins_index',bal_bins_indexudf(f.col('balance_amount_bins')))

        card_type_udf = f.udf(card_type,StringType())
        limitsudf =f.udf(Limits,DoubleType())

        ddf3 = ddf3.withColumn("Card_category",card_type_udf(f.col("SD_BIN"),f.col("SD_FIID")))
        cardtypeindexudf =f.udf(card_type_index,IntegerType())

        ddf3 = ddf3.withColumn('card_type_index',cardtypeindexudf(f.col('Card_category'))) 
        ddf3 = ddf3.withColumn('Daily_card_limit',limitsudf(f.col('Card_Category'),f.col('MD_CUST_TRAN_AMT1')))

        ddf3 = ddf3.withColumn('DD_DATE_conv',f.to_date("DD_DATE"))
        ddf3 = ddf3.withColumn("sd_pan_linked",ddf3["SD_PAN"])

        temp = ddf3.groupBy(['sd_pan_linked','DD_DATE_conv']).agg(f.sum("MD_TRAN_AMT1").alias("Maximum_withdrawal_Amt_perday"))


        ddf3 = ddf3.join(temp.drop('DD_DATE_conv'),on=['sd_pan_linked'],how='left')

        ddf3 = ddf3.withColumn('withdrawal_amt_exceed_flag',f.when(ddf3.Maximum_withdrawal_Amt_perday<ddf3.Daily_card_limit,f.lit(0)).otherwise(f.lit(1)))
        app.logger.info('withdrawal_limit created')

        ddf3 = ddf3.withColumn('insufficient_bal_flag',f.when(ddf3.MD_CUST_TRAN_AMT1<ddf3.MD_TRAN_AMT1,f.lit(1)).otherwise(f.lit(0))) 
        ddf3 = ddf3.dropDuplicates(['SD_TIEBREAKER'])


        app.logger.info("key entry transaction flag")
        ddf3 = ddf3.filter(ddf3.SD_FIID.isin(['HDFC', 'HDFB']))
        app.logger.info("Credit card debit card filtered")

        ddf3 = ddf3.filter(ddf3.ChannelType != 'UNKNOWN')
        ddf3 = ddf3.filter(ddf3.SD_TRAN_CDE != '4444')

        app.logger.info("Unnecessary transactions filtered")
        app.logger.info(ddf3.count())

        final_root_path = conf["intermediary_path"]
        name_of_file = "Derived_table_W"

        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, ddf3)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e, app)

    if sc is not None:
        sc.stop()
        
    out = insert_weekly_agg_pipeline_status("Derived_tables_creation",resp["output_table_path"],resp["Error"])
    app.logger.info(out)
    return resp


class DerivedColsApi(Resource):
    def post(self):
        resp = derived_cols_table()
        return jsonify(resp)
        
api.add_resource(DerivedColsApi,'/', '/derived_cols')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9002", debug=False)
