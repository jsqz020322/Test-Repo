# encoding : utf-8 
# Author : B Ravikanth
# Last modified Date : 30-06-2022


import os
from pyspark.sql.types import IntegerType
import pyspark.sql.functions as f
import json

from SparkUtils.spark_utils import create_spark_context, delete_hdfs_file, \
    read_table, write_final_df, exception_block,get_relavant_date_range_df
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


def grouped_agg_days_temporal(df,group_col,order_col,col_name,nlag,new_col_name,func_name):
    
    if func_name == "count":
        temp_sum = df.groupby(group_col+ [order_col])['SD_TIEBREAKER'].count().reset_index()
        temp_sum = temp_sum.sort_values(group_col+ [order_col], ascending=True).reset_index(drop=True)
        temp_sum_nday = temp_sum.set_index(order_col).groupby(group_col)['SD_TIEBREAKER'].\
                                                                            rolling(nlag, min_periods=2).sum().reset_index()
        temp_sum_nday.columns = group_col+[order_col, new_col_name]
        df = df.merge(temp_sum_nday, on=group_col+[ order_col], how='left')
        df = df.fillna({new_col_name:0})
    elif func_name == "mean":
        temp_sum = df.groupby(group_col+ [order_col])[col_name].mean().reset_index()
        temp_sum = temp_sum.sort_values(group_col+ [order_col], ascending=True).reset_index(drop=True)
        temp_sum_nday = temp_sum.set_index(order_col).groupby(group_col)[col_name].\
                                                                            rolling(nlag, min_periods=2).mean().reset_index()
        temp_sum_nday.columns = group_col+[order_col, new_col_name]
        df = df.merge(temp_sum_nday, on=group_col+[ order_col], how='left')
        df = df.fillna({new_col_name:0})
    elif func_name == "max":
        temp_sum = df.groupby(group_col+ [order_col])[col_name].max().reset_index()
        temp_sum = temp_sum.sort_values(group_col+ [order_col], ascending=True).reset_index(drop=True)
        temp_sum_nday = temp_sum.set_index(order_col).groupby(group_col)[col_name].\
                                                                            rolling(nlag, min_periods=2).max().reset_index()
        temp_sum_nday.columns = group_col+[order_col, new_col_name]
        df = df.merge(temp_sum_nday, on=group_col+[ order_col], how='left')
        df = df.fillna({new_col_name:0})
    
    
    return df
    

def create_mcc_agg_col(df,mcc_li,col_name,new_col_name,nlag):

    group_col = "SD_PAN"
    order_col = "DD_DATE_conv"
#     col_name = "tempcol"
    
    temp_sum = df.groupby([group_col, order_col])[col_name].sum().reset_index()
    temp_sum = temp_sum.sort_values([group_col, order_col], ascending=True).reset_index(drop=True)

    temp_sum_nday = temp_sum.set_index(order_col).groupby(group_col)[col_name].\
                                                                        rolling(nlag, min_periods=2).sum().reset_index()
    temp_sum_nday.columns = [group_col, order_col, new_col_name]
    df = df.merge(temp_sum_nday, on=[group_col, order_col], how='left')
    df = df.fillna({new_col_name:0})
    
    return df


# @app.route('/mcc_aggregates', methods=["POST"])
def mcc_aggregates():
    sc = None
    try :
        config_json_path = curr_dir + "/config/mcc_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)

        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)

        ddf3 = df3.withColumn('date_timestamp',df3.DD_DATE.astype('Timestamp').cast('long'))
        
        
        tempudf = f.udf(lambda x: 1 if x in ['5411','5311','5331','5251'] else 0, IntegerType())
        ddf3 = ddf3.withColumn('storestran', tempudf('SD_RETL_SIC_CDE'))
        
        tempudf = f.udf(lambda x: 1 if x in ['5812','5814','5921','5813'] else 0, IntegerType())
        ddf3 = ddf3.withColumn('restuarant_tran', tempudf('SD_RETL_SIC_CDE'))
        
        tempudf = f.udf(lambda x: 1 if x in ['5541','5983'] else 0, IntegerType())
        ddf3 = ddf3.withColumn('gasoline_tran', tempudf('SD_RETL_SIC_CDE'))
        
        tempudf = f.udf(lambda x: 1 if x in ['6011'] else 0, IntegerType())
        ddf3 = ddf3.withColumn('atmwithdrawal', tempudf('SD_RETL_SIC_CDE'))

        mcc_temp_file = temp_path+'mcctemp.parquet'

#         delete_hdfs_file(mcc_temp_file)
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(mcc_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(mcc_temp_file)

        ddf3.write.parquet(mcc_temp_file)

        ddf2 = read_table(spark, mcc_temp_file)
        
        df_list = []
        

        ##################################
        

        ddf4 = ddf2.to_pandas_on_spark()
        ddf4['DD_DATE_conv'] = ddf4['DD_DATE'].apply(lambda x:x.date())
        
        ddf4 = create_mcc_agg_col(ddf4,['5411','5311','5331','5251'] ,'storestran' ,'storestran_count_prev30days', 30)
        ddf4 = create_mcc_agg_col(ddf4,['5812','5814','5921','5813'],'restuarant_tran' ,'restuarant_tran_count_prev30days', 30)
        ddf4 = create_mcc_agg_col(ddf4,['5541','5983'] ,'gasoline_tran', 'gasoline_tran_count_prev30days', 30)
        ddf4 = create_mcc_agg_col(ddf4,['6011'],'atmwithdrawal', 'atmwithdrawal_count_prev30days', 30)

        added_cols_sic_cde_cnt_30 = ['storestran_count_prev30days','restuarant_tran_count_prev30days','gasoline_tran_count_prev30days',
                                    'atmwithdrawal_count_prev30days']
        
        nc = ['SD_TIEBREAKER', 'DD_DATE'] + added_cols_sic_cde_cnt_30
        
        
        ddf4 = ddf4.to_spark()
        
        temp_df = ddf4.select(nc)
        temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)

        par_path = temp_path+'mcctemp_1.parquet'

#         delete_hdfs_file(par_path)
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(par_path)

        temp_df2.write.parquet(par_path)

        df_list.append(par_path)

        ###########
       
        
        
        ddf4 = ddf2.to_pandas_on_spark()
        ddf4['DD_DATE_conv'] = ddf4['DD_DATE'].apply(lambda x:x.date())
        
        ddf4 = create_mcc_agg_col(ddf4,['5411', '5311', '5331', '5251'],'storestran' , 'storestran_count_prev3days', 3)
        ddf4 = create_mcc_agg_col(ddf4,['5812', '5814', '5921', '5813'],'restuarant_tran' , 'restuarant_tran_count_prev3days', 3)
        ddf4 = create_mcc_agg_col(ddf4,['5541', '5983'],'gasoline_tran', 'gasoline_tran_count_prev3days', 3)
        
        added_cols_sic_cde_cnt_3 = ['storestran_count_prev3days','restuarant_tran_count_prev3days','gasoline_tran_count_prev3days']
        
        
        nc = ['SD_TIEBREAKER', 'DD_DATE'] + added_cols_sic_cde_cnt_3
        ddf4 = ddf4.to_spark()
        temp_df = ddf4.select(nc)
        temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)

        par_path = temp_path+'mcctemp_2.parquet'

#         delete_hdfs_file(par_path)
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(par_path)

        temp_df2.write.parquet(par_path)

        df_list.append(par_path)
        
        
        ###########
        
        ddf4 = ddf2.to_pandas_on_spark()
        ddf4['DD_DATE_conv'] = ddf4['DD_DATE'].apply(lambda x:x.date())
        
        ddf4 = grouped_agg_days_temporal(ddf4,['SD_PAN','SD_RETL_SIC_CDE'],'DD_DATE_conv','SD_RETL_SIC_CDE',30,'count_mcc_prev30days',"count")
        
        ddf4 = grouped_agg_days_temporal(ddf4,['SD_PAN','SD_RETL_SIC_CDE'],'DD_DATE_conv','MD_TRAN_AMT1',30,'mean_tran_amt_mcc_prev30days',"mean")
        
        ddf4 = grouped_agg_days_temporal(ddf4,['SD_PAN','SD_RETL_SIC_CDE'],'DD_DATE_conv','MD_TRAN_AMT1',30,'max_tran_amt_mcc_prev30days',"max")
        

        added_cols_mcc_30 = ['count_mcc_prev30days','mean_tran_amt_mcc_prev30days','max_tran_amt_mcc_prev30days']
        
        nc = ['SD_TIEBREAKER', 'DD_DATE'] + added_cols_mcc_30
        ddf4 = ddf4.to_spark()
        temp_df = ddf4.select(nc)
        temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)

        par_path = temp_path+'mcctemp_3.parquet'

#         delete_hdfs_file(par_path)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(par_path)

        temp_df2.write.parquet(par_path)

        df_list.append(par_path)

        ###########
        
        df1 = spark.read.format('parquet')\
                .option("inferSchema","true")\
                .load(df_list[0])
        
        for par_path in df_list[1:]:

            joindf = df1

            tempdf = spark.read.format('parquet')\
                .option("inferSchema","true")\
                .load(par_path+'/')
            othercols = [c for c in tempdf.columns if c not in  ['SD_TIEBREAKER','DD_DATE']]
            selcols = [f.col('SD_TIEBREAKER').alias('SD_TIEBREAKER_B'),f.col('DD_DATE').alias('DD_DATE_B')]+othercols

            tempdf2 = tempdf.select(selcols)
            df1 = joindf.join(tempdf2,joindf.SD_TIEBREAKER==tempdf2.SD_TIEBREAKER_B,'left')
            df1 = df1.drop(*['SD_TIEBREAKER_B','DD_DATE_B'])

            del tempdf,tempdf2


#         df_final = get_relavant_date_range_df(df1,'DD_DATE',strtdate,enddate)

#         df_final = df_final.drop('DD_DATE')

        name_of_file = "MCC_agg_ATM_table_W"
    
        df1 = df1.dropDuplicates(["SD_TIEBREAKER"])

        final_path = write_final_df(df1,strtdate, enddate,name_of_file,conf)

#         delete_hdfs_file(mcc_temp_file)
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(mcc_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(mcc_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()

    ins_status = insert_weekly_agg_pipeline_status("Mcc_agg_creation",resp["output_table_path"],resp["Error"][:250])
    return resp

class MccAggregatesApi(Resource):
    def post(self):
        resp = mcc_aggregates()
        return jsonify(resp)
        

api.add_resource(MccAggregatesApi,'/', '/mcc_aggregates')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9005", debug=False)