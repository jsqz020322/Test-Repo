# Author Name : B Ravikanth
# Last update : 28-06-2022
# Import required libraries and packages


import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")

import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block, grouped_agg_days_temporal, freq_loc
from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

agg_list_channel_type_1 = [['ChannelType', f.sum, "count", 'All', 'ChannelType', ['ATM', 'POS'], 'N','integer']]

agg_list_channel_type_2 = [['ChannelType', f.sum, "count", 'All', 'ChannelType', ['CNP SECURED', 'CNP UNSECURED'], 'N','integer']]
    
agg_list_tran_count = [['SD_TIEBREAKER', f.count, "count", 'All', 'NA', 'NA', 'N', 'integer']]


def burst_tran_count(spark,card_temp_file,agg_list,final_path, strtdate, enddate,conf):
    
    new_col_name = ''
    df_list = []
    
    try:
        
        df = spark.read.parquet(card_temp_file)
    
        
        l = agg_list[0]
        
        group_col = 'sd_pan_linked'
        order_col = 'date_timestamp'
        nlag = 60
        col_name = l[0]
        func = l[1]
        fun_name = l[2]
        mon_flag = l[3]
        part_col2 = l[4]
        part_cat2 = l[5]
        ch_flag = l[6]
        coltype = l[7]
        
        
        new_col_name = col_name.lower()+'_'+fun_name+'_'+'prev1min'
        new_col_name = new_col_name.replace(" ","")
        
        
        df = grouped_agg_days_temporal(df,group_col,order_col,col_name,nlag,new_col_name,func,coltype)
        fill_col_vals = {
            new_col_name : 0
        }
        
        added_cols = [new_col_name]
        
        nc = ['SD_TIEBREAKER', 'DD_DATE'] + added_cols
        temp_df = df.select(nc)
        temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)

        par_path = final_path  + '111.parquet'

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(par_path)


        temp_df2.write.parquet(par_path)

        df_list.append(par_path)
        
        
        
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        
    return temp_df2,df_list


def locmapping(x,y):
    try:
        if(y=='NA' or len(x)==0):
            return 0
        
        for i in x:
            if(i.strip()==y.strip()):
                return 1
        return 0
    except:
        return 0
    
def freq_cols_list(spark,card_temp_file,final_path,strtdate, enddate,conf):
    
    df_list = []
    
    
    df2 = spark.read.parquet(card_temp_file)
    
    strip_df = f.udf(lambda x:str.upper(x.strip()) if x!=None else x,StringType())
    
    locmapping_udf = f.udf(locmapping, IntegerType())

    df2 = df2.withColumn('SD_TERM_CITY',strip_df('SD_TERM_CITY'))
    df2 = df2.withColumn('SD_TERM_ST',strip_df('SD_TERM_ST'))
    df2 = df2.withColumn('SD_TERM_CNTRY',strip_df('SD_TERM_CNTRY'))

    
    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_CNTRY',30*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_cntry_prev30days',locmapping_udf('tmp_col','SD_TERM_CNTRY'))

    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_CNTRY',3*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_cntry_prev3days',locmapping_udf('tmp_col','SD_TERM_CNTRY'))

    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_ST',30*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_state_prev30days',locmapping_udf('tmp_col','SD_TERM_ST'))

    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_ST',3*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_state_prev3days',locmapping_udf('tmp_col','SD_TERM_ST'))

    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_CITY',30*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_city_prev30days',locmapping_udf('tmp_col','SD_TERM_CITY'))

    df2 = freq_loc(df2,['SD_PAN','ChannelType'],'date_timestamp','SD_TERM_CITY',3*24*60*60,'tmp_col',f.collect_set,'set')
    df2 = df2.withColumn('current_tran_city_prev3days',locmapping_udf('tmp_col','SD_TERM_CITY'))

    # Columns to be added
    add_cols_freq_loc = ["current_tran_cntry_prev30days", "current_tran_cntry_prev3days","current_tran_state_prev30days","current_tran_state_prev3days","current_tran_city_prev30days","current_tran_city_prev3days"]

    nc = ['SD_TIEBREAKER', "DD_DATE"] + add_cols_freq_loc
    df_final = df2.select(nc)
    df_final = get_relavant_date_range_df(df_final,'DD_DATE',strtdate,enddate)
    
    par_path = final_path  + '112.parquet'

    if conf["kerberos_flag"] == "True":
        delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
    else:
        delete_hdfs_file(par_path)


    df_final.write.parquet(par_path)

    df_list.append(par_path)
    
    return df_final,df_list



def cnp_sec_add_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate):
    agg_df, df_list = None, None
    
    try:
        
        agg_list_sec_usage = [agg_list_channel_type_1, agg_list_channel_type_2]
        agg_list_burst_tran = [agg_list_tran_count]
        
        final_path = temp_path + 'cnp_add_card_30d_temp_'
        
        new_df_list = []
        
        agg_df, df_list = create_agg_list(agg_list_sec_usage, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)
        
        new_df_list = new_df_list+df_list
        
        agg_df, df_list = burst_tran_count(spark,card_temp_file,agg_list_tran_count,final_path,strtdate, enddate,conf)
        
        new_df_list = new_df_list+df_list
        
        agg_df, df_list = freq_cols_list(spark,card_temp_file,final_path,strtdate, enddate,conf)
        
        new_df_list = new_df_list+df_list
        
        df1 = join_temp_tables(new_df_list[:1], spark)
        df2 = join_temp_tables(new_df_list[1:], spark)
            
        df1 = df1.persist()
        df2 = df2.persist()

        joindf = df1
        tempdf = df2
        othercols = [c for c in tempdf.columns if c not in ['SD_TIEBREAKER', 'DD_DATE',"SD_PAN","DD_DATE_conv"]]
        selcols = [f.col('SD_TIEBREAKER').alias('SD_TIEBREAKER_B'), f.col('DD_DATE').alias('DD_DATE_B')] + othercols

        tempdf2 = tempdf.select(selcols)
        df = joindf.join(tempdf2, joindf.SD_TIEBREAKER == tempdf2.SD_TIEBREAKER_B, 'left')
        df = df.na.fill(0)
        df = df.drop(*['SD_TIEBREAKER_B', 'DD_DATE_B'])
        
        
        df_final = get_relavant_date_range_df(df,'DD_DATE',strtdate,enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.withColumn("total_transactions", f.col("channeltype_ATM_count_prev30days") + f.col("channeltype_POS_count_prev30days") + f.col("channeltype_CNPSECURED_count_prev30days") + f.col("channeltype_CNPUNSECURED_count_prev30days"))
        
        df_final = df_final.withColumn("cnp_secured_usage_prev30days", f.col("channeltype_CNPSECURED_count_prev30days")/f.col("total_transactions"))
        
        df_final = df_final.withColumn("cnp_unsecured_usage_prev30days", f.col("channeltype_CNPUNSECURED_count_prev30days")/f.col("total_transactions"))
        
        
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        
    return df_final, new_df_list


def cnp_sec_card_agg():
    sc = None
    try:
        config_json_path = curr_dir + "/config/CNP_additional_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        ddf2 = df3
        
        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])
        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp']

        ddf3 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'cnp_add_cardtemp.parquet'

        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(card_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(card_temp_file)

        # Write temp agg to HDFS
        app.logger.info("Writing data to temporary parquet")
        ddf3.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None
        
        df_final, df_list = cnp_sec_add_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate)
        

        name_of_file = "CNP_Additional_agg_table_W"
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])


        final_root_path = conf["intermediary_path"]
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            delete_hdfs_file(i)

        delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
       
    ins_status = insert_weekly_agg_pipeline_status("CNP_Additional_agg_table",resp["output_table_path"],resp["Error"][:250])
     
    return resp


class CNPCardAggregatesApi(Resource):
    def post(self):
        resp = cnp_sec_card_agg()
        return jsonify(resp)

api.add_resource(CNPCardAggregatesApi,'/', '/cnp_add_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9018", debug=False)