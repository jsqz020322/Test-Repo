from datetime import datetime
from DataBaseUtils.db_utils import mysql_conn
import os

def insert_weekly_agg_pipeline_status(taskname,output_path,error):
    status_flag = False
    try:
        sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
        mycursor = sql_conn.cursor()
        
        sql = "INSERT INTO weekly_aggregates_pipeline_status (CreatedTime,TaskName,OutputTablePath,Status,Error) VALUES (%s, %s, %s, %s,%s)"
        
        # CreatedTime:
        created_time = datetime.now()

        if error == "NA":
            status = 1
        else:
            status = 0
            
        val = (created_time, taskname, output_path, status, error)

        mycursor.execute(sql, val)
        sql_conn.commit()
        status_flag = True
        
        sql_conn.close()
        
    except Exception as e:
        print("Exception occured while storing data in mysql table " + str(e))

    return status_flag

# status = insert_weekly_agg_pipeline_status("TEMP","/temp","NA")
# print(status)