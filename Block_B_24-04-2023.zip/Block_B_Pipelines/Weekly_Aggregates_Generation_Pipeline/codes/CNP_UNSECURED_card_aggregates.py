# Author Name : B Ravikanth
# Last update : 28-06-2022
# Import required libraries and packages


import os
import sys
import json
import warnings
warnings.filterwarnings("ignore")

import pyspark.sql.functions as f
from SparkUtils.spark_utils import create_spark_context, get_relavant_date_range_df, delete_hdfs_file, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block, grouped_agg_days_temporal
from SparkUtils.card_agg_utils import add_aggregates_n_days
from pyspark.sql.types import IntegerType,StringType 
from ATM_additional_aggregates_New import read_derived_table
import logging
from flask import Flask, jsonify, request
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect
from All_channel_card_aggregates import create_agg_list

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


    

def mcc_type(SD_RETL_SIC_CDE,mcc_li):
    try:
        if SD_RETL_SIC_CDE.strip() in mcc_li:
            return SD_RETL_SIC_CDE
        else:
            return "Others"
    except:
        return "NA"


def stnl(SD_TERM_NAME_LOC, stnl_dict):
    try:

        res = "Others"
        for key in stnl_dict.keys():
            val = stnl_dict[key]
            if type(val)==str:
                val = [val]
            #print(k,v)
            for each_v in val:
                if each_v.lower() in SD_TERM_NAME_LOC.strip().lower():
                    res = key
                    break
            if res!="Others":
                break

        return res
    except:
        return "NA"

# List of 30 Day Aggregates

agg_list_amt = [['MD_TRAN_AMT1',f.mean,"mean",'M','NA','NA','Y','double'], ['MD_TRAN_AMT1',f.max,"max",'M','NA','NA','Y','double'], ['MD_TRAN_AMT1',f.min,"min",'M','NA','NA','Y','double']]

agg_list_Amtbins_split1 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins', ["0","0_1","1_500","501_2000"],'Y','integer']]

agg_list_Amtbins_split2 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins', ["2001_5000","5001_10000","10001_20000","20001_30000"],'Y','integer']]

agg_list_Amtbins_split3 = [['Amount_bins', f.sum, "count", 'M', 'Amount_bins', ["30001_50000", "50001_100000"],'Y','integer']]

agg_list_sd_resp_cde_split1 = [['sd_resp_cde_type', f.sum, "count", 'All', 'sd_resp_cde_type', ["PRM_Declined","InvalidData","ExpiredCard","RestrictedCard"],'Y','integer']]

agg_list_sd_resp_cde_split2 = [['sd_resp_cde_type',f.sum,"count",'All','sd_resp_cde_type', ["WithdrawalLimitExceeded","Pickup_Capture","InsuffFunds","IntlLimitExceeded_NA","Block_Decline_H","OtherDeclines"],'Y','integer']]

agg_list_cntry_tran = [['CntryType',f.sum,"count",'All','CntryType',['Domestic','International'],'Y','integer'], ['pin_entered_dom_flag',f.sum,"count",'All','NA','NA','Y','integer'],['tran_type',f.sum,"count",'All','tran_type',['ON_US','REMOTE_ON_US'],'Y','integer']]

agg_list_trancde = [['tran_cde_type',f.sum,"count",'All','tran_cde_type',['BalInquiry','PinChange','PinInquiry','Purchase'],'Y','integer']]

agg_list_hrtype = [['hour_type',f.sum,"count",'All','hour_type',['busHrs','close_midnight','lateNight','earlyMrng'],'Y','integer']]

agg_list_mcc_split1 = [['mcc',f.sum,"count",'All','mcc',["5734", "5968", "5735", "7311"],'Y','integer']]

agg_list_mcc_split2 = [['mcc',f.sum,"count",'All','mcc',["8398", "7399", "7372", "5967"],'Y','integer']]

agg_list_mcc_split3 = [['mcc',f.sum,"count",'All','mcc',["5816","7829","5812","5818"],'Y','integer']]

agg_list_mcc_split4 = [['mcc',f.sum,"count",'All','mcc',["4121","5999","4789","5311"],'Y','integer']]

agg_list_mcc_split5 = [['mcc',f.sum,"count",'All','mcc',["5995","5942","5641","7523"],'Y','integer']]


agg_list_ch_type = [['ChannelType', f.sum, "count", 'All', 'ChannelType', ["CNP UNSECURED"], 'N', 'integer']]


def cnp_unsec_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate, flag_val):
    agg_df, df_list = None, None
    
    try:
        agg_list_3d = [agg_list_ch_type, agg_list_mcc_split1, agg_list_mcc_split2, agg_list_mcc_split3, 
                       agg_list_mcc_split4, agg_list_mcc_split5]
        
        agg_list_30d = [agg_list_amt, agg_list_Amtbins_split1, agg_list_Amtbins_split2, agg_list_Amtbins_split3, 
                       agg_list_sd_resp_cde_split1, agg_list_sd_resp_cde_split2, agg_list_cntry_tran, agg_list_trancde,
                       agg_list_hrtype, agg_list_mcc_split1, agg_list_mcc_split2, agg_list_mcc_split3, 
                       agg_list_mcc_split4, agg_list_mcc_split5]
        
        
        final_path = temp_path + 'cnp_unsec_card_3d_temp_'
    
        if flag_val == "3days":
            agg_df, df_list = create_agg_list(agg_list_3d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 3)

        if flag_val == "30days":
            agg_df, df_list = create_agg_list(agg_list_30d, app, spark, temp_path, card_temp_file,conf, final_path, strtdate, enddate, 30)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        
    return agg_df, df_list


def cnp_unsec_card_agg(flag_val):
    sc = None
    try:
        config_json_path = curr_dir + "/config/CNP_UnSecured_card_30day_aggregates.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        spark, sc = create_spark_context(conf,conf["appName"])

        temp_path, status_df, current_date , last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(conf, spark)
        ddf2 = df3
        
        ddf2 = ddf2.withColumn("sd_pan_linked", ddf2["SD_PAN"])
        ddf3 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf3 = ddf3.filter(ddf3.ChannelType==conf["channel"])
        
        
        # Create "mcc" - Newly added
        mcc_li = conf["mcc_li"]
        mcc_udf = f.udf(lambda x:mcc_type(x,mcc_li),StringType())
        ddf3 = ddf3.withColumn("mcc", mcc_udf("SD_RETL_SIC_CDE"))
        
        
        req_cols = conf['req_cols']
        req_cols = req_cols + ['sd_pan_linked','date_timestamp','mcc']

        ddf3 = ddf3.select(req_cols)
        card_temp_file = temp_path + 'cnp_unsec_cardtemp.parquet'

        delete_hdfs_file(card_temp_file)

        # Write temp agg to HDFS
        app.logger.info("Writing data to temporary parquet")
        ddf3.write.parquet(card_temp_file)

        df_list = []
        name_of_file = None
        
        df, df_list = cnp_unsec_card_aggregates_ndays(app, spark, temp_path, card_temp_file,conf, strtdate, enddate,flag_val)
        

        if flag_val == "3days":
            name_of_file = "CNP_UNSEC_Card3day_POS_table_W"

        if flag_val == "30days":
            name_of_file = "CNP_UNSEC_Card30day_POS_table_W"

        # saving the final parquet
        df_final = get_relavant_date_range_df(df, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')

        final_root_path = conf["intermediary_path"]
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])
        
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            delete_hdfs_file(i)

        delete_hdfs_file(card_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
        
    except Exception as e:
        resp = exception_block(e,app)

    if sc is not None:
        sc.stop()
       
    if flag_val == "3days":
        ins_status = insert_weekly_agg_pipeline_status("CNP_UNSecured_Card_3day_agg_creation",resp["output_table_path"],resp["Error"][:250])
    if flag_val == "30days":
        ins_status = insert_weekly_agg_pipeline_status("CNP_UNSecured_Card_30day_agg_creation",resp["output_table_path"],resp["Error"][:250])
        
    return resp


class CNPUNSecuredCardAggregatesApi(Resource):
    def post(self):
        apiconf = json.loads(request.data)
        flag_val = apiconf["flag_val"]
        resp = cnp_unsec_card_agg(flag_val)
        return jsonify(resp)

api.add_resource(CNPUNSecuredCardAggregatesApi,'/', '/cnp_unsecured_card_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9019", debug=False)