import json
import logging
import os
from collections import Counter

import pyspark.sql.functions as sf
from DataBaseUtils.weekly_agg_pipeline_queries import read_derived_table_status
from SparkUtils.card_agg_utils import grouped_agg_days_temporal
from SparkUtils.spark_utils import read_table, create_spark_context, delete_hdfs_file, get_relavant_date_range_df, \
    prev_field, join_temp_tables, write_weekly_agg_intermediary_tables, exception_block
from flask import Flask, jsonify
from pyspark.sql.types import IntegerType, StringType
from pyspark.sql.window import Window
from weekly_aggregates_pipeline_status import insert_weekly_agg_pipeline_status
import datetime
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

def write_temp_df(df, added_cols, final_path, i, df_list, strtdate, enddate,conf):
    nc = ['SD_TIEBREAKER', 'DD_DATE'] + added_cols
    temp_df = df.select(nc)
    temp_df2 = get_relavant_date_range_df(temp_df, 'DD_DATE', strtdate, enddate)
    par_path = final_path + str(i) + '.parquet'
    
    if conf["kerberos_flag"] == "True":
        delete_hdfs_file(par_path,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
    else:
        delete_hdfs_file(par_path)

#     delete_hdfs_file(par_path)

    temp_df2.write.parquet(par_path)
    df_list.append(par_path)
    i = i + 1
    return i, df_list


def daily_withdrawal_amt(amtli, dayli):
    ret_val = 0.0
    try:
        if amtli is not None:
            ret_val = amtli / len(dayli)
    except Exception as ex:
        app.logger.info("Exception occured in daily_withdrawal_amt func: " + str(ex))

    return ret_val


def max_daily_atm_tran_count(day_li, cday):
    ret_val = 0.0
    try:
        if len(day_li) != 0:
            k = [c for c in day_li if c != cday]
            ret_val = Counter(k).most_common(1)[0][1]

    except Exception as e:
        print("Exception occured in max_daily_atm_tran_count func : " + str(e))

    return ret_val


def week_withdrawal_amt(amtli, mnthli):
    ret_val = 0.0
    try:
        if amtli is not None:
            ret_val = amtli / len(mnthli)
    except Exception as e:
        print("Exception occured in week_withdrawal_amt func : " + str(e))

    return ret_val


def max_weekly_atm_tran_count(mnth_li, cday):
    ret_val = 0.0
    try:
        if len(mnth_li) != 0:
            k = [c for c in mnth_li if c != cday]
            ret_val = Counter(k).most_common(1)[0][1]

    except Exception as e:
        print("Exception occured in max_weekly_atm_tran_count func : " + str(e))

    return ret_val


def days_diff(day1, day2):
    ret_val = -1
    try:
        h = (day1 - day2).days
        if h == 0:
            h = day1.day - day2.day
        ret_val = h

    except Exception as e:
        print("Exception occured in days_diff func : " + str(e))

    return ret_val


def week_val(day):
    if day < 8:
        w_val = 1
    elif 7 < day < 16:
        w_val = 2
    elif 15 < day < 23:
        w_val = 3
    else:
        w_val = 4
    return w_val
  
    
def read_derived_table(conf, spark):
    conn_string = os.getenv("BLOCK_B_CONN")
    status_df, current_date, last_week_date, previous_date = read_derived_table_status(conn_string)
    temp_path = conf["temp_path"]
    tab_path_1 = conf["derived_tables_path"]
    
    time_stamp = datetime.datetime.now()
    year = time_stamp.strftime("%Y")
    week_of_year = int(time_stamp.strftime("%V"))
    month_of_year = int(time_stamp.strftime("%m"))
    
    prev_month = month_of_year-1
    
    if prev_month==0:
        year=str(int(year)-1)
        prev_month = 12
        monthly_tab_path = tab_path_1+"year_" + year + "/month_"+str(prev_month) + "/*/*"
    
    elif prev_month < 10:
        monthly_tab_path = tab_path_1+"year_" + year + "/month_0"+str(prev_month) + "/*/*" 
    else:
        monthly_tab_path = tab_path_1+"year_" + year + "/month_"+str(prev_month) + "/*/*" 
    
    ## reading monthly tables
    df1 = read_table(spark, monthly_tab_path)
    
    if "SM_USER_POSTAL_CDE_um" in df1.columns:
        df1 = df1.withColumnRenamed("SM_USER_POSTAL_CDE_um","SM_USER_POSTAL_CDE_cm")
    
    tab_path_2 = "/".join(status_df.loc[0]['OutputTablePath'].split("/")[:-2])+"/*/*" 

    req_cols = conf["req_cols"]
    ## start date and end date of months considered
    strtdate = last_week_date
    enddate = current_date

    df2 = read_table(spark, tab_path_2)
    
    if "SM_USER_POSTAL_CDE_um" in df2.columns:
        df2 = df2.withColumnRenamed("SM_USER_POSTAL_CDE_um","SM_USER_POSTAL_CDE_cm")
    
    df3 = df1.select(req_cols).union(df2.select(req_cols))

    del df1, df2

    return temp_path, status_df, current_date, last_week_date, previous_date, df3, strtdate, enddate


# @app.route('/atm_additional_agg', methods=["POST"])
def atm_additional_feats_func():
    sc = None
    try:
        config_json_path = curr_dir + "/config/ATM_additional_agg.json"
        conf = json.load(open(config_json_path, "r"))
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        

        spark, sc = create_spark_context(conf, conf["appName"])
        ## providing spark configuration No. of executors,executor memory etc.,

        temp_path, status_df, current_date, last_week_date, previous_date, df3, strtdate, enddate = read_derived_table(
            conf, spark)

        ddf2 = df3.filter(df3.ChannelType == 'ATM')

        atm_temp_file = temp_path+'atm_temp.parquet'
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(atm_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(atm_temp_file)
        
#         delete_hdfs_file(atm_temp_file)

        ddf2.write.parquet(atm_temp_file)
        app.logger.info("Temp table created")

        ddf2 = read_table(spark, atm_temp_file)

        ddf2 = ddf2.withColumn('date_timestamp', ddf2.DD_DATE.astype('Timestamp').cast('long'))
        ddf2 = ddf2.withColumn('dayOfYear', sf.dayofyear('DD_DATE'))
        ddf2 = ddf2.withColumn('dayOfMonth', sf.dayofmonth('DD_DATE'))

        week_month_udf = sf.udf(lambda x: week_val(x))
        ddf2 = ddf2.withColumn('weekOfMonth', week_month_udf('dayOfMonth'))
        ddf2 = ddf2.withColumn('monthOfYear', sf.month('DD_DATE'))
        ddf2 = ddf2.withColumn('weekOfYear', sf.weekofyear('DD_DATE'))

        app.logger.info("time columns created")
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(temp_path+"atmtemp_*.parquet",kerberos_flag="True",keytab_path=conf["keytab_path"],
                             kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(temp_path+"atmtemp_*.parquet")

#         delete_hdfs_file("atmtemp_*.parquet")

        final_path = temp_path+'atmtemp_'

        df_list = []

        i = 0

        df = ddf2

        added_cols = []

        ###############

        group_col = ['SD_PAN', 'sd_monetary']
        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'MD_TRAN_AMT1', 30 * 24 * 60 * 60,
                                       'temp_amt_li', sf.sum, 'list')
        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'dayOfYear', 30 * 24 * 60 * 60, 'temp_day_li',
                                       sf.collect_set, 'list')

        ###########

        group_col = ['SD_PAN', 'dayOfYear']
        ordercol = 'date_timestamp'
        window = Window.partitionBy(group_col).orderBy(ordercol)
        # 
        df = df.withColumn('temp_day_li', sf.collect_list('MD_TRAN_AMT1').over(window))

        lenudf = sf.udf(lambda x: len(x) - 1, IntegerType())

        df = df.withColumn('current_day_atm_trancount', lenudf('temp_day_li'))

        group_col = ['SD_PAN']

        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'dayOfYear', 30 * 24 * 60 * 60, 'temp_day_li',
                                       sf.collect_list, 'list')

        max_daily_atm_tran_count_udf = sf.udf(max_daily_atm_tran_count, IntegerType())

        df = df.withColumn('max_daily_atm_tran_count_prev30days',
                           max_daily_atm_tran_count_udf('temp_day_li', 'dayOfYear'))
        df = df.drop(*['temp_day_li'])
        added_cols.append('current_day_atm_trancount')
        added_cols.append('max_daily_atm_tran_count_prev30days')

        app.logger.info("max_daily_atm_tran_count_prev30days")

        ###########

        group_col = ['SD_PAN', 'sd_monetary', 'weekOfMonth']

        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'MD_TRAN_AMT1', 90 * 24 * 60 * 60,
                                       'temp_amt_li', sf.sum, 'list')
        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'monthOfYear', 90 * 24 * 60 * 60,
                                       'temp_mnth_li', sf.collect_set, 'list')

        i, df_list = write_temp_df(df, added_cols, final_path, i, df_list, strtdate, enddate,conf)

        df = ddf2

        added_cols = []

        ###############

        group_col = ['SD_PAN', 'weekOfMonth']
        ordercol = 'date_timestamp'
        window = Window.partitionBy(group_col).orderBy(ordercol)

        df = df.withColumn('temp_mnth_li', sf.collect_list('MD_TRAN_AMT1').over(window))

        lenudf = sf.udf(lambda x: len(x) - 1, IntegerType())

        df = df.withColumn('current_week_atm_trancount', lenudf('temp_mnth_li'))

        group_col = ['SD_PAN', 'weekOfMonth']

        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'monthOfYear', 90 * 24 * 60 * 60,
                                       'temp_week_li', sf.collect_list, 'list')
        app.logger.info("current_week_atm_trancount")

        max_weekly_atm_tran_count_udf = sf.udf(max_weekly_atm_tran_count, IntegerType())

        df = df.withColumn('max_weekly_atm_tran_count_prev90days',
                           max_weekly_atm_tran_count_udf('temp_week_li', 'monthOfYear'))
        df = df.drop(*['temp_week_li', 'temp_mnth_li'])
        added_cols.append('current_week_atm_trancount')
        added_cols.append('max_weekly_atm_tran_count_prev90days')

        app.logger.info("max_weekly_atm_tran_count_prev90days")

        ###############

        group_col = ['SD_PAN', 'sd_monetary', 'dayOfYear']

        ordercol = 'date_timestamp'
        window = Window.partitionBy(group_col).orderBy(ordercol)
        # 
        df = df.withColumn('temp_amt_li', sf.sum('MD_TRAN_AMT1').over(window))

        group_col = ['SD_PAN', 'sd_monetary']
        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'temp_amt_li', 3 * 24 * 60 * 60, 'temp_day_li',
                                       sf.collect_list, 'list')

        i, df_list = write_temp_df(df, added_cols, final_path, i, df_list, strtdate, enddate,conf)

        df = ddf2

        added_cols = []

        tempudf = sf.udf(lambda x: 1 if x != 'Approved' else 0, IntegerType())
        df = df.withColumn('tempcol', tempudf('sd_resp_cde_type'))
        group_col = ['SD_PAN', 'sd_monetary', 'CntryType']
        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'tempcol', 30 * 24 * 60 * 60,
                                       'atm_dec_w_count_cntrytype_prev30days', sf.sum, 'integer')

        added_cols.append('atm_dec_w_count_cntrytype_prev30days')

        ###############

        df = grouped_agg_days_temporal(df, group_col, 'date_timestamp', 'tempcol', 3 * 24 * 60 * 60,
                                       'atm_dec_w_count_cntrytype_prev3days', sf.sum, 'integer')
        df = df.drop('tempcol')

        added_cols.append('atm_dec_w_count_cntrytype_prev3days')

        ###############

        group_col = ['SD_PAN']
        df = prev_field(df, group_col, 'date_timestamp', 'DD_DATE', 1, 'prev_atm_date', sf.lag, 'timestamp')

        days_diff_udf = sf.udf(days_diff, IntegerType())
        df = df.withColumn('prev_atm_tran_days', days_diff_udf('DD_DATE', 'prev_atm_date'))
        df = df.drop(*['prev_atm_date'])

        added_cols.append('prev_atm_tran_days')

        i, df_list = write_temp_df(df, added_cols, final_path, i, df_list, strtdate, enddate,conf)

#         app.logger.info(i, df_list)

        #################################
    
        df2 = ddf2
        
        df2 = df2.withColumn('Month',sf.month("DD_DATE"))
        df2 = df2.withColumn("MD_TRAN_AMT1",sf.col('MD_TRAN_AMT1').cast("double"))

        df2 = df2.withColumn('tmp_col',sf.mean('MD_TRAN_AMT1').over(Window.partitionBy(['SD_PAN','Month'])))
        temp = df2.select(['SD_TIEBREAKER','tmp_col','SD_PAN'])
        temp = temp.groupBy(['SD_PAN']).agg((sf.sumDistinct("tmp_col")/sf.countDistinct('tmp_col')).alias("MD_TRAN_AMT1_withdrawal_Amt_avg_over_60days"))

        df2 = df2.join(temp,on=['SD_PAN'],how='left')
        
        added_cols = []
        
        added_cols.append('MD_TRAN_AMT1_withdrawal_Amt_avg_over_60days')

        i, df_list = write_temp_df(df2, added_cols, final_path, i, df_list, strtdate, enddate,conf)
    
    
        ###################################
    

        df1 = join_temp_tables(df_list[:], spark)
        df1 = df1.persist()

        ## saving the final parquet

        df_final = get_relavant_date_range_df(df1, 'DD_DATE', strtdate, enddate)

        df_final = df_final.drop('DD_DATE')
        
        df_final = df_final.dropDuplicates(["SD_TIEBREAKER"])

        final_root_path = conf["intermediary_path"]
        name_of_file = "ATM_addn_agg_table_W"
        final_path = write_weekly_agg_intermediary_tables(final_root_path, name_of_file, df_final)

        for i in df_list:
            
            if conf["kerberos_flag"] == "True":
                delete_hdfs_file(i,kerberos_flag="True",keytab_path=conf["keytab_path"],
                                 kerberos_path=conf["kerberos_path"])
            else:
                delete_hdfs_file(i)
                
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(temp_path + 'atmtemp_*.parquet',kerberos_flag="True",keytab_path=conf["keytab_path"],
                             kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(temp_path + 'atmtemp_*.parquet')
            
        atm_temp_file = temp_path+'atm_temp.parquet'
        
        if conf["kerberos_flag"] == "True":
            delete_hdfs_file(atm_temp_file,kerberos_flag="True",keytab_path=conf["keytab_path"],kerberos_path=conf["kerberos_path"])
        else:
            delete_hdfs_file(atm_temp_file)

        resp = {"status": 200, "Error": "NA", "output_table_path": final_path}
    except Exception as e:
        resp = exception_block(e, app)

    if sc is not None:
        sc.stop()

    ins_status = insert_weekly_agg_pipeline_status("ATM_add_agg_creation",resp["output_table_path"],resp["Error"][:250])
    
    return resp


class AtmAddnAggApi(Resource):
    def post(self):
        resp = atm_additional_feats_func()
        return jsonify(resp)
        

api.add_resource(AtmAddnAggApi,'/', '/atm_additional_agg')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9006", debug=False)
