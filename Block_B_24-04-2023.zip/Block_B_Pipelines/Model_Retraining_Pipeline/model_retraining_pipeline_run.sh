nohup python code/ATM_Model_retraining_flask_api.py > nohup_outs/ATM_Model_retraining_flask_api.out &
nohup python code/POS_Model_retraining_flask_api.py > nohup_outs/POS_Model_retraining_flask_api.out &
nohup python code/CNP_SECURED_Model_retraining_flask_api.py > nohup_outs/CNP_SECURED_Model_retraining_flask_api.out &
nohup python code/CNP_UNSECURED_Model_retraining_flask_api.py > nohup_outs/CNP_UNSECURED_Model_retraining_flask_api.out &