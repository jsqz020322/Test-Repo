# encoding : utf-8 
# Author : Anish srivathsav
# Last modified Date : 26-01-2023

# Import required packages and libraries
import os
import sys
import json
import datetime
import numpy as np
import pandas as pd
from datetime import timedelta
import pandas.io.sql as psql

# Import spark libraries
import pyspark
from pyspark.sql.window import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.ml import Pipeline
from pyspark.ml.clustering import KMeansModel
from pyspark.ml.feature import VectorAssembler

from SparkUtils.spark_utils import create_spark_context, delete_hdfs_file
from DataBaseUtils.db_utils import mysql_conn
from SparkUtils.card_agg_utils import channel_type
from model_pipeline_status import insert_model_pipeline_status

# To ignore warnings
import warnings
warnings.filterwarnings("ignore")

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


# Frauds cluster predict
def cluster_predict_fraud(fraud_df, conf, mapped_dict, app):
    try:
        kmeans_algo = KMeansModel.load(conf['Kmeans_model_fraud'])
        app.logger.info("K-Means fraud cluster model is loaded")

        sel_cols = list(mapped_dict.values())
        app.logger.info(sel_cols)

        stages = []
        assembler_inputs = sel_cols
        assembler = VectorAssembler(inputCols=assembler_inputs, outputCol="features")
        stages += [assembler]
        pipeline = Pipeline(stages=stages)

        features_transform = pipeline.fit(fraud_df.select(sel_cols))
        app.logger.info("PipelineModel loaded")

        fraud_df = features_transform.transform(fraud_df)
        fraud_df = kmeans_algo.transform(fraud_df)
        
        app.logger.info("Fraud data count after cluster prediction: " + str(fraud_df.count()))
        app.logger.info("Fraud cluster is predicted")
        
        
    except Exception as e:
        app.logger.info(e)
        
    return fraud_df


# Genuine cluster predict
def cluster_predict_genuine(week_data, conf, mapped_dict, app):
    try:
        kmeans_algo = KMeansModel.load(conf['Kmeans_model'])
        app.logger.info("K-Means genuine cluster model is loaded")

        sel_cols = list(mapped_dict.values())

        stages = []
        assembler_inputs = sel_cols
        assembler = VectorAssembler(inputCols=assembler_inputs, outputCol="features")
        stages += [assembler]
        pipeline = Pipeline(stages=stages)

        features_transform = pipeline.fit(week_data.select(sel_cols))
        app.logger.info("PipelineModel loaded")

        week_data = features_transform.transform(week_data)
        week_data = kmeans_algo.transform(week_data)
        
    except Exception as e:
        app.logger.info(e)
        
    return week_data


# Fraud sampling
def fraud_sampling(df):
    # Define Window
    wspec = Window.partitionBy("SD_PAN").orderBy("DD_DATE")

    # First frauds
    df = df.withColumn("row_number", row_number().over(wspec))
    ff_data = df.filter((df.row_number == 1) & (df.Fraud == 1))
    
    # Non first frauds
    non_ff_data = df.filter((df.row_number != 1) & (df.Fraud == 1))

    # Resample
    if (ff_data.count() * 1) > (non_ff_data.count()):
        total_fraud_data = ff_data.union(non_ff_data)
    else:
        non_ff_sample_ratio = (ff_data.count() * 1)/non_ff_data.count()
        non_ff_sample = non_ff_data.sample(False, fraction = non_ff_sample_ratio, seed = 88)
        total_fraud_data = ff_data.union(non_ff_sample)
    
    return total_fraud_data


# Detail table & fraud table join
def detail_fraud_join(det, fd, app):
    app.logger.info("Joining the Detail and Fraud  Tables")

    fd_2 = fd.select(col('SD_TIEBREAKER').alias('FD_TIEBREAKER'), 'ND_MARK_TYPE').rdd.repartition(50).toDF()
    fd_2 = fd_2.withColumn('Fraud', lit(1))

    ta = det.alias('ta')
    tb = fd_2.alias('tb')

    df_fd_join = ta.join(tb, ta.SD_TIEBREAKER == tb.FD_TIEBREAKER, how='left')

    fill_col_vals = {'Fraud': 0}

    df_fd_join = df_fd_join.na.fill(fill_col_vals)
    df_fd_join = df_fd_join.drop('FD_TIEBREAKER')
    del fd_2, ta, tb
    
    return df_fd_join


def sampling_data(historical_data, previous_week_data, conf, req_cols, mapped_dict, app, fraud_cluster_flag):
    app.logger.info("Sampling Data")
    
    try:
        # Merge historical & previous frauds
        historical_previous_frauds = historical_data.select(req_cols).filter(historical_data.Fraud == 1). \
                                     union(previous_week_data.select(req_cols).filter(previous_week_data.Fraud == 1))        
        # Drop NaNs
        historical_previous_frauds = historical_previous_frauds.dropna()
        app.logger.info("Selected Frauds in Historical & Previous Week")
        
        # Cache
        historical_previous_frauds = historical_previous_frauds.cache()
                
        if fraud_cluster_flag == "Yes": # For CNP Secured & CNP Unsecured 
            app.logger.info(historical_previous_frauds.columns)
            fraud_clusters = cluster_predict_fraud(historical_previous_frauds, conf, mapped_dict, app)            
            
            li = fraud_clusters.select("prediction").distinct().collect()
            app.logger.info(li)
            unique_clusters = []
            
            for i in range(0, len(li)):
                unique_clusters.append(li[i]["prediction"])
           
            app.logger.info("Unique fraud clusters:")
            app.logger.info(unique_clusters)

            # Append all the sampled clusters
            cluster_df_fraud_list = []

            for cluster in unique_clusters:
                cluster_df = fraud_clusters.filter(fraud_clusters.prediction == cluster)
                cluster_df_sampled = fraud_sampling(cluster_df)

                cluster_df_fraud_list.append(cluster_df_sampled)

            # Merge all cluster df's
            total_fraud_data = reduce(DataFrame.unionAll, cluster_df_fraud_list)
            app.logger.info("Fraud Data is Created")
             
        else: # For ATM & POS
            total_fraud_data = fraud_sampling(historical_previous_frauds)
            app.logger.info("Fraud Data is Created")
            
        # Total frauds after resampling
        total_frauds = total_fraud_data.count()

        # Sample genuine transactions from historical data
        historical_data_genuine = historical_data.filter(historical_data.Fraud == 0)        
        historical_sample_ratio  = (total_frauds * conf['historical_sampling_ratio'])/historical_data_genuine.count()
        historical_sample = historical_data_genuine.select(req_cols). \
                            sample(False, fraction=historical_sample_ratio, seed = 88).union(total_fraud_data.select(req_cols))
        
        app.logger.info("Merged Fraud & " + str(conf['historical_sampling_ratio']) + " Genuine from Historical Data")

        # Sample genuine transactions from previous week 
        previous_week_genuine = previous_week_data.filter(previous_week_data.Fraud == 0)
        app.logger.info("Genuine Transactions in Previous Week: "+ str(previous_week_genuine.count()))
        

        # List of clusters
        li = previous_week_genuine.select("prediction").distinct().collect()
        unique_clusters = []

        for i in range(0, len(li)):
            unique_clusters.append(li[i]["prediction"])

        # Append all the sampled clusters
        total_genuine_data = None

        for cluster in unique_clusters:
            app.logger.info("Cluster Processing : "+str(cluster))
            cluster_df = previous_week_genuine.filter(previous_week_genuine.prediction == cluster)
            app.logger.info(cluster_df.count())
            
            if cluster_df.count() != 0:
                cluster_sample = (total_frauds * conf["pweek_sampling_ratio"]*(cluster_df.count()/previous_week_genuine.count()))/cluster_df.count()
                cluster_df_sampled = cluster_df.sample(False,fraction = cluster_sample,seed=70)
                
                if total_genuine_data is None:
                    total_genuine_data = cluster_df_sampled
                else:
                    total_genuine_data = total_genuine_data.unionAll(cluster_df_sampled)

        total_genuine = total_genuine_data.count()
        
        # Final training data
        training_sample = historical_sample.select(req_cols).union(total_genuine_data.select(req_cols))

        for key, short_key in mapped_dict.items():
            training_sample = training_sample.withColumnRenamed(new=key,existing=short_key)
            
        return training_sample
    
    except Exception as e:
        app.logger.info(e)
        app.logger.info("Something went wrong in creating training data ")
        return None


# Extract previous week data
def extract_transactions(conf, spark, connection, app):
    det_fd = None
    weekly_df = None
    
    try:
        previous_week_date = datetime.datetime.now() - timedelta(days=1)
        previous_week_date = previous_week_date.strftime("%Y-%m-%d")

        query1 = """SELECT * from weekly_aggregates_pipeline_status where CreatedTime >=""" + "'" + \
                 previous_week_date + "'" + " and Status=1"       
        data_ingestion_df = psql.read_sql_query(query1, connection).sort_values(by='CreatedTime',ascending=False). \
                            reset_index(drop=True)
        
        if (data_ingestion_df.shape[0] > 0):
            weekly_df_path = data_ingestion_df[data_ingestion_df['TaskName'] == "weekly_aggregates_merge_api"]. \
                             reset_index(drop=True).loc[0]['OutputTablePath']
            app.logger.info("Previous Week Path: " + weekly_df_path)
            
            weekly_df = spark.read.parquet(weekly_df_path)
            

        if weekly_df is not None:
            weekly_df = weekly_df.filter(weekly_df.channel_Index == conf["channel_Index"])

        else:
            app.logger.info("Some thing went wrong in extracting Detail and Fraud_Detail_Flag")
        
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)

    return weekly_df


def train_test_api(app, conf):
    
    # Global variables
    global spark
    global sc
    training_data = None
    resp = None
    sql_conn = None
    model_version=None
    model_path = None
    previous_week = None
    historical = None

    model_channel_type = conf['ChannelType']
    rt_nrt_flag = conf["RT_NRT_Flag"]
    fraud_cluster_flag = conf["fraud_cluster_flag"]

    # Create Spark Context
    spark, sc = create_spark_context(conf, conf["appName"])

    # Create MySQL Connection Object
    sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
        
    try:
        app.logger.info(conf)
        
        # Previous date
        previous_date = datetime.datetime.now() - timedelta(days=7)
        previous_date = previous_date.strftime("%Y-%m-%d")
        
        # Get historical data & previous week data
        if sql_conn != None:
            fetch_query = """SELECT * from model_pipeline_status where CreatedTime >=""" + "'" + previous_date + "'" + \
                          " and Status=1 and Channel_Type=" + "'" + conf["ChannelType"] + "'"
            model_pipeline_df = psql.read_sql_query(fetch_query, sql_conn)

            if (model_pipeline_df.shape[0] > 0):
                model_pipeline_df = model_pipeline_df.sort_values(by='CreatedTime', ascending=False)
                model_pipeline_df = model_pipeline_df.reset_index(drop=True)
                historical = spark.read.format('parquet').option("inferSchema", "true").\
                                        load(model_pipeline_df.loc[0]['TrainDataPath'])
                historical = historical.fillna(0)
                app.logger.info("Historical data path: " + model_pipeline_df.loc[0]['TrainDataPath'])

            else:
                app.logger.info("Historical data is not available for the date range specified")

            previous_week = extract_transactions(conf, spark, sql_conn, app)

        else:
            app.logger.info('MySql connection is not established')
            
        # Preprocess previous week data
        if (previous_week != None):
            previous_week = previous_week.withColumn('MD_CUST_TRAN_AMT1', col('MD_CUST_TRAN_AMT1').cast("double"))
            previous_week = previous_week.withColumn('MD_CUST_TRAN_AMT4', col('MD_CUST_TRAN_AMT4').cast("double"))
            previous_week = previous_week.fillna(0)
            
#             if "mbr_num_cardtype" in previous_week.columns:
#                 mbr_num_cardtype_udf = udf(lambda x:0 if x=='pricard' else 1, IntegerType())
#                 previous_week = previous_week.withColumn('mbr_num_cardtype', mbr_num_cardtype_udf('mbr_num_cardtype'))
#                 app.logger.info("Column mbr_num_cardtype is numerically encoded")
#             else:
#                 pass
            
            app.logger.info("Loaded previous week data and preprocessed")
            
            # Read features data for the Channel
            features_path = curr_dir + conf['features_path']
            col_df = pd.read_csv(features_path)
            mapped_dict = dict(zip(col_df['feature'], col_df['short_key']))
            
            # Convert feature names to short keys
            for key, short_key in mapped_dict.items():
                previous_week = previous_week.withColumnRenamed(new=short_key, existing=key)
                historical = historical.withColumnRenamed(new=short_key, existing=key)
            
            app.logger.info("Column names converted to short keys")
                
            if "DA12" in previous_week.columns:
                previous_week = previous_week.withColumn('DA12', col('DA12').cast("int"))
                app.logger.info("Column DA12 converted to integer type")
            else:
                pass
            
            req_cols = list(mapped_dict.values()) + ['SD_TIEBREAKER', 'DD_DATE', 'Fraud', 'SD_PAN']
            previous_week = previous_week.select(req_cols).fillna(0)

            # Cluster predict for previous week genuine transactions
            previous_week = cluster_predict_genuine(previous_week, conf, mapped_dict, app)  
            app.logger.info("Clusters predicted for previous week data")
            app.logger.info("No. of transactions in Historical: " + str(historical.count()))
            app.logger.info("No. of transactions in Previous Week: " + str(previous_week.count()))
            
            previous_week = previous_week.cache()
            
            # Create training data
            train_df = sampling_data(historical, previous_week, conf, req_cols, mapped_dict, app, fraud_cluster_flag)
            
            time_stamp = datetime.datetime.now()
            current_year = time_stamp.strftime("%Y")
            current_week_of_year = time_stamp.strftime("%V")
            current_date = time_stamp.strftime("%d_%m_%Y")
            current_time = time_stamp.strftime("%H_%M_%S")

            # Train data path
            train_data_path = conf[
                                  'train_data_path'] + model_channel_type + "/" + rt_nrt_flag + "/" + "year_" + current_year + "/" + "Training_data_" + model_channel_type + '_' + rt_nrt_flag + '_' + 'week_' + current_week_of_year + '_' + current_date + '_' + current_time + ".parquet"  

            delete_hdfs_file(train_data_path)
            app.logger.info(train_data_path)

            # Write data to HDFS
            train_df.write.parquet(train_data_path)
            app.logger.info('Training Data saved to {}'.format(train_data_path))

            resp = {"status": 200, "Error": "NA", "Training_data": train_data_path, "model_channel": model_channel_type,
                    "RT_NRT_Flag": rt_nrt_flag,"model_version":model_version,"model_path":model_path}

        else:
            resp = {"status": 400, "Error": "failed due to internal error", "Training_data": training_data, "model_channel": model_channel_type, "RT_NRT_Flag": rt_nrt_flag,"model_version":model_version,"model_path":model_path}
            
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
        resp = {"status": 400, "Error": str(e), "Training_data": training_data, "model_channel": model_channel_type,
                "RT_NRT_Flag": rt_nrt_flag,"model_version":model_version,"model_path":model_path}
      
    if sc is not None:
        sc.stop()
        
    if sql_conn is not None:
        sql_conn.close()
        
    app.logger.info("Updating Status")
    insert_model_pipeline_status(resp)

    return resp
