from datetime import datetime
from DataBaseUtils.db_utils import mysql_conn
import os

def insert_model_pipeline_status(resp):
    status_flag = False
    try:
        sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
        mycursor = sql_conn.cursor()
        sql = "INSERT INTO model_pipeline_status (CreatedTime,Model_Version,Channel_Type,ModelPath," \
              "RT_NRT_Flag ,TrainDataPath,Status,Error) VALUES (%s, %s, %s, %s, %s, %s ,%s ,%s) "
        
        # CreatedTime:
        created_time = datetime.now()
        # ModelVersion:
        Model_Version= resp["model_version"]
        # Channel_Type:
        channel_type = resp['model_channel']
        
        #ModelPath
        model_path = resp["model_path"]
        #RT_NRT_Flag
        rt_nrt_flag = resp["RT_NRT_Flag"]
        
        #TrainDataPath
        training_data = resp["Training_data"]
        
        #Error
        error = resp["Error"]
        
        #Status
        
        if resp["status"] == 200:
            status = 1
        else:
            status = 0
        
        val = (created_time, Model_Version, channel_type, model_path,rt_nrt_flag,training_data, status, error)
        
            
        mycursor.execute(sql, val)
        sql_conn.commit()
        status_flag = True
        sql_conn.close()
        
    except Exception as e:
        print("Exception occured while storing data in mysql table " + str(e))

    return status_flag