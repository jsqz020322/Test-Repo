# encoding : utf-8 
# Author : B Ravikanth
# Last modified Date : 30-06-2022

import os
import json
import logging
from flask import Flask, jsonify

from Train_data_draft import train_test_api
from Model_Retraining import model_retraining
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])


curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))



class AtmTrainDataApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/atm_train_data_creation.json"
        conf = json.load(open(config_json_path, "r"))
        resp = train_test_api(app,conf)
        return jsonify(resp)
    
class PosTrainDataApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/pos_train_data_creation.json"
        conf = json.load(open(config_json_path, "r"))
        resp = train_test_api(app,conf)
        return jsonify(resp)

class CnpSecuredTrainDataApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/cnp_secured_train_data_creation.json"
        conf = json.load(open(config_json_path, "r"))
        resp = train_test_api(app,conf)
        return jsonify(resp)
    
class CnpUnsecuredTrainDataApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/cnp_unsecured_train_data_creation.json"
        conf = json.load(open(config_json_path, "r"))
        resp = train_test_api(app,conf)
        return jsonify(resp)
    

class AtmModelRetrainingApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/atm_model_retraining.json"
        conf = json.load(open(config_json_path, "r"))
        resp = model_retraining(app,conf)
        return jsonify(resp)
        
class PosModelRetrainingApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/pos_model_retraining.json"
        conf = json.load(open(config_json_path, "r"))
        resp = model_retraining(app,conf)
        return jsonify(resp)

class CnpSecuredModelRetrainingApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/cnp_secured_model_retraining.json"
        conf = json.load(open(config_json_path, "r"))
        resp = model_retraining(app,conf)
        return jsonify(resp)
    
class CnpUnsecuredModelRetrainingApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/cnp_unsecured_model_retraining.json"
        conf = json.load(open(config_json_path, "r"))
        resp = model_retraining(app,conf)
        return jsonify(resp)
        
api.add_resource(AtmTrainDataApi,'/', '/atm_train_test_api')
api.add_resource(PosTrainDataApi,'/', '/pos_train_test_api')
api.add_resource(CnpSecuredTrainDataApi,'/', '/cnp_secured_train_test_api')
api.add_resource(CnpUnsecuredTrainDataApi,'/', '/cnp_unsecured_train_test_api')
api.add_resource(AtmModelRetrainingApi,'/', '/atm_model_retraining')
api.add_resource(PosModelRetrainingApi,'/', '/pos_model_retraining')
api.add_resource(CnpSecuredModelRetrainingApi,'/', '/cnp_secured_model_retraining')
api.add_resource(CnpUnsecuredModelRetrainingApi,'/', '/cnp_unsecured_model_retraining')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9200")