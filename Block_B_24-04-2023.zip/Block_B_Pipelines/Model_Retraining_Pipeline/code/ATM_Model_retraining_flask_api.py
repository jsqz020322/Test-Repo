# encoding : utf-8 
# Author : B Ravikanth
# Last modified Date : 30-06-2022

import os
import json
import logging
from flask import Flask, jsonify

from Train_data import train_test_api
from Model_Retraining import model_retraining
from flask_restful import Resource,Api
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

csrf_protect = CSRFProtect(app)
api = Api(app,decorators=[csrf_protect.exempt])


curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))



class AtmTrainDataApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/atm_train_data_creation.json"
        conf = json.load(open(config_json_path, "r"))
        resp = train_test_api(app,conf)
        return jsonify(resp)

class AtmModelRetrainingApi(Resource):
    def post(self):
        config_json_path = curr_dir + "/config/atm_model_retraining.json"
        conf = json.load(open(config_json_path, "r"))
        resp = model_retraining(app,conf)
        return jsonify(resp)
        
api.add_resource(AtmTrainDataApi,'/', '/atm_train_test_api')
api.add_resource(AtmModelRetrainingApi,'/', '/atm_model_retraining')

if __name__ == '__main__':
    app.run("0.0.0.0", port="9200",debug=False)