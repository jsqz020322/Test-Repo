# encoding : utf-8 
# Author : Anish srivathsav
# Created  Date : 30-04-2022
# Last Modified Date :

# REQUIRED LIBRARIES
import os
import warnings

warnings.filterwarnings('ignore')
import sys
import pandas as pd
import pyspark.sql.functions as f
from pyspark.sql.types import *
import json
# PYSPARK ML LIBRARIES
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
import datetime

from sklearn2pmml import sklearn2pmml
from sklearn2pmml.pipeline import PMMLPipeline
import pandas.io.sql as psql
from SparkUtils.spark_utils import create_spark_context
from DataBaseUtils.db_utils import mysql_conn
from model_pipeline_status import insert_model_pipeline_status
import joblib

from minio import Minio
from kafka import KafkaProducer
import json

curr_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


# providing spark configuration No. of executors,executor memory etc.,
def check_model_size(model_path, app):
    stat = 1
    app.logger.info("reading file ")
    if os.path.getsize(model_path) > 0:
        stat = 2
        
    return stat

def save_model_minio(model_path,conf,app):
    try:
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        minio_client = Minio(conf["minio_url"],access_key=conf["minio_access_key"],secret_key=conf["minio_secret_key"],secure=False)

        result = minio_client.fput_object(
            conf["minio_bucket_name"], model_path.split("/")[-1], model_path,
            metadata={"Model_version": model_path.split("/")[-1]},
        )
        
        app.logger.info("Model file saved in minio in path :  "+str(result.object_name))

        value_serializer = lambda x:x.encode('utf-8')
        producer = KafkaProducer(bootstrap_servers=conf["bootstrap_servers"],client_id=conf["client_id"],value_serializer=value_serializer)

        msg = {"minio_bucket":"pmml-files","minio_object_name":result.object_name,"file_location":result.location,
           "channel":conf["ChannelType"],"model_version":result.object_name,"model_timestamp":current_date}
        
        producer.send(topic=conf["topic"],value=str(msg))
        producer.close()
        
        app.logger.info("Model detials published to kafka : ")
        
    except Exception as e:
        app.logger.info("Exception occured in save model minio "+str(e))
    
    
def save_model_jfrog(model_path,conf,app):
    try:
        
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        
        bash_cmd = """curl -sSf -u """+conf["JFROG_USERNAME"]+":"+conf["JFROG_PASSWORD"]+""" -X PUT -T """+model_path+"""  https://artifactory.hdfcbank.com:443/artifactory/QTXMLFraudDetection/"""
        
        res = os.system(bash_cmd)
        
        app.logger.info(res)
        
        if res==0:
            
            
        
            model_version = model_path.split("/")[-1]
            jfrog_path = "https://artifactory.hdfcbank.com:443/artifactory/QTXMLFraudDetection/"+model_version

            app.logger.info("Model file saved in jfrog in path :  "+str(model_version))

            value_serializer = lambda x:x.encode('utf-8')
            producer = KafkaProducer(bootstrap_servers=conf["bootstrap_servers"],client_id=conf["client_id"],value_serializer=value_serializer)

            msg = {"minio_bucket":"QTXMLFraudDetection","minio_object_name":model_version,"file_location":jfrog_path,
               "channel":conf["ChannelType"],"model_version":model_version,"model_timestamp":current_date}
            
            app.logger.info(msg)

            producer.send(topic=conf["topic"],value=str(msg))
            producer.close()
        
            app.logger.info("Model detials published to kafka : ")
        else:
            app.logger.info("Model file not saved in jfrog in path :  ")
        
    except Exception as e:
        app.logger.info("Exception occured in save model minio "+str(e))
    

# Model Training
def algorithm_training(spark, conf, training_data_path, model_path, app):
    ret_val = None
    try:
        features_path = curr_dir + conf['features_path']
        col_df = pd.read_csv(features_path)
#         app.logger.info(col_df.head())
        mapped_dict = dict(zip(col_df['feature'], col_df['short_key']))
        app.logger.info(training_data_path)
        train_data = spark.read.format('parquet').option("inferSchema", "true").load(training_data_path)
        train_data = train_data.withColumn('label', f.col('Fraud').cast("int"))
        
        
        for key, short_key in mapped_dict.items():
            train_data = train_data.withColumnRenamed(new=short_key, existing=key)
        req_cols = list(mapped_dict.values())
        
        if conf["ChannelType"] == "POS":
            train_data = train_data.drop(*["I2","MD_T3_3","MD_T3_30","MD_T4_3","MD_T4_30"])
            req_cols = [r for r in req_cols if r not in ["I2","MD_T3_3","MD_T3_30","MD_T4_3","MD_T4_30"]]
        
        if conf["ChannelType"] == "CNP SECURED":
            train_data = train_data.drop(*["I2","FC_30"])
            req_cols = [r for r in req_cols if r not in ["I2","FC_30"]]
            
        if conf["ChannelType"] == "CNP UNSECURED":
            train_data = train_data.drop(*["I2","FC_3","FC_30"])
            req_cols = [r for r in req_cols if r not in ["I2","FC_3","FC_30"]]
        

        # converting Data into Pandas Dataframe
        train_df = train_data.toPandas()

        X = train_df.drop('label', axis=1)
        Y = train_df['label']
        # converting data into arrays for Model Re-Training
        train_x = X[req_cols]
        train_y = Y

        if conf["ChannelType"] == "ATM":
            # Algorithm  Training
            parameters = conf["HyperParameters"]
            rf_grid_search = GridSearchCV(estimator=RandomForestClassifier(n_jobs=10, bootstrap=True, verbose=1,
                                                                           criterion='entropy',
                                                                           min_samples_leaf=conf['minSamplesLeaf'],
                                                                           max_leaf_nodes=conf['MaxLeafNodes'],
                                                                           max_features='auto'), param_grid=parameters,
                                          cv=3)
            rf_grid_search.fit(train_x, train_y)
            best_parameters = rf_grid_search.best_params_

            rf = RandomForestClassifier(n_jobs=-1, random_state=789, bootstrap=True, verbose=1,
                                        criterion=conf['impurity'], max_depth=best_parameters['max_depth'],
                                        n_estimators=best_parameters['n_estimators'],
                                        min_samples_leaf=conf['minSamplesLeaf'], max_leaf_nodes=conf['MaxLeafNodes'])

            rf_model = rf.fit(train_x, train_y)
        
        else: # POS
            # Algorithm  Training
            parameters = conf["HyperParameters"]
            rf_grid_search = GridSearchCV(estimator=RandomForestClassifier(n_jobs=10, bootstrap=True, verbose=1,
                                                                           criterion='entropy',
                                                                           max_leaf_nodes=conf['MaxLeafNodes'],
                                                                           max_features='auto'), param_grid=parameters,
                                          cv=3)
            rf_grid_search.fit(train_x, train_y)
            best_parameters = rf_grid_search.best_params_

            rf = RandomForestClassifier(n_jobs=-1, random_state=789, bootstrap=True, verbose=1,
                                        criterion=conf['impurity'], max_depth=best_parameters['max_depth'],
                                        n_estimators=best_parameters['n_estimators'],max_leaf_nodes=conf['MaxLeafNodes'])

            rf_model = rf.fit(train_x, train_y)
            
        joblib_file = model_path.replace(".pmml",".joblib")
        
        joblib.dump(rf_model,joblib_file)
            

        # saving the Model as pmml file
        app.logger.info(model_path)
        try:
            os.remove(model_path)
        except Exception as e:
            app.logger.info("something went wrong in  Removing If older model  file exist")

        pipeline = PMMLPipeline([("classifier", rf)])
        pipeline.fit(train_x, train_y)
        sklearn2pmml(pipeline, model_path)
        status = check_model_size(model_path, app)
        if status == 2:
            app.logger.info("Model Saved")
            
            save_model_jfrog(model_path,conf,app)
            
            #    EXTRACTING FEATURE IMPORTANCES
            important_feat_dict = {}
            reverse_mapped_dict = dict(zip(mapped_dict.values(), mapped_dict.keys()))
            for idx, val in enumerate(rf_model.feature_importances_):
                important_feat_dict[X[req_cols].columns[idx]] = val

            feat_df = pd.DataFrame(important_feat_dict.items(), columns=['feature', 'value'])

            feat_df = feat_df.sort_values(by='value', ascending=False).reset_index()
            feat_df = feat_df.replace({'feature': reverse_mapped_dict})
            ret_val = feat_df
        else:
            app.logger.info("Model is not saved because  something went wrong in Model Re-Training")
    except Exception as e:
        app.logger.info("something went wrong in Algorithm Training")
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(e)
        app.logger.info(exc_val)
    
    return ret_val


def model_retraining(app,conf):
    sc = None
    resp = None
    model_channel_type = conf['ChannelType']
    rt_nrt_flag = conf['RT_NRT_Flag']
    spark, sc = create_spark_context(conf, conf["appName"])
    sql_conn = None
    sql_conn = mysql_conn(os.getenv("BLOCK_B_CONN"))
    training_data = None
    try:
        app.logger.info(conf)
        
        if conf["kerberos_flag"] == "True":
            
            try:
                kerb_cmd = "kinit -kt "+conf["keytab_path"]+" "+conf["kerberos_path"]
                os.system(kerb_cmd)

                app.logger.info("kerberos initialization done")


            except Excpetion as e:
                app.logger.info(e)
        
        
        app.logger.info("connecting to Databse")
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        if sql_conn != None:
            fetch_query = ' SELECT * FROM  model_pipeline_status WHERE  CreatedTime >=' + "'" + current_date + "'"'' + \
                          ' and Channel_Type=' + "'" + model_channel_type + "'"
            model_pipeline_df = psql.read_sql_query(fetch_query, sql_conn)
            model_pipeline_df = model_pipeline_df.sort_values(by='CreatedTime',ascending=False).reset_index(drop=True)
            app.logger.info(model_pipeline_df.head())

            if (model_pipeline_df.shape[0] > 0) and (model_pipeline_df.loc[0]['Status'] == 1) and (
                    model_pipeline_df.loc[0]['RT_NRT_Flag'] == "NRT") and (
                    model_pipeline_df.loc[0]['TrainDataPath'] != None):

                training_data_path = model_pipeline_df.loc[0]['TrainDataPath']
                app.logger.info(training_data_path)
                current_year = datetime.datetime.now().strftime("%Y")
                current_week = datetime.datetime.now().strftime("%V")
                current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                model_channel_type = conf['ChannelType']
                rt_nrt_flag = conf['RT_NRT_Flag']
                model_version = "Q_" + str(rt_nrt_flag) + "_" + str(model_channel_type) + "_" + "Year_" + str(
                    current_year) + "_W" + str(current_week) + "_" + str(current_date)
                app.logger.info(model_version)
                
                try:
                    os.makedirs((conf['ModelRootPath'] + "/" +conf['RT_NRT_Flag'] + "/" + conf['ChannelType']).replace(" ","_"))
                except:
                    app.logger.info("Model save directories exist")
                
                model_path = conf['ModelRootPath'] + "/" +conf['RT_NRT_Flag'] + "/" + conf['ChannelType'] + "/" + "Q_" + str(
                    rt_nrt_flag) + "_" + str(model_channel_type) + "_" + "Year_" + str(current_year) + "_" + "W" + str(
                    current_week) + "_" + str(current_date) + ".pmml"
                
                model_path = model_path.replace(" ","_")
                
                feature_df = algorithm_training(spark, conf, training_data_path, model_path, app)
                
                try:
                    os.makedirs((conf['FeaturesRootPath'] + "/" + conf['RT_NRT_Flag'] + "/" + conf['ChannelType']).replace(" ","_"))
                except:
                    app.logger.info("Feature imp save directories exist")
                
                feature_path = conf['FeaturesRootPath'] + "/" + conf['RT_NRT_Flag'] + "/" + conf[
                    'ChannelType'] + "/" + "Q_" + str(rt_nrt_flag) + "_" + str(
                    model_channel_type) + "_" + "Year_" + str(
                    current_year) + "_" + "W" + str(current_week) + "_" + str(current_date) + ".csv"
                
                feature_path = feature_path.replace(" ","_")
                try:
                    os.remove(feature_path)
                except OSError as e:
                    app.logger.info(" Exception occured :" + str(e))

                app.logger.info('saving  the feature importances')
                feature_df.to_csv(feature_path, index=False, header=True)
                resp = {"status": 200, "Error": "NA", "model_channel": model_channel_type, "RT_NRT_Flag": rt_nrt_flag,
                        "model_path": model_path,
                        "model_version": model_version, "Status": 1, "Training_data": training_data_path}

            else:
                app.logger.info("There is No Update Training DataPath  in  Database ")
                
                resp = {"status": 400, "Error": "There is No Update Training DataPath  in  Database ", "model_channel": model_channel_type, "RT_NRT_Flag": rt_nrt_flag,
                        "model_path": None,
                        "model_version": None, "Status": 0, "Training_data": training_data}

        else:
            app.logger.info(' MySql connection is not established..successfully!!')
            resp = {"status": 400, "Error": " MySql connection is not established..successfully!! ", "model_channel": model_channel_type, "RT_NRT_Flag": rt_nrt_flag,
                        "model_path": None,
                        "model_version": None, "Status": 0, "Training_data": training_data}

    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_val = "Exception occured : " + str(exc_type) + " " + str(fname) + " " + str(exc_tb.tb_lineno) + " " + str(
            error)
        app.logger.info(exc_val)
        training_data = None
        model_channel_type = conf['ChannelType']
        rt_nrt_flag = conf['RT_NRT_Flag']
        resp = {"status": 400, "Error": exc_val, "model_channel": model_channel_type, "RT_NRT_Flag": rt_nrt_flag,
                "model_path": None,
                "model_version": None, "Status": 0, "Training_data": training_data}
        
    
    if sc is not None:
        sc.stop()

    if sql_conn is not None:
        sql_conn.close()
    insert_model_pipeline_status(resp)

    return resp
