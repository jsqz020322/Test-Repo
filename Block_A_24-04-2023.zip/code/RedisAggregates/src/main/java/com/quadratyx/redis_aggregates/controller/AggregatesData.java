package com.quadratyx.redis_aggregates.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisCluster;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AggregatesData {

    private static final Logger logger = LoggerFactory.getLogger(AggregatesData.class);

    @Autowired
    @Qualifier("redisClusterConfiguration")
    private JedisCluster jedisCluster;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @PostMapping(value = "/redisaggregates", headers = "Accept=application/json")
    public Map<String, Object> redisData(@RequestBody Map<String, String> requestData) {

        Map<String, Object> jsonOut = new HashMap<>();
        String status = "50";

        try {
            logger.info("Data Size = " + requestData.size());
            for (Map.Entry<String, String> entry : requestData.entrySet()) {
//                String key = entry.getKey();
//                String value = entry.getValue();
//                if (jedisCluster.exists(key)) {
//                    jedisCluster.del(key);
//                }
                jedisCluster.set(entry.getKey(), entry.getValue());
            }
            status = "20";
        } catch (Exception ie) {
            logger.error("Exception =" + ie.getMessage(), ie);
            StringWriter sw = new StringWriter();
            ie.printStackTrace(new PrintWriter(sw));
            String exception = sw.toString();
            sendMessage(exception, exceptionTopic);
            status = "50";
        }
        jsonOut.put("Status", status);
        return jsonOut;
    }

    private void sendMessage(String message, String topicName) {
        kafkaTemplate.send(topicName, message);
    }
}
