package com.quadratyx.redis_aggregates.async;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.core.*;

import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisPoolConfig;



@Configuration
@EnableAsync
public class AsyncConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(AsyncConfiguration.class);

    @Value("${spring.redis.host}")
    private String host;

    @Value("${spring.redis.port}")
    private int port;

    @Value("${spring.redis.jedis.pool.max-total}")
    private int maxTotal;

    @Value("${spring.redis.jedis.pool.max-idle}")
    private int maxIdle;

    @Value("${spring.redis.jedis.pool.min-idle}")
    private int minIdle;

    @Value("${spring.redis.connectionTimeout}")
    private int connectionTimeout;

    @Value("${spring.redis.soTimeout}")
    private int soTimeout;

    @Value("${spring.redis.password}")
    private String password;

    @Value("${spring.redis.maxAttempts}")
    private int maxAttempts;

    @Value("${spring.redis.maxTimeMilli}")
    private int maxTimeMilli;

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${spring.kafka.producer.ssl.trust-store-location}")
    private String trustStoreLocation;

    @Value("${spring.kafka.producer.ssl.trust-store-password}")
    private String trustStorePassword;

    @Value("${spring.kafka.producer.ssl.key-store-location}")
    private String keyStoreLocation;

    @Value("${spring.kafka.producer.ssl.key-store-password}")
    private String keyStorePassword;

    @Value("${spring.kafka.security.protocol}")
    private String securityProtocol;

    @Value("${spring.kafka.linger.ms}")
    private String lingerMs;

    @Value("${spring.kafka.batch.size}")
    private String batchSize;

    @Value("${spring.kafka.compression.type}")
    private String compressionType;

    @Bean(name="redisClusterConfiguration")
    public JedisCluster getRedisCluster() {
        Set<HostAndPort> jedisClusterNode = new HashSet<>();
        jedisClusterNode.add(new HostAndPort(host,port));
        JedisPoolConfig cfg = new JedisPoolConfig();
        cfg.setMaxTotal(maxTotal);
        cfg.setMaxIdle(maxIdle);
        cfg.setMaxWaitMillis(maxTimeMilli);
        cfg.setTestOnBorrow(true);
        return new JedisCluster(jedisClusterNode, connectionTimeout, soTimeout, maxAttempts , password,  cfg );
    }

    @Bean
    public Map<String,Object> producerConfigs(){
        Map<String,Object> props = new HashMap<>();
        try {
            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            props.put(ProducerConfig.LINGER_MS_CONFIG,lingerMs);
            props.put(ProducerConfig.BATCH_SIZE_CONFIG,batchSize);
            props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG,compressionType);
            props.put(ProducerConfig.RETRIES_CONFIG, 3);
            props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, 1000);
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,trustStoreLocation);
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,trustStorePassword);
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,keyStoreLocation);
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,keyStorePassword);
            props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG,"");
            props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG,securityProtocol);
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        }
        catch(Exception e){
            logger.error("ProducerConfigs bean ----");
            logger.error(String.valueOf(e));
        }
        return props;
    }

    @Bean
    public ProducerFactory<String,String> producerFactory(){
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String,String> kafkaTemplate (){
        return new KafkaTemplate<>(producerFactory());
    }
}