#!/bin/sh
java -jar RedisAggregates.jar  --spring.config.location=/config/application.properties
