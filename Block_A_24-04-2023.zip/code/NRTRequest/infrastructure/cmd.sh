#!/bin/sh
java -jar NRTRequest.jar --spring.config.location=/config/application.properties