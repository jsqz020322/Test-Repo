package com.quadratyx.NRTRequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes={com.quadratyx.NRTRequest.NrtRequestApplicationTests.class})

class NrtRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
