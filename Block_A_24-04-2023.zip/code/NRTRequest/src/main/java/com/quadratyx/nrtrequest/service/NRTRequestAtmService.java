package com.quadratyx.nrtrequest.service;

import com.quadratyx.nrtrequest.model.NRTRequestFormat;

import java.util.Map;

/**
 * An interface for NRTRequest ATM Service
 */
public interface NRTRequestAtmService {

    /**
     * This is the unimplemented method for NRT Request Atm Service
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return NRTResponseFormat object
     * @throws Exception in case of invalid format
     */
    int nrtScoreAtmService(String tId, Map<String, Object> cacheMap);

    /**
     * This is the unimplemented method used for producing messages into kafka topics as asynchronous mode
     *
     * @param message   the message details
     * @param topicName the kafka topic name
     * @return a <code> null </code>
     */
    void sendMessage(String message, String topicName);

    void sendInputMessage(Map<String, Object> cacheMap, NRTRequestFormat nrtRequestFormat, String topicName);

    void logTrace(NRTRequestFormat nrtRequestFormat, Map<String, Object> jsonOut);
}

