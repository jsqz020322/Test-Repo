package com.quadratyx.nrtrequest.controller;

import com.quadratyx.nrtrequest.model.NRTRequestFormat;
import com.quadratyx.nrtrequest.service.NRTRequestAtmService;
import com.quadratyx.nrtrequest.service.NRTRequestCNPSecuredService;
import com.quadratyx.nrtrequest.service.NRTRequestCNPUnsecuredService;
import com.quadratyx.nrtrequest.service.NRTRequestPosService;
import com.quadratyx.nrtrequest.serviceImpl.PreProcessingFunctions;
import com.quadratyx.nrtrequest.serviceImpl.RedisCacheService;
import com.quadratyx.nrtrequest.util.BusinessConstant;
import com.quadratyx.nrtrequest.util.CommanCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * A rest controller class for calling API end point.
 */
@RestController
public class NRTScoreController {
    private static final Logger logger = LoggerFactory.getLogger(NRTScoreController.class);

    @Autowired
    private NRTRequestAtmService nrtRequestAtmService;

    @Autowired
    private NRTRequestPosService nrtRequestPosService;

    @Autowired
    private NRTRequestCNPSecuredService nrtRequestCNPSecuredService;

    @Autowired
    private NRTRequestCNPUnsecuredService nrtRequestCNPUnsecuredService;

    @Autowired
    private PreProcessingFunctions preProcessingservice;

    @Autowired
    private RedisCacheService cacheService;

    @Autowired
    @Qualifier("config")
    private Map<String, String> cityPostCdesDict;

    @Autowired
    @Qualifier("config1")
    private Map<String, String> postCdeDict;

    @Autowired
    @Qualifier("defaultAggregate")
    private Map<String, Object> defaultAggregate;

    @Autowired
    @Qualifier("merchantDefaultAggregate")
    private Map<String, Object> merchantDefaultAggregate;

    @Value("${spring.kafka.bootstrap.inputtopic}")
    private String inputTopic;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    /**
     * This is the method for calling API end point "/fetchnrtscore"
     *
     * @param nrtRequestFormat transaction information for near real time request
     * @return a <code> Map of String, Object </code> as a response JSON
     * @throws Exception in case of any exception
     */
    @PostMapping(value = "/fetchnrtscore", headers = "Accept=application/json")
    public Map<String, Object> nrtRequest(@Valid @RequestBody NRTRequestFormat nrtRequestFormat) throws Exception {
        long st = System.currentTimeMillis();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss.SSS");
        String s_time = LocalDateTime.now().format(dateTimeFormatter);

        Map<String, Object> jsonOut = new HashMap<>();
        String key = nrtRequestFormat.getPan().toString();
        String tId = nrtRequestFormat.getTiebreaker();
        jsonOut.put("Tiebreaker", tId);
        String nearRealTimeRsnCode1 = "NearRealTimeRsnCode1";
        try {
            String sdFiid = nrtRequestFormat.getFiid();
            CompletableFuture<Integer> channelType = preProcessingservice.ChannelType(nrtRequestFormat.getProdInd(), nrtRequestFormat.getEComFlag(), nrtRequestFormat.getRtlrSICCode(), nrtRequestFormat.getPontOfSrvceEntryMode());
            CompletableFuture<Integer> monetaryTrain = preProcessingservice.monetary_tran(nrtRequestFormat.getTranCode());
            CompletableFuture<Integer> tempBlkCard = preProcessingservice.temp_blk_card(sdFiid, nrtRequestFormat.getCardStat(), nrtRequestFormat.getCardBlckCode());
            CompletableFuture<String> cardType = preProcessingservice.cardType(nrtRequestFormat.getBin(), nrtRequestFormat.getFiid());

            Long lddDate = nrtRequestFormat.getTranDateTime();
            String ddDate = Long.toString(lddDate);
            Instant iddDate = Instant.ofEpochMilli(lddDate);

            int transType = preProcessingservice.Transtype(nrtRequestFormat.getAcqrInstIdNum());
            int pinChangeDays = preProcessingservice.diff_days(String.valueOf(nrtRequestFormat.getCardPINChngDate()), iddDate);
            int addrChangeDays = preProcessingservice.diff_days(String.valueOf(nrtRequestFormat.getLastAdrsChngDate()), iddDate);
            int crdReqstDays = preProcessingservice.diff_days(String.valueOf(nrtRequestFormat.getCardRqstDate()), iddDate);
            CompletableFuture<Integer> hourType = preProcessingservice.hour_classify(lddDate);
            int sdFid = preProcessingservice.credit_card_flag(sdFiid);
            int authSrc = preProcessingservice.auth_src(nrtRequestFormat.getTranAuthSrc());
            int isHotSpotCountry = preProcessingservice.hotspotCountryFlag(nrtRequestFormat.getTermCntr());

            Map<String, Object> cacheMap = new HashMap<>(cacheService.getCachedata(key, tId, defaultAggregate));

            Double tranAmt1 = nrtRequestFormat.getTranAmt1();
            Double custTranAmt1 = nrtRequestFormat.getCustTranAmt1();
            String SD_TERM_POSTAL_CDE = (String) cacheMap.get("P39");

            //CompletableFuture<Integer> ageBins = preProcessingservice.age_bins(String.valueOf(cacheMap.get("D3")), iddDate);
            CompletableFuture<Double> maxWithdrawalAmtPerDay = preProcessingservice.maxWithdrawalAmtPerDay(ddDate, String.valueOf(cacheMap.get("P34")), (Double) cacheMap.get("WD_1"), tranAmt1);

            CompletableFuture<Integer> result = channelType.thenApply(cType -> cType);
            int cType = result.get();
            if (cType == -1) {
                logger.error("transaction {} for  unknown channel", tId);
                String value = "Tiebreaker: " + tId + "\n" + "ProdInd: " + nrtRequestFormat.getProdInd() + " " + "RtlrSICCode: " + nrtRequestFormat.getRtlrSICCode() + " " + "EComFlag: " + nrtRequestFormat.getEComFlag() + " " + "EntryMode: " + nrtRequestFormat.getPontOfSrvceEntryMode();
                nrtRequestAtmService.sendMessage(value, exceptionTopic);

                jsonOut.put("NearRealTimeScore", 0);
                jsonOut.put(nearRealTimeRsnCode1, BusinessConstant.OK);
            } else {
                int current_state_mapping = 0;
                int current_city_mapping = 0;
                int current_country_mapping = 0;
                String merchantKey = nrtRequestFormat.getTermid();
                switch (cType) {
                    case 1 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);
                    }
                    case 3 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);

                        current_state_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C1_L"), nrtRequestFormat.getTermSt());
                        current_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C2_L"), nrtRequestFormat.getTermCity());
                        current_country_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C3_L"), nrtRequestFormat.getTermCntr());
                    }
                    case 4 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);

                        current_state_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU1_L"), nrtRequestFormat.getTermSt());
                        current_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU2_L"), nrtRequestFormat.getTermCity());
                        current_country_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU3_L"), nrtRequestFormat.getTermCntr());
                    }
                }

                CompletableFuture<Integer> monetaryTrainResult = monetaryTrain.thenApply(mTrain -> mTrain);
                int mTrain = monetaryTrainResult.get();

                String cntryType = preProcessingservice.CntryType(nrtRequestFormat.getTermCntr());
                int amountBins = preProcessingservice.AmountBins(tranAmt1, mTrain);
                int domTranFlag = preProcessingservice.domTranFlag(cntryType);

                String termPostalCode = preProcessingservice.term_postal_code(nrtRequestFormat.getTermPstlCode());
                CompletableFuture<String> postalCdeCleaned = preProcessingservice.clean_post_cde_rem_char(termPostalCode, cntryType);
                String checkPostalCode = preProcessingservice.check_postal_cde(postalCdeCleaned, cntryType, postCdeDict);
                String fillPostalCde = preProcessingservice.fill_postal_cde(nrtRequestFormat.getTermCity(), checkPostalCode, cntryType, cityPostCdesDict);
                String locLatLong = preProcessingservice.fill_lat_long(fillPostalCde, cntryType, postCdeDict);
                CompletableFuture<String> prevPostalCdeCleaned = preProcessingservice.clean_post_cde_rem_char(SD_TERM_POSTAL_CDE, cntryType);
                String prevPostalCode = preProcessingservice.check_postal_cde(prevPostalCdeCleaned, cntryType, postCdeDict);
                String prevLatLong = preProcessingservice.fill_lat_long(prevPostalCode, cntryType, postCdeDict);
                Double distancePrevloc = preProcessingservice.distance_prevloc(locLatLong, prevLatLong);
                int distancePrevlocation = distancePrevloc.intValue();

                CompletableFuture<String> userPostalCdeCleaned = preProcessingservice.clean_post_cde_rem_char((String) cacheMap.get("CM_3"), cntryType);
                String userCheckPostalCode = preProcessingservice.check_postal_cde(userPostalCdeCleaned, cntryType, postCdeDict);
                String userLocLatLong = preProcessingservice.fill_lat_long(userCheckPostalCode, cntryType, postCdeDict);
                String userPrevLatLong = preProcessingservice.fill_lat_long(prevPostalCode, cntryType, postCdeDict);
                Double distanceHomeLoc = preProcessingservice.distance_prevloc(userLocLatLong, userPrevLatLong);
                int distFromHomeLoc = distanceHomeLoc.intValue();

                int netbankingRegCardFlag = preProcessingservice.netbanking_reg((String) cacheMap.get("S24"));
                int prevTranTimeDiffMins = preProcessingservice.prev_tran_time_diff_mins(lddDate, String.valueOf(cacheMap.get("P34")));
                int blkcdeIndex = preProcessingservice.crd_blk_cde(nrtRequestFormat.getFiid(), nrtRequestFormat.getCardBlckCode());
                int atmTermCityClassNumIndex = preProcessingservice.metro_flag(nrtRequestFormat.getTermNameLoc());
                int insufficientBalFlag = preProcessingservice.insufficientBalFlag(custTranAmt1, tranAmt1);
                int prePostalcdeMatching = preProcessingservice.prev_current_term_matching(SD_TERM_POSTAL_CDE, nrtRequestFormat.getTermPstlCode());
                int prevTermCityMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P36"), nrtRequestFormat.getTermCity());
                int prevTermCntryMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P38"), nrtRequestFormat.getTermCntr());
                int prevTermNameLocMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P35"), nrtRequestFormat.getTermNameLoc());
                int prevTermStateMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P37"), nrtRequestFormat.getTermSt());
                int prevTermCityMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P40"), nrtRequestFormat.getTermCity());
                int prevTermCntryMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P42"), nrtRequestFormat.getTermCntr());
                int prevTermStateMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P41"), nrtRequestFormat.getTermSt());

                Double balAmount = preProcessingservice.bal_amount(tranAmt1, custTranAmt1, mTrain);
                String balAmountBins = preProcessingservice.balAmountBins(balAmount, mTrain);
                int balanceAmountBinsIndex = preProcessingservice.balanceAmountBinsIndex(balAmountBins);

                int cardTypeIndex = preProcessingservice.cardTypeIndex(cardType);
                Double limits = preProcessingservice.limits(cardType, custTranAmt1);
                int withdrawAmtExceedFlag = preProcessingservice.withdrawAmtExceedFlag(maxWithdrawalAmtPerDay, limits);
                int frequentMerchantFlag = preProcessingservice.frequentMerchantFlag(String.valueOf(cacheMap.get("M_S_60")), nrtRequestFormat.getTermid());
                int MerchantFlag = preProcessingservice.MerchantFlagPOS(String.valueOf(cacheMap.get("M_L_30")), nrtRequestFormat.getRtlrSICCode());
                int mbrNumCardType = preProcessingservice.mbrNumCardType(nrtRequestFormat.getMmbrNum());

                int loc_city_mapping = 0;
                if (nrtRequestFormat.getTermCity() != null) {
                    loc_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("P36"), nrtRequestFormat.getTermCity());
                }
                cacheMap.put("L1", loc_city_mapping);

                CommanCode commanCode = new CommanCode();
                commanCode.utilFunc(nrtRequestFormat, cType, mTrain, transType, pinChangeDays, addrChangeDays, crdReqstDays,
                        hourType, sdFid, authSrc, cntryType, tempBlkCard, amountBins, distancePrevlocation,
                        distFromHomeLoc, netbankingRegCardFlag, domTranFlag, prevTranTimeDiffMins, blkcdeIndex,
                        atmTermCityClassNumIndex, insufficientBalFlag, prePostalcdeMatching, prevTermCityMatching,
                        prevTermCntryMatching, prevTermNameLocMatching, prevTermStateMatching,
                        prevTermCityMatchingChannelwise, prevTermCntryMatchingChannelwise, prevTermStateMatchingChannelwise,
                        isHotSpotCountry, mbrNumCardType, balanceAmountBinsIndex, cardTypeIndex, limits, maxWithdrawalAmtPerDay,
                        withdrawAmtExceedFlag, frequentMerchantFlag, MerchantFlag, current_city_mapping, current_state_mapping,
                        current_country_mapping, cacheMap);

                int mScore = -1;
                switch (cType) {
                    case 1 -> mScore = nrtRequestPosService.nrtScorePosService(tId, cacheMap);
                    case 2 -> mScore = nrtRequestAtmService.nrtScoreAtmService(tId, cacheMap);
                    case 3 -> mScore = nrtRequestCNPSecuredService.nrtScoreCNPSecuredService(tId, cacheMap);
                    case 4 -> mScore = nrtRequestCNPUnsecuredService.nrtScoreCNPUnsecuredService(tId, cacheMap);
                }

                if (mScore == -1) {
                    jsonOut.put(nearRealTimeRsnCode1, BusinessConstant.INTERNAL_SERVER_ERROR);
                } else {
                    jsonOut.put("NearRealTimeScore", mScore);
                    jsonOut.put(nearRealTimeRsnCode1, BusinessConstant.OK);
                    cacheMap.put("FS", mScore);
                    cacheMap.remove("TS1");
                    nrtRequestAtmService.sendInputMessage(cacheMap, nrtRequestFormat, inputTopic);
                }
            }

        } catch (Exception e) {
            logger.error("Exception is " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Error in Controller Tiebreaker: " + tId + "\n" + sw.toString();
            nrtRequestAtmService.sendMessage(exception, exceptionTopic);
            jsonOut.put(nearRealTimeRsnCode1, BusinessConstant.INTERNAL_SERVER_ERROR);
        } finally {
            Map<String, Object> logJsonOut = new HashMap<>(jsonOut);
            logJsonOut.put("s_time", s_time);
            logJsonOut.put("t_ms", (System.currentTimeMillis() - st));
            logJsonOut.put("e_time", LocalDateTime.now().format(dateTimeFormatter));
            nrtRequestAtmService.logTrace(nrtRequestFormat, logJsonOut);
        }
        return jsonOut;
    }
}