package com.quadratyx.nrtrequest.serviceImpl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.nrtrequest.model.NRTRequestFormat;
import com.quadratyx.nrtrequest.service.NRTRequestAtmService;
import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.FieldValue;
import org.jpmml.evaluator.InputField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This service module is used for prediction of model score for ATM NRT Transactions
 */
@Service
public class NRTRequestAtmServiceImpl implements NRTRequestAtmService {
    private static final Logger logger = LoggerFactory.getLogger(NRTRequestAtmServiceImpl.class);

    @Autowired
    @Lazy
    @Qualifier("atmMapping")
    private Evaluator evaluator;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${spring.kafka.bootstrap.outputtopic}")
    private String outputTopic;

    /**
     * This is the implemented method used for prediction of model score for NRT Transactions
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return int
     * @throws Exception in case of any exception
     */

    public int nrtScoreAtmService(String tId, Map<String, Object> cacheMap) {
        int score = -1;
        Map<String, FieldValue> arguments = null;
        try {
            List<InputField> inputFields = evaluator.getInputFields();
            arguments = new HashMap<>();

            for (InputField inputField : inputFields) {
                String inputName = inputField.getName();
                Object rawValue = cacheMap.get(inputName);
                FieldValue inputValue = inputField.prepare(rawValue);
                arguments.put(inputName, inputValue);
            }
            Map<String, Object> results = (Map<String, Object>) evaluator.evaluate(arguments);
            Double sc = (Double) results.get("probability(1)") * 100;
            score = (int) Math.round(sc);
        } catch (Exception e) {
            score = -1;
            //logger.error("Exception " + e.getMessage(), e);
            //logger.error("arguments ==" + arguments.toString());
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Model Failed to execute ATM Tiebreaker: " + tId + "\n" + sw.toString() + "\n" + arguments;
            sendMessage(exception, exceptionTopic);
        }
        return score;
    }

    /**
     * This is the implemented method used for producing messages into kafka topics as asynchronous mode
     *
     * @param message   the message details
     * @param topicName the kafka topic name
     * @return a <code> null </code>
     */
    @Async("nrtLogThreadPoolTaskExecutor")
    public void sendMessage(String message, String topicName) {
        ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topicName, message);
        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
            public void onSuccess(SendResult<String, String> result) {
            }

            public void onFailure(Throwable ex) {
            }
        });
    }

    @Async("nrtLogThreadPoolTaskExecutor")
    public void sendInputMessage(Map<String, Object> cacheMap, NRTRequestFormat nrtRequestFormat, String topicName) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            Map<String, Object> rawMap = objectMapper.convertValue(nrtRequestFormat, HashMap.class);
            cacheMap.putAll(rawMap);

            String message = objectMapper.writeValueAsString(cacheMap);
            ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topicName, message);
            future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
                public void onSuccess(SendResult<String, String> result) {
                }
                public void onFailure(Throwable ex) {
                    //logger.error("Unable to send message = [");
                }
            });
        } catch (Exception e) {
            logger.error("Exception is " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Unable to publish message to DA : " + nrtRequestFormat.getTiebreaker() + "\n" + sw.toString();
            sendMessage(exception, exceptionTopic);
        }
    }

    @Async("nrtLogThreadPoolTaskExecutor")
    public void logTrace(NRTRequestFormat nrtRequestFormat, Map<String, Object> jsonOut) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> loggerMap = new HashMap<>();
            loggerMap.put("RequestBody", nrtRequestFormat.toString());
            loggerMap.put("ResponseBody", jsonOut.toString());

            String message = objectMapper.writeValueAsString(loggerMap);
            ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(outputTopic, message);
            future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
                public void onSuccess(SendResult<String, String> result) {
                }

                public void onFailure(Throwable ex) {
                }
            });
        } catch (Exception e) {
            logger.error("Exception = " + e.getMessage(), e);
        }
    }

}