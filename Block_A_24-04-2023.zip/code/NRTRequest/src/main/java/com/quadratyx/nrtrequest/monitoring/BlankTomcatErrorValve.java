package com.quadratyx.nrtrequest.monitoring;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.valves.ErrorReportValve;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Writer;

public class BlankTomcatErrorValve extends ErrorReportValve {
    private static final Logger logger = LoggerFactory.getLogger(BlankTomcatErrorValve.class);

    protected void report(Request request, Response response, Throwable throwable) {
        if (!response.setErrorReported())
            return;
        logger.warn("{} Fatal error before getting to Spring. {}", response.getStatus(), throwable);
        try {
            Writer writer = response.getReporter();
            writer.write(Integer.toString(response.getStatus()));
            writer.write(" Fatal error. Could not process request.");
            response.finishResponse();
        } catch (IOException e) {
        }
    }


}
