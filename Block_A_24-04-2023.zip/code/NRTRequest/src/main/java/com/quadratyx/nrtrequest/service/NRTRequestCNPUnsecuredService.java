package com.quadratyx.nrtrequest.service;

import java.util.Map;

/**
 * An interface for NRTRequest CNP Secured Service
 */
public interface NRTRequestCNPUnsecuredService {

    /**
     * This is the unimplemented method for NRT Request CNPUnsecured Service
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return int
     */
    int nrtScoreCNPUnsecuredService(String tId, Map<String, Object> cacheMap);
}
