package com.quadratyx.nrtrequest.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.validation.constraints.NotNull;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This is a model class to hold transaction information for near real time request
 *
 * @see Object
 */
@JsonInclude(JsonInclude.Include.ALWAYS)
@JsonPropertyOrder({
        "Tiebreaker",
        "RecordSourceId",
        "PAN",
        "RETLID",
        "AcctNum",
        "TERMID",
        "TranCode",
        "TranAmt1",
        "MsgType",
        "PontOfSrvcCondCode",
        "PontOfSrvceEntryMode",
        "EComFlag",
        "EMVTrmnlVrfyRslt",
        "EMVUsrFlr",
        "RtlrSICCode",
        "TermNameLoc",
        "TermCity",
        "TermSt",
        "TermCntr",
        "TermPstlCode",
        "CustTranAmt1",
        "CustTranAmt4",
        "PINTries",
        "AcqrInstIdNum",
        "FrwdInstId",
        "TranAuthSrc",
        "CAVVAAV",
        "AcctType",
        "FIID",
        "BIN",
        "PINIndx",
        "MmbrNum",
        "CardPrdtType",
        "CardStat",
        "CardBlckCode",
        "TranDateTime",
        "CardRqstDate",
        "CardPINChngDate",
        "LastAdrsChngDate",
        "IBK1InstIdNum",
        "ProdInd",
        "SqncNum",
        "TranRsnCode",
        "CardVrfyFlag",
        "CVDPrsntFlag",
        "EMVCardVrfyRslts",
        "CustTranAmt2",
        "CustTranAmt3",
        "CustTranDate",
        "CredDebInd",
        "CashInd",
        "OrgnCrncyCode",
        "AchNum",
        "ScndryAcctNmbr",
        "OrigWireAcctId",
        "BenWireAcctId",
        "TranAmt2",
        "TranAmt3",
        "SlsRjctCde",
        "VisaAdvncAuthScor_Type",
        "AprvlCode",
        "RespCode",
        "OrigWireInstIDNum",
        "OrigWireCntryCode",
        "OrigWireCrncyCode",
        "BenWireInstIdNum",
        "BenWireCntryCode",
        "BenWireCrncyCode",
        "RealTimeStat",
        "RealTimeDsps",
        "RealTimeRuleFrd",
        "RealTimeRuleDsps",
        "RealTimeScore"
})

public class NRTRequestFormat {

    @JsonProperty("Tiebreaker")
    @NotNull
    private String tiebreaker;
    @JsonProperty("RecordSourceId")
    private Integer recordSourceId;
    @NotNull
    @JsonProperty("PAN")
    private String pan;
    @JsonProperty("RETLID")
    private String retlid;
    @JsonProperty("AcctNum")
    private String acctNum;
    @JsonProperty("TERMID")
    private String termid;
    @JsonProperty("TranCode")
    private String tranCode;
    @JsonProperty("TranAmt1")
    private Double tranAmt1;
    @JsonProperty("MsgType")
    private String msgType;
    @JsonProperty("PontOfSrvcCondCode")
    private String pontOfSrvcCondCode;
    @NotNull
    @JsonProperty("PontOfSrvceEntryMode")
    private String pontOfSrvceEntryMode;
    @JsonProperty("EComFlag")
    private String eComFlag;
    @JsonProperty("EMVTrmnlVrfyRslt")
    private String eMVTrmnlVrfyRslt;
    @JsonProperty("EMVUsrFlr")
    private String eMVUsrFlr;
    @NotNull
    @JsonProperty("RtlrSICCode")
    private String rtlrSICCode;
    @JsonProperty("TermNameLoc")
    private String termNameLoc;
    @JsonProperty("TermCity")
    private String termCity;
    @JsonProperty("TermSt")
    private String termSt;
    @JsonProperty("TermCntr")
    private String termCntr;
    @JsonProperty("TermPstlCode")
    private String termPstlCode;
    @JsonProperty("CustTranAmt1")
    private Double custTranAmt1;
    @JsonProperty("CustTranAmt4")
    private Double custTranAmt4;
    @JsonProperty("PINTries")
    private String pINTries;
    @JsonProperty("AcqrInstIdNum")
    private String acqrInstIdNum;
    @JsonProperty("FrwdInstId")
    private String frwdInstId;
    @JsonProperty("TranAuthSrc")
    private String tranAuthSrc;
    @JsonProperty("CAVVAAV")
    private Integer cavvaav;
    @JsonProperty("AcctType")
    private String acctType;
    @JsonProperty("FIID")
    private String fiid;
    @JsonProperty("BIN")
    private String bin;
    @JsonProperty("PINIndx")
    private String pINIndx;
    @JsonProperty("MmbrNum")
    private String mmbrNum;
    @JsonProperty("CardPrdtType")
    private String cardPrdtType;
    @JsonProperty("CardStat")
    private String cardStat;
    @JsonProperty("CardBlckCode")
    private String cardBlckCode;
    @JsonProperty("TranDateTime")
    private Long tranDateTime;
    @JsonProperty("CardRqstDate")
    private Long cardRqstDate;
    @JsonProperty("CardPINChngDate")
    private Long cardPINChngDate;
    @JsonProperty("LastAdrsChngDate")
    private Long lastAdrsChngDate;
    @JsonProperty("IBK1InstIdNum")
    private String iBK1InstIdNum;
    @NotNull
    @JsonProperty("ProdInd")
    private String prodInd;
    @JsonProperty("SqncNum")
    private String sqncNum;
    @JsonProperty("TranRsnCode")
    private String tranRsnCode;
    @JsonProperty("CardVrfyFlag")
    private String cardVrfyFlag;
    @JsonProperty("CVDPrsntFlag")
    private String cVDPrsntFlag;
    @JsonProperty("EMVCardVrfyRslts")
    private String eMVCardVrfyRslts;
    @JsonProperty("CustTranAmt2")
    private Double custTranAmt2;
    @JsonProperty("CustTranAmt3")
    private Double custTranAmt3;
    @JsonProperty("CustTranDate")
    private Long custTranDate;
    @JsonProperty("CredDebInd")
    private String credDebInd;
    @JsonProperty("CashInd")
    private String cashInd;
    @JsonProperty("OrgnlCrncyCode")
    private String orgnlCrncyCode;
    @JsonProperty("AchNum")
    private String achNum;
    @JsonProperty("ScndryAcctNmbr")
    private String scndryAcctNmbr;
    @JsonProperty("OrigWireAcctId")
    private String origWireAcctId;
    @JsonProperty("BenWireAcctId")
    private String benWireAcctId;
    @JsonProperty("TranAmt2")
    private Double tranAmt2;
    @JsonProperty("TranAmt3")
    private Double tranAmt3;
    @JsonProperty("SlsRjctCde")
    private String slsRjctCde;
    @JsonProperty("VisaAdvncAuthScor_Type")
    private String visaAdvncAuthScorType;
    @JsonProperty("AprvlCode")
    private String aprvlCode;
    @JsonProperty("RespCode")
    private String respCode;
    @JsonProperty("OrigWireInstIDNum")
    private String origWireInstIDNum;
    @JsonProperty("OrigWireCntryCode")
    private String origWireCntryCode;
    @JsonProperty("OrigWireCrncyCode")
    private String origWireCrncyCode;
    @JsonProperty("BenWireInstIdNum")
    private String benWireInstIdNum;
    @JsonProperty("BenWireCntryCode")
    private String benWireCntryCode;
    @JsonProperty("BenWireCrncyCode")
    private String benWireCrncyCode;
    @JsonProperty("RealTimeStat")
    private String realTimeStat;
    @JsonProperty("RealTimeDsps")
    private String realTimeDsps;
    @JsonProperty("RealTimeRuleFrd")
    private Integer realTimeRuleFrd;
    @JsonProperty("RealTimeRuleDsps")
    private String realTimeRuleDsps;
    @JsonProperty("RealTimeScore")
    private Integer realTimeScore;

    /**
     * Default Constructor
     */
    public NRTRequestFormat() {
        //Default Constructor
    }

    /**
     * Gets the Tiebreaker detail
     *
     * @return a <code> string </code>
     * specifying the Tiebreaker detail
     */

    @JsonProperty("Tiebreaker")
    public String getTiebreaker() {
        return tiebreaker;
    }

    /**
     * Sets the Tiebreaker detail
     *
     * @param tiebreaker the Tiebreaker detail
     */
    @JsonProperty("Tiebreaker")
    public void setTiebreaker(String tiebreaker) {
        this.tiebreaker = tiebreaker;
    }

    /**
     * Gets the RecordSourceId detail
     *
     * @return a <code> integer </code>
     * specifying the RecordSourceId detail
     */
    @JsonProperty("RecordSourceId")
    public Integer getRecordSourceId() {
        return recordSourceId;
    }

    /**
     * Sets the  RecordSourceId detail
     *
     * @param recordSourceId the RecordSourceId detail
     */
    @JsonProperty("RecordSourceId")
    public void setRecordSourceId(Integer recordSourceId) {
        this.recordSourceId = recordSourceId;
    }


    /**
     * Gets the PAN detail
     *
     * @return a <code> string </code>
     * specifying the PAN detail
     */
    @JsonProperty("PAN")
    public UUID getPan() {
        return generateType5UUID(pan);
    }

    /**
     * Sets the PAN detail
     *
     * @param pan the PAN detail
     * @throws Exception in case of Invalid value
     */
    @JsonProperty("PAN")
    public void setPan(String pan) throws Exception {
        Pattern p = Pattern.compile("^[0-9]{13,19}$");
        Matcher m = p.matcher(pan);
        if (!m.find())
            throw (new Exception("Invalid value!! Expects a 13 to 19 digit number "));
        this.pan = pan;
    }

    /**
     * Gets the RETLID detail
     *
     * @return a <code> string </code>
     * specifying the RETLID detail
     */
    @JsonProperty("RETLID")
    public String getRetlid() {
        return retlid;
    }

    /**
     * Sets the RETLID detail
     *
     * @param retlid the RETLID detail
     */
    @JsonProperty("RETLID")
    public void setRetlid(String retlid) {
        this.retlid = retlid;
    }

    /**
     * Gets the AcctNum detail
     *
     * @return a <code> string </code>
     * specifying the AcctNum detail
     */
    @JsonProperty("AcctNum")
    public String getAcctNum() {
        return acctNum;
    }

    /**
     * Sets the AcctNum detail
     *
     * @param acctNum the AcctNum detail
     */
    @JsonProperty("AcctNum")
    public void setAcctNum(String acctNum) {
        this.acctNum = acctNum;
    }

    /**
     * Gets the TERMID detail
     *
     * @return a <code> string </code>
     * specifying the TERMID detail
     */
    @JsonProperty("TERMID")
    public String getTermid() {
        return termid;
    }

    /**
     * Sets the TERMID detail
     *
     * @param termid the TERMID detail
     */
    @JsonProperty("TERMID")
    public void setTermid(String termid) {
        this.termid = termid;
    }

    /**
     * Gets the TranCode detail
     *
     * @return a <code> string </code>
     * specifying the TranCode detail
     */
    @JsonProperty("TranCode")
    public String getTranCode() {
        return tranCode;
    }

    /**
     * Sets the TranCode detail
     *
     * @param tranCode the TranCode detail
     */
    @JsonProperty("TranCode")
    public void setTranCode(String tranCode) {
        this.tranCode = tranCode;
    }

    /**
     * Gets the TranAmt1 detail
     *
     * @return a <code> double </code>
     * specifying the TranAmt1 detail
     */
    @JsonProperty("TranAmt1")
    public Double getTranAmt1() {
        return tranAmt1;
    }

    /**
     * Sets the TranAmt1 detail
     *
     * @param tranAmt1 the TranAmt1 detail
     */
    @JsonProperty("TranAmt1")
    public void setTranAmt1(Double tranAmt1) {
        this.tranAmt1 = tranAmt1;
    }

    /**
     * Gets the MsgType detail
     *
     * @return a <code> string </code>
     * specifying the MsgType detail
     */
    @JsonProperty("MsgType")
    public String getMsgType() {
        return msgType;
    }

    /**
     * Sets the MsgType detail
     *
     * @param msgType the MsgType detail
     */
    @JsonProperty("MsgType")
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    /**
     * Gets the PontOfSrvcCondCode detail
     *
     * @return a <code> string </code>
     * specifying the PontOfSrvcCondCode detail
     */
    @JsonProperty("PontOfSrvcCondCode")
    public String getPontOfSrvcCondCode() {
        return pontOfSrvcCondCode;
    }

    /**
     * Sets the PontOfSrvcCondCode detail
     *
     * @param pontOfSrvcCondCode the PontOfSrvcCondCode detail
     */
    @JsonProperty("PontOfSrvcCondCode")
    public void setPontOfSrvcCondCode(String pontOfSrvcCondCode) {
        this.pontOfSrvcCondCode = pontOfSrvcCondCode;
    }

    /**
     * Gets the PontOfSrvceEntryMode detail
     *
     * @return a <code> string </code>
     * specifying the PontOfSrvceEntryMode detail
     */
    @JsonProperty("PontOfSrvceEntryMode")
    public String getPontOfSrvceEntryMode() {
        return pontOfSrvceEntryMode;
    }

    /**
     * Sets the PontOfSrvceEntryMode detail
     *
     * @param pontOfSrvceEntryMode the PontOfSrvceEntryMode detail
     */
    @JsonProperty("PontOfSrvceEntryMode")
    public void setPontOfSrvceEntryMode(String pontOfSrvceEntryMode) {
        this.pontOfSrvceEntryMode = pontOfSrvceEntryMode;
    }

    /**
     * Gets the EComFlag detail
     *
     * @return a <code> string </code>
     * specifying the EComFlag detail
     */
    @JsonProperty("EComFlag")
    public String getEComFlag() {
        return eComFlag;
    }

    /**
     * Sets the EComFlag detail
     *
     * @param eComFlag the EComFlag detail
     */
    @JsonProperty("EComFlag")
    public void setEComFlag(String eComFlag) {
        this.eComFlag = eComFlag;
    }

    /**
     * Gets the EMVTrmnlVrfyRslt detail
     *
     * @return a <code> string </code>
     * specifying the EMVTrmnlVrfyRslt detail
     */
    @JsonProperty("EMVTrmnlVrfyRslt")
    public String getEMVTrmnlVrfyRslt() {
        return eMVTrmnlVrfyRslt;
    }

    /**
     * Sets the EMVTrmnlVrfyRslt detail
     *
     * @param eMVTrmnlVrfyRslt the EMVTrmnlVrfyRslt detail
     */
    @JsonProperty("EMVTrmnlVrfyRslt")
    public void setEMVTrmnlVrfyRslt(String eMVTrmnlVrfyRslt) {
        this.eMVTrmnlVrfyRslt = eMVTrmnlVrfyRslt;
    }

    /**
     * Gets the EMVUsrFlr detail
     *
     * @return a <code> string </code>
     * specifying the EMVUsrFlr detail
     */
    @JsonProperty("EMVUsrFlr")
    public String getEMVUsrFlr() {
        return eMVUsrFlr;
    }

    /**
     * Sets the EMVUsrFlr detail
     *
     * @param eMVUsrFlr the EMVUsrFlr detail
     */
    @JsonProperty("EMVUsrFlr")
    public void setEMVUsrFlr(String eMVUsrFlr) {
        this.eMVUsrFlr = eMVUsrFlr;
    }

    /**
     * Gets the RtlrSICCode detail
     *
     * @return a <code> string </code>
     * specifying the RtlrSICCode detail
     */
    @JsonProperty("RtlrSICCode")
    public String getRtlrSICCode() {
        return rtlrSICCode;
    }

    /**
     * Sets the RtlrSICCode detail
     *
     * @param rtlrSICCode the RtlrSICCode detail
     */
    @JsonProperty("RtlrSICCode")
    public void setRtlrSICCode(String rtlrSICCode) {
        this.rtlrSICCode = rtlrSICCode;
    }

    /**
     * Gets the TermNameLoc detail
     *
     * @return a <code> string </code>
     * specifying the TermNameLoc detail
     */
    @JsonProperty("TermNameLoc")
    public String getTermNameLoc() {
        return termNameLoc;
    }

    /**
     * Sets the TermNameLoc detail
     *
     * @param termNameLoc the TermNameLoc detail
     */
    @JsonProperty("TermNameLoc")
    public void setTermNameLoc(String termNameLoc) {
        this.termNameLoc = termNameLoc;
    }

    /**
     * Gets the TermCity detail
     *
     * @return a <code> string </code>
     * specifying the TermCity detail
     */
    @JsonProperty("TermCity")
    public String getTermCity() {
        return termCity;
    }

    /**
     * Sets the TermCity detail
     *
     * @param termCity the TermCity detail
     */
    @JsonProperty("TermCity")
    public void setTermCity(String termCity) {
        this.termCity = termCity;
    }

    /**
     * Gets the TermSt detail
     *
     * @return a <code> string </code>
     * specifying the TermSt detail
     */
    @JsonProperty("TermSt")
    public String getTermSt() {
        return termSt;
    }

    /**
     * Sets the TermSt detail
     *
     * @param termSt the TermSt detail
     */
    @JsonProperty("TermSt")
    public void setTermSt(String termSt) {
        this.termSt = termSt;
    }

    /**
     * Gets the TermCntr detail
     *
     * @return a <code> string </code>
     * specifying the TermCntr detail
     */
    @JsonProperty("TermCntr")
    public String getTermCntr() {
        return termCntr;
    }

    /**
     * Sets the TermCntr detail
     *
     * @param termCntr the TermCntr detail
     */
    @JsonProperty("TermCntr")
    public void setTermCntr(String termCntr) {
        this.termCntr = termCntr;
    }

    /**
     * Gets the TermPstlCode detail
     *
     * @return a <code> string </code>
     * specifying the TermPstlCode detail
     */
    @JsonProperty("TermPstlCode")
    public String getTermPstlCode() {
        return termPstlCode;
    }

    /**
     * Sets the TermPstlCode detail
     *
     * @param termPstlCode the TermPstlCode detail
     */
    @JsonProperty("TermPstlCode")
    public void setTermPstlCode(String termPstlCode) {
        this.termPstlCode = termPstlCode;
    }

    /**
     * Gets the CustTranAmt1 detail
     *
     * @return a <code> string </code>
     * specifying the CustTranAmt1 detail
     */
    @JsonProperty("CustTranAmt1")
    public Double getCustTranAmt1() {
        return custTranAmt1;
    }

    /**
     * Sets the CustTranAmt1 detail
     *
     * @param custTranAmt1 the CustTranAmt1 detail
     */
    @JsonProperty("CustTranAmt1")
    public void setCustTranAmt1(Double custTranAmt1) {
        this.custTranAmt1 = custTranAmt1;
    }

    /**
     * Gets the CustTranAmt4 detail
     *
     * @return a <code> string </code>
     * specifying the CustTranAmt4 detail
     */
    @JsonProperty("CustTranAmt4")
    public Double getCustTranAmt4() {
        return custTranAmt4;
    }

    /**
     * Sets the CustTranAmt4 detail
     *
     * @param custTranAmt4 the CustTranAmt4 detail
     */
    @JsonProperty("CustTranAmt4")
    public void setCustTranAmt4(Double custTranAmt4) {
        this.custTranAmt4 = custTranAmt4;
    }

    /**
     * Gets the PINTries detail
     *
     * @return a <code> string </code>
     * specifying the PINTries detail
     */
    @JsonProperty("PINTries")
    public String getPINTries() {
        return pINTries;
    }

    /**
     * Sets the PINTries details
     *
     * @param pINTries the PINTries details
     */
    @JsonProperty("PINTries")
    public void setPINTries(String pINTries) {
        this.pINTries = pINTries;
    }

    /**
     * Gets the AcqrInstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the AcqrInstIdNum detail
     */
    @JsonProperty("AcqrInstIdNum")
    public String getAcqrInstIdNum() {
        return acqrInstIdNum;
    }

    /**
     * Sets the AcqrInstIdNum detail
     *
     * @param acqrInstIdNum the AcqrInstIdNum detail
     */
    @JsonProperty("AcqrInstIdNum")
    public void setAcqrInstIdNum(String acqrInstIdNum) {
        this.acqrInstIdNum = acqrInstIdNum;
    }

    /**
     * Gets the FrwdInstId detail
     *
     * @return a <code> string </code>
     * specifying the FrwdInstId detail
     */
    @JsonProperty("FrwdInstId")
    public String getFrwdInstId() {
        return frwdInstId;
    }

    /**
     * Sets the FrwdInstId detail
     *
     * @param frwdInstId the FrwdInstId detail
     */
    @JsonProperty("FrwdInstId")
    public void setFrwdInstId(String frwdInstId) {
        this.frwdInstId = frwdInstId;
    }

    /**
     * Gets the TranAuthSrc detail
     *
     * @return a <code> string </code>
     * specifying the TranAuthSrc detail
     */
    @JsonProperty("TranAuthSrc")
    public String getTranAuthSrc() {
        return tranAuthSrc;
    }

    /**
     * Sets the TranAuthSrc detail
     *
     * @param tranAuthSrc the TranAuthSrc detail
     */
    @JsonProperty("TranAuthSrc")
    public void setTranAuthSrc(String tranAuthSrc) {
        this.tranAuthSrc = tranAuthSrc;
    }

    /**
     * Gets the CAVVAAV detail
     *
     * @return a <code> integer </code>
     * specifying the CAVVAAV detail
     */
    @JsonProperty("CAVVAAV")
    public Integer getCavvaav() {
        return cavvaav;
    }

    /**
     * Sets the CAVVAAV detail
     *
     * @param cavvaav the CAVVAAV detail
     */
    @JsonProperty("CAVVAAV")
    public void setCavvaav(Integer cavvaav) {
        this.cavvaav = cavvaav;
    }

    /**
     * Gets the AcctType detail
     *
     * @return a <code> string </code>
     * specifying the AcctType detail
     */
    @JsonProperty("AcctType")
    public String getAcctType() {
        return acctType;
    }

    /**
     * Sets the AcctType detail
     *
     * @param acctType the AcctType detail
     */
    @JsonProperty("AcctType")
    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    /**
     * Gets the FIID detail
     *
     * @return a <code> string </code>
     * specifying the FIID detail
     */
    @JsonProperty("FIID")
    public String getFiid() {
        return fiid;
    }

    /**
     * Sets the FIID detail
     *
     * @param fiid the FIID detail
     */
    @JsonProperty("FIID")
    public void setFiid(String fiid) {
        this.fiid = fiid;
    }

    /**
     * Gets the BIN detail
     *
     * @return a <code> string </code>
     * specifying the BIN detail
     */
    @JsonProperty("BIN")
    public String getBin() {
        return bin;
    }

    /**
     * Sets the BIN detail
     *
     * @param bin the BIN detail
     */
    @JsonProperty("BIN")
    public void setBin(String bin) {
        this.bin = bin;
    }

    /**
     * Gets the PINIndx detail
     *
     * @return a <code> string </code>
     * specifying the PINIndx detail
     */
    @JsonProperty("PINIndx")
    public String getPINIndx() {
        return pINIndx;
    }

    /**
     * Sets the PINIndx detail
     *
     * @param pINIndx the PINIndx detail
     */
    @JsonProperty("PINIndx")
    public void setPINIndx(String pINIndx) {
        this.pINIndx = pINIndx;
    }

    /**
     * Gets the MmbrNum detail
     *
     * @return a <code> string </code>
     * specifying the MmbrNum detail
     */
    @JsonProperty("MmbrNum")
    public String getMmbrNum() {
        return mmbrNum;
    }

    /**
     * Sets the MmbrNum detail
     *
     * @param mmbrNum the MmbrNum detail
     */
    @JsonProperty("MmbrNum")
    public void setMmbrNum(String mmbrNum) {
        this.mmbrNum = mmbrNum;
    }

    /**
     * Gets the CardPrdtType detail
     *
     * @return a <code> string </code>
     * specifying the CardPrdtType detail
     */
    @JsonProperty("CardPrdtType")
    public String getCardPrdtType() {
        return cardPrdtType;
    }

    /**
     * Sets the CardPrdtType detail
     *
     * @param cardPrdtType the CardPrdtType detail
     */
    @JsonProperty("CardPrdtType")
    public void setCardPrdtType(String cardPrdtType) {
        this.cardPrdtType = cardPrdtType;
    }

    /**
     * Gets the CardStat detail
     *
     * @return a <code> string </code>
     * specifying the CardStat detail
     */
    @JsonProperty("CardStat")
    public String getCardStat() {
        return cardStat;
    }

    /**
     * Sets the CardStat detail
     *
     * @param cardStat the CardStat detail
     */
    @JsonProperty("CardStat")
    public void setCardStat(String cardStat) {
        this.cardStat = cardStat;
    }

    /**
     * Gets the CardBlckCode detail
     *
     * @return a <code> string </code>
     * specifying the CardBlckCode detail
     */
    @JsonProperty("CardBlckCode")
    public String getCardBlckCode() {
        return cardBlckCode;
    }

    /**
     * Sets the CardBlckCode detail
     *
     * @param cardBlckCode the CardBlckCode detail
     */
    @JsonProperty("CardBlckCode")
    public void setCardBlckCode(String cardBlckCode) {
        this.cardBlckCode = cardBlckCode;
    }

    /**
     * Gets the TranDateTime detail
     *
     * @return a <code> long </code>
     * specifying the TranDateTime detail
     */
    @JsonProperty("TranDateTime")
    public Long getTranDateTime() {
        return tranDateTime;
    }

    /**
     * Sets the TranDateTime detail
     *
     * @param tranDateTime the TranDateTime detail
     */
    @JsonProperty("TranDateTime")
    public void setTranDateTime(Long tranDateTime) {
        this.tranDateTime = tranDateTime;
    }

    /**
     * Gets the CardRqstDate detail
     *
     * @return a <code> long </code>
     * specifying the CardRqstDate detail
     */
    @JsonProperty("CardRqstDate")
    public Long getCardRqstDate() {
        return cardRqstDate;
    }

    /**
     * Sets the CardRqstDate detail
     *
     * @param cardRqstDate the CardRqstDate detail
     */
    @JsonProperty("CardRqstDate")
    public void setCardRqstDate(Long cardRqstDate) {
        this.cardRqstDate = cardRqstDate;
    }

    /**
     * Gets the CardPINChngDate detail
     *
     * @return a <code> long </code>
     * specifying the CardPINChngDate detail
     */
    @JsonProperty("CardPINChngDate")
    public Long getCardPINChngDate() {
        return cardPINChngDate;
    }

    /**
     * Sets the CardPINChngDate detail
     *
     * @param cardPINChngDate the CardPINChngDate detail
     */
    @JsonProperty("CardPINChngDate")
    public void setCardPINChngDate(Long cardPINChngDate) {
        this.cardPINChngDate = cardPINChngDate;
    }

    /**
     * Gets the LastAdrsChngDate detail
     *
     * @return a <code> long </code>
     * specifying the LastAdrsChngDate detail
     */
    @JsonProperty("LastAdrsChngDate")
    public Long getLastAdrsChngDate() {
        return lastAdrsChngDate;
    }

    /**
     * Sets the LastAdrsChngDate detail
     *
     * @param lastAdrsChngDate the LastAdrsChngDate detail
     */
    @JsonProperty("LastAdrsChngDate")
    public void setLastAdrsChngDate(Long lastAdrsChngDate) {
        this.lastAdrsChngDate = lastAdrsChngDate;
    }

    /**
     * Gets the IBK1InstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the IBK1InstIdNum detail
     */
    @JsonProperty("IBK1InstIdNum")
    public String getIBK1InstIdNum() {
        return iBK1InstIdNum;
    }

    /**
     * Sets the IBK1InstIdNum detail
     *
     * @param iBK1InstIdNum the IBK1InstIdNum detail
     */
    @JsonProperty("IBK1InstIdNum")
    public void setIBK1InstIdNum(String iBK1InstIdNum) {
        this.iBK1InstIdNum = iBK1InstIdNum;
    }

    /**
     * Gets the ProdInd detail
     *
     * @return a <code> string </code>
     * specifying the ProdInd detail
     */
    @JsonProperty("ProdInd")
    public String getProdInd() {
        return prodInd;
    }

    /**
     * Sets the ProdInd detail
     *
     * @param prodInd the ProdInd detail
     */
    @JsonProperty("ProdInd")
    public void setProdInd(String prodInd) {
        this.prodInd = prodInd;
    }

    /**
     * Gets the SqncNum detail
     *
     * @return a <code> string </code>
     * specifying the SqncNum detail
     */
    @JsonProperty("SqncNum")
    public String getSqncNum() {
        return sqncNum;
    }

    /**
     * Sets the SqncNum detail
     *
     * @param sqncNum the SqncNum detail
     */
    @JsonProperty("SqncNum")
    public void setSqncNum(String sqncNum) {
        this.sqncNum = sqncNum;
    }

    /**
     * Gets the TranRsnCode detail
     *
     * @return a <code> string </code>
     * specifying the TranRsnCode detail
     */
    @JsonProperty("TranRsnCode")
    public String getTranRsnCode() {
        return tranRsnCode;
    }

    /**
     * Sets the TranRsnCode detail
     *
     * @param tranRsnCode the TranRsnCode detail
     */
    @JsonProperty("TranRsnCode")
    public void setTranRsnCode(String tranRsnCode) {
        this.tranRsnCode = tranRsnCode;
    }

    /**
     * Gets the CardVrfyFlag detail
     *
     * @return a <code> string </code>
     * specifying the CardVrfyFlag detail
     */
    @JsonProperty("CardVrfyFlag")
    public String getCardVrfyFlag() {
        return cardVrfyFlag;
    }

    /**
     * Sets the CardVrfyFlag detail
     *
     * @param cardVrfyFlag the CardVrfyFlag detail
     */
    @JsonProperty("CardVrfyFlag")
    public void setCardVrfyFlag(String cardVrfyFlag) {
        this.cardVrfyFlag = cardVrfyFlag;
    }

    /**
     * Gets the CVDPrsntFlag detail
     *
     * @return a <code> string </code>
     * specifying the CVDPrsntFlag detail
     */
    @JsonProperty("CVDPrsntFlag")
    public String getCVDPrsntFlag() {
        return cVDPrsntFlag;
    }

    /**
     * Sets the CVDPrsntFlag detail
     *
     * @param cVDPrsntFlag the CVDPrsntFlag detail
     */
    @JsonProperty("CVDPrsntFlag")
    public void setCVDPrsntFlag(String cVDPrsntFlag) {
        this.cVDPrsntFlag = cVDPrsntFlag;
    }

    /**
     * Gets the EMVCardVrfyRslts detail
     *
     * @return a <code> string </code>
     * specifying the EMVCardVrfyRslts detail
     */
    @JsonProperty("EMVCardVrfyRslts")
    public String getEMVCardVrfyRslts() {
        return eMVCardVrfyRslts;
    }

    /**
     * Sets the EMVCardVrfyRslts detail
     *
     * @param eMVCardVrfyRslts the EMVCardVrfyRslts detail
     */
    @JsonProperty("EMVCardVrfyRslts")
    public void setEMVCardVrfyRslts(String eMVCardVrfyRslts) {
        this.eMVCardVrfyRslts = eMVCardVrfyRslts;
    }

    /**
     * Gets the CustTranAmt2 detail
     *
     * @return a <code> double </code>
     * specifying the CustTranAmt2 detail
     */
    @JsonProperty("CustTranAmt2")
    public Double getCustTranAmt2() {
        return custTranAmt2;
    }

    /**
     * Sets the CustTranAmt2 detail
     *
     * @param custTranAmt2 the CustTranAmt2 detail
     */
    @JsonProperty("CustTranAmt2")
    public void setCustTranAmt2(Double custTranAmt2) {
        this.custTranAmt2 = custTranAmt2;
    }

    /**
     * Gets the CustTranAmt3 detail
     *
     * @return a <code> double </code>
     * specifying the CustTranAmt3 detail
     */
    @JsonProperty("CustTranAmt3")
    public Double getCustTranAmt3() {
        return custTranAmt3;
    }

    /**
     * Sets the CustTranAmt3 detail
     *
     * @param custTranAmt3 the CustTranAmt3 detail
     */
    @JsonProperty("CustTranAmt3")
    public void setCustTranAmt3(Double custTranAmt3) {
        this.custTranAmt3 = custTranAmt3;
    }

    /**
     * Gets the CustTranDate detail
     *
     * @return a <code> long </code>
     * specifying the CustTranDate detail
     */
    @JsonProperty("CustTranDate")
    public Long getCustTranDate() {
        return custTranDate;
    }

    /**
     * Sets the CustTranDate detail
     *
     * @param custTranDate the CustTranDate detail
     */
    @JsonProperty("CustTranDate")
    public void setCustTranDate(Long custTranDate) {
        this.custTranDate = custTranDate;
    }

    /**
     * Gets the CredDebInd detail
     *
     * @return a <code> string </code>
     * specifying the CredDebInd detail
     */
    @JsonProperty("CredDebInd")
    public String getCredDebInd() {
        return credDebInd;
    }

    /**
     * Sets the CredDebInd detail
     *
     * @param credDebInd the CredDebInd detail
     */
    @JsonProperty("CredDebInd")
    public void setCredDebInd(String credDebInd) {
        this.credDebInd = credDebInd;
    }

    /**
     * Gets the CashInd detail
     *
     * @return a <code> string </code>
     * specifying the CashInd detail
     */
    @JsonProperty("CashInd")
    public String getCashInd() {
        return cashInd;
    }

    /**
     * Sets the CashInd detail
     *
     * @param cashInd the CashInd detail
     */
    @JsonProperty("CashInd")
    public void setCashInd(String cashInd) {
        this.cashInd = cashInd;
    }

    /**
     * Gets the OrgnlCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the OrgnlCrncyCode detail
     */
    @JsonProperty("OrgnlCrncyCode")
    public String getOrgnlCrncyCode() {
        return orgnlCrncyCode;
    }

    /**
     * Sets the OrgnlCrncyCode detail
     *
     * @param orgnlCrncyCode the OrgnlCrncyCode detail
     */
    @JsonProperty("OrgnlCrncyCode")
    public void setOrgnlCrncyCode(String orgnlCrncyCode) {
        this.orgnlCrncyCode = orgnlCrncyCode;
    }

    /**
     * Gets the AchNum detail
     *
     * @return a <code> string </code>
     * specifying the AchNum detail
     */
    @JsonProperty("AchNum")
    public String getAchNum() {
        return achNum;
    }

    /**
     * Sets the AchNum detail
     *
     * @param achNum the AchNum detail
     */
    @JsonProperty("AchNum")
    public void setAchNum(String achNum) {
        this.achNum = achNum;
    }

    /**
     * Gets the ScndryAcctNmbr detail
     *
     * @return a <code> string </code>
     * specifying the ScndryAcctNmbr detail
     */
    @JsonProperty("ScndryAcctNmbr")
    public String getScndryAcctNmbr() {
        return scndryAcctNmbr;
    }

    /**
     * Sets the ScndryAcctNmbr detail
     *
     * @param scndryAcctNmbr the ScndryAcctNmbr detail
     */
    @JsonProperty("ScndryAcctNmbr")
    public void setScndryAcctNmbr(String scndryAcctNmbr) {
        this.scndryAcctNmbr = scndryAcctNmbr;
    }

    /**
     * Gets the OrigWireAcctId detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireAcctId detail
     */
    @JsonProperty("OrigWireAcctId")
    public String getOrigWireAcctId() {
        return origWireAcctId;
    }

    /**
     * Sets the OrigWireAcctId detail
     *
     * @param origWireAcctId the OrigWireAcctId detail
     */
    @JsonProperty("OrigWireAcctId")
    public void setOrigWireAcctId(String origWireAcctId) {
        this.origWireAcctId = origWireAcctId;
    }

    /**
     * Gets the BenWireAcctId detail
     *
     * @return a <code> string </code>
     * specifying the BenWireAcctId detail
     */
    @JsonProperty("BenWireAcctId")
    public String getBenWireAcctId() {
        return benWireAcctId;
    }

    /**
     * Sets the BenWireAcctId detail
     *
     * @param benWireAcctId the BenWireAcctId detail
     */
    @JsonProperty("BenWireAcctId")
    public void setBenWireAcctId(String benWireAcctId) {
        this.benWireAcctId = benWireAcctId;
    }

    /**
     * Gets the TranAmt2 detail
     *
     * @return a <code> string </code>
     * specifying the TranAmt2 detail
     */
    @JsonProperty("TranAmt2")
    public Double getTranAmt2() {
        return tranAmt2;
    }

    /**
     * Sets the TranAmt2 detail
     *
     * @param tranAmt2 the TranAmt2 detail
     */
    @JsonProperty("TranAmt2")
    public void setTranAmt2(Double tranAmt2) {
        this.tranAmt2 = tranAmt2;
    }

    /**
     * Gets the TranAmt3 detail
     *
     * @return a <code> string </code>
     * specifying the TranAmt3 detail
     */
    @JsonProperty("TranAmt3")
    public Double getTranAmt3() {
        return tranAmt3;
    }

    /**
     * Sets the TranAmt3 detail
     *
     * @param tranAmt3 the TranAmt3 detail
     */
    @JsonProperty("TranAmt3")
    public void setTranAmt3(Double tranAmt3) {
        this.tranAmt3 = tranAmt3;
    }

    /**
     * Gets the SlsRjctCde detail
     *
     * @return a <code> string </code>
     * specifying the SlsRjctCde detail
     */
    @JsonProperty("SlsRjctCde")
    public String getSlsRjctCde() {
        return slsRjctCde;
    }

    /**
     * Sets the SlsRjctCde detail
     *
     * @param slsRjctCde the SlsRjctCde detail
     */
    @JsonProperty("SlsRjctCde")
    public void setSlsRjctCde(String slsRjctCde) {
        this.slsRjctCde = slsRjctCde;
    }

    /**
     * Gets the VisaAdvncAuthScor_Type detail
     *
     * @return a <code> string </code>
     * specifying the VisaAdvncAuthScor_Type detail
     */
    @JsonProperty("VisaAdvncAuthScor_Type")
    public String getVisaAdvncAuthScorType() {
        return visaAdvncAuthScorType;
    }

    /**
     * Sets the VisaAdvncAuthScor_Type detail
     *
     * @param visaAdvncAuthScorType the VisaAdvncAuthScor_Type detail
     */
    @JsonProperty("VisaAdvncAuthScor_Type")
    public void setVisaAdvncAuthScorType(String visaAdvncAuthScorType) {
        this.visaAdvncAuthScorType = visaAdvncAuthScorType;
    }

    /**
     * Gets the AprvlCode detail
     *
     * @return a <code> string </code>
     * specifying the AprvlCode detail
     */
    @JsonProperty("AprvlCode")
    public String getAprvlCode() {
        return aprvlCode;
    }

    /**
     * Sets the AprvlCode detail
     *
     * @param aprvlCode the AprvlCode detail
     */
    @JsonProperty("AprvlCode")
    public void setAprvlCode(String aprvlCode) {
        this.aprvlCode = aprvlCode;
    }

    /**
     * Gets the RespCode detail
     *
     * @return a <code> string </code>
     * specifying the RespCode detail
     */
    @JsonProperty("RespCode")
    public String getRespCode() {
        return respCode;
    }

    /**
     * Sets the RespCode detail
     *
     * @param respCode the RespCode detail
     */
    @JsonProperty("RespCode")
    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    /**
     * Gets the OrigWireInstIDNum detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireInstIDNum detail
     */
    @JsonProperty("OrigWireInstIDNum")
    public String getOrigWireInstIDNum() {
        return origWireInstIDNum;
    }

    /**
     * Sets the OrigWireInstIDNum detail
     *
     * @param origWireInstIDNum the OrigWireInstIDNum detail
     */
    @JsonProperty("OrigWireInstIDNum")
    public void setOrigWireInstIDNum(String origWireInstIDNum) {
        this.origWireInstIDNum = origWireInstIDNum;
    }

    /**
     * Gets the OrigWireCntryCode detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireCntryCode detail
     */
    @JsonProperty("OrigWireCntryCode")
    public String getOrigWireCntryCode() {
        return origWireCntryCode;
    }

    /**
     * Sets the OrigWireCntryCode detail
     *
     * @param origWireCntryCode the OrigWireCntryCode detail
     */
    @JsonProperty("OrigWireCntryCode")
    public void setOrigWireCntryCode(String origWireCntryCode) {
        this.origWireCntryCode = origWireCntryCode;
    }

    /**
     * Gets the OrigWireCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireCrncyCode detail
     */
    @JsonProperty("OrigWireCrncyCode")
    public String getOrigWireCrncyCode() {
        return origWireCrncyCode;
    }

    /**
     * Sets the OrigWireCrncyCode detail
     *
     * @param origWireCrncyCode the OrigWireCrncyCode detail
     */
    @JsonProperty("OrigWireCrncyCode")
    public void setOrigWireCrncyCode(String origWireCrncyCode) {
        this.origWireCrncyCode = origWireCrncyCode;
    }

    /**
     * Gets the BenWireInstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the BenWireInstIdNum detail
     */
    @JsonProperty("BenWireInstIdNum")
    public String getBenWireInstIdNum() {
        return benWireInstIdNum;
    }

    /**
     * Sets the BenWireInstIdNum detail
     *
     * @param benWireInstIdNum the BenWireInstIdNum detail
     */
    @JsonProperty("BenWireInstIdNum")
    public void setBenWireInstIdNum(String benWireInstIdNum) {
        this.benWireInstIdNum = benWireInstIdNum;
    }

    /**
     * Gets the BenWireCntryCode detail
     *
     * @return a <code> string </code>
     * specifying the BenWireCntryCode detail
     */
    @JsonProperty("BenWireCntryCode")
    public String getBenWireCntryCode() {
        return benWireCntryCode;
    }

    /**
     * Sets the BenWireCntryCode detail
     *
     * @param benWireCntryCode the BenWireCntryCode detail
     */
    @JsonProperty("BenWireCntryCode")
    public void setBenWireCntryCode(String benWireCntryCode) {
        this.benWireCntryCode = benWireCntryCode;
    }

    /**
     * Gets the BenWireCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the BenWireCrncyCode detail
     */
    @JsonProperty("BenWireCrncyCode")
    public String getBenWireCrncyCode() {
        return benWireCrncyCode;
    }

    /**
     * Sets the BenWireCrncyCode detail
     *
     * @param benWireCrncyCode the BenWireCrncyCode detail
     */
    @JsonProperty("BenWireCrncyCode")
    public void setBenWireCrncyCode(String benWireCrncyCode) {
        this.benWireCrncyCode = benWireCrncyCode;
    }

    /**
     * Gets the RealTimeStat detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeStat detail
     */
    @JsonProperty("RealTimeStat")
    public String getRealTimeStat() {
        return realTimeStat;
    }

    /**
     * Sets the RealTimeStat detail
     *
     * @param realTimeStat the RealTimeStat detail
     */
    @JsonProperty("RealTimeStat")
    public void setRealTimeStat(String realTimeStat) {
        this.realTimeStat = realTimeStat;
    }

    /**
     * Gets the RealTimeDsps detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeDsps detail
     */
    @JsonProperty("RealTimeDsps")
    public String getRealTimeDsps() {
        return realTimeDsps;
    }

    /**
     * Sets the RealTimeDsps detail
     *
     * @param realTimeDsps the RealTimeDsps detail
     */
    @JsonProperty("RealTimeDsps")
    public void setRealTimeDsps(String realTimeDsps) {
        this.realTimeDsps = realTimeDsps;
    }

    /**
     * Gets the RealTimeRuleFrd detail
     *
     * @return a <code> integer </code>
     * specifying the RealTimeRuleFrd detail
     */
    @JsonProperty("RealTimeRuleFrd")
    public Integer getRealTimeRuleFrd() {
        return realTimeRuleFrd;
    }

    /**
     * Sets the RealTimeRuleFrd detail
     *
     * @param realTimeRuleFrd the RealTimeRuleFrd detail
     */
    @JsonProperty("RealTimeRuleFrd")
    public void setRealTimeRuleFrd(Integer realTimeRuleFrd) {
        this.realTimeRuleFrd = realTimeRuleFrd;
    }

    /**
     * Gets the RealTimeRuleDsps detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeRuleDsps detail
     */
    @JsonProperty("RealTimeRuleDsps")
    public String getRealTimeRuleDsps() {
        return realTimeRuleDsps;
    }

    /**
     * Sets the RealTimeRuleDsps detail
     *
     * @param realTimeRuleDsps the RealTimeRuleDsps detail
     */
    @JsonProperty("RealTimeRuleDsps")
    public void setRealTimeRuleDsps(String realTimeRuleDsps) {
        this.realTimeRuleDsps = realTimeRuleDsps;
    }

    /**
     * Gets the RealTimeScore detail
     *
     * @return a <code> integer </code>
     * specifying the RealTimeScore detail
     */
    @JsonProperty("RealTimeScore")
    public Integer getRealTimeScore() {
        return realTimeScore;
    }

    /**
     * Sets the RealTimeScore detail
     *
     * @param realTimeScore the RealTimeScore detail
     */
    @JsonProperty("RealTimeScore")
    public void setRealTimeScore(Integer realTimeScore) {
        this.realTimeScore = realTimeScore;
    }

    public static UUID generateType5UUID(String name) {
        try {
//            byte[] hash = {00};
            final byte[] bytes = name.getBytes(StandardCharsets.UTF_8);
            final MessageDigest md = MessageDigest.getInstance("SHA-256");
            final byte[] hash = md.digest(bytes);
            long msb = getLeastAndMostSignificantBitsVersion5(hash, 0);
            long lsb = getLeastAndMostSignificantBitsVersion5(hash, 8);

            //Set the version field
            msb &= ~(0xfL << 12);
            msb |= 5L << 12;

            //Set the variant field to 2
            lsb &= ~(0x3L << 62);
            lsb |= 2L << 62;
            return new UUID(msb, lsb);
        } catch (NoSuchAlgorithmException e) {
            throw new AssertionError(e);
        }
    }

    private static long getLeastAndMostSignificantBitsVersion5(final byte[] src, final int offset) {
        long ans = 0;
        for (int i = offset + 7; i >= offset; i -= 1) {
            ans <<= 8;
            ans |= src[i] & 0xffL;
        }
        return ans;
    }

    @Override
    public String toString() {
        return "NRTRequestFormat{" +
                "tiebreaker='" + tiebreaker + '\'' +
                ", recordSourceId=" + recordSourceId +
                ", pan='" + getPan() + '\'' +
                ", retlid='" + retlid + '\'' +
                ", acctNum='" + acctNum + '\'' +
                ", termid='" + termid + '\'' +
                ", tranCode='" + tranCode + '\'' +
                ", tranAmt1=" + tranAmt1 +
                ", msgType='" + msgType + '\'' +
                ", pontOfSrvcCondCode='" + pontOfSrvcCondCode + '\'' +
                ", pontOfSrvceEntryMode='" + pontOfSrvceEntryMode + '\'' +
                ", eComFlag='" + eComFlag + '\'' +
                ", eMVTrmnlVrfyRslt='" + eMVTrmnlVrfyRslt + '\'' +
                ", eMVUsrFlr='" + eMVUsrFlr + '\'' +
                ", rtlrSICCode='" + rtlrSICCode + '\'' +
                ", termNameLoc='" + termNameLoc + '\'' +
                ", termCity='" + termCity + '\'' +
                ", termSt='" + termSt + '\'' +
                ", termCntr='" + termCntr + '\'' +
                ", termPstlCode='" + termPstlCode + '\'' +
                ", custTranAmt1=" + custTranAmt1 +
                ", custTranAmt4=" + custTranAmt4 +
                ", pINTries='" + pINTries + '\'' +
                ", acqrInstIdNum='" + acqrInstIdNum + '\'' +
                ", frwdInstId='" + frwdInstId + '\'' +
                ", tranAuthSrc='" + tranAuthSrc + '\'' +
                ", cavvaav=" + cavvaav +
                ", acctType='" + acctType + '\'' +
                ", fiid='" + fiid + '\'' +
                ", bin='" + bin + '\'' +
                ", pINIndx='" + pINIndx + '\'' +
                ", mmbrNum='" + mmbrNum + '\'' +
                ", cardPrdtType='" + cardPrdtType + '\'' +
                ", cardStat='" + cardStat + '\'' +
                ", cardBlckCode='" + cardBlckCode + '\'' +
                ", tranDateTime=" + tranDateTime +
                ", cardRqstDate=" + cardRqstDate +
                ", cardPINChngDate=" + cardPINChngDate +
                ", lastAdrsChngDate=" + lastAdrsChngDate +
                ", iBK1InstIdNum='" + iBK1InstIdNum + '\'' +
                ", prodInd='" + prodInd + '\'' +
                ", sqncNum='" + sqncNum + '\'' +
                ", tranRsnCode='" + tranRsnCode + '\'' +
                ", cardVrfyFlag='" + cardVrfyFlag + '\'' +
                ", cVDPrsntFlag='" + cVDPrsntFlag + '\'' +
                ", eMVCardVrfyRslts='" + eMVCardVrfyRslts + '\'' +
                ", custTranAmt2=" + custTranAmt2 +
                ", custTranAmt3=" + custTranAmt3 +
                ", custTranDate=" + custTranDate +
                ", credDebInd='" + credDebInd + '\'' +
                ", cashInd='" + cashInd + '\'' +
                ", orgnlCrncyCode='" + orgnlCrncyCode + '\'' +
                ", achNum='" + achNum + '\'' +
                ", scndryAcctNmbr='" + scndryAcctNmbr + '\'' +
                ", origWireAcctId='" + origWireAcctId + '\'' +
                ", benWireAcctId='" + benWireAcctId + '\'' +
                ", tranAmt2=" + tranAmt2 +
                ", tranAmt3=" + tranAmt3 +
                ", slsRjctCde='" + slsRjctCde + '\'' +
                ", visaAdvncAuthScorType='" + visaAdvncAuthScorType + '\'' +
                ", aprvlCode='" + aprvlCode + '\'' +
                ", respCode='" + respCode + '\'' +
                ", origWireInstIDNum='" + origWireInstIDNum + '\'' +
                ", origWireCntryCode='" + origWireCntryCode + '\'' +
                ", origWireCrncyCode='" + origWireCrncyCode + '\'' +
                ", benWireInstIdNum='" + benWireInstIdNum + '\'' +
                ", benWireCntryCode='" + benWireCntryCode + '\'' +
                ", benWireCrncyCode='" + benWireCrncyCode + '\'' +
                ", realTimeStat='" + realTimeStat + '\'' +
                ", realTimeDsps='" + realTimeDsps + '\'' +
                ", realTimeRuleFrd=" + realTimeRuleFrd +
                ", realTimeRuleDsps='" + realTimeRuleDsps + '\'' +
                ", realTimeScore=" + realTimeScore +
                '}';
    }
}

