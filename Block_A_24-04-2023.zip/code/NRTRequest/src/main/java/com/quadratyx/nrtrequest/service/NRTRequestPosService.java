package com.quadratyx.nrtrequest.service;

import java.util.Map;

/**
 * An interface for NRTRequest POS Service
 */
public interface NRTRequestPosService {

    /**
     * This is the unimplemented method for NRT Request POS Service
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return int
     */
    int nrtScorePosService(String tId, Map<String, Object> cacheMap);

}

