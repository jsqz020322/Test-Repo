package com.quadratyx.nrtrequest.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;
import java.util.Map;

/**
 * This is a model class to hold response information for near real time api
 *
 * @see Object
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "Tiebreaker",
        "NearRealTimeRsnCode1",
        "NearRealTimeScore",
})

public class NRTResponseFormat {

    @NotBlank
    private String tieBreaker;
    private Integer nearRealTimeRsnCode1;
    private Integer nearRealTimeScore;

    private String breaker = "Tiebreaker";
    private String status = "NearRealTimeRsnCode1";

    /**
     * Gets the Tiebreaker detail
     *
     * @return a <code> string </code>
     * specifying the Tiebreaker detail
     */
    public String getTieBreaker() {
        return tieBreaker;
    }

    /**
     * Sets the Tiebreaker detail
     *
     * @param tieBreaker the Tiebreaker detail
     */
    public void setTieBreaker(String tieBreaker) {
        this.tieBreaker = tieBreaker;
    }

    /**
     * Gets the NearRealTimeRsnCode1 detail
     *
     * @return a <code> string </code>
     * specifying the NearRealTimeRsnCode1 detail
     */
    public Integer getNearRealTimeRsnCode1() {
        return nearRealTimeRsnCode1;
    }

    /**
     * Sets the NearRealTimeRsnCode1 detail
     *
     * @param nearRealTimeRsnCode1 the NearRealTimeRsnCode1 detail
     */
    public void setNearRealTimeRsnCode1(Integer nearRealTimeRsnCode1) {
        this.nearRealTimeRsnCode1 = nearRealTimeRsnCode1;
    }

    /**
     * Gets the NearRealTimeScore detail
     *
     * @return a <code> string </code>
     * specifying the NearRealTimeScore detail
     */
    public Integer getNearRealTimeScore() {
        return nearRealTimeScore;
    }

    /**
     * Sets the NearRealTimeScore detail
     *
     * @param nearRealTimeScore the NearRealTimeScore detail
     */
    public void setNearRealTimeScore(Integer nearRealTimeScore) {
        this.nearRealTimeScore = nearRealTimeScore;
    }

    /**
     * This method is used for generating the response without parameter
     *
     * @return a <code> map </code>
     * with key as string and value as object for response json
     */
    public Map<String, Object> toResponse() {
        Map<String, Object> response = new HashMap<>();
        response.put(breaker, tieBreaker);
        response.put(status, nearRealTimeRsnCode1);
        return response;
    }

    /**
     * This is the method for generating the result with parameter
     *
     * @param tieBreaker           the TieBreaker details
     * @param nearRealTimeRsnCode1 the near real time response code detail
     * @return a <code> map </code>
     * with key as string and value as object for response json
     */
    public Map<String, Object> toResponse(String tieBreaker, Integer nearRealTimeRsnCode1) {
        Map<String, Object> response = new HashMap<>();
        response.put(breaker, tieBreaker);
        response.put(status, nearRealTimeRsnCode1);
        return response;
    }


}

