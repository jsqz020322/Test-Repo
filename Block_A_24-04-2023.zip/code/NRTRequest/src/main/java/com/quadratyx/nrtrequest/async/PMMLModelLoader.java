package com.quadratyx.nrtrequest.async;

import jakarta.xml.bind.JAXBException;
import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.LoadingModelEvaluatorBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class PMMLModelLoader implements ApplicationContextAware {

    private static final Logger logger = LoggerFactory.getLogger(PMMLModelLoader.class);

    private ExecutorService executorService = Executors.newFixedThreadPool(4);
    private ApplicationContext context;

    @Value("${model.atmpmmlfile.path}")
    private String atmPmmlFilePath;

    @Value("${model.pospmmlfile.path}")
    private String posPmmlFilePath;

    @Value("${model.cnpsecuredpmmlfile.path}")
    private String cnpsecuredPmmlFilePath;

    @Value("${model.cnpunsecuredpmmlfile.path}")
    private String cnpunsecuredPmmlFilePath;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        this.context = applicationContext;
        DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) context.getAutowireCapableBeanFactory();

        List<String> pmmmlFiles = Arrays.asList(cnpunsecuredPmmlFilePath, cnpsecuredPmmlFilePath, posPmmlFilePath, atmPmmlFilePath);

        int i = 1;
        for (String pmmlfile : pmmmlFiles) {
            String beanName = "";
            switch (i) {
                case 1 -> beanName = "cnpUnsecuredMapping";
                case 2 -> beanName = "cnpSecuredMapping";
                case 3 -> beanName = "posMapping";
                case 4 -> beanName = "atmMapping";
            }
            String finalBeanName = beanName;
            executorService.submit(() -> {
                try {
                    Evaluator evaluator;
                    logger.info("Loading Model = " + pmmlfile);
                    long st = System.currentTimeMillis();
                    evaluator = new LoadingModelEvaluatorBuilder()
                            .setLocatable(false)
                            .load(new File(pmmlfile))
                            .build();
                    logger.info(" Evaluator Build {}", (System.currentTimeMillis() - st));
                    logger.info("beanName == " + finalBeanName);
                    beanFactory.registerSingleton(finalBeanName, evaluator);
                } catch (IOException | SAXException | JAXBException e) {
                    throw new RuntimeException("Failed to Load");
                }
            });
            i++;
        }
    }
}