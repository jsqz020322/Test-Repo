package com.quadratyx.nrtrequest.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * This is the JSON Response class annotated with the @XmlRootElement annotation,
 * which means its value is represented as XML element in an XML document
 *
 * @param <T> is a conventional letter that stands for "Type", and it refers to the concept of Generics in Java.
 */
@XmlRootElement(name = "response")
public class JSONResponse<T> {

    private ResStatus status;
    private String message;
    private String errorStackTrace;
    private Integer errorCode;
    private String version;
    private T result;

    /**
     * This is the default constructor
     */
    public JSONResponse() {
        // Default constructor
    }

    /**
     * Gets the status detail
     *
     * @return a <code> ResStatus </code>
     * specifying the status detail
     */
    public ResStatus getStatus() {
        return status;
    }

    /**
     * Sets the status detail
     *
     * @param status the status detail
     */
    public void setStatus(ResStatus status) {
        this.status = status;
    }

    /**
     * Gets the message detail
     *
     * @return a <code> string </code>
     * specifying the message detail
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message detail
     *
     * @param msg the message detail
     */
    public void setMessage(String msg) {
        this.message = msg;
    }

    /**
     * Gets the error stack trace detail
     *
     * @return a <code> string </code>
     * specifying the error stack trace detail
     */
    public String getErrorStackTrace() {
        return errorStackTrace;
    }

    /**
     * Sets the error stack trace detail
     *
     * @param errorStackTrace the error stack trace detail
     */
    public void setErrorStackTrace(String errorStackTrace) {
        this.errorStackTrace = errorStackTrace;
    }

    /**
     * Gets the error code
     *
     * @return a <code> integer </code>
     * specifying the error code
     */
    public Integer getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the error Code detail
     *
     * @param errorCode the error Code detail
     */
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Gets the result
     *
     * @return a <code> generic Type </code>
     * specifying the result
     */
    public T getResult() {
        return result;
    }

    /**
     * Sets the result detail
     *
     * @param data the result detail
     */
    public void setResult(T data) {
        this.result = data;
    }

    /**
     * Gets the version
     *
     * @return a <code> string </code>
     * specifying the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the version detail
     *
     * @param version the version detail
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * Convert to standard string format
     *
     * @return a <code> string </code> representing
     * JSON Response in standard format
     */

    @Override
    public String toString() {
        return String.format("JSONResponse [status=%s, message=%s, errorStackTrace=%s, errorCode=%s, version=%s, result=%s]", this.status,
                this.message, this.errorStackTrace, this.errorCode, this.version, this.result);
    }

    /**
     * An enum is a special "class" that represents a group of constants (unchangeable variables, like final variables).
     */
    public enum ResStatus {
        /**
         * For SUCCESS - Success response with status code 20
         */
        SUCCESS,
        /**
         * For PARTIAL_SUCCESS - Partial Success response with status code 20 with warning
         */
        PARTIAL_SUCCESS,
        /**
         * For WARNING - Warning status
         */
        WARNING,
        /**
         * For ERROR - error status
         */
        ERROR;

        /**
         * Convert to standard string format
         *
         * @return a <code> string </code> representing
         * enum class constant in standard format
         */
        @Override
        public String toString() {
            return this.name().toLowerCase();
        }
    }
}
