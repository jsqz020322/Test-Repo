package com.quadratyx.nrtrequest.globalhandler;

import com.quadratyx.nrtrequest.model.NRTRequestFormat;
import com.quadratyx.nrtrequest.model.NRTResponseFormat;
import com.quadratyx.nrtrequest.util.BusinessConstant;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * This the Global Handler class for handling Global Exception at controller level
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * This is the method for customize the response for HttpRequestMethodNotSupportedException.
     *
     * @param ex          the exception
     * @param httpHeaders the headers to be written to the response
     * @param httpStatus  the selected response status
     * @param request     the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders httpHeaders, HttpStatus httpStatus, WebRequest request) {
        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.METHOD_NOT_ALLOWED);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.METHOD_NOT_ALLOWED);
    }

    /**
     * This is the method for customize the response for HttpMediaTypeNotSupportedException.
     *
     * @param ex      the exception
     * @param headers the headers to be written to the response
     * @param status  the selected response status
     * @param request the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.UNSUPPORTED_MEDIA_TYPE);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    /**
     * This is the method for customize the response for NoHandlerFoundException.
     *
     * @param ex      the exception
     * @param headers the headers to be written to the response
     * @param status  the selected response status
     * @param request the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.NOT_FOUND);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.NOT_FOUND);
    }

    /**
     * This is the method for customize the response for HttpMessageNotReadableException.
     *
     * @param ex      the exception
     * @param headers the headers to be written to the response
     * @param status  the selected response status
     * @param request the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.BAD_REQUEST);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.BAD_REQUEST);
    }

    /**
     * This is the method for customize the response for MethodArgumentNotValidException.
     *
     * @param ex      the exception
     * @param headers the headers to be written to the response
     * @param status  the selected response status
     * @param request the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.BAD_REQUEST);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.BAD_REQUEST);
    }

    /**
     * This is the method for customize the response for AsyncRequestTimeoutException.
     *
     * @param ex      the exception
     * @param headers the headers to be written to the response
     * @param status  the selected response status
     * @param request the current request
     * @return a <code> ResponseEntity </code> instance
     */
    @Override
    protected ResponseEntity<Object> handleAsyncRequestTimeoutException(
            AsyncRequestTimeoutException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        NRTResponseFormat responseFormat = new NRTResponseFormat();
        NRTRequestFormat req = new NRTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTieBreaker(tId);
        responseFormat.setNearRealTimeRsnCode1(BusinessConstant.SERVICE_UNAVAILABLE);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.SERVICE_UNAVAILABLE);
    }
}

























