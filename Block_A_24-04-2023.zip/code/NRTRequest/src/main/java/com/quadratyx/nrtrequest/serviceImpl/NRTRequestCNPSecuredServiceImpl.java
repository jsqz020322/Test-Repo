package com.quadratyx.nrtrequest.serviceImpl;

import com.quadratyx.nrtrequest.service.NRTRequestAtmService;
import com.quadratyx.nrtrequest.service.NRTRequestCNPSecuredService;
import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.FieldValue;
import org.jpmml.evaluator.InputField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * This service module is used for prediction of model score for POS NRT Transactions
 */
@Service
public class NRTRequestCNPSecuredServiceImpl implements NRTRequestCNPSecuredService {

    private static final Logger logger = LoggerFactory.getLogger(NRTRequestCNPSecuredServiceImpl.class);

    @Autowired
    @Lazy
    @Qualifier("cnpSecuredMapping")
    private Evaluator evaluator;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @Autowired
    private NRTRequestAtmService nrtRequestAtmService;

    /**
     * This is the implemented method used for prediction of model score for NRT POS Transactions
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return NRTResponseFormat object
     * @throws Exception in case of any exception
     */
    public int nrtScoreCNPSecuredService(String tId, Map<String, Object> cacheMap) {
        int score = -1;
        Map<String, FieldValue> arguments = null;
        try {
            List<InputField> inputFields = evaluator.getInputFields();
            arguments = new HashMap<>();

            for (InputField inputField : inputFields) {
                String inputName = inputField.getName();
                Object rawValue = cacheMap.get(inputName);
                FieldValue inputValue = inputField.prepare(rawValue);
                arguments.put(inputName, inputValue);
            }
            Map<String, Object> results = (Map<String, Object>) evaluator.evaluate(arguments);
            Double sc = (Double) results.get("probability(1)") * 100;
            score = (int) Math.round(sc);
        } catch (Exception e) {
            score = -1;
//            logger.error("Exception " + e.getMessage(), e);
//            logger.error("arguments ==" + arguments.toString());
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Tiebreaker: " + tId + "\n" + sw.toString() + arguments;
            nrtRequestAtmService.sendMessage(exception, exceptionTopic);
        }
        return score;
    }
}
