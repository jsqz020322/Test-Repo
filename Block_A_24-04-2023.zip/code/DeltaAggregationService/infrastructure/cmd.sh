#!/bin/sh
java -jar DeltaAggregation.jar  --spring.config.location=/config/application.properties
