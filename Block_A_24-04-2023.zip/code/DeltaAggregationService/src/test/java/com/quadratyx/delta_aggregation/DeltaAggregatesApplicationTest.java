package com.quadratyx.delta_aggregation;

import com.quadratyx.delta_aggregation.service_impl.Aggregates3DaysTest;
import com.quadratyx.delta_aggregation.service_impl.Aggregates30DaysTest;
import com.quadratyx.delta_aggregation.service_impl.AggregatesBinsTest;
import com.quadratyx.delta_aggregation.service_impl.PreprocessingFunctionsTest;
import com.quadratyx.delta_aggregation.service_impl.PreviousTransactionBasedAggregatesTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.SpringBootConfiguration;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This is the test service module for Delta Aggregation Service
 */
@SpringBootTest
class DeltaAggregatesApplicationTest {

    @Autowired
    private Aggregates3DaysTest aggregates3DaysTest;

    @Autowired
    private Aggregates30DaysTest aggregates30DaysTest;

    @Autowired
    private AggregatesBinsTest aggregatesBinsTest;

    @Autowired
    private PreviousTransactionBasedAggregatesTest previousTransactionBasedAggregatesTest;

    /**
     *
     * This is the method used for validation of Delta Aggregation Service
     */
    @Test
    void contextLoads() {

        assertThat(aggregates3DaysTest).isNotNull();
        assertThat(aggregates30DaysTest).isNotNull();
        assertThat(aggregatesBinsTest).isNotNull();
        assertThat(previousTransactionBasedAggregatesTest).isNotNull();

    }

}
