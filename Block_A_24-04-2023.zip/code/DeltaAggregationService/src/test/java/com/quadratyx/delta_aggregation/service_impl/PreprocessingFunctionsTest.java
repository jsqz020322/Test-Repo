package com.quadratyx.delta_aggregation.service_impl;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.SpringBootConfiguration;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * This is the test service module for PreProcessing functions creation
 */
@SpringBootTest
public class PreprocessingFunctionsTest {

    @Autowired
    private PreprocessingFunctions preprocessingFunctions;

    /**
     * This is the method used for validation of PreProcessing functions
     * @throws ExecutionException in case of any execution exception
     * @throws InterruptedException in case of any thread interruption
     */
    @Test
    public void setPreprocessingFunctions() throws ExecutionException, InterruptedException {

        //preprocessingFunctions.loadJsons();

        String tranCode = "10";
        String tranCodeType = preprocessingFunctions.tranCodeType(tranCode);
        assertThat(tranCodeType).isEqualTo("Purchase");

        Double MD_TRAN_AMT1 = 7000.0;
        Double MD_CUST_TRAN_AMT1 = 18816.96;
        Integer monetary_tran = 1;
        String balanceNotAvailable = preprocessingFunctions.balanceNotAvailable(MD_TRAN_AMT1, MD_CUST_TRAN_AMT1, monetary_tran);
        assertThat(balanceNotAvailable).isEqualTo("SuffBal");

        String pontOfSrvceEntryMode = "051";
        String entryModeType = preprocessingFunctions.entryModeType(pontOfSrvceEntryMode);
        assertThat(entryModeType).isEqualTo("chipvalidated");

        String PINIndx = "1";
        String TermCntr = "IN";
        Integer channel_Index = 2;
        String pinEnteredDomFlag = preprocessingFunctions.pinEnteredDomFlag(PINIndx, TermCntr, channel_Index);
        assertThat(pinEnteredDomFlag).isEqualTo("entered");

        String RealTimeRuleDsps = "A";
        String realTimeRuleStatus = preprocessingFunctions.realTimeRuleStatus(RealTimeRuleDsps);
        assertThat(realTimeRuleStatus).isEqualTo("Authorized");

        String RespCode = "000";
        String TranAuthSrc = "H";
        String sdRespCodeType = preprocessingFunctions.sdRespCodeType(RespCode, TranAuthSrc);
        assertThat(sdRespCodeType).isEqualTo("Approved");

        String EMVUsrFlr = "154";
        Integer fallBackStatus = preprocessingFunctions.fallBackStatus(pontOfSrvceEntryMode, EMVUsrFlr);
        assertThat(fallBackStatus).isEqualTo(0);

    }
}
