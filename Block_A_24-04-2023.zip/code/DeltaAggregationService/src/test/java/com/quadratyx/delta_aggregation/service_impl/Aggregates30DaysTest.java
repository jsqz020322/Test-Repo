package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.service_impl.RedisAggregatesUpdate;
import com.quadratyx.delta_aggregation.service_impl.Aggregates30Days;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;

import java.util.*;

/**
 * This is the test service module for 30Days Aggregates creation
 */
@SpringBootTest
public class Aggregates30DaysTest {

    @Autowired
    private Aggregates30Days aggregates30Days;

    @Autowired
    private RedisAggregatesUpdate redisAggregatesUpdate;

    @Autowired
    private DeltaAggRequestFormat deltaAggRequestFormat;

    /**
     * This is the method used for validation of 30Days aggregates
     */
    @Test
    public void validate_30days_aggregates() {

//      ATM 30 days aggregates
        Map<String, List<String>> jsonMap = new HashMap<>();
        Map<String, String> shortkeyAggMap = new HashMap<>();


        Map<String, Object> req_agg_map = new HashMap<String, Object>();
        req_agg_map.put("E1_30", 18.0);
        req_agg_map.put("T14", 10.0);

        Map<String, Object> preprocessed_data = new HashMap<String, Object>();
        Map<String, Object> curr_30agg_map = redisAggregatesUpdate.populate_aggregates_data(deltaAggRequestFormat);

        Double A2_30_0 = 1.0;
        Double H3_30 = 20.0;
        Integer DA14 = 0;
        Integer I3 = 0;
        String DA13 = "Domestic";
        Integer I8 = 2;
        String tran_cde_type = "Purchase";
        String sd_res_code_type = "Approved";

        deltaAggRequestFormat.setA2_30_0(A2_30_0);
        deltaAggRequestFormat.setH3_30(H3_30);
        deltaAggRequestFormat.setDA14(DA14);
        deltaAggRequestFormat.setI3(I3);
        deltaAggRequestFormat.setDA13(DA13);
        deltaAggRequestFormat.setI8(I8);
        preprocessed_data.put("tran_cde_type", tran_cde_type);
        preprocessed_data.put("sd_res_code_type", sd_res_code_type);

        aggregates30Days.updateATM30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_30agg_map);

//      30 days aggregates

        Double A1_30_0 = 0.0;
        Double E1_30 = 17.0;
        Integer DA5 = 1;
        String P36 = "NAWADA";
        String P39 = "805110";
        Double T14 = 9.0;
        Double RAW1 = 7000.0;
        String RtlrSICCode = "6011";
        String PontOfSrvcCondCode = "";
        String PontOfSrvceEntryMode = "051";
        String TermCity = "Surat";
        String TermPstlCode = null;
        String rule_status = "Authorized";
        String entry_mode_type = "chipvalidated";
        Integer fall_back_status = 0;

        deltaAggRequestFormat.setA1_30_0(A1_30_0);
        deltaAggRequestFormat.setE1_30(E1_30);
        deltaAggRequestFormat.setDA5(DA5);
        deltaAggRequestFormat.setP36(P36);
        deltaAggRequestFormat.setP39(P39);
        deltaAggRequestFormat.setT14(T14);
        deltaAggRequestFormat.setRAW1(RAW1);
        deltaAggRequestFormat.setRtlrSICCode(RtlrSICCode);
        deltaAggRequestFormat.setPontOfSrvcCondCode(PontOfSrvcCondCode);
        deltaAggRequestFormat.setPontOfSrvceEntryMode(PontOfSrvceEntryMode);
        deltaAggRequestFormat.setTermCity(TermCity);
        deltaAggRequestFormat.setTermPstlCode(TermPstlCode);
        preprocessed_data.put("rule_status", rule_status);
        preprocessed_data.put("entry_mode_type", entry_mode_type);
        preprocessed_data.put("fall_back_status", fall_back_status);

        aggregates30Days.update30DaysAggregates(deltaAggRequestFormat, preprocessed_data,
                curr_30agg_map);

        curr_30agg_map.values().removeAll(Collections.singleton(null));
        curr_30agg_map.remove("TS1");

        boolean is_match = curr_30agg_map.equals(req_agg_map);
        assertThat(is_match).isTrue();
    }

}
