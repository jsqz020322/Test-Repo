package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.service_impl.Aggregates3Days;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the test service module for 3Days Aggregates creation
 */
@SpringBootTest
public class Aggregates3DaysTest {

    @Autowired
    private Aggregates3Days aggregates3Days;

    @Autowired
    private RedisAggregatesUpdate redisAggregatesUpdate;

    @Autowired
    private DeltaAggRequestFormat deltaAggRequestFormat;

    @Test
    /**
     * This is the method used for validation of 3Days aggregates
     */
    public void validate_3days_aggregates() {

//      ATM 3 days aggregates

        Map<String, List<String>> jsonMap = new HashMap<>();
        Map<String, String> shortkeyAggMap = new HashMap<>();

        Map<String, Object> req_agg_map = new HashMap<String, Object>();
        req_agg_map.put("E1_3", 2.0);
        req_agg_map.put("A2_30_0", 1.0);
        req_agg_map.put("H3_30", 20.0);
        req_agg_map.put("C5_3", 1.0);
        req_agg_map.put("C10", 1.0);
        req_agg_map.put("C11", 9.0);
        req_agg_map.put("E1_30", 17.0);
        req_agg_map.put("T14", 9.0);
        req_agg_map.put("P36", "NAWADA");
        req_agg_map.put("P39", "805110");
        req_agg_map.put("A1_30_0", 0.0);

        Map<String, Object> preprocessed_data = new HashMap<String, Object>();
        Map<String, Object> curr_3agg_map = redisAggregatesUpdate.populate_aggregates_data(deltaAggRequestFormat);

        Double A2_3_0 = 0.0;
        Double H3_3 = 0.0;
        Double C5_3 = 0.0;
        Integer I3 = 0;
        String DA13 = "Domestic";
        Integer I8 = 2;
        Double C10 = 0.0;
        Double C11 = 8.0;
        String tran_cde_type = "Purchase";
        String sd_res_code_type = "Approved";

        deltaAggRequestFormat.setA2_3_0(A2_3_0);
        deltaAggRequestFormat.setH3_3(H3_3);
        deltaAggRequestFormat.setC5_3(C5_3);
        deltaAggRequestFormat.setI3(I3);
        deltaAggRequestFormat.setDA13(DA13);
        deltaAggRequestFormat.setI8(I8);
        deltaAggRequestFormat.setC10(C10);
        deltaAggRequestFormat.setC11(C11);
        preprocessed_data.put("tran_cde_type", tran_cde_type);
        preprocessed_data.put("sd_res_code_type", sd_res_code_type);

         aggregates3Days.updateATM3DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_3agg_map);

//      3 days aggregates

        Double E1_3 = 1.0;
        Integer DA5 = 1;
        String P36 = "NAWADA";
        String P39 = "805110";
        Double T14 = 9.0;
        Double RAW1 = 7000.0;
        String RtlrSICCode = "6011";
        String PontOfSrvcCondCode = "";
        String PontOfSrvceEntryMode = "051";
        String TermCity = "Surat";
        String TermPstlCode = null;
        String rule_status = "Authorized";
        String entry_mode_type = "chipvalidated";
        Integer fall_back_status = 0;

        deltaAggRequestFormat.setE1_3(E1_3);
        deltaAggRequestFormat.setDA5(DA5);
        deltaAggRequestFormat.setP36(P36);
        deltaAggRequestFormat.setP39(P39);
        deltaAggRequestFormat.setT14(T14);
        deltaAggRequestFormat.setRAW1(RAW1);
        deltaAggRequestFormat.setRtlrSICCode(RtlrSICCode);
        deltaAggRequestFormat.setPontOfSrvcCondCode(PontOfSrvcCondCode);
        deltaAggRequestFormat.setPontOfSrvceEntryMode(PontOfSrvceEntryMode);
        deltaAggRequestFormat.setTermCity(TermCity);
        deltaAggRequestFormat.setTermPstlCode(TermPstlCode);
        preprocessed_data.put("rule_status", rule_status);
        preprocessed_data.put("entry_mode_type", entry_mode_type);
        preprocessed_data.put("fall_back_status", fall_back_status);

        aggregates3Days.update3DaysAggregates(deltaAggRequestFormat, preprocessed_data,
                curr_3agg_map);

        curr_3agg_map.values().removeAll(Collections.singleton(null));
        curr_3agg_map.remove("TS1");

        boolean is_match = curr_3agg_map.equals(req_agg_map);
        assertThat(is_match).isTrue();
    }
}