package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.service_impl.Aggregates3Days;
import com.quadratyx.delta_aggregation.service_impl.AggregateBins;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the test service module for Aggregates bins creation
 */
@SpringBootTest
public class AggregatesBinsTest {

    @Autowired
    private DeltaAggRequestFormat deltaAggRequestFormat;

    @Autowired
    private AggregateBins aggregateBins;

    /**
     * This is the method used for validation of aggregates bins
     */
    @Test
    public void validate_aggregatebins() {

        Double A2_30_0 = 1.0;
        Double A2_30_2 = 1.0;
        Double A2_30_3 = 1.0;
        Double A2_30_4 = 1.0;
        Double A2_30_5 = 1.0;
        Double A2_30_6 = 1.0;
        Double A2_30_7 = 1.0;
        Double A2_30_8 = 1.0;
        Double A2_30_9 = 1.0;
        deltaAggRequestFormat.setA2_30_0(A2_30_0);
        deltaAggRequestFormat.setA2_30_2(A2_30_2);
        deltaAggRequestFormat.setA2_30_3(A2_30_3);
        deltaAggRequestFormat.setA2_30_4(A2_30_4);
        deltaAggRequestFormat.setA2_30_5(A2_30_5);
        deltaAggRequestFormat.setA2_30_6(A2_30_6);
        deltaAggRequestFormat.setA2_30_7(A2_30_7);
        deltaAggRequestFormat.setA2_30_8(A2_30_8);
        deltaAggRequestFormat.setA2_30_9(A2_30_9);

        Map<String, Double> req_map = new HashMap<String, Double>();
        req_map.put("amount_bins_M_ATM_prev30days_0", 1.0);
        req_map.put("amount_bins_M_prev30days_0", 0.0);
        req_map.put("amount_bins_M_ATM_prev30days_2", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_3", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_4", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_5", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_6", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_7", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_8", 1.0);
        req_map.put("amount_bins_M_ATM_prev30days_9", 1.0);

        Map<String, Double> result = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
        result.values().removeAll(Collections.singleton(null));

        boolean is_match = req_map.equals(result);
        assertThat(is_match).isTrue();
    }
}