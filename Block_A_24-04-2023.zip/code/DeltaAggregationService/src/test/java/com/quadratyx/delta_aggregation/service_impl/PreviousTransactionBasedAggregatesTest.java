package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.service_impl.PreviousTransactionBasedAggregates;
import com.quadratyx.delta_aggregation.service_impl.RedisAggregatesUpdate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * This is the test service module for Previous transaction based aggregates creation
 */
@SpringBootTest
public class PreviousTransactionBasedAggregatesTest {

    @Autowired
    private PreviousTransactionBasedAggregates previousTransactionBasedAggregates;

    @Autowired
    private RedisAggregatesUpdate redisAggregatesUpdate;

    @Autowired
    private DeltaAggRequestFormat deltaAggRequestFormat;

    /**
     * This is the method used for validation of Previous transaction based aggregates
     */
    @Test
    public void previous_transactions_validation() {

//      Setting required attributes in Request Format
        Integer DA15 = 42;
        Integer I8 = 2;
        Integer I5 = 2;
        Integer DA11 = 0;
        deltaAggRequestFormat.setDA15(DA15);
        deltaAggRequestFormat.setI8(I8);
        deltaAggRequestFormat.setI5(I5);
        deltaAggRequestFormat.setDA11(DA11);

//      Setting required attributes in preprocessed_data
        Double tran_cde_type = 10.0;
        String sd_res_code_type = "Approved";
        Integer fall_back_status = 0;
        Map<String, Object> preprocessed_data = new HashMap<String, Object>();
        preprocessed_data.put("tran_cde_type", tran_cde_type);
        preprocessed_data.put("sd_res_code_type", sd_res_code_type);
        preprocessed_data.put("fall_back_status", fall_back_status);

//      Initializing curr_agg_map with empty values
        Map<String, Object> curr_agg_map = new HashMap<String, Object>();


//      Comparison of results with the expected output
        curr_agg_map = previousTransactionBasedAggregates.updatePrevTranAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);

//      Initializing req_agg_map with expected values in map
        Map<String, Object> req_agg_map = new HashMap<String, Object>();
        req_agg_map.put("P31", 0);
        req_agg_map.put("P5", 2);
        req_agg_map.put("P17", 10.0);
        req_agg_map.put("P18", 2);
        req_agg_map.put("P19", 0);
        req_agg_map.put("P20", 0);
        req_agg_map.put("P22", 0);
        req_agg_map.put("P24", 0);
        req_agg_map.put("P32", 0);
        req_agg_map.put("P33", 0);
        req_agg_map.put("P25", 0);

        boolean is_match = curr_agg_map.equals(req_agg_map);
        assertThat(is_match).isTrue();
    }
}
