package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This is the service module for creation of previous transaction based aggregates
 */
@Service
public class PreviousTransactionBasedAggregates {

    private static final Logger logger = LoggerFactory.getLogger(PreviousTransactionBasedAggregates.class);

    @Autowired
    private DeltaAggregatesMain deltaAggregatesMain;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    /**
     * This is the method used for updating previous transaction aggregates attributes
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param preprocessed_data     preprocessed derived fields detail
     * @param curr_agg_map          current aggregates map detail
     * @return a <code> Map of String, Object </code> specifying the updated previous transaction aggregates attributes
     */
    public Map<String, Object> updatePrevTranAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessed_data,
                                                        Map<String, Object> curr_agg_map) {

        try {

//          Update previous atm transaction days
            Integer prev_tran_time_diff_mins = deltaAggRequestFormat.getDA15();
            Integer no_of_days = prev_tran_time_diff_mins / (60 * 24);
            curr_agg_map.put("P31", no_of_days);

//          Update previous hour type
            Integer hour_type_Index = deltaAggRequestFormat.getI8();
            curr_agg_map.put("P5", hour_type_Index);

            // Update previous transaction time
            curr_agg_map.put("P34", deltaAggRequestFormat.getTranDateTime());

//          Update previous city
            String city =  deltaAggRequestFormat.getP36();
            if (!("NA").equals(deltaAggRequestFormat.getTermCity()) && (deltaAggRequestFormat.getL1()==0)) {
                city = deltaAggRequestFormat.getP36()+ "_" +deltaAggRequestFormat.getTermCity();
            }
            curr_agg_map.put("P36",city);


//          Update previous transaction code type
            Double tran_cde_type_bin = (Double) preprocessed_data.get("tran_cde_type_bin");
            curr_agg_map.put("P17", tran_cde_type_bin);

//          Update previous transaction channel type
            curr_agg_map.put("P18", deltaAggRequestFormat.getI5());

//          Update previous transaction country type with dom_tran_flag
            curr_agg_map.put("P19", deltaAggRequestFormat.getDA11());

//          Update previous transaction flag with sd_resp_cde_type
            String sd_resp_cde_type = (String) preprocessed_data.get("sd_res_code_type");
            if (sd_resp_cde_type.equals("Approved")) {
                curr_agg_map.put("P20", 0);
                curr_agg_map.put("P22", 0);
                curr_agg_map.put("P32", 0);
                curr_agg_map.put("P33", 0);
                curr_agg_map.put("P24", 0);
            }

//          Update previous transaction fall back flag attribute
            Integer fall_back_status = (Integer) preprocessed_data.get("fall_back_status");
            curr_agg_map.put("P25", fall_back_status);

            Integer diffMins = deltaAggRequestFormat.getDA15();
            Double sd_tiebreaker_count_prev1min = deltaAggRequestFormat.getTC_1();
            if (diffMins <= 1) {
                curr_agg_map.put("TC_1", sd_tiebreaker_count_prev1min + 1);
            } else {
                Long currDate = deltaAggRequestFormat.getTranDateTime();
                curr_agg_map.put("P34", currDate);
                curr_agg_map.put("TC_1", 1);
            }
        } catch (Exception e) {
            logger.error("Exception = " + e.getMessage(), e);
            curr_agg_map = new HashMap<>();
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updatePrevTranAggregates Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }

        return curr_agg_map;
    }
}
