package com.quadratyx.delta_aggregation.service_impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

/**
 * This is the service module for creation of Derived Fields
 */
@Service
public class PreprocessingFunctions {

    private static final Logger logger = LoggerFactory.getLogger(PreprocessingFunctions.class);

    @Autowired
    @Qualifier("config")
    private Map<String, List<String>> jsonMap;

    /**
     * This is method used for creating transaction code type derived field
     *
     * @param tranCode transaction code detail
     * @return a <code> CompletableFuture String </code> specifying the transaction code type
     */
    public String tranCodeType(String tranCode) {
        String result = "NA";
        try {
            List<String> bal_inquiry = jsonMap.get("sd_tran_cde_bal_inquiry");
            List<String> pin_change = jsonMap.get("sd_tran_cde_pin_change");
            List<String> pin_inquiry = jsonMap.get("sd_tran_cde_pin_inquiry");
            List<String> purchase = jsonMap.get("sd_tran_cde_purchase");
            List<String> mail_order = jsonMap.get("sd_tran_cde_mail_order");

            if (tranCode != null && !tranCode.isEmpty()) {
                tranCode = tranCode.trim();

                if (bal_inquiry.contains(tranCode)) {
                    result = "BalInquiry";
                } else if (pin_change.contains(tranCode)) {
                    result = "PinChange";
                } else if (pin_inquiry.contains(tranCode)) {
                    result = "PinInquiry";
                } else if (purchase.contains(tranCode)) {
                    result = "Purchase";
                } else if (mail_order.contains(tranCode)) {
                    result = "MailOrder";
                } else {
                    result = "Others";
                }
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for creating transaction code type bin derived field
     *
     * @param tranCodeType transaction code type detail
     * @return a <code> Double </code> specifying the transaction code type bin
     */
    public double tranCodeTypeBin(String tranCodeType) {
        double result;

        result = switch (tranCodeType) {
            case "NA" -> 0.0;
            case "BalInquiry" -> 1.0;
            case "PinChange" -> 2.0;
            case "PinInquiry" -> 3.0;
            case "Purchase" -> 4.0;
            case "MailOrder" -> 5.0;
            default -> 6.0;
        };
        return result;
    }

    /**
     * This is the method used for creating balance available or not derived field
     *
     * @param MD_TRAN_AMT1      transaction amount detail
     * @param MD_CUST_TRAN_AMT1 customized transaction amount details
     * @param monetary_tran     monetary transaction detail
     * @return a <code> CompletableFuture String </code> specifying the sufficent balance or not
     */
    public String balanceNotAvailable(Double MD_TRAN_AMT1, Double MD_CUST_TRAN_AMT1, int monetary_tran) {
        String result = "NA";
        try {
            if (monetary_tran == 1) {
                if (MD_CUST_TRAN_AMT1 - MD_TRAN_AMT1 >= 0) {
                    result = "SuffBal";
                } else {
                    result = "InSuffBal";
                }
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for creating the entry mode type derived field
     *
     * @param pontOfSrvceEntryMode transaction entry mode detail
     * @return a <code> CompletableFuture String </code> specifying the entry mode type details
     */
    public String entryModeType(String pontOfSrvceEntryMode) {
        String result = "NA";
        try {
            List<String> entry_mde_cnp = jsonMap.get("sd_pt_entry_mde_cnp");
            List<String> entry_mde_mag_stripe = jsonMap.get("sd_pt_entry_mde_mag_stripe");
            List<String> entry_mde_chip_validated = jsonMap.get("sd_pt_entry_mde_chip_validated");
            List<String> entry_mde_contactless_card = jsonMap.get("sd_pt_entry_mde_contactless_card");
            if (entry_mde_cnp.contains(pontOfSrvceEntryMode)) {
                result = "cnp";
            } else if (entry_mde_chip_validated.contains(pontOfSrvceEntryMode)) {
                result = "chipvalidated";
            } else if (entry_mde_contactless_card.contains(pontOfSrvceEntryMode)) {
                result = "contactlesscard";
            } else if (entry_mde_mag_stripe.contains(pontOfSrvceEntryMode)) {
                result = "magstripe";
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for creating pin entered domestic flag derived field
     *
     * @param PINIndx       Pin association detail
     * @param TermCntr      Terminal country detail
     * @param channel_Index Channel type detail
     * @return a <code> CompletableFuture String </code> specifying the pin entered domestic flag details
     */
    public String pinEnteredDomFlag(String PINIndx, String TermCntr, int channel_Index) {
        String result = "NA";
        try {
            List<String> channel_type_lst = jsonMap.get("channel_type");
            String channel_type = jsonMap.get(String.valueOf(channel_Index)).get(0);
            if (("IN".equals(TermCntr.strip())) && (channel_type_lst.contains(channel_type))) {
                if (Integer.parseInt(PINIndx) == 1) {
                    result = "entered";
                } else {
                    result = "notentered";
                }
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for creating of real time rule status derived field
     *
     * @param RealTimeRuleDsps Real time rule disposition detail
     * @return a <code> CompletableFuture String </code> specifying the real time rule status details
     */
    public String realTimeRuleStatus(String RealTimeRuleDsps) {
        String result = "NA";
        try {
            List<String> authorized = jsonMap.get("sd_real_time_rule_dsps_authorized");
            List<String> allow_overtime = jsonMap.get("sd_real_time_rule_dsps_allow_overtime");
            List<String> declined = jsonMap.get("sd_real_time_rule_dsps_declined");

            if (authorized.contains(RealTimeRuleDsps)) {
                result = "Authorized";
            } else if (allow_overtime.contains(RealTimeRuleDsps)) {
                result = "Allow Over Time";
            } else if (declined.contains(RealTimeRuleDsps)) {
                result = "Declined";
            }

        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }


    /**
     * This is the method used for creating the response type derived field
     *
     * @param RespCode    Response code detail
     * @param TranAuthSrc transaction authorization detail
     * @return a <code> CompletableFuture String </code> specifying the response code type details
     */
    public String sdRespCodeType(String RespCode, String TranAuthSrc) {
        String result = "NA";
        try {
            List<String> sd_resp_code_apprvd = jsonMap.get("sd_resp_code_apprvd");
            List<String> sd_resp_code_prm_decline = jsonMap.get("sd_resp_code_prm_decline");
            List<String> sd_resp_code_invalid_data_B = jsonMap.get("sd_resp_code_invalid_data_B");
            List<String> sd_resp_code_invalid_data_H = jsonMap.get("sd_resp_code_invalid_data_H");
            List<String> sd_resp_code_expired_card_B = jsonMap.get("sd_resp_code_expired_card_B");
            List<String> sd_resp_code_expired_card_H = jsonMap.get("sd_resp_code_expired_card_H");
            List<String> sd_resp_code_restricted = jsonMap.get("sd_resp_code_restricted");
            List<String> sd_resp_code_insuff_funds_B = jsonMap.get("sd_resp_code_insuff_funds_B");
            List<String> sd_resp_code_insuff_funds_H = jsonMap.get("sd_resp_code_insuff_funds_H");
            List<String> sd_resp_code_withdrawal_limit_exceed = jsonMap.get("sd_resp_code_withdrawal_limit_exceed");
            List<String> sd_resp_code_init_limit_exceeded = jsonMap.get("sd_resp_code_init_limit_exceeded");
            List<String> sd_resp_code_block_decline_H = jsonMap.get("sd_resp_code_block_decline_H");
            List<String> sd_resp_code_pick_up_capture = jsonMap.get("sd_resp_code_pick_up_capture");
            TranAuthSrc = TranAuthSrc.strip();
            if (RespCode != null) {
                if (TranAuthSrc.equals("B")) {
                    if (sd_resp_code_apprvd.contains(RespCode)) {
                        result = "Approved";
                    } else if (sd_resp_code_prm_decline.contains(RespCode)) {
                        result = "PRM_Declined";
                    } else if (sd_resp_code_invalid_data_B.contains(RespCode)) {
                        result = "InvalidData";
                    } else if (sd_resp_code_expired_card_B.contains(RespCode)) {
                        result = "ExpiredCard";
                    } else if (sd_resp_code_restricted.contains(RespCode)) {
                        result = "RestrictedCard";
                    } else if (sd_resp_code_insuff_funds_B.contains(RespCode)) {
                        result = "InsuffFunds";
                    } else if (sd_resp_code_withdrawal_limit_exceed.contains(RespCode)) {
                        result = "WithdrawalLimitExceeded";
                    } else if (sd_resp_code_init_limit_exceeded.contains(RespCode)) {
                        result = "IntlLimitExceeded_NA";
                    } else if (sd_resp_code_pick_up_capture.contains(RespCode)) {
                        result = "Pickup_Capture";
                    } else {
                        result = "OtherDeclines";
                    }
                }
                if (TranAuthSrc.equals("H")) {
                    if (sd_resp_code_apprvd.contains(RespCode)) {
                        result = "Approved";
                    } else if (sd_resp_code_block_decline_H.contains(RespCode)) {
                        result = "Block_Decline_H";
                    } else if (sd_resp_code_invalid_data_H.contains(RespCode)) {
                        result = "InvalidData";
                    } else if (sd_resp_code_expired_card_H.contains(RespCode)) {
                        result = "ExpiredCard";
                    } else if (sd_resp_code_insuff_funds_H.contains(RespCode)) {
                        result = "InsuffFunds";
                    } else {
                        result = "OtherDeclines";
                    }
                }
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for creating the response code derived field
     *
     * @param RespCode    Response code detail
     * @param TranAuthSrc transaction authorization detail
     * @return a <code> CompletableFuture String </code> specifying the response code type details
     */
    public int sdRespCode(String RespCode, String TranAuthSrc) {
        int result = 0;
        try {
            List<String> sd_resp_code_apprvd = jsonMap.get("sd_resp_code_apprvd");
            List<String> sd_resp_code_prm_decline = jsonMap.get("sd_resp_code_prm_decline");
            List<String> sd_resp_code_invalid_data_B = jsonMap.get("sd_resp_code_invalid_data_B");
            List<String> sd_resp_code_invalid_data_H = jsonMap.get("sd_resp_code_invalid_data_H");
            List<String> sd_resp_code_expired_card_B = jsonMap.get("sd_resp_code_expired_card_B");
            List<String> sd_resp_code_expired_card_H = jsonMap.get("sd_resp_code_expired_card_H");
            List<String> sd_resp_code_restricted = jsonMap.get("sd_resp_code_restricted");
            List<String> sd_resp_code_insuff_funds_B = jsonMap.get("sd_resp_code_insuff_funds_B");
            List<String> sd_resp_code_insuff_funds_H = jsonMap.get("sd_resp_code_insuff_funds_H");
            List<String> sd_resp_code_withdrawal_limit_exceed = jsonMap.get("sd_resp_code_withdrawal_limit_exceed");
            List<String> sd_resp_code_init_limit_exceeded = jsonMap.get("sd_resp_code_init_limit_exceeded");
            List<String> sd_resp_code_block_decline_H = jsonMap.get("sd_resp_code_block_decline_H");
            List<String> sd_resp_code_pick_up_capture = jsonMap.get("sd_resp_code_pick_up_capture");
            TranAuthSrc = TranAuthSrc.strip();
            if (RespCode != null) {
                if (TranAuthSrc.equals("B")) {
                    if (sd_resp_code_apprvd.contains(RespCode)) {
                        result = 1;
                    } else if (sd_resp_code_prm_decline.contains(RespCode)) {
                        result = 2;
                    } else if (sd_resp_code_invalid_data_B.contains(RespCode)) {
                        result = 3;
                    } else if (sd_resp_code_expired_card_B.contains(RespCode)) {
                        result = 4;
                    } else if (sd_resp_code_restricted.contains(RespCode)) {
                        result = 5;
                    } else if (sd_resp_code_insuff_funds_B.contains(RespCode)) {
                        result = 6;
                    } else if (sd_resp_code_withdrawal_limit_exceed.contains(RespCode)) {
                        result = 7;
                    } else if (sd_resp_code_init_limit_exceeded.contains(RespCode)) {
                        result = 8;
                    } else if (sd_resp_code_pick_up_capture.contains(RespCode)) {
                        result = 9;
                    }
                }
                if (TranAuthSrc.equals("H")) {
                    if (sd_resp_code_apprvd.contains(RespCode)) {
                        result = 1;
                    } else if (sd_resp_code_block_decline_H.contains(RespCode)) {
                        result = 10;
                    } else if (sd_resp_code_invalid_data_H.contains(RespCode)) {
                        result = 3;
                    } else if (sd_resp_code_expired_card_H.contains(RespCode)) {
                        result = 4;
                    } else if (sd_resp_code_insuff_funds_H.contains(RespCode)) {
                        result = 6;
                    }
                }
            }
        } catch (Exception e) {
            result = 0;
        }
        return result;
    }

    /**
     * This is the method for creating fall back status derived field
     *
     * @param pontOfSrvceEntryMode transaction entry mode detail
     * @param EMVUsrFlr            EMV usage filler deatil
     * @return a <code> CompletableFuture String </code> specifying the fall back status details
     */
    public int fallBackStatus(String pontOfSrvceEntryMode, String EMVUsrFlr) {
        int result = 0;
        try {
            List<String> srv_entry_mde = jsonMap.get("sd_pt_srv_entry_mde");

            if ((srv_entry_mde.contains(pontOfSrvceEntryMode)) && (EMVUsrFlr.strip().startsWith("15")))
                result = 1;

        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method for creating token service type derived field
     *
     * @param prodInd              for channel type detail
     * @param rtlrSICcode          for retail SIC code detail
     * @param pontOfSrvceEntryMode transaction entry mode detail
     * @param acctNum              for customer account detail
     * @return a <code> CompletableFuture String </code> specifying the token service type details
     */
    public String tokenServiceType(String prodInd, String rtlrSICcode, String pontOfSrvceEntryMode, String acctNum) {
        String result = "NA";
        try {
            List<String> rtlr_sic_code = jsonMap.get("atm_sd_retl_li");
            List<String> srv_entry_mde = jsonMap.get("pos_sd_entry_mde_li");
            List<String> token_entry_mde = jsonMap.get("tokenpay_entry_mde_li");
            List<String> spay_acct_num = jsonMap.get("spay_acct_li");
            List<String> gpay_acct_num = jsonMap.get("gpay_acct_li");
            List<String> jpay_acct_num = jsonMap.get("jpay_acct_li");

            if ((prodInd.equals("02")) && (!rtlr_sic_code.contains(rtlrSICcode)) && (srv_entry_mde.contains(pontOfSrvceEntryMode.substring(0, 2)))) {
                if ((token_entry_mde.contains(pontOfSrvceEntryMode)) && (spay_acct_num.contains(acctNum))) {
                    result = "SamsungPay";
                } else if ((token_entry_mde.contains(pontOfSrvceEntryMode)) && (gpay_acct_num.contains(acctNum))) {
                    result = "GPay";
                } else if ((token_entry_mde.contains(pontOfSrvceEntryMode)) && (jpay_acct_num.contains(acctNum))) {
                    result = "JioPay";
                } else {
                    result = "NA";
                }
            }

        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    public String sdRespCodeTypeNew(int channel, String sdRespCode) {
        String result = "otherDeclines";
        try {
            if (sdRespCode != null) {
                int sdRespCde = Integer.parseInt(sdRespCode);
                if (sdRespCde == 50) {
                    if (channel == 2)
                        result = "Restricted_Card";
                    if (channel == 1)
                        result = "Host_Decline";
                } else if (sdRespCde == 51)
                    result = "Expired_Card";
                else if (sdRespCde == 52)
                    result = "Invalid_Card_Number";
                else if (sdRespCde == 53)
                    result = "Invalid_PIN";
                else if (sdRespCde == 54)
                    result = "System_Issue";
                else if (sdRespCde == 55)
                    result = "Invalid_Transaction";
                else if (sdRespCde == 56)
                    result = "Transaction_Not_Permitted_to_Cardholder";
                else if (sdRespCde == 57)
                    result = "Transaction_Not_Supported";
                else if (sdRespCde == 58) {
                    if (channel == 2)
                        result = "Not_Sufficient_Funds";
                    if (channel == 1)
                        result = "Invalid_card_number";
                } else if (sdRespCde == 59)
                    result = "Not_Sufficient_Funds";
                else if (sdRespCde == 60) {
                    if (channel == 2)
                        result = "Exceeds_Withdrawal_amount_limit";
                    if (channel == 1)
                        result = "No_PBF";
                } else if (sdRespCde == 63)
                    result = "Exceeds_Withdrawal_amount_limit";
                else if (sdRespCde == 64)
                    result = "Bad_Track_Data";
                else if (sdRespCde == 67)
                    result = "Invalid_transaction_date";
                else if (sdRespCde == 68)
                    result = "External_Decline";
                else if (sdRespCde == 70)
                    result = "System_Issue";
                else if (sdRespCde == 72)
                    result = "Issuer_or_Switch_is_inoperative";
                else if (sdRespCde == 74) {
                    if (channel == 2)
                        result = "Format_Error";
                    if (channel == 1)
                        result = "Unable_to_authorize";
                } else if (sdRespCde == 76)
                    result = "Not_Sufficient_Funds";
                else if (sdRespCde == 77)
                    result = "INTL_Limit_Exceeded";
                else if (sdRespCde == 78) {
                    if (channel == 2)
                        result = "Invalid_Country_code";
                    if (channel == 1)
                        result = "Duplicate_Transaction";
                } else if (sdRespCde == 87)
                    result = "TVR_Decline";
                else if (sdRespCde == 88)
                    result = "PRM_Decline";
                else if (sdRespCde == 89)
                    result = "CAF_Status_0_or_9";
                else if (sdRespCde == 97)
                    result = "Mod_10_Check";
                else if (sdRespCde == 100)
                    result = "Unable_to_process_transaction";
                else if (sdRespCde == 105)
                    result = "Card_not_supported";
                else if (sdRespCde == 150)
                    result = "Restricted_Card";
                else if (sdRespCde == 151)
                    result = "Expired_Card";
                else if (sdRespCde == 162)
                    result = "PIN_Tries_Exceeded";
                else if (sdRespCde == 168)
                    result = "External_Decline";
                else if (sdRespCde == 201)
                    result = "Invalid_PIN";
                else if (sdRespCde == 204)
                    result = "Enter_Lesser_Amount";
                else if (sdRespCde == 206)
                    result = "CAF_not_found";
                else if (sdRespCde == 213)
                    result = "Merchant_PIN_Bypass";
                else if (sdRespCde == 216)
                    result = "INTL_Limit_Exceeded";
                else if (sdRespCde == 217)
                    result = "INTL_Flag_not_Enabled";
                else if (sdRespCde == 218)
                    result = "PRM_Decline";
                else if (sdRespCde == 400)
                    result = "REQ_CRYPTOGRAM_FAILURE";
                else if (sdRespCde == 401)
                    result = "HSM_Param_Error";
                else if (sdRespCde == 900)
                    result = "PIN_Tries_Exceeded";
                else if (sdRespCde == 901)
                    result = "Expired_Card";
                else if (sdRespCde == 903)
                    result = "Stolen_Card_or_pickup";
                else if (sdRespCde == 909)
                    result = "Capture";
                else if (sdRespCde >= 0 && sdRespCde < 10)
                    result = "Approved";
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for computing current transaction date time and previous transaction date time
     *
     * @param dd_date      current transaction date time detail
     * @param prev_dd_date previous  transaction date time detail
     * @return a <code> integer </code> specifying the minutes difference
     */
    public int tran_count(Long dd_date, Long prev_dd_date) {
        int result = 0;
        ZoneId zone = ZoneId.of("Asia/Kolkata");
        try {
            if (prev_dd_date == null || prev_dd_date.equals("0")) {
                result = 0;
            } else {
                LocalDate dateTime = LocalDate.ofInstant(Instant.ofEpochMilli(dd_date), zone);
                LocalDate prevDate = LocalDate.ofInstant(Instant.ofEpochMilli(prev_dd_date), zone);
                if (dateTime.equals(prevDate)) {
                    result = 1;
                } else {
                    result = 0;
                }

            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method used for computing difference between current transaction date time and previous transaction date
     *
     * @param dd_date      current transaction date time detail
     * @param prev_dd_date previous  transaction date time detail
     * @return a <code> integer </code> specifying the minutes difference
     */
    public int tranCount7days(Long dd_date, Long prev_dd_date) {
        int result = 0;
        try {
            Instant pinstant = Instant.ofEpochMilli(prev_dd_date);
            Instant instant = Instant.ofEpochMilli(dd_date);
            long day = ChronoUnit.DAYS.between(instant, pinstant);
            int days = (int) day;
            if (days < 7) {
                result = 1;
            } else {
                result = 0;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }
}
