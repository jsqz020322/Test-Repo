package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the service module for 3Days Aggregates creation
 */
@Service
public class Aggregates3Days {

    private static final Logger logger = LoggerFactory.getLogger(Aggregates3Days.class);

    @Autowired
    private AggregateBins aggregateBins;

    @Autowired
    private AggregateFunctions aggregateFunctions;

    @Autowired
    private DeltaAggregatesMain deltaAggregatesMain;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    @Autowired
    @Qualifier("config")
    private Map<String, List<String>> jsonMap;

    /**
     * This is the method used for updating ATM3DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param currAggMap            current aggregates map detail
     */
    public void updateATM3DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessedData,
                                         Map<String, Object> currAggMap) {
        try {

//          Calculating ATM amount bin based on the derived amount_bin_index attribute for previous 3 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, BusinessConstant.AMOUNT_BINS_M_ATM_PREV3DAYS_, currAggMap);


//          Country Type for current transaction
            String CntryType = deltaAggRequestFormat.getDA13();
            if ("Domestic".equals(CntryType)) {
                Double cntrytype_ATM_Domestic_count_prev3days = deltaAggRequestFormat.getC5_3();
                currAggMap.put("C5_3", cntrytype_ATM_Domestic_count_prev3days + 1);
            } else if ("International".equals(CntryType)) {
                Double cntrytype_ATM_International_count_prev3days = deltaAggRequestFormat.getC6_3();
                currAggMap.put("C6_3", cntrytype_ATM_International_count_prev3days + 1);
            }

//          Adding hour type count based on hour_type_index for previous 3 days ATM transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, BusinessConstant.HOUR_TYPE_ATM_PREV3DAYS_,
                    currAggMap);

//          Transaction code categorization for ATM transactions for prev 3 days
            Map<String, Double> req_map = aggregateBins.get_tran_cde_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessedData, req_map, currAggMap, BusinessConstant.TRAN_CDE_TYPE_ATM_, BusinessConstant.ED3DAYS);

//          Updating SD response code type for ATM transactions
            req_map = aggregateBins.get_sd_resp_cde_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, currAggMap, BusinessConstant.SD_RESP_CDE_TYPE_ATM_, BusinessConstant.ED3DAYS);

//          Updating ATM current date and week transaction count
            Double current_day_atm_trancount = deltaAggRequestFormat.getC10();
            currAggMap.put("C10", current_day_atm_trancount + 1);
            Double current_week_atm_trancount = deltaAggRequestFormat.getC11();
            currAggMap.put("C11", current_week_atm_trancount + 1);

//          Updating ATM approval count for country and transaction type
            String sd_resp_cde_type = String.valueOf(preprocessedData.get(BusinessConstant.SD_RES_CODE_TYPE));
            if (!sd_resp_cde_type.equals("Approved")) {
                Double atm_dec_w_count_cntrytype_prev3days = deltaAggRequestFormat.getA5_3_3();
                currAggMap.put("A5_3_3", atm_dec_w_count_cntrytype_prev3days + 1);
            }
        } catch (Exception e) {
            currAggMap = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updateATM3DaysAggregates " + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating 3DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param currAggMap            current aggregates map detail
     */
    public void update3DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessedData,
                                      Map<String, Object> currAggMap) {
        try {

//          Calculating amount bin based on the derived amount_bin_index attribute for previous 3 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, BusinessConstant.AMOUNT_BINS_M_PREV3DAYS_, currAggMap);

//          Country Type for current transaction
            String CntryType = deltaAggRequestFormat.getDA13();
            if ("International".equals(CntryType)) {
                Double cntrytype_International_count_prev3days = deltaAggRequestFormat.getC8_3();
                currAggMap.put("C8_3", cntrytype_International_count_prev3days + 1);
            }

//          Aggregate update for entry_mode_type
            String entry_mode_type = String.valueOf(preprocessedData.get("entry_mode_type"));
            Double chipvalidated_count = deltaAggRequestFormat.getE1_3();
            Double contactlesscard_count = deltaAggRequestFormat.getE2_3();
            Double magstripe_count = deltaAggRequestFormat.getE3_3();
            switch (entry_mode_type) {
                case "chipvalidated" -> currAggMap.put("E1_3", chipvalidated_count + 1);
                case "contactlesscard" -> currAggMap.put("E2_3", contactlesscard_count + 1);
                case "magstripe" -> currAggMap.put("E3_3", magstripe_count + 1);
                default -> logger.debug("entry_mode_type for 3 days aggregates updation is not matching with expected values");
            }

//          Monetary updation
            Integer monetary_tran = deltaAggRequestFormat.getDA5();
            Double monetary_NM_count_prev3days = deltaAggRequestFormat.getS2_3();
            if (monetary_tran != null && monetary_tran != 1) {
                currAggMap.put("S2_3", monetary_NM_count_prev3days + 1);
            }

//          Transaction code categorization for ATM transactions for prev 3 days
            Map<String, Double> req_map = aggregateBins.get_tran_cde_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessedData, req_map, currAggMap, BusinessConstant.TRAN_CDE_TYPE_, BusinessConstant.ED3DAYS);


//          Updating SD response code type for transactions
            req_map = aggregateBins.get_sd_resp_cde_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, currAggMap, BusinessConstant.SD_RESP_CDE_TYPE_, BusinessConstant.ED3DAYS);

//          Real Time Status count update
            req_map = aggregateBins.get_rel_time_rule_status_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getRealtimeStatusUpdation(preprocessedData, req_map, currAggMap, BusinessConstant.REAL_TIME_RULE_STATUS_, BusinessConstant.ED3DAYS);

//          Updating fall back status attribute for previous 3 days
            Integer fall_back_status = (Integer) preprocessedData.get(BusinessConstant.FALLBACK_STATUS);
            Double fall_back_status_count_prev3days = deltaAggRequestFormat.getF2_3();
            if (fall_back_status == 1) {
                currAggMap.put("F2_3", fall_back_status_count_prev3days + 1);
            }

//          Updating gasoline transaction count for previous 3 days
            Double gasoline_tran_count_prev3days = deltaAggRequestFormat.getG2_3();
            String SD_RETL_SIC_CDE = deltaAggRequestFormat.getRtlrSICCode();
            List<String> gasoline_tran_count = jsonMap.get("gasoline_tran_count");
            if (gasoline_tran_count.contains(SD_RETL_SIC_CDE)) {
                currAggMap.put("G2_3", gasoline_tran_count_prev3days + 1);
            }

//          Updating key entry flag count for previous 3 days
            String PontOfSrvcCondCode = deltaAggRequestFormat.getPontOfSrvcCondCode();
            String PontOfSrvceEntryMode = deltaAggRequestFormat.getPontOfSrvceEntryMode();
            List<String> srvc_cond_code = jsonMap.get("PontOfSrvcCondCode");
            List<String> srvc_entry_mode = jsonMap.get("PontOfSrvceEntryMode");

            if (srvc_cond_code.contains(PontOfSrvcCondCode) && srvc_entry_mode.contains(PontOfSrvceEntryMode)) {
                Double key_entry_tx_flag_key_entry_tx_count_prev3days = deltaAggRequestFormat.getK1_3();
                currAggMap.put("K1_3", key_entry_tx_flag_key_entry_tx_count_prev3days + 1);
            }

//          Updating restaurant Transaction count
            List<String> sd_retl_sic_cde_restaurant = jsonMap.get("sd_retl_sic_cde_restaurant");
            if (sd_retl_sic_cde_restaurant.contains(SD_RETL_SIC_CDE)) {
                Double restuarant_tran_count_prev3days = deltaAggRequestFormat.getR4_3();
                currAggMap.put("R4_3", restuarant_tran_count_prev3days + 1);
            }

//          Updating Stores Transaction count
            List<String> sd_retl_sic_cde_storestran = jsonMap.get("sd_retl_sic_cde_storestran");
            if (sd_retl_sic_cde_storestran.contains(SD_RETL_SIC_CDE)) {
                Double storestran_count_prev3days = deltaAggRequestFormat.getS23_3();
                currAggMap.put("S23_3", storestran_count_prev3days + 1);
            }

        } catch (Exception e) {
            currAggMap = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "update3DaysAggregates" + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }


    /**
     * This is the method used for updating POS3DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param currAggMap            current aggregates map detail
     */
    public void updatePOS3DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessedData,
                                         Map<String, Object> currAggMap) {
        try {

//          Calculating POS amount bin based on the derived amount_bin_index attribute for previous 3 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att_3days(deltaAggRequestFormat);
            String key = "amount_bins_M_POS_prev3days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, BusinessConstant.amount_bins_M_POS_prev3days_, currAggMap);

//          Updating SD response code type for POS transactions
            String st = "sd_resp_cde_type_POS_";
            Map<String, Double> req_map = aggregateBins.get_sd_resp_cde_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, currAggMap, BusinessConstant.sd_resp_cde_type_POS_, BusinessConstant.ED3DAYS);

//          Calculating POS mcc bin based on the derived mcc_bin_index attribute for previous 3 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, BusinessConstant.mcc_pos_retail_codes_3, BusinessConstant.MCC_POS_, BusinessConstant.ED3DAYS, currAggMap);

//          Token type categorization for POS transactions for prev 3 days
            Map<String, Double> token_bins_idx = aggregateBins.get_token_srvc_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getTokenSrvcBins(preprocessedData, token_bins_idx, currAggMap, BusinessConstant.token_srvc_POS_, BusinessConstant.ED3DAYS);

//          Updating Fraud Score bin count based on the fraud score for previous 3 days
            Map<String, Double> fs_bins_idx = aggregateBins.get_fs_bins_att_3days(deltaAggRequestFormat);
            aggregateFunctions.getFSBinAggregates(deltaAggRequestFormat.getFS(), fs_bins_idx, BusinessConstant.FRAUD, BusinessConstant.ED3DAYS, currAggMap);

//          Calculating mean bin count for the POS transaction amount and contactless card for 3 days
            String entry_mode_type = String.valueOf(preprocessedData.get(BusinessConstant.ENTRY_MODE_TYPE));
            if ("contactlesscard".equals(entry_mode_type)) {
                Map<String, Double> mean_bins_index = aggregateBins.get_mean_bins_att_3days(deltaAggRequestFormat);
                String meanKey = "md_tran_amt1_M_POS_contactlesscard_mean_prev3days";
                aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_index, meanKey, currAggMap);

//          Calculating max bin count for the POS transaction amount and contactless card for 3 days
                Map<String, Double> max_bins_index = aggregateBins.get_max_bins_att_3days(deltaAggRequestFormat);
                String maxKey = "md_tran_amt1_M_POS_contactlesscard_max_prev3days";
                aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_index, maxKey, currAggMap);
            }
        } catch (Exception e) {
            currAggMap = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updatePOS3DaysAggregates " + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating CNPSecured3DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param currAggMap            current aggregates map detail
     */
    public void updateCNPSecured3DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                Map<String, Object> currAggMap) {
        try {
//          Calculating CNP SECURED mcc bin based on the derived mcc_bin_index attribute for previous 3 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_3days(deltaAggRequestFormat);
            String str = "mcc_CNPSECURED_";
            String aggKey = "mcc_cnp_secured_retail_codes";
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, aggKey, str, BusinessConstant.ED3DAYS,
                    currAggMap);

//          Calculating Current trans state bins for previous 3 days

            String stateList = deltaAggRequestFormat.getC1_L();
            Integer aggVal = deltaAggRequestFormat.getCP1_3();
            aggregateFunctions.getCurrentStateCountBinAggregates(deltaAggRequestFormat, currAggMap, stateList, aggVal, BusinessConstant.stateListSecured);


//          Calculating Current trans city bins for previous 3 days
            String cityList = deltaAggRequestFormat.getC2_L();
            Integer agg_val = deltaAggRequestFormat.getCP2_3();
            aggregateFunctions.getCurrentCityCountBinAggregates(deltaAggRequestFormat, currAggMap, cityList, agg_val, BusinessConstant.current_city_list_secured);

//          Calculating Current trans country bins for previous 3 days
            String countryList = deltaAggRequestFormat.getC3_L();
            Integer AggVal = deltaAggRequestFormat.getCP3_3();
            aggregateFunctions.getCurrentCntryCountBinAggregates(deltaAggRequestFormat, currAggMap, countryList, AggVal, BusinessConstant.current_cntry_list_secured);


        } catch (Exception e) {
            currAggMap = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating CNPUnsecured3DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param currAggMap            current aggregates map detail
     */
    public void updateCNPUnsecured3DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                  Map<String, Object> currAggMap) {
        try {
//          Calculating CNP UNSECURED mcc bin based on the derived mcc_bin_index attribute for previous 3 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_3days(deltaAggRequestFormat);
            String str = "mcc_CNPUNSECURED_";
            String aggKey = "mcc_cnp_unsecured_retail_codes";
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, aggKey, str, BusinessConstant.ED3DAYS, currAggMap);

//          Updating channel type CNPUnsecured count for prev 3 days
            Double C3_3 = deltaAggRequestFormat.getC3_3();
            currAggMap.put("C3_3", C3_3 + 1);

//          Calculating Current trans state bins for previous 3 days

            String stateList = deltaAggRequestFormat.getCU1_L();
            Integer aggVal = deltaAggRequestFormat.getCP1_3();
            aggregateFunctions.getCurrentStateCountBinAggregates(deltaAggRequestFormat, currAggMap, stateList, aggVal, BusinessConstant.stateListUnsecured);


//          Calculating Current trans city bins for previous 3 days
            String cityList = deltaAggRequestFormat.getCU2_L();
            Integer agg_val = deltaAggRequestFormat.getCP2_3();
            aggregateFunctions.getCurrentCityCountBinAggregates(deltaAggRequestFormat, currAggMap, cityList, agg_val, BusinessConstant.current_city_list_unsecured);

//          Calculating Current trans country bins for previous 3 days
            String countryList = deltaAggRequestFormat.getCU3_L();
            Integer AggVal = deltaAggRequestFormat.getCP3_3();
            aggregateFunctions.getCurrentCntryCountBinAggregates(deltaAggRequestFormat, currAggMap, countryList, AggVal, BusinessConstant.current_cntry_list_unsecured);


        } catch (Exception e) {
            currAggMap = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }
}

