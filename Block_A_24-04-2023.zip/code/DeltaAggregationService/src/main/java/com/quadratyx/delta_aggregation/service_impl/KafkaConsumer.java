package com.quadratyx.delta_aggregation.service_impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * This is the service module for listening Kafka Consumer functionality
 */
@Service
public class KafkaConsumer {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumer.class);

    @Autowired
    DeltaAggregatesMain deltaAggregatesMain;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    /**
     * This is the method used for consuming the messages from kafka topic
     *
     * @param message kafka message details
     * @throws InterruptedException in case of any thread interruption
     */
    @KafkaListener(topics = "${spring.kafka.bootstrap.topicName}", concurrency = "${spring.kafka.concurrency}", groupId = "${spring.kafka.bootstrap.groupName}")
    public void publish(String message) throws InterruptedException, JsonProcessingException {
        if (!message.equals("") && !message.equals("{}")) {
            DeltaAggRequestFormat deltaAggRequestFormat = new DeltaAggRequestFormat();
            message = message.replace(" ", "");
            ObjectMapper objectMapper = new ObjectMapper();
            int status = -1;
            try {
                deltaAggRequestFormat = objectMapper.readValue(message, DeltaAggRequestFormat.class);
                status = 1;
            } catch (Exception e) {
                logger.error("Exception = " + e.getMessage(), e);
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String exception = "Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
                deltaAggregatesMain.sendMessage(exception, exceptionTopic);
            }
            if (status == 1) {
                deltaAggregatesMain.update_aggregates(deltaAggRequestFormat);
            }

        } else {
            logger.debug("Message received from Kafka is empty for current transaction data");
        }
    }
}
