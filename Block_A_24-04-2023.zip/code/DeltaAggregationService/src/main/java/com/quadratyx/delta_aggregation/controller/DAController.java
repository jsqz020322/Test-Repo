package com.quadratyx.delta_aggregation.controller;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.service_impl.DeltaAggregatesMain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
public class DAController {

    private static final Logger logger = LoggerFactory.getLogger(DAController.class);

    @Autowired
    DeltaAggregatesMain deltaAggregatesMain;

    @PostMapping(value = "/daMessage", headers = "Accept=application/json")
    public Map<String, Object> daMessage(@Valid @RequestBody DeltaAggRequestFormat deltaAggRequestFormat) throws Exception {
        Map<String, Object> jsonOut = new HashMap<>();
        try {
            logger.info("deltaAggRequestFormat is " + deltaAggRequestFormat.toString());
            jsonOut = deltaAggregatesMain.update_aggregates(deltaAggRequestFormat);
            logger.info("jsonOut is " + jsonOut.toString());
        } catch (Exception e) {
            logger.error("Exception is " + e.getMessage(), e);
        }
        return jsonOut;
    }
}