package com.quadratyx.delta_aggregation;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * This is the main class module for Delta Aggregation Service
 */
@SpringBootApplication
@EnableAsync
@Component
public class DeltaAggregatesApplication implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(DeltaAggregatesApplication.class);

    /**
     * This is the main() function of NRT API
     *
     * @param args Java command-line arguments and is an array of type java.lang.String class.
     */
    public static void main(String[] args) {
        SpringApplication.run(DeltaAggregatesApplication.class, args);
    }

    /**
     * This is the override method of main() function
     *
     * @param args Java command-line arguments and is an array of type java.lang.String class.
     */
    @Override
    public void run(String... args) {
        try {
            logger.info("Delta Aggregation Application is running.................");
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    @Value("${jsonfile.path}")
    private String jsonfilePath;

    @Bean(name = "config")
    public Map<String, List<String>> loadJson() throws IOException {
        File file = new File(jsonfilePath);
        return new ObjectMapper().readValue(file, Map.class);
    }

    @Value("${shortkeymap.path}")
    private String shortkeyMap;

    @Bean(name = "config1")
    public Map<String, String> loadShortKeyMap() throws IOException {
        File file = new File(shortkeyMap);
        return new ObjectMapper().readValue(file, Map.class);
    }
}