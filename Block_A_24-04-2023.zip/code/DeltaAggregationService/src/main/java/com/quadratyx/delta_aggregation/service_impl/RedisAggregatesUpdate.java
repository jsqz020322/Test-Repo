package com.quadratyx.delta_aggregation.service_impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the service module for updating Redis Aggregates
 */
@Service
public class RedisAggregatesUpdate {

    private static final Logger logger = LoggerFactory.getLogger(RedisAggregatesUpdate.class);
    private final String channel_type_log = "channel type is - {}";
    @Autowired
    private DeltaAggregatesMain deltaAggregatesMain;
    @Autowired
    private Aggregates30Days aggregates30Days;
    @Autowired
    private Aggregates3Days aggregates3Days;
    @Autowired
    private MerchantAggregates merchantAggregates;
    @Autowired
    private PreviousTransactionBasedAggregates previousTranAggregates;
    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    //    @Autowired
//    @Qualifier("redisSentinelConnection")
//    private Jedis jedisCluster;
    @Autowired
    @Qualifier("redisClusterConfiguration")
    private JedisCluster jedisCluster;
    @Autowired
    @Qualifier("config")
    private Map<String, List<String>> jsonMap;
    @Autowired
    @Qualifier("config1")
    private Map<String, String> shortkeyAggMap;

    /**
     * This is the method used for updating all the aggregates' data into redis
     *
     * @param deltaAggRequestFormat Delta Aggregation Request Format detail
     * @param preprocessed_data     preprocessed_data PreProcessed Derived fields detail
     * @return a <code> Map of String, Object </code> specifying all the updated aggregates data into redis
     */
    public Map<String, Object> updateAggregatesData(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessed_data) {
        Map<String, Object> curr_agg_map = null;
        try {
            curr_agg_map = new HashMap<>(populate_aggregates_data(deltaAggRequestFormat));
            update_map_data(deltaAggRequestFormat, curr_agg_map, preprocessed_data);

            if (curr_agg_map != null && !curr_agg_map.isEmpty()) {
                setList(jedisCluster, deltaAggRequestFormat.getPan(), curr_agg_map);
            }
        } catch (Exception e) {
            curr_agg_map = null;
            logger.error("Exception  " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updateAggregatesData Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }

        return curr_agg_map;
    }

    /**
     * This is the method used for updating all merchant aggregates data into redis
     *
     * @param deltaAggRequestFormat Delta Aggregation Request Format detail
     * @return a <code> Map of String, Object </code> specifying all the updated merchant aggregates data into redis
     */

    public Map<String, Object> updateMerchantAggregatesData(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessed_data) {
        Map<String, Object> curr_map = null;
        try {
            curr_map = new HashMap<>(populate_merchant_aggregate_data(deltaAggRequestFormat));
            update_merchant_map_data(deltaAggRequestFormat, curr_map, preprocessed_data);

            if (curr_map != null && !curr_map.isEmpty()) {
                setList(jedisCluster, deltaAggRequestFormat.getTermid().trim(), curr_map);
            }

        } catch (Exception e) {
            curr_map = null;
            logger.error("Exception updateMerchantAggregatesData " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updateMerchantAggregatesData Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
        return curr_map;
    }

    /**
     * This is the method used for pushing a key with map for values into redis cluster
     *
     * @param jedisCluster Redis cluster detail
     * @param key          Redis key detail
     * @param value        a map of values
     * @return a <code> long </code> specifying the redis pushed data
     */
    public void setList(JedisCluster jedisCluster, String key, Map<String, Object> value) throws Exception {
        String redis_input = new ObjectMapper().writeValueAsString(value);
//        if (jedisCluster.exists(key)) {
//            logger.debug("Key exists............ so deleting key -----------------");
//            jedisCluster.del(key);
//        }
        jedisCluster.set(key, redis_input);
    }

    /**
     * This is the method used for updating the map data
     *
     * @param deltaAggRequestFormat Delta Aggregation Request Format detail
     * @param curr_agg_map          current aggregates map detail
     * @param preprocessed_data     PreProcessed Derived fields detail
     * @return a updated <code> Map of String, Object </code>
     */
    private void update_map_data(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> curr_agg_map, Map<String, Object> preprocessed_data) {
        try {
            int cType = deltaAggRequestFormat.getI5();
            switch (cType) {
                case 1 -> {
                    curr_agg_map.put("C4_30", deltaAggRequestFormat.getC4_30() + 1);
                    aggregates30Days.updatePOS30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    if (!curr_agg_map.isEmpty()) {
                        curr_agg_map.put("C4_3", deltaAggRequestFormat.getC4_3() + 1);
                        aggregates3Days.updatePOS3DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    }
                }
                case 2 -> {
                    curr_agg_map.put("C1_30", deltaAggRequestFormat.getC1_30() + 1);
                    aggregates30Days.updateATM30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    if (!curr_agg_map.isEmpty()) {
                        aggregates3Days.updateATM3DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    }
                }
                case 3 -> {
                    curr_agg_map.put("C2_30", deltaAggRequestFormat.getC2_30() + 1);
                    aggregates30Days.updateCNPSecured30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    if (!curr_agg_map.isEmpty()) {
                        curr_agg_map.put("C2_3", deltaAggRequestFormat.getC2_3() + 1);
                        aggregates3Days.updateCNPSecured3DaysAggregates(deltaAggRequestFormat, curr_agg_map);
                    }
                }
                case 4 -> {
                    curr_agg_map.put("C3_30", deltaAggRequestFormat.getC3_30() + 1);
                    aggregates30Days.updateCNPUnsecured30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    if (!curr_agg_map.isEmpty()) {
                        curr_agg_map.put("C3_3", deltaAggRequestFormat.getC3_3() + 1);
                        aggregates3Days.updateCNPUnsecured3DaysAggregates(deltaAggRequestFormat, curr_agg_map);
                    }
                }
            }

            if (!curr_agg_map.isEmpty()) {
                aggregates30Days.update30DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                if (!curr_agg_map.isEmpty()) {
                    aggregates3Days.update3DaysAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    if (!curr_agg_map.isEmpty()) {
                        previousTranAggregates.updatePrevTranAggregates(deltaAggRequestFormat, preprocessed_data, curr_agg_map);
                    }
                }
            }
            if (!curr_agg_map.isEmpty()) {
                String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(new Date());
                curr_agg_map.put("TS1", timeStamp);
            }

        } catch (Exception e) {
            curr_agg_map = new HashMap<>();
            logger.error("Exception =" + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "update_map_data Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }


    /**
     * This is the method used for updating the map data
     *
     * @param deltaAggRequestFormat Delta Aggregation Request Format detail
     * @param curr_map              current aggregates map detail
     * @param preprocessed_data     PreProcessed Derived fields detail
     * @return a updated <code> Map of String, Object </code>
     */
    private void update_merchant_map_data(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> curr_map, Map<String, Object> preprocessed_data) {
        try {
            int channel_type = deltaAggRequestFormat.getI5();

            if (channel_type == 1) {
                merchantAggregates.updatePOSMerchantAggregates(deltaAggRequestFormat, curr_map, preprocessed_data);
            } else {
                merchantAggregates.updateMerchantAggregates(deltaAggRequestFormat, curr_map, preprocessed_data);
            }

            if (!curr_map.isEmpty()) {
                String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(new Date());
                curr_map.put("TS1", timeStamp);
            }
        } catch (Exception e) {
            curr_map = null;
            logger.error("Exception = " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "update_merchant_map_data Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for getting aggregates data from redis cluster
     *
     * @param key redis key detail
     * @return a <code> Map of String,Object </code> specifying the redis data for a key
     * @throws JsonProcessingException in case of invalid json processing
     */
    public Map<String, Object> getCachedata(String key, String tId) throws JsonProcessingException {
        Map<String, Object> redisMap = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String redisAggregates = jedisCluster.get(key);
            if (redisAggregates != null) {
                redisMap = objectMapper.readValue(redisAggregates, Map.class);
            } else {
                String defaultValue = jedisCluster.get("default");
                redisMap = objectMapper.readValue(defaultValue, Map.class);
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "getCachedata Tiebreaker : " + tId + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
        return redisMap;
    }

    /**
     * This is the method used for getting merchant based aggregates data from redis cluster
     *
     * @param key redis key detail
     * @return a <code> Map of String,Object </code> specifying the redis data for a key
     * @throws JsonProcessingException in case of invalid json processing
     */
    public Map<String, Object> getMerchantData(String key, String tId) throws JsonProcessingException {
        Map<String, Object> merchantMap = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String merchantAggregates = jedisCluster.get(key);
            if (merchantAggregates != null) {
                merchantMap = objectMapper.readValue(merchantAggregates, Map.class);
            } else {
                String defaultValue = jedisCluster.get("default_merchant");
                merchantMap = objectMapper.readValue(defaultValue, Map.class);
            }
        } catch (Exception e) {
            logger.error("Exception = " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "getMerchantData Tiebreaker : " + tId + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
        return merchantMap;
    }

    /**
     * This the method used for storing the aggregates value into a map
     *
     * @param deltaAggRequestFormat delta aggregation request format detail
     */
    public Map<String, Object> populate_aggregates_data(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Object> map = new HashMap<>();

        map.put("A1_30_1", deltaAggRequestFormat.getA1_30_1());
        map.put("A1_30_0", deltaAggRequestFormat.getA1_30_0());
        map.put("A1_30_10", deltaAggRequestFormat.getA1_30_10());
        map.put("A1_30_6", deltaAggRequestFormat.getA1_30_6());
        map.put("A1_30_2", deltaAggRequestFormat.getA1_30_2());
        map.put("A1_30_7", deltaAggRequestFormat.getA1_30_7());
        map.put("A1_30_4", deltaAggRequestFormat.getA1_30_4());
        map.put("A1_30_8", deltaAggRequestFormat.getA1_30_8());
        map.put("A1_30_11", deltaAggRequestFormat.getA1_30_11());
        map.put("A1_30_9", deltaAggRequestFormat.getA1_30_9());
        map.put("A1_30_5", deltaAggRequestFormat.getA1_30_5());
        map.put("A1_30_3", deltaAggRequestFormat.getA1_30_3());
        map.put("A1_3_1", deltaAggRequestFormat.getA1_3_1());
        map.put("A1_3_10", deltaAggRequestFormat.getA1_3_10());
        map.put("A1_3_6", deltaAggRequestFormat.getA1_3_6());
        map.put("A1_3_7", deltaAggRequestFormat.getA1_3_7());
        map.put("A1_3_4", deltaAggRequestFormat.getA1_3_4());
        map.put("A1_3_8", deltaAggRequestFormat.getA1_3_8());
        map.put("A1_3_11", deltaAggRequestFormat.getA1_3_11());
        map.put("A1_3_3", deltaAggRequestFormat.getA1_3_3());
        map.put("A2_30_0", deltaAggRequestFormat.getA2_30_0());
        map.put("A2_3_0", deltaAggRequestFormat.getA2_3_0());
        map.put("A2_30_2", deltaAggRequestFormat.getA2_30_2());
        map.put("A2_3_2", deltaAggRequestFormat.getA2_3_2());
        map.put("A2_30_6", deltaAggRequestFormat.getA2_30_6());
        map.put("A2_3_6", deltaAggRequestFormat.getA2_3_6());
        map.put("A2_30_7", deltaAggRequestFormat.getA2_30_7());
        map.put("A2_3_7", deltaAggRequestFormat.getA2_3_7());
        map.put("A2_30_4", deltaAggRequestFormat.getA2_30_4());
        map.put("A2_3_4", deltaAggRequestFormat.getA2_3_4());
        map.put("A2_30_8", deltaAggRequestFormat.getA2_30_8());
        map.put("A2_3_8", deltaAggRequestFormat.getA2_3_8());
        map.put("A2_30_9", deltaAggRequestFormat.getA2_30_9());
        map.put("A2_3_9", deltaAggRequestFormat.getA2_3_9());
        map.put("A2_30_5", deltaAggRequestFormat.getA2_30_5());
        map.put("A2_3_5", deltaAggRequestFormat.getA2_3_5());
        map.put("A2_30_3", deltaAggRequestFormat.getA2_30_3());
        map.put("A2_3_3", deltaAggRequestFormat.getA2_3_3());
        map.put("A3_30", deltaAggRequestFormat.getA3_30());
        map.put("A4", deltaAggRequestFormat.getA4());
        map.put("A5_30_3", deltaAggRequestFormat.getA5_30_3());
        map.put("A5_3_3", deltaAggRequestFormat.getA5_3_3());

        map.put("C1_30", deltaAggRequestFormat.getC1_30());
        map.put("C1_3", deltaAggRequestFormat.getC1_3());
        map.put("C2_30", deltaAggRequestFormat.getC2_30());
        map.put("C2_3", deltaAggRequestFormat.getC2_3());
        map.put("C3_3", deltaAggRequestFormat.getC3_3());
        map.put("C3_30", deltaAggRequestFormat.getC3_30());
        map.put("C4_3", deltaAggRequestFormat.getC4_3());
        map.put("C4_30", deltaAggRequestFormat.getC4_30());
        map.put("C5_3", deltaAggRequestFormat.getC5_3());
        map.put("C6_30", deltaAggRequestFormat.getC6_30());
        map.put("C6_3", deltaAggRequestFormat.getC6_3());
        map.put("C7_30", deltaAggRequestFormat.getC7_30());
        map.put("C8_3", deltaAggRequestFormat.getC8_3());
        map.put("C8_30", deltaAggRequestFormat.getC8_30());
        map.put("C8_P_30", deltaAggRequestFormat.getC8_P_30());
        map.put("C9_30", deltaAggRequestFormat.getC9_30());
        map.put("C10", deltaAggRequestFormat.getC10());
        map.put("C11", deltaAggRequestFormat.getC11());
        map.put("C2_30_3", deltaAggRequestFormat.getC2_30_3());
        map.put("C2_30_4", deltaAggRequestFormat.getC2_30_4());
        map.put("C2_30_5", deltaAggRequestFormat.getC2_30_5());
        map.put("C2_30_6", deltaAggRequestFormat.getC2_30_6());
        map.put("C2_30_7", deltaAggRequestFormat.getC2_30_7());
        map.put("C2_30_8", deltaAggRequestFormat.getC2_30_8());
        map.put("C2_30_9", deltaAggRequestFormat.getC2_30_9());
        map.put("C3_30_3", deltaAggRequestFormat.getC3_30_3());
        map.put("C3_30_4", deltaAggRequestFormat.getC3_30_4());
        map.put("C3_30_5", deltaAggRequestFormat.getC3_30_5());
        map.put("C3_30_6", deltaAggRequestFormat.getC3_30_6());
        map.put("C3_30_7", deltaAggRequestFormat.getC3_30_7());
        map.put("C3_30_8", deltaAggRequestFormat.getC3_30_8());
        map.put("C3_30_9", deltaAggRequestFormat.getC3_30_9());
        map.put("CC1_30", deltaAggRequestFormat.getCC1_30());
        map.put("CC2_30", deltaAggRequestFormat.getCC2_30());
        map.put("CC3_30", deltaAggRequestFormat.getCC3_30());
        map.put("CC4_30", deltaAggRequestFormat.getCC4_30());
        map.put("CU1_L", deltaAggRequestFormat.getCU1_L());
        map.put("CU2_L", deltaAggRequestFormat.getCU2_L());
        map.put("CU3_L", deltaAggRequestFormat.getCU3_L());
        map.put("C1_L", deltaAggRequestFormat.getC1_L());
        map.put("C2_L", deltaAggRequestFormat.getC2_L());
        map.put("C3_L", deltaAggRequestFormat.getC3_L());
        map.put("CM_3", deltaAggRequestFormat.getCM_3());
        map.put("CP1_30", deltaAggRequestFormat.getCP1_30());
        map.put("CP2_30", deltaAggRequestFormat.getCP2_30());
        map.put("CP3_30", deltaAggRequestFormat.getCP3_30());
        map.put("CP1_3", deltaAggRequestFormat.getCP1_3());
        map.put("CP2_3", deltaAggRequestFormat.getCP2_3());
        map.put("CP3_3", deltaAggRequestFormat.getCP3_3());
        map.put("CS_30", deltaAggRequestFormat.getCS_30());
        map.put("CU_30", deltaAggRequestFormat.getCU_30());

        //map.put("D3", deltaAggRequestFormat.getD3());

        map.put("E1_30", deltaAggRequestFormat.getE1_30());
        map.put("E1_3", deltaAggRequestFormat.getE1_3());
        map.put("E2_3", deltaAggRequestFormat.getE2_3());
        map.put("E3_3", deltaAggRequestFormat.getE3_3());
        map.put("E2_30", deltaAggRequestFormat.getE2_30());
        map.put("E3_30", deltaAggRequestFormat.getE3_30());

        map.put("F2_3", deltaAggRequestFormat.getF2_3());
        map.put("F2_30", deltaAggRequestFormat.getF2_30());
        map.put("F3_3", deltaAggRequestFormat.getF3_3());
        map.put("FM_60", deltaAggRequestFormat.getFM_60());

        map.put("G1_30", deltaAggRequestFormat.getG1_30());
        map.put("G2_3", deltaAggRequestFormat.getG2_3());

        map.put("H2_30", deltaAggRequestFormat.getH2_30());
        map.put("H2_3", deltaAggRequestFormat.getH2_3());
        map.put("H3_30", deltaAggRequestFormat.getH3_30());
        map.put("H3_3", deltaAggRequestFormat.getH3_3());
        map.put("H4_30", deltaAggRequestFormat.getH4_30());
        map.put("H4_3", deltaAggRequestFormat.getH4_3());
        map.put("H5_30", deltaAggRequestFormat.getH5_30());
        map.put("H5_3", deltaAggRequestFormat.getH5_3());
        map.put("H6_30", deltaAggRequestFormat.getH6_30());
        map.put("H7_30", deltaAggRequestFormat.getH7_30());
        map.put("H8_3", deltaAggRequestFormat.getH8_3());
        map.put("H8_P_30", deltaAggRequestFormat.getH8_P_30());
        map.put("H8_30", deltaAggRequestFormat.getH8_30());
        map.put("H9_30", deltaAggRequestFormat.getH9_30());
        map.put("H9_3", deltaAggRequestFormat.getH9_3());
        map.put("HC1_30", deltaAggRequestFormat.getHC1_30());
        map.put("HC2_30", deltaAggRequestFormat.getHC2_30());
        map.put("HC3_30", deltaAggRequestFormat.getHC3_30());
        map.put("HC4_30", deltaAggRequestFormat.getHC4_30());
        map.put("HC5_30", deltaAggRequestFormat.getHC5_30());
        map.put("HC6_30", deltaAggRequestFormat.getHC6_30());
        map.put("HC7_30", deltaAggRequestFormat.getHC7_30());
        map.put("HC8_30", deltaAggRequestFormat.getHC8_30());

        map.put("K1_30", deltaAggRequestFormat.getK1_30());
        map.put("K1_3", deltaAggRequestFormat.getK1_3());

        map.put("L1", deltaAggRequestFormat.getL1());

        map.put("M9", deltaAggRequestFormat.getM9());
        map.put("M14", deltaAggRequestFormat.getM14());
        map.put("M15", deltaAggRequestFormat.getM15());
        map.put("M1_30", deltaAggRequestFormat.getM1_30());
        map.put("M5_30", deltaAggRequestFormat.getM5_30());
        map.put("M6_30", deltaAggRequestFormat.getM6_30());
        map.put("M7_30", deltaAggRequestFormat.getM7_30());
        map.put("M8_30", deltaAggRequestFormat.getM8_30());
        map.put("MC_3_1", deltaAggRequestFormat.getMC_3_1());
        map.put("MC_30_1", deltaAggRequestFormat.getMC_30_1());
        map.put("MC_30_2", deltaAggRequestFormat.getMC_30_2());
        map.put("MC_3_2", deltaAggRequestFormat.getMC_3_2());
        map.put("MC_3_3", deltaAggRequestFormat.getMC_3_3());
        map.put("MC_30_3", deltaAggRequestFormat.getMC_30_3());
        map.put("MC_30_4", deltaAggRequestFormat.getMC_30_4());
        map.put("MC_3_4", deltaAggRequestFormat.getMC_3_4());
        map.put("MC_3_5", deltaAggRequestFormat.getMC_3_5());
        map.put("MC_30_5", deltaAggRequestFormat.getMC_30_5());
        map.put("MC_30_6", deltaAggRequestFormat.getMC_30_6());
        map.put("MC_3_6", deltaAggRequestFormat.getMC_3_6());
        map.put("MC_3_7", deltaAggRequestFormat.getMC_3_7());
        map.put("MC_30_7", deltaAggRequestFormat.getMC_30_7());
        map.put("MC_30_8", deltaAggRequestFormat.getMC_30_8());
        map.put("MC_3_8", deltaAggRequestFormat.getMC_3_8());
        map.put("MC_3_9", deltaAggRequestFormat.getMC_3_9());
        map.put("MC_30_9", deltaAggRequestFormat.getMC_30_9());
        map.put("MC_30_10", deltaAggRequestFormat.getMC_30_10());
        map.put("MC_3_10", deltaAggRequestFormat.getMC_3_10());
        map.put("MC_3_11", deltaAggRequestFormat.getMC_3_11());
        map.put("MC_30_11", deltaAggRequestFormat.getMC_30_11());
        map.put("MC_30_12", deltaAggRequestFormat.getMC_30_12());
        map.put("MC_3_12", deltaAggRequestFormat.getMC_3_12());
        map.put("MC_3_13", deltaAggRequestFormat.getMC_3_13());
        map.put("MC_30_13", deltaAggRequestFormat.getMC_30_13());
        map.put("MD_T1_30", deltaAggRequestFormat.getMD_T1_30());
        map.put("MD_T2_30", deltaAggRequestFormat.getMD_T2_30());
        map.put("MD_T3_30", deltaAggRequestFormat.getMD_T3_30());
        map.put("MD_T3_3", deltaAggRequestFormat.getMD_T3_3());
        map.put("MD_T4_30", deltaAggRequestFormat.getMD_T4_30());
        map.put("MD_T4_3", deltaAggRequestFormat.getMD_T4_3());
        map.put("M_L_30", deltaAggRequestFormat.getM_L_30());
        map.put("MP_30_1", deltaAggRequestFormat.getMP_30_1());
        map.put("MP_3_1", deltaAggRequestFormat.getMP_3_1());
        map.put("MP_30_2", deltaAggRequestFormat.getMP_30_2());
        map.put("MP_3_2", deltaAggRequestFormat.getMP_3_2());
        map.put("MP_30_3", deltaAggRequestFormat.getMP_30_3());
        map.put("MP_3_3", deltaAggRequestFormat.getMP_3_3());
        map.put("MP_30_4", deltaAggRequestFormat.getMP_30_4());
        map.put("MP_3_4", deltaAggRequestFormat.getMP_3_4());
        map.put("MP_30_5", deltaAggRequestFormat.getMP_30_5());
        map.put("MP_3_5", deltaAggRequestFormat.getMP_3_5());
        map.put("MP_30_6", deltaAggRequestFormat.getMP_30_6());
        map.put("MP_3_6", deltaAggRequestFormat.getMP_3_6());
        map.put("MP_30_7", deltaAggRequestFormat.getMP_30_7());
        map.put("MP_3_7", deltaAggRequestFormat.getMP_3_7());
        map.put("MP_3_8", deltaAggRequestFormat.getMP_3_8());
        map.put("MP_30_9", deltaAggRequestFormat.getMP_30_9());
        map.put("MP_3_9", deltaAggRequestFormat.getMP_3_9());
        map.put("MP_30_10", deltaAggRequestFormat.getMP_30_10());
        map.put("MP_3_10", deltaAggRequestFormat.getMP_3_10());
        map.put("MP_30_11", deltaAggRequestFormat.getMP_30_11());
        map.put("MP_3_11", deltaAggRequestFormat.getMP_3_11());
        map.put("MP_30_12", deltaAggRequestFormat.getMP_30_12());
        map.put("MP_3_12", deltaAggRequestFormat.getMP_3_12());
        map.put("MP_30_13", deltaAggRequestFormat.getMP_30_13());
        map.put("MP_3_13", deltaAggRequestFormat.getMP_3_13());
        map.put("MP_30_14", deltaAggRequestFormat.getMP_30_14());
        map.put("MP_3_14", deltaAggRequestFormat.getMP_3_14());
        map.put("MP_30_15", deltaAggRequestFormat.getMP_30_15());
        map.put("MP_3_15", deltaAggRequestFormat.getMP_3_15());
        map.put("MP_30_16", deltaAggRequestFormat.getMP_30_16());
        map.put("MP_3_16", deltaAggRequestFormat.getMP_3_16());
        map.put("MP_30_17", deltaAggRequestFormat.getMP_30_17());
        map.put("MP_3_17", deltaAggRequestFormat.getMP_3_17());
        map.put("MP_30_18", deltaAggRequestFormat.getMP_30_18());
        map.put("MP_3_18", deltaAggRequestFormat.getMP_3_18());
        map.put("MP_30_19", deltaAggRequestFormat.getMP_30_19());
        map.put("MP_3_19", deltaAggRequestFormat.getMP_3_19());
        map.put("MP_30_20", deltaAggRequestFormat.getMP_30_20());
        map.put("MP_3_20", deltaAggRequestFormat.getMP_3_20());
        map.put("MU_30_1", deltaAggRequestFormat.getMU_30_1());
        map.put("MU_30_2", deltaAggRequestFormat.getMU_30_2());
        map.put("MU_30_3", deltaAggRequestFormat.getMU_30_3());
        map.put("MU_30_4", deltaAggRequestFormat.getMU_30_4());
        map.put("MU_30_5", deltaAggRequestFormat.getMU_30_5());
        map.put("MU_30_6", deltaAggRequestFormat.getMU_30_6());
        map.put("MU_30_7", deltaAggRequestFormat.getMU_30_7());
        map.put("MU_30_8", deltaAggRequestFormat.getMU_30_8());
        map.put("MU_30_9", deltaAggRequestFormat.getMU_30_9());
        map.put("MU_30_10", deltaAggRequestFormat.getMU_30_10());
        map.put("MU_30_11", deltaAggRequestFormat.getMU_30_11());
        map.put("MU_30_12", deltaAggRequestFormat.getMU_30_12());
        map.put("MU_30_13", deltaAggRequestFormat.getMU_30_13());
        map.put("MU_30_14", deltaAggRequestFormat.getMU_30_14());
        map.put("MU_30_15", deltaAggRequestFormat.getMU_30_15());
        map.put("MU_30_16", deltaAggRequestFormat.getMU_30_16());
        map.put("MU_30_17", deltaAggRequestFormat.getMU_30_17());
        map.put("MU_30_18", deltaAggRequestFormat.getMU_30_18());
        map.put("MU_30_19", deltaAggRequestFormat.getMU_30_19());
        map.put("MU_30_20", deltaAggRequestFormat.getMU_30_20());
        map.put("MU_3_1", deltaAggRequestFormat.getMU_3_1());
        map.put("MU_3_2", deltaAggRequestFormat.getMU_3_2());
        map.put("MU_3_3", deltaAggRequestFormat.getMU_3_3());
        map.put("MU_3_4", deltaAggRequestFormat.getMU_3_4());
        map.put("MU_3_5", deltaAggRequestFormat.getMU_3_5());
        map.put("MU_3_6", deltaAggRequestFormat.getMU_3_6());
        map.put("MU_3_7", deltaAggRequestFormat.getMU_3_7());
        map.put("MU_3_8", deltaAggRequestFormat.getMU_3_8());
        map.put("MU_3_9", deltaAggRequestFormat.getMU_3_9());
        map.put("MU_3_10", deltaAggRequestFormat.getMU_3_10());
        map.put("MU_3_11", deltaAggRequestFormat.getMU_3_11());
        map.put("MU_3_12", deltaAggRequestFormat.getMU_3_12());
        map.put("MU_3_13", deltaAggRequestFormat.getMU_3_13());
        map.put("MU_3_14", deltaAggRequestFormat.getMU_3_14());
        map.put("MU_3_15", deltaAggRequestFormat.getMU_3_15());
        map.put("MU_3_16", deltaAggRequestFormat.getMU_3_16());
        map.put("MU_3_17", deltaAggRequestFormat.getMU_3_17());
        map.put("MU_3_18", deltaAggRequestFormat.getMU_3_18());
        map.put("MU_3_19", deltaAggRequestFormat.getMU_3_19());
        map.put("MU_3_20", deltaAggRequestFormat.getMU_3_20());
        map.put("MC_T1_30", deltaAggRequestFormat.getMC_T1_30());
        map.put("MC_T2_30", deltaAggRequestFormat.getMC_T2_30());
        map.put("MC_T3_30", deltaAggRequestFormat.getMC_T3_30());
        map.put("MU_T1_30", deltaAggRequestFormat.getMU_T1_30());
        map.put("MU_T2_30", deltaAggRequestFormat.getMU_T2_30());
        map.put("MU_T3_30", deltaAggRequestFormat.getMU_T3_30());
        map.put("M_S_60", deltaAggRequestFormat.getM_S_60());

        map.put("P2_3_1", deltaAggRequestFormat.getP2_3_1());
        map.put("P2_30_6", deltaAggRequestFormat.getP2_30_6());
        map.put("P2_3_6", deltaAggRequestFormat.getP2_3_6());
        map.put("P2_30_2", deltaAggRequestFormat.getP2_30_2());
        map.put("P2_3_2", deltaAggRequestFormat.getP2_3_2());
        map.put("P2_30_7", deltaAggRequestFormat.getP2_30_7());
        map.put("P2_3_7", deltaAggRequestFormat.getP2_3_7());
        map.put("P2_30_4", deltaAggRequestFormat.getP2_30_4());
        map.put("P2_3_4", deltaAggRequestFormat.getP2_3_4());
        map.put("P2_3_8", deltaAggRequestFormat.getP2_3_8());
        map.put("P2_30_9", deltaAggRequestFormat.getP2_30_9());
        map.put("P2_3_9", deltaAggRequestFormat.getP2_3_9());
        map.put("P2_30_5", deltaAggRequestFormat.getP2_30_5());
        map.put("P2_3_5", deltaAggRequestFormat.getP2_3_5());
        map.put("P2_30_3", deltaAggRequestFormat.getP2_30_3());
        map.put("P2_3_3", deltaAggRequestFormat.getP2_3_3());
        map.put("P3_30", deltaAggRequestFormat.getP3_30());
        map.put("P4", deltaAggRequestFormat.getP4());
        map.put("P5", deltaAggRequestFormat.getP5());
        map.put("P6", deltaAggRequestFormat.getP6());
        map.put("P8", deltaAggRequestFormat.getP8());
        map.put("P12", deltaAggRequestFormat.getP12());
        map.put("P16", deltaAggRequestFormat.getP16());
        map.put("P17", deltaAggRequestFormat.getP17());
        map.put("P18", deltaAggRequestFormat.getP18());
        map.put("P19", deltaAggRequestFormat.getP19());
        map.put("P20", deltaAggRequestFormat.getP20());
        map.put("P21", deltaAggRequestFormat.getP21());
        map.put("P22", deltaAggRequestFormat.getP22());
        map.put("P23", deltaAggRequestFormat.getP23());
        map.put("P32", deltaAggRequestFormat.getP32());
        map.put("P33", deltaAggRequestFormat.getP33());
        map.put("P24", deltaAggRequestFormat.getP24());
        map.put("P25", deltaAggRequestFormat.getP25());
        map.put("P27", deltaAggRequestFormat.getP27());
        map.put("P28", deltaAggRequestFormat.getP28());
        map.put("P29", deltaAggRequestFormat.getP29());
        map.put("P31", deltaAggRequestFormat.getP31());
        map.put("P34", deltaAggRequestFormat.getP34());
        map.put("P35", deltaAggRequestFormat.getP35());
        map.put("P36", deltaAggRequestFormat.getP36());
        map.put("P37", deltaAggRequestFormat.getP37());
        map.put("P38", deltaAggRequestFormat.getP38());
        map.put("P39", deltaAggRequestFormat.getP39());
        map.put("P40", deltaAggRequestFormat.getP40());
        map.put("P41", deltaAggRequestFormat.getP41());
        map.put("P42", deltaAggRequestFormat.getP42());

        map.put("R1_3", deltaAggRequestFormat.getR1_3());
        map.put("R1_30", deltaAggRequestFormat.getR1_30());
        map.put("R2_30", deltaAggRequestFormat.getR2_30());
        map.put("R3_3", deltaAggRequestFormat.getR3_3());
        map.put("R3_30", deltaAggRequestFormat.getR3_30());
        map.put("R4_3", deltaAggRequestFormat.getR4_3());
        map.put("R4_30", deltaAggRequestFormat.getR4_30());

        map.put("S1_30", deltaAggRequestFormat.getS1_30());
        map.put("S2_30", deltaAggRequestFormat.getS2_30());
        map.put("S2_3", deltaAggRequestFormat.getS2_3());
        map.put("S3_30", deltaAggRequestFormat.getS3_30());
        map.put("S3_3", deltaAggRequestFormat.getS3_3());
        map.put("S4_3", deltaAggRequestFormat.getS4_3());
        map.put("S5_30", deltaAggRequestFormat.getS5_30());
        map.put("S5_3", deltaAggRequestFormat.getS5_3());
        map.put("S6_3", deltaAggRequestFormat.getS6_3());
        map.put("S7_30", deltaAggRequestFormat.getS7_30());
        map.put("S7_3", deltaAggRequestFormat.getS7_3());
        map.put("S8_30", deltaAggRequestFormat.getS8_30());
        map.put("S8_3", deltaAggRequestFormat.getS8_3());
        map.put("S9_30", deltaAggRequestFormat.getS9_30());
        map.put("S9_3", deltaAggRequestFormat.getS9_3());
        map.put("S10_30", deltaAggRequestFormat.getS10_30());
        map.put("S10_3", deltaAggRequestFormat.getS10_3());
        map.put("S11_30", deltaAggRequestFormat.getS11_30());
        map.put("S11_3", deltaAggRequestFormat.getS11_3());
        map.put("S12_30", deltaAggRequestFormat.getS12_30());
        map.put("S12_3", deltaAggRequestFormat.getS12_3());
        map.put("S13_30", deltaAggRequestFormat.getS13_30());
        map.put("S13_3", deltaAggRequestFormat.getS13_3());
        map.put("S14_3", deltaAggRequestFormat.getS14_3());
        map.put("S14_30", deltaAggRequestFormat.getS14_30());
        map.put("S15_3", deltaAggRequestFormat.getS15_3());
        map.put("S15_30", deltaAggRequestFormat.getS15_30());
        map.put("S16_30", deltaAggRequestFormat.getS16_30());
        map.put("S16_3", deltaAggRequestFormat.getS16_3());
        map.put("S17_3", deltaAggRequestFormat.getS17_3());
        map.put("S17_30", deltaAggRequestFormat.getS17_30());
        map.put("S18_3", deltaAggRequestFormat.getS18_3());
        map.put("S18_30", deltaAggRequestFormat.getS18_30());
        map.put("S19_3", deltaAggRequestFormat.getS19_3());
        map.put("S19_30", deltaAggRequestFormat.getS19_30());
        map.put("S20_30", deltaAggRequestFormat.getS20_30());
        map.put("S21_30", deltaAggRequestFormat.getS21_30());
        map.put("S22_30", deltaAggRequestFormat.getS22_30());
        map.put("S23_30", deltaAggRequestFormat.getS23_30());
        map.put("S23_3", deltaAggRequestFormat.getS23_3());
        map.put("S24", deltaAggRequestFormat.getS24());
        map.put("S28_30", deltaAggRequestFormat.getS28_30());
        map.put("S29_30", deltaAggRequestFormat.getS29_30());
        map.put("S30_30", deltaAggRequestFormat.getS30_30());
        map.put("S31_30", deltaAggRequestFormat.getS31_30());
        map.put("S32_30", deltaAggRequestFormat.getS32_30());
        map.put("S33_30", deltaAggRequestFormat.getS33_30());
        map.put("S34_30", deltaAggRequestFormat.getS34_30());
        map.put("S35_30", deltaAggRequestFormat.getS35_30());
        map.put("S36_30", deltaAggRequestFormat.getS36_30());
        map.put("S37_30", deltaAggRequestFormat.getS37_30());
        map.put("S38_30", deltaAggRequestFormat.getS38_30());
        map.put("S39_30", deltaAggRequestFormat.getS39_30());
        map.put("S40_30", deltaAggRequestFormat.getS40_30());
        map.put("S41_30", deltaAggRequestFormat.getS41_30());
        map.put("S42_30", deltaAggRequestFormat.getS42_30());
        map.put("S43_30", deltaAggRequestFormat.getS43_30());
        map.put("S44_30", deltaAggRequestFormat.getS44_30());
        map.put("S45_30", deltaAggRequestFormat.getS45_30());
        map.put("S46_30", deltaAggRequestFormat.getS46_30());
        map.put("S47_30", deltaAggRequestFormat.getS47_30());
        map.put("S48_30", deltaAggRequestFormat.getS48_30());
        map.put("S49_30", deltaAggRequestFormat.getS49_30());
        map.put("S50_30", deltaAggRequestFormat.getS50_30());
        map.put("S51_30", deltaAggRequestFormat.getS51_30());
        map.put("S52_30", deltaAggRequestFormat.getS52_30());
        map.put("S53_30", deltaAggRequestFormat.getS53_30());
        map.put("S54_30", deltaAggRequestFormat.getS54_30());
        map.put("S55_30", deltaAggRequestFormat.getS55_30());
        map.put("S56_30", deltaAggRequestFormat.getS56_30());
        map.put("SC1_30", deltaAggRequestFormat.getSC1_30());
        map.put("SC2_30", deltaAggRequestFormat.getSC2_30());
        map.put("SC3_30", deltaAggRequestFormat.getSC3_30());
        map.put("SC4_30", deltaAggRequestFormat.getSC4_30());
        map.put("SC5_30", deltaAggRequestFormat.getSC5_30());
        map.put("SC6_30", deltaAggRequestFormat.getSC6_30());
        map.put("SC7_30", deltaAggRequestFormat.getSC7_30());
        map.put("SC8_30", deltaAggRequestFormat.getSC8_30());
        map.put("SC9_30", deltaAggRequestFormat.getSC9_30());
        map.put("SP4_30", deltaAggRequestFormat.getSP4_30());
        map.put("SP5_30", deltaAggRequestFormat.getSP5_30());
        map.put("SP6_3", deltaAggRequestFormat.getSP6_3());
        map.put("SP7_30", deltaAggRequestFormat.getSP7_30());
        map.put("SP8_30", deltaAggRequestFormat.getSP8_30());
        map.put("SP9_30", deltaAggRequestFormat.getSP9_30());
        map.put("SP10_3", deltaAggRequestFormat.getSP10_3());
        map.put("SP11_30", deltaAggRequestFormat.getSP11_30());
        map.put("SP20_3", deltaAggRequestFormat.getSP20_3());
        map.put("SP21_3", deltaAggRequestFormat.getSP21_3());
        map.put("SP22_3", deltaAggRequestFormat.getSP22_3());
        map.put("SU1_30", deltaAggRequestFormat.getSU1_30());
        map.put("SU2_30", deltaAggRequestFormat.getSU2_30());
        map.put("SU3_30", deltaAggRequestFormat.getSU3_30());
        map.put("SU4_30", deltaAggRequestFormat.getSU4_30());
        map.put("SU5_30", deltaAggRequestFormat.getSU5_30());
        map.put("SU6_30", deltaAggRequestFormat.getSU6_30());
        map.put("SU7_30", deltaAggRequestFormat.getSU7_30());
        map.put("SU8_30", deltaAggRequestFormat.getSU8_30());
        map.put("SU9_30", deltaAggRequestFormat.getSU9_30());
        map.put("SU10_30", deltaAggRequestFormat.getSU10_30());

        map.put("T1_30", deltaAggRequestFormat.getT1_30());
        map.put("T1_3", deltaAggRequestFormat.getT1_3());
        map.put("T2_30", deltaAggRequestFormat.getT2_30());
        map.put("T2_3", deltaAggRequestFormat.getT2_3());
        map.put("T3_3", deltaAggRequestFormat.getT3_3());
        map.put("T3_30", deltaAggRequestFormat.getT3_30());
        map.put("T5_30", deltaAggRequestFormat.getT5_30());
        map.put("T6_3", deltaAggRequestFormat.getT6_3());
        map.put("T6_30", deltaAggRequestFormat.getT6_30());
        map.put("T7_30", deltaAggRequestFormat.getT7_30());
        map.put("T8_30", deltaAggRequestFormat.getT8_30());
        map.put("T9_30", deltaAggRequestFormat.getT9_30());
        map.put("T14", deltaAggRequestFormat.getT14());
        map.put("TC_30", deltaAggRequestFormat.getTC_30());
        map.put("TC1_30", deltaAggRequestFormat.getTC1_30());
        map.put("TC_1", deltaAggRequestFormat.getTC_1());

        map.put("TS1_30", deltaAggRequestFormat.getTS1_30());
        map.put("TS1_3", deltaAggRequestFormat.getTS1_3());

        map.put("WD_1", deltaAggRequestFormat.getWD_1());
        map.put("WD_1_60", deltaAggRequestFormat.getWD_1_60());

        map.put("TS1", "");

        return map;
    }

    /**
     * This the method used for storing the merchant aggregates value into a map
     *
     * @param deltaAggRequestFormat delta aggregation request format detail
     */
    public Map<String, Object> populate_merchant_aggregate_data(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Object> map = new HashMap<>();
        map.put("EM_30", deltaAggRequestFormat.getEM_30());
        map.put("EM_7", deltaAggRequestFormat.getEM_7());
        map.put("FC_30", deltaAggRequestFormat.getFC_30());
        map.put("FC_7", deltaAggRequestFormat.getFC_7());
        map.put("FC_B7", deltaAggRequestFormat.getFC_B7());
        map.put("FC_3", deltaAggRequestFormat.getFC_3());


        map.put("HM_30", deltaAggRequestFormat.getHM_30());
        map.put("HM_7", deltaAggRequestFormat.getHM_7());
        map.put("HM1_30", deltaAggRequestFormat.getHM1_30());
        map.put("HM2_30", deltaAggRequestFormat.getHM2_30());
        map.put("HM3_30", deltaAggRequestFormat.getHM3_30());
        map.put("HM4_30", deltaAggRequestFormat.getHM4_30());
        map.put("M1_1", deltaAggRequestFormat.getM1_1());
        map.put("M1_7", deltaAggRequestFormat.getM1_7());
        map.put("MR1_30", deltaAggRequestFormat.getMR1_30());
        map.put("MR2_30", deltaAggRequestFormat.getMR2_30());
        map.put("MR3_30", deltaAggRequestFormat.getMR3_30());
        map.put("PM", deltaAggRequestFormat.getPM());

        map.put("TM1_30", deltaAggRequestFormat.getTM1_30());
        map.put("TM2_30", deltaAggRequestFormat.getTM2_30());

        map.put("TS1", "");

        return map;
    }
}
