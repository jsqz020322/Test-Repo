package com.quadratyx.delta_aggregation.util;

/**
 * This is the class for Constant value that we are passing as status code
 */
public class BusinessConstant {

	/**
	 * Default Constructor
	 */
	private BusinessConstant() {
	}

	public static final Integer OK = 20;
	public static final Integer BAD_REQUEST = 40;
	public static final Integer FORBIDDEN = 43;
	public static final Integer NOT_FOUND = 44;
	public static final Integer METHOD_NOT_ALLOWED = 45;
	public static final Integer UNSUPPORTED_MEDIATYPE = 46;
	public static final Integer INTERNAL_SERVER_ERROR = 50;
	public static final Integer SERVICE_UNAVAILABLE = 53;

	public static final String CONTACT_LESS_CARD = "contactlesscard";

	public static final String BAL_CHECK = "bal_check";
	public static final String ENTRY_MODE_TYPE = "entry_mode_type";
	public static final String PIN_ENTERED_DOM_FLAG = "pin_entered_dom_flag";
	public static final String RULE_STATUS = "rule_status";
	public static final String SD_RES_CODE_TYPE = "sd_res_code_type";
	public static final String SD_RES_CODE = "sd_res_code";
	public static final String FALLBACK_STATUS = "fall_back_status";
	public static final String TOKEN_SRVC_TYPE = "token_srvc_type";
	public static final String SD_RESP_CODE_TYPE_NEW = "sd_resp_code_type_new";
	public static final String TRANCOUNT = "tranCount";
	public static final String TRANCOUNT7DAYS= "tranCount7days";
	public static final String TRAN_CDE_TYPE = "tran_cde_type";
	public static final String TRAN_CDE_TYPE_BIN = "tran_cde_type_bin";

	//Merchant Key
	public static final String FRAUD_COUNT_PREV30_DAYS_MERCHANT = "fraud_count_prev30days_merchant";
	public static final String FRAUD_COUNT_PREV7_DAYS_MERCHANT  = "fraud_count_prev7days_merchant";
	public static final String FRAUD_COUNT_PREV3_DAYS_MERCHANT = "fraud_count_prev3days_merchant";
	public static final String HOUR_TYPE_MERCHANT_PREV30DAYS_ = "hour_type_merchant_prev30days_";
	public static final String MD_TRAN_ATM1_M_MEAN_PREV30DAYS_merchant = "md_tran_amt1_M_mean_prev30days_merchant";
	public static final String MD_TRAN_ATM1_M_MIN_PREV30DAYS_merchant = "md_tran_amt1_M_min_prev30days_merchant";
	public static final String MD_TRAN_ATM1_M_MAX_PREV30DAYS_merchant = "md_tran_amt1_M_max_prev30days_merchant";
	public static final String TRAN_TYPE_MERCHANT_PREV30DAYS_ = "tran_type_merchant_prev30days_";
	public static final String HOUR_TYPE_POS_MERCHANT_PREV30DAYS_ = "hour_type_POS_merchant_prev30days_";
	public static final String HOUR_TYPE_POS_MERCHANT_PREV7DAYS_ = "hour_type_POS_merchant_prev7days_";

	public static final String COUNT_MCC_PREV30DAYS = "count_mcc_prev30days";
	public static final String MCC_LIST_RTLSICCODE = "mcc_list_RtlSicCode";
	public static final String MCC_LIST_SDTERMID = "mcc_list_SDTermID";

	public static final String AMOUNT_BINS_M_ATM_PREV3DAYS_ = "amount_bins_M_ATM_prev3days_";
	public static final String HOUR_TYPE_ATM_PREV3DAYS_ = "hour_type_ATM_prev3days_";
	public static final String TRAN_CDE_TYPE_ATM_ = "tran_cde_type_ATM_";
	public static final String SD_RESP_CDE_TYPE_ATM_ ="sd_resp_cde_type_ATM_";
	public static final String AMOUNT_BINS_M_PREV3DAYS_ = "amount_bins_M_prev3days_";
	public static final String TRAN_CDE_TYPE_ = "tran_cde_type_";
	public static final String SD_RESP_CDE_TYPE_ = "sd_resp_cde_type_";
	public static final String REAL_TIME_RULE_STATUS_ = 	"real_time_rule_status_";
	public static final String current_tran_state_prev3days = "current_tran_state_prev3days";
	public static final String stateListSecured = "current_state_list_secured";
	public static final String stateListUnsecured = "current_state_list_unsecured";
	public static final String  current_tran_city_prev3days = "current_tran_city_prev3days";
	public static final String current_city_list_secured = "current_city_list_secured";
	public static final String current_city_list_unsecured = "current_city_list_unsecured";
	public static final String  current_tran_cntry_prev3days = "current_tran_cntry_prev3days";
	public static final String current_cntry_list_secured = "current_cntry_list_secured";
	public static final String current_cntry_list_unsecured = "current_cntry_list_unsecured";


	public static final String amount_bins_M_POS_prev3days_ = "amount_bins_M_POS_prev3days_";
	public static final String sd_resp_cde_type_POS_ = "sd_resp_cde_type_POS_";
	public static final String MCC_POS_ = "mcc_POS_";
	public static final String mcc_pos_retail_codes_3 = "mcc_pos_retail_codes_3";
	public static final String token_srvc_POS_ = "token_srvc_POS_";
	public static final String FRAUD = "fraud";
	public static final String MEANKEY_POS = "md_tran_amt1_M_POS_contactlesscard_mean_prev3days";
	public static final String MAXKEY = "md_tran_amt1_M_POS_contactlesscard_max_prev3days";
	public static final String MCC_CNPUNSECURED_ = "mcc_CNPUNSECURED_";
	public static final String MCC_CNP_UNSECURED_RETAIL_CODES= "mcc_cnp_unsecured_retail_codes";

	public static final String ED3DAYS = "_count_prev3days";
	public static final String TIEBREAKER = "Tiebreaker: ";
	public static final String ED30DAYS = "_count_prev30days";
	public static final String interNational = "International";

}
