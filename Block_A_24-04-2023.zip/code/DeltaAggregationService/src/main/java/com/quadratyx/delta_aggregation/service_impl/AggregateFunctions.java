package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * This is the service module for creating of aggregates functions
 */
@Service
public class AggregateFunctions {

    @Autowired
    @Qualifier("config1")
    private Map<String, String> shortkeyAggMap;

    @Autowired
    @Qualifier("config")
    private Map<String, List<String>> jsonMap;

    /**
     * This is the method used for adding amount bin count based on the derived amount_bin_index attribute
     *
     * @param bin        Integer request format detail
     * @param amtBinsIdx amount_bin_index detail
     * @param key        redis aggregates key
     * @param currAggMap current aggregates map detail
     */
    public void getAmountBinAggregates(Integer bin, Map<String, Double> amtBinsIdx, String key,
                                       Map<String, Object> currAggMap) {
        if (bin != -1) {
            String actualAggKey = key + bin;
            Double binCount = amtBinsIdx.get(actualAggKey);
            if (jsonMap.get(actualAggKey) != null) {
                String shortKey = shortkeyAggMap.get(jsonMap.get(actualAggKey).get(0));
                currAggMap.computeIfPresent(shortKey, (k, v) -> binCount + 1);
            }
        }
    }

    /**
     * This is the method used for adding hour type count based on hour_type_index for transactions
     *
     * @param bin             Integer request format detail
     * @param hourTypeBinsIdx hour type bins index deatil
     * @param key             redis aggregates key
     * @param currAggMap      current aggregates map detail
     */
    public void getHourTypeIndex(Integer bin, Map<String, Double> hourTypeBinsIdx, String key, Map<String, Object> currAggMap) {
        if (bin != -1) {
            String actualAggKey = key + bin;
            Double binCount = hourTypeBinsIdx.get(actualAggKey);
            if (jsonMap.get(actualAggKey) != null) {
                String shortKey = shortkeyAggMap.get(jsonMap.get(actualAggKey).get(0));
                currAggMap.computeIfPresent(shortKey, (k, v) -> binCount + 1);
            }
        }
    }

    /**
     * This is the method used for transaction code categorization for transactions
     *
     * @param preprocessedData PreProcessed derived fields map detail
     * @param reqMap           a Map of String, Double with bins details
     * @param currAggMap       current aggregates map detail
     * @param st               a string value
     * @param ed               suffix value
     */
    public void getTranCodeBins(Map<String, Object> preprocessedData, Map<String, Double> reqMap,
                                Map<String, Object> currAggMap,
                                String st, String ed) {
        String reqKey = "";
        String tran_cde_type = String.valueOf(preprocessedData.get(BusinessConstant.TRAN_CDE_TYPE));
        List<String> requiredValues = Arrays.asList("BalInquiry", "PinChange", "PinInquiry", "MailOrder", "Purchase");
        if (!tran_cde_type.equals("NA") && (requiredValues.contains(tran_cde_type))) {
            reqKey = st + tran_cde_type + ed;
            String shortKey = shortkeyAggMap.get(reqKey);
            if (reqMap.get(reqKey) != null) {
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }

    /**
     * This is the method used for updating SD response code type for transactions
     *
     * @param preprocessedData PreProcessed derived fields map detail
     * @param reqMap           a Map of String, Double with bins details
     * @param currAggMap       current aggregates map detail
     * @param st               a string value
     * @param ed               suffix value
     */
    public void getSDResponseCodeType(Map<String, Object> preprocessedData, Map<String, Double> reqMap,
                                      Map<String, Object> currAggMap,
                                      String st, String ed) {
        String reqKey = "";
        String sd_resp_cde_type = String.valueOf(preprocessedData.get(BusinessConstant.SD_RES_CODE_TYPE));
        if (!sd_resp_cde_type.equals("NA")) {
            reqKey = st + sd_resp_cde_type + ed;
            String shortKey = shortkeyAggMap.get(reqKey);
            if (reqMap.get(reqKey) != null) {
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }

    public void getSDResponseCodeTypeNew(Map<String, Object> preprocessedData, Map<String, Double> reqMap,
                                         Map<String, Object> currAggMap,
                                         String st, String ed) {
        String reqKey = "";
        String sd_resp_cde_type = String.valueOf(preprocessedData.get(BusinessConstant.SD_RESP_CODE_TYPE_NEW));
        if (!sd_resp_cde_type.equals("NA")) {
            reqKey = st + sd_resp_cde_type + ed;
            String shortKey = shortkeyAggMap.get(reqKey);
            if (reqMap.get(reqKey) != null) {
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }

    /**
     * This is the method used for updating real time status count for transactions
     *
     * @param preprocessedData PreProcessed derived fields map detail
     * @param reqMap           a Map of String, Double with bins details
     * @param currAggMap       current aggregates map detail
     * @param st               a string value
     * @param ed               suffix value
     */
    public void getRealtimeStatusUpdation(Map<String, Object> preprocessedData, Map<String, Double> reqMap,
                                          Map<String, Object> currAggMap,
                                          String st, String ed) {
        String rule_status = String.valueOf(preprocessedData.get(BusinessConstant.RULE_STATUS));
        if (!rule_status.equals("NA")) {
            if (rule_status.equals("Allow Over Time")) {
                rule_status = "Allowoverlimit";
            } else if (rule_status.equals("Authorized")) {
                rule_status = "Authorized";
            } else if (rule_status.equals("Declined")) {
                rule_status = "Declined";
            }
            String reqKey = st + rule_status + ed;
            String shortKey = shortkeyAggMap.get(reqKey);
            if (reqMap.get(reqKey) != null) {
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }


    /**
     * This is the method used for adding mcc bin count based on the RtlrSICCode attribute
     *
     * @param mcc_pos    String detail
     * @param mccBinsIdx mcc_bin_index detail
     * @param aggKey     config.json aggregates key
     * @param currAggMap current aggregates map detail
     */
    public void getMCCBinAggregates(String mcc_pos, Map<String,
            Double> mccBinsIdx, String aggKey, String prefixStr, String ed, Map<String, Object> currAggMap) {

        String reqKey = "";
        List<String> requiredValues = jsonMap.get(aggKey);
        if (!("NA").equals(mcc_pos) && (requiredValues.contains(mcc_pos))) {
            reqKey = prefixStr + mcc_pos + ed;
            String shortKey = shortkeyAggMap.get(reqKey);
            if (mccBinsIdx.get(reqKey) != null) {
                Double binCount = mccBinsIdx.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> binCount + 1);
            }
        }
    }


    /**
     * This is the method used for adding mcc bin count based on the mcc_bins_idx attribute
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param mccCountBinsIdx       mcc_bins_idx detail
     * @param currAggMap            current aggregates map detail
     */
    public void getMccCountBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                         Map<String, Double> mccCountBinsIdx, Map<String, Object> currAggMap) {

        String reqKey = deltaAggRequestFormat.getM_L_30();
        String[] requiredValues = reqKey.split("_");
        List<String> reqlist = new ArrayList<String>(Arrays.asList(requiredValues));
        String mcc_val = deltaAggRequestFormat.getRtlrSICCode();
        if (!"NA".equals(mcc_val) && (reqlist.contains(mcc_val))) {
            //String Key = "count_mcc_prev30days";
            String shortKey = shortkeyAggMap.get(BusinessConstant.COUNT_MCC_PREV30DAYS);
            if (mccCountBinsIdx.get(BusinessConstant.COUNT_MCC_PREV30DAYS) != null) {
                Double binCount = mccCountBinsIdx.get(BusinessConstant.COUNT_MCC_PREV30DAYS);
                currAggMap.computeIfPresent(shortKey, (k, v) -> binCount + 1);
            }
        } else {
            String shortKey = shortkeyAggMap.get(BusinessConstant.MCC_LIST_RTLSICCODE);
            reqKey = reqKey + "_" + mcc_val;
            currAggMap.replace(shortKey, reqKey);
        }
    }

    /**
     * This is the method used for adding mean bin count based on the TranAmt1 attribute and previous aggregate value
     *
     * @param current_tran_amt Double request format detail
     * @param meanBinsIdx      mean_bin_index detail
     * @param aggKey           aggregates key
     * @param currAggMap       current aggregates map detail
     */
    public void getMeanBinAggregates(Double current_tran_amt, Map<String, Double> meanBinsIdx,
                                     String aggKey, Map<String, Object> currAggMap) {

        String shortKey = shortkeyAggMap.get(aggKey);
        Double binCount = meanBinsIdx.get(aggKey);
        if (binCount == 0) {
            binCount = current_tran_amt;
        } else {
            binCount = ((binCount * 30) + current_tran_amt) / 30;
        }

        Double finalBinCount = binCount;
        currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
    }

    /**
     * This is the method used for adding mean mcc bin count based on the getRtlrSICCode attribute and previous aggregate value
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param meanBinsIdx           mean_bin_index detail
     * @param aggKey                aggregates key
     * @param currAggMap            current aggregates map detail
     */
    public void getMeanMccBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> meanBinsIdx,
                                        String aggKey, Map<String, Object> currAggMap) {
        //mean_tran_amt_mcc_prev30days
        if (deltaAggRequestFormat.getRtlrSICCode() != null) {
            Double current_mcc = deltaAggRequestFormat.getTranAmt1();
            String shortKey = shortkeyAggMap.get(aggKey);
            Double binCount = meanBinsIdx.get(aggKey);
            if (binCount == 0) {
                binCount = current_mcc;
            } else {
                binCount = ((binCount * 30) + current_mcc) / 30;
            }
            Double finalBinCount = binCount;
            currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
        }
    }

    /**
     * This is the method used for adding min bin count based on the TranAmt1 attribute and previous aggregate value
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param minBinsIdx            min_bin_index detail
     * @param aggKey                aggregates key
     * @param currAggMap            current aggregates map detail
     */
    public void getMinBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> minBinsIdx,
                                    String aggKey, Map<String, Object> currAggMap) {

        Double current_tran_amt = deltaAggRequestFormat.getTranAmt1();
        String shortKey = shortkeyAggMap.get(aggKey);
        Double binCount = minBinsIdx.get(aggKey);
        if (binCount == 0) {
            binCount = current_tran_amt;
        } else {
            binCount = Math.min(binCount, current_tran_amt);
        }
        Double finalBinCount = binCount;
        currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
    }

    /**
     * This is the method used for adding max bin count based on the TranAmt1 attribute and previous aggregate value
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param maxBinsIdx            max_bin_index detail
     * @param aggKey                aggregates key
     * @param currAggMap            current aggregates map detail
     */
    public void getMaxBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> maxBinsIdx,
                                    String aggKey, Map<String, Object> currAggMap) {

        Double current_tran_amt = deltaAggRequestFormat.getTranAmt1();
        String shortKey = shortkeyAggMap.get(aggKey);
        Double binCount = maxBinsIdx.get(aggKey);
        if (binCount == 0) {
            binCount = current_tran_amt;
        } else {
            binCount = Math.max(binCount, current_tran_amt);
        }
        Double finalBinCount = binCount;
        currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
    }

    /**
     * This is the method used for adding max mcc bin count based on the TranAmt1 attribute and previous aggregate value
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param maxBinsIdx            max_bin_index detail
     * @param aggKey                aggregates key
     * @param currAggMap            current aggregates map detail
     */
    public void getMaxMccBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> maxBinsIdx,
                                       String aggKey, Map<String, Object> currAggMap) {

        if (deltaAggRequestFormat.getRtlrSICCode() != null) {
            Double current_amt = deltaAggRequestFormat.getTranAmt1();
            String shortKey = shortkeyAggMap.get(aggKey);
            Double binCount = maxBinsIdx.get(aggKey);
            if (binCount == 0) {
                binCount = current_amt;
            } else {
                binCount = Math.max(binCount, current_amt);
            }
            Double finalBinCount = binCount;
            currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
        }
    }


    /**
     * This is the method used for token service type categorization count
     *
     * @param preprocessedData PreProcessed derived fields map detail
     * @param reqMap           a Map of String, Double with bins details
     * @param currAggMap       current aggregates map detail
     * @param st               a string value
     * @param ed               suffix value
     */
    public void getTokenSrvcBins(Map<String, Object> preprocessedData, Map<String, Double> reqMap,
                                 Map<String, Object> currAggMap, String st, String ed) {
        String reqKey = "";
        String token_srvc_type = String.valueOf(preprocessedData.get(BusinessConstant.TOKEN_SRVC_TYPE));
        List<String> requiredValues = Arrays.asList("SamsungPay");
        if (!token_srvc_type.equals("NA") && (requiredValues.contains(token_srvc_type))) {
            reqKey = st + token_srvc_type + ed;
            if (jsonMap.get(reqKey) != null) {
                String shortKey = shortkeyAggMap.get(jsonMap.get(reqKey).get(0));
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }

    /**
     * This is the method used for adding fraud bin count based on the FS attribute
     *
     * @param fs         Integer request format detail
     * @param reqMap     fs_bin_index detail
     * @param st         start of the required key
     * @param ed         end of the required key
     * @param currAggMap current aggregates map detail
     */
    public void getFSBinAggregates(Integer fs, Map<String, Double> reqMap, String st,
                                   String ed, Map<String, Object> currAggMap) {
        String reqKey = "";
        if (jsonMap.get("POS_threshold") != null) {
            Integer thr = Integer.parseInt(jsonMap.get("POS_threshold").get(0));
            if (fs != null && fs >= thr) {
                reqKey = st + ed;
                String shortKey = shortkeyAggMap.get(reqKey);
                Double reqVal = reqMap.get(reqKey);
                currAggMap.computeIfPresent(shortKey, (k, v) -> reqVal + 1);
            }
        }
    }

    /**
     * This is the method used add binary value based on the FS attribute
     *
     * @param fs         Delta aggregation request format detail
     * @param currAggMap current aggregates map detail
     */
    public void getFraudFlag(Integer fs, Map<String, Object> currAggMap) {
        if (jsonMap.get("POS_threshold") != null) {
            Integer thr = Integer.parseInt(jsonMap.get("POS_threshold").get(0));

            if (fs != null && fs >= thr) {
                currAggMap.put("FC_B7", 1);
            } else {
                currAggMap.put("FC_B7", 0);
            }
        }
    }

    /**
     * This is the method used for get average of MD_TRAN_AMT per day based on the avgBinsIdx attribute
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param avgBinsIdx            average_Bins_value detail
     * @param currAggMap            current aggregates map detail
     */

    public void getAvgBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> avgBinsIdx,
                                    String aggKey, Map<String, Object> currAggMap) {

        Double current_tran_amt = deltaAggRequestFormat.getTranAmt1();
        String shortKey = shortkeyAggMap.get(aggKey);
        Double binCount = avgBinsIdx.get(aggKey);
        if (binCount == 0) {
            binCount = current_tran_amt;
        } else {
            binCount = ((binCount * 60) + current_tran_amt) / 60;
        }
        Double finalBinCount = binCount;
        currAggMap.computeIfPresent(shortKey, (k, v) -> finalBinCount);
    }

    /**
     * This is the method used for get frequent merchant value added to the list when it is the first time based on the TermID attribute
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param currAggMap            current aggregates map detail
     */
    public void getMerchantSDAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> currAggMap) {

        String reqKey = deltaAggRequestFormat.getM_S_60();
        String[] requiredValues = reqKey.split("_");
        List<String> reqlist = new ArrayList<String>(Arrays.asList(requiredValues));
        String ms_val = deltaAggRequestFormat.getTermid();
        if (reqKey != null && !(reqlist.contains(ms_val))) {
            String shortKey = shortkeyAggMap.get(BusinessConstant.MCC_LIST_SDTERMID);
            reqKey = reqKey + "_" + ms_val;
            currAggMap.replace(shortKey, reqKey);
        }
    }

    /**
     * This is the method used for adding tran type count based on tran_type_index for transactions
     *
     * @param deltaAggRequestFormat Delta aggregation request format detail
     * @param tranTypeBinsIdx       tran type bins index deatil
     * @param key                   redis aggregates key
     * @param currAggMap            current aggregates map detail
     */
    public void getTranTypeIndex(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Double> tranTypeBinsIdx,
                                 String key, Map<String, Object> currAggMap) {

        Integer bin = deltaAggRequestFormat.getDA7();
        if (bin != -1) {
            String actualAggKey = key + bin;
            Double binCount = tranTypeBinsIdx.get(actualAggKey);
            if (jsonMap.get(actualAggKey) != null) {
                String shortKey = shortkeyAggMap.get(jsonMap.get(actualAggKey).get(0));
                currAggMap.computeIfPresent(shortKey, (k, v) -> binCount + 1);
            }
        }
    }

    public void getCurrentStateCountBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                  Map<String, Object> currAggMap,
                                                  String stateList, Integer aggVal, String key) {

        String shortKey = shortkeyAggMap.get(key);
        if (!("NA").equals(deltaAggRequestFormat.getTermSt()) && (aggVal == 0)) {
            stateList = stateList + "_" + deltaAggRequestFormat.getTermSt();
        }
        currAggMap.put(shortKey, stateList);
    }

    public void getCurrentCityCountBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                 Map<String, Object> currAggMap,
                                                 String cityList, Integer aggVal, String key) {

        String shortKey = shortkeyAggMap.get(key);
        if (!("NA").equals(deltaAggRequestFormat.getTermCity()) && (aggVal == 0)) {
            cityList = cityList + "_" + deltaAggRequestFormat.getTermCity();
        }
        currAggMap.put(shortKey, cityList);

    }

    public void getCurrentCntryCountBinAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                  Map<String, Object> currAggMap,
                                                  String countryList, Integer aggVal, String key) {

        String shortKey = shortkeyAggMap.get(key);
        if (!("NA").equals(deltaAggRequestFormat.getTermCntr()) && (aggVal == 0)) {
            countryList = countryList + "_" + deltaAggRequestFormat.getTermCntr();
        }
        currAggMap.put(shortKey, countryList);

    }
}