package com.quadratyx.delta_aggregation.service_impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * This is the main service module for Delta Aggregation
 */
@Service
public class DeltaAggregatesMain {
    private static final Logger logger = LoggerFactory.getLogger(DeltaAggregatesMain.class);

    @Autowired
    private RedisAggregatesUpdate aggregatesUpdate;
    @Autowired
    private PreprocessingFunctions preprocessingFunctions;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    @Value("${spring.kafka.bootstrap.outputTopic}")
    private String output_topic;

    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    DeltaAggregatesMain(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * This is the method used for updating aggregates into redis
     *
     * @param deltaAggRequestFormat Delta aggregates request format detail
     * @throws JsonProcessingException in case of any thread interruption
     */
    public Map<String, Object> update_aggregates(DeltaAggRequestFormat deltaAggRequestFormat) throws JsonProcessingException {
        Map<String, Object> JsonOut = new HashMap<>();

        String tie_breaker = deltaAggRequestFormat.getTiebreaker();
        String tiebreaker = "Tiebreaker";
        String status = "status";
        try {
            if (deltaAggRequestFormat.getI5() == null || deltaAggRequestFormat.getI5() == -1) {
                logger.error("Unable to update aggregates for unknown channel= " + deltaAggRequestFormat.getI5() + " &TID = " + tie_breaker);
                JsonOut.put(tiebreaker, tie_breaker);
                JsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
            } else {
                String tran_cde_type = preprocessingFunctions.tranCodeType(deltaAggRequestFormat.getTranCode());
                String entry_mode_type = preprocessingFunctions.entryModeType(deltaAggRequestFormat.getPontOfSrvceEntryMode());
                String pin_entered_dom_flag = preprocessingFunctions.pinEnteredDomFlag(deltaAggRequestFormat.getpINIndx(), deltaAggRequestFormat.getTermCntr(), deltaAggRequestFormat.getI5());
                String rule_status = preprocessingFunctions.realTimeRuleStatus(deltaAggRequestFormat.getRealTimeRuleDsps());
                String sd_res_code_type = preprocessingFunctions.sdRespCodeType(deltaAggRequestFormat.getRespCode(), deltaAggRequestFormat.getTranAuthSrc());
                int fall_back_status = preprocessingFunctions.fallBackStatus(deltaAggRequestFormat.getPontOfSrvceEntryMode(), deltaAggRequestFormat.geteMVUsrFlr());
                String token_srvc_type = preprocessingFunctions.tokenServiceType(deltaAggRequestFormat.getProdInd(), deltaAggRequestFormat.getRtlrSICCode(), deltaAggRequestFormat.getPontOfSrvceEntryMode(), deltaAggRequestFormat.getScndryAcctNmbr());
                int sd_res_code = preprocessingFunctions.sdRespCode(deltaAggRequestFormat.getRespCode(), deltaAggRequestFormat.getTranAuthSrc());
                String sdRespCodeTypeNew = preprocessingFunctions.sdRespCodeTypeNew(deltaAggRequestFormat.getI5(), deltaAggRequestFormat.getRespCode());
                int tranCount = 0;
                int tranCount7days = 0;

                if (deltaAggRequestFormat.getI5() == 3 || deltaAggRequestFormat.getI5() == 4) {
                    tranCount = preprocessingFunctions.tran_count(deltaAggRequestFormat.getTranDateTime(), Long.valueOf(deltaAggRequestFormat.getPM()));
                    tranCount7days = preprocessingFunctions.tranCount7days(deltaAggRequestFormat.getTranDateTime(), Long.valueOf(deltaAggRequestFormat.getPM()));
                }

                Map<String, Object> preprocessed_data = new HashMap<>();
                Double tran_cde_type_bin = preprocessingFunctions.tranCodeTypeBin(tran_cde_type);
                preprocessed_data.put(BusinessConstant.TRAN_CDE_TYPE, tran_cde_type);
                preprocessed_data.put(BusinessConstant.TRAN_CDE_TYPE_BIN, tran_cde_type_bin);
                preprocessed_data.put(BusinessConstant.ENTRY_MODE_TYPE, entry_mode_type);
                preprocessed_data.put(BusinessConstant.PIN_ENTERED_DOM_FLAG, pin_entered_dom_flag);
                preprocessed_data.put(BusinessConstant.RULE_STATUS, rule_status);
                preprocessed_data.put(BusinessConstant.SD_RES_CODE_TYPE, sd_res_code_type);
                preprocessed_data.put(BusinessConstant.SD_RES_CODE, sd_res_code);
                preprocessed_data.put(BusinessConstant.FALLBACK_STATUS, fall_back_status);
                preprocessed_data.put(BusinessConstant.TOKEN_SRVC_TYPE, token_srvc_type);
                preprocessed_data.put(BusinessConstant.SD_RESP_CODE_TYPE_NEW, sdRespCodeTypeNew);
                preprocessed_data.put(BusinessConstant.TRANCOUNT, tranCount);
                preprocessed_data.put(BusinessConstant.TRANCOUNT7DAYS, tranCount7days);

                JsonOut.put("Pr_Crd_Mer_Agg", deltaAggRequestFormat);
                Map<String, Object> aggregates_map = aggregatesUpdate.updateAggregatesData(deltaAggRequestFormat,
                        preprocessed_data);
                String merchant_key = deltaAggRequestFormat.getTermid();

                if (aggregates_map == null) {
                    JsonOut.put(tiebreaker, tie_breaker);
                    JsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
                } else if (deltaAggRequestFormat.getI5() == 2 || merchant_key == null || merchant_key.trim().isEmpty()) {
                    JsonOut.put(tiebreaker, tie_breaker);
                    JsonOut.put("Curr_Crd_Agg", aggregates_map);
                    JsonOut.put(status, BusinessConstant.OK);
                } else {
                    Map<String, Object> merchant_map = aggregatesUpdate.updateMerchantAggregatesData(deltaAggRequestFormat, preprocessed_data);
                    if (merchant_map != null && !merchant_map.isEmpty()) {
                        JsonOut.put(tiebreaker, tie_breaker);
                        JsonOut.put("Curr_Crd_Agg", aggregates_map);
                        JsonOut.put("Curr_Mer_Agg", merchant_map);
                        JsonOut.put(status, BusinessConstant.OK);
                    } else {
                        JsonOut.put(tiebreaker, tie_breaker);
                        JsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
                    }
                }

            }

        } catch (Exception e) {
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "update_aggregates Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            sendMessage(exception, exceptionTopic);
            JsonOut.put(tiebreaker, tie_breaker);
            JsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
        }
        String daMessage = new ObjectMapper().writeValueAsString(JsonOut);
        sendMessage(daMessage, output_topic);
        return JsonOut;
    }

    /**
     * This is the method used for producing data message into kafka topic as a asynchronous mode
     *
     * @param message   Delta Aggregation Service json response detail
     * @param topicName kafka topic name detail
     * @return a <code> null </code>
     */
    public void sendMessage(String message, String topicName) {
        kafkaTemplate.send(topicName, message);
    }
}