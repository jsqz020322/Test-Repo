package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

/**
 * This is the service module for 30Days Aggregates creation
 */
@Service
public class MerchantAggregates {
    private static final Logger logger = LoggerFactory.getLogger(Aggregates30Days.class);

    @Autowired
    private AggregateBins aggregateBins;

    @Autowired
    private AggregateFunctions aggregateFunctions;

    @Autowired
    private DeltaAggregatesMain deltaAggregatesMain;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    /**
     * This is the method used for updating POSMerchantAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param currAggMap            current aggregates map detail
     */
    public void updateMerchantAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> currAggMap,
                                         Map<String, Object> preprocessedData) {
        try {

//          fraud count based on previous fraud score for previous 30 days and 7days and 3days for merchant aggregates
            Map<String, Double> fs_idx = aggregateBins.get_fs_bins_att_merchant(deltaAggRequestFormat);
            String end = "";

            // secured & unsecured
            aggregateFunctions.getFSBinAggregates(deltaAggRequestFormat.getFS(), fs_idx, BusinessConstant.FRAUD_COUNT_PREV30_DAYS_MERCHANT, end,
                    currAggMap);

            if (deltaAggRequestFormat.getI5() == 3) {
                // secured
                // fraud binary flag based on previous fraud score for previous 7 days for merchant aggregates
                aggregateFunctions.getFraudFlag(deltaAggRequestFormat.getFS(),currAggMap);
                // Transaction count previous 1day update
                Double tranCount1days = deltaAggRequestFormat.getM1_1();
                Integer tranCount = (Integer) preprocessedData.get(BusinessConstant.TRANCOUNT);
                if (tranCount == 1) {
                    currAggMap.put("M1_1", tranCount1days + 1);
                } else {
                    currAggMap.put("PM", deltaAggRequestFormat.getTranDateTime());
                    currAggMap.put("M1_1", 1);
                }
            } else {
                // unsecured
                // fraud count based on previous fraud score for previous 3days for merchant aggregates
                aggregateFunctions.getFSBinAggregates(deltaAggRequestFormat.getFS(), fs_idx, BusinessConstant.FRAUD_COUNT_PREV3_DAYS_MERCHANT, end,
                        currAggMap);

                Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
                aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, BusinessConstant.HOUR_TYPE_MERCHANT_PREV30DAYS_,
                        currAggMap);

                Map<String, Double> tran_type_bins_idx = aggregateBins.get_tran_type_bins_att_30days(deltaAggRequestFormat);
                aggregateFunctions.getTranTypeIndex(deltaAggRequestFormat, tran_type_bins_idx, BusinessConstant.TRAN_TYPE_MERCHANT_PREV30DAYS_,
                        currAggMap);

            }

//          Calculating mean bin count for the transaction amount for 30 days for merchant aggregates
            Map<String, Double> mean_bins_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_idx, BusinessConstant.MD_TRAN_ATM1_M_MEAN_PREV30DAYS_merchant,
                    currAggMap);

//          Calculating min bin count for the transaction amount for 30 days for merchant aggregates
            Map<String, Double> min_bins_idx = aggregateBins.get_min_bins_att_30days(deltaAggRequestFormat);
            aggregateFunctions.getMinBinAggregates(deltaAggRequestFormat, min_bins_idx, BusinessConstant.MD_TRAN_ATM1_M_MIN_PREV30DAYS_merchant,
                    currAggMap);

//          Calculating max bin count for the transaction amount for 30 days for merchant aggregates
            Map<String, Double> max_bins_idx = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
            aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_idx, BusinessConstant.MD_TRAN_ATM1_M_MAX_PREV30DAYS_merchant,
                    currAggMap);

//          Transaction count previous 7days update
            Double tranCount7days = deltaAggRequestFormat.getM1_7();
            Integer tran7days = (Integer) preprocessedData.get(BusinessConstant.TRANCOUNT7DAYS);
            if (tran7days == 1) {
                currAggMap.put("M1_7", tranCount7days + 1);
            } else {
                currAggMap.put("PM", deltaAggRequestFormat.getTranDateTime());
                currAggMap.put("M1_7", 1);
            }

        } catch (Exception e) {
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Tiebreaker:" + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating POSMerchantAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param currAggMap            current aggregates map detail
     */
    public void updatePOSMerchantAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> currAggMap, Map<String, Object> preprocessedData) {
        try {
//          Adding hour type count for POS transaction based on hour_type_index for previous 30 days and 7days for merchant aggregates
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, BusinessConstant.HOUR_TYPE_POS_MERCHANT_PREV30DAYS_,
                    currAggMap);

            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, BusinessConstant.HOUR_TYPE_POS_MERCHANT_PREV7DAYS_,
                    currAggMap);

//          fraud count based on previous fraud score for previous 30 days and 7days and 3days for merchant aggregates
            Map<String, Double> fs_idx = aggregateBins.get_fs_bins_att_merchant(deltaAggRequestFormat);
            String end = "";
            aggregateFunctions.getFSBinAggregates(deltaAggRequestFormat.getFS(), fs_idx, BusinessConstant.FRAUD_COUNT_PREV30_DAYS_MERCHANT, end,
                    currAggMap);

            aggregateFunctions.getFSBinAggregates(deltaAggRequestFormat.getFS(), fs_idx, BusinessConstant.FRAUD_COUNT_PREV7_DAYS_MERCHANT, end,
                    currAggMap);

//     entry mode count based on entry_mode_type for previous 30 days and 7days based for merchant aggregates
            String entryModeType = String.valueOf(preprocessedData.get(BusinessConstant.ENTRY_MODE_TYPE));
            Double contactlessCardCount30days = deltaAggRequestFormat.getEM_30();
            Double contactlessCardCount7days = deltaAggRequestFormat.getEM_7();
            if (BusinessConstant.CONTACT_LESS_CARD.equals(entryModeType)) {
                currAggMap.put("EM_30", contactlessCardCount30days + 1);
                currAggMap.put("EM_7", contactlessCardCount7days + 1);
            }

        } catch (Exception e) {
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Tiebreaker: " + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }
}
