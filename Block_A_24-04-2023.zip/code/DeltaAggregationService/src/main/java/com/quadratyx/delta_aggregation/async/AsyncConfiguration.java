package com.quadratyx.delta_aggregation.async;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.scheduling.annotation.EnableAsync;
import redis.clients.jedis.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Indicates that a class declares one or more @Bean methods and may be processed by the Spring container to generate bean definitions and service requests for those beans at runtime
 */
@Configuration
@EnableAsync
public class AsyncConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(AsyncConfiguration.class);

    @Value("${spring.redis.host}")
    private String host;

    @Value("${spring.redis.port}")
    private int port;

    @Value("${spring.redis.jedis.pool.max-total}")
    private int maxTotal;

    @Value("${spring.redis.jedis.pool.max-idle}")
    private int maxIdle;

    @Value("${spring.redis.jedis.pool.min-idle}")
    private int minIdle;

    @Value("${spring.redis.connectionTimeout}")
    private int connectionTimeout;

    @Value("${spring.redis.soTimeout}")
    private int soTimeout;

    @Value("${spring.redis.password}")
    private String password;

    @Value("${spring.redis.maxAttempts}")
    private int maxAttempts;

    @Value("${spring.redis.maxTimeMilli}")
    private int maxTimeMilli;

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${spring.kafka.producer.ssl.trust-store-location}")
    private String producerTrustStoreLocation;

    @Value("${spring.kafka.producer.ssl.trust-store-password}")
    private String producerTrustStorePassword;

    @Value("${spring.kafka.producer.ssl.key-store-location}")
    private String producerKeyStoreLocation;

    @Value("${spring.kafka.producer.ssl.key-store-password}")
    private String producerKeyStorePassword;

    @Value("${spring.kafka.consumer.ssl.trust-store-location}")
    private String consumerTrustStoreLocation;

    @Value("${spring.kafka.consumer.ssl.trust-store-password}")
    private String consumerTrustStorePassword;

    @Value("${spring.kafka.consumer.ssl.key-store-location}")
    private String consumerKeyStoreLocation;

    @Value("${spring.kafka.consumer.ssl.key-store-password}")
    private String consumerKeyStorePassword;

    @Value("${spring.kafka.security.protocol}")
    private String securityProtocol;

    @Value("${spring.kafka.batch.size}")
    private String batchSize;

    @Value("${spring.kafka.compression.type}")
    private String compressionType;

    @Value("${spring.kafka.bootstrap.groupName}")
    private String groupName;

//    @Value("${spring.redis.sentinel.master}")
//    private String master_name;
//
//    @Value("${spring.redis.sentinel.nodes}")
//    private Set sentinels;
//
//    @Value("${spring.redis.username}")
//    private String user_name;

    /**
     * This is the JavaBean for redis cluster connection configuration
     *
     * @return a <code> JedisCluster </code> instance
     */
    @Bean(name = "redisClusterConfiguration")
    public JedisCluster getRedisCluster() {
        Set<HostAndPort> jedisClusterNode = new HashSet<>();
        jedisClusterNode.add(new HostAndPort(host, port));
        JedisPoolConfig cfg = new JedisPoolConfig();
        cfg.setMaxTotal(maxTotal);
        cfg.setMaxIdle(maxIdle);
        cfg.setMaxWaitMillis(maxTimeMilli);
        cfg.setTestOnBorrow(true);
        return new JedisCluster(jedisClusterNode, connectionTimeout, soTimeout, maxAttempts, password, cfg);
    }

//    @Bean(name="redisSentinelConnection")
//    public Jedis jedisSentinelConnection() {
//        JedisSentinelPool pool = new JedisSentinelPool(master_name, sentinels);
//        Jedis jedis = pool.getResource();
//        jedis.auth(user_name,password);
//        jedis.connect();
//        return jedis;
//    }

    /**
     * This is the JavaBean for Kafka producer configuration
     *
     * @return a <code> Map of String,Object </code> instance
     */
    @Bean
    public Map<String, Object> producerConfigs() {
        Map<String, Object> props = new HashMap<>();
        try {
            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            props.put(ProducerConfig.BATCH_SIZE_CONFIG, batchSize);
            props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, compressionType);
            props.put(ProducerConfig.RETRIES_CONFIG, 3);
            props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, 1000);
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, producerTrustStoreLocation);
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, producerTrustStorePassword);
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, producerKeyStoreLocation);
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, producerKeyStorePassword);
            props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
            props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocol);
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        } catch (Exception e) {
            logger.error("ProducerConfigs Bean ----" + e.getMessage(), e);
        }
        return props;
    }

    /**
     * This is the JavaBean for creating a Kafka producer factory
     *
     * @return a <code> DefaultKafkaProducerFactory </code> instance
     */
    @Bean
    public ProducerFactory<String, String> producerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    /**
     * This is the JavaBean for creating a Kafka template
     *
     * @return a <code> KafkaTemplate </code> instance
     */
    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean
    public Map<String, Object> consumerConfigs() {
        Map<String, Object> props = new HashMap<>();
        try {
            props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            props.put(ConsumerConfig.GROUP_ID_CONFIG, groupName);
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, consumerTrustStoreLocation);
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, consumerTrustStorePassword);
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, consumerKeyStoreLocation);
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, consumerKeyStorePassword);
            props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
            props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocol);
            props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        } catch (Exception e) {
            logger.error("Error in ConsumerConfigs bean ----" + e.getMessage(), e);
        }
        return props;
    }

    /**
     * This is the JavaBean for creating a Kafka producer factory
     *
     * @return a <code> DefaultKafkaConsumerFactory </code> instance
     */
    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerConfigs());
    }

    /**
     * This is the JavaBean for creating concurrent kafka listener container factory
     *
     * @return a <code> object of ConcurrentKafkaListenerContainerFactory </code>
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListener() {
        ConcurrentKafkaListenerContainerFactory<String, String> obj = new ConcurrentKafkaListenerContainerFactory<>();
        obj.setConsumerFactory(consumerFactory());
        return obj;
    }
}