package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * This is the service module for creating of aggregates bin functions
 */
@Service
public class AggregateBins {

    private static final Logger logger = LoggerFactory.getLogger(AggregateBins.class);
    String line = "line number - ";

    /**
     * This is the method used for getting 30days amount bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days amount bins names and values
     */
    public Map<String, Double> get_amount_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> amt_bins_idx = new HashMap<>();
        try {
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_0", deltaAggRequestFormat.getA2_30_0());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_2", deltaAggRequestFormat.getA2_30_2());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_3", deltaAggRequestFormat.getA2_30_3());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_4", deltaAggRequestFormat.getA2_30_4());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_5", deltaAggRequestFormat.getA2_30_5());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_6", deltaAggRequestFormat.getA2_30_6());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_7", deltaAggRequestFormat.getA2_30_7());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_8", deltaAggRequestFormat.getA2_30_8());
            amt_bins_idx.put("amount_bins_M_ATM_prev30days_9", deltaAggRequestFormat.getA2_30_9());
            amt_bins_idx.put("amount_bins_M_prev30days_0", deltaAggRequestFormat.getA1_30_0());
            amt_bins_idx.put("amount_bins_M_prev30days_1", deltaAggRequestFormat.getA1_30_1());
            amt_bins_idx.put("amount_bins_M_prev30days_2", deltaAggRequestFormat.getA1_30_2());
            amt_bins_idx.put("amount_bins_M_prev30days_3", deltaAggRequestFormat.getA1_30_3());
            amt_bins_idx.put("amount_bins_M_prev30days_4", deltaAggRequestFormat.getA1_30_4());
            amt_bins_idx.put("amount_bins_M_prev30days_5", deltaAggRequestFormat.getA1_30_5());
            amt_bins_idx.put("amount_bins_M_prev30days_6", deltaAggRequestFormat.getA1_30_6());
            amt_bins_idx.put("amount_bins_M_prev30days_7", deltaAggRequestFormat.getA1_30_7());
            amt_bins_idx.put("amount_bins_M_prev30days_8", deltaAggRequestFormat.getA1_30_8());
            amt_bins_idx.put("amount_bins_M_prev30days_9", deltaAggRequestFormat.getA1_30_9());
            amt_bins_idx.put("amount_bins_M_prev30days_10", deltaAggRequestFormat.getA1_30_10());
            amt_bins_idx.put("amount_bins_M_prev30days_11", deltaAggRequestFormat.getA1_30_11());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_2", deltaAggRequestFormat.getP2_30_2());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_3", deltaAggRequestFormat.getP2_30_3());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_4", deltaAggRequestFormat.getP2_30_4());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_5", deltaAggRequestFormat.getP2_30_5());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_6", deltaAggRequestFormat.getP2_30_6());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_7", deltaAggRequestFormat.getP2_30_7());
            amt_bins_idx.put("amount_bins_M_POS_prev30days_9", deltaAggRequestFormat.getP2_30_9());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_3", deltaAggRequestFormat.getC2_30_3());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_4", deltaAggRequestFormat.getC2_30_4());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_5", deltaAggRequestFormat.getC2_30_5());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_6", deltaAggRequestFormat.getC2_30_6());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_7", deltaAggRequestFormat.getC2_30_7());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_8", deltaAggRequestFormat.getC2_30_8());
            amt_bins_idx.put("amount_bins_M_CNPSECURED_prev30days_9", deltaAggRequestFormat.getC2_30_9());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_3", deltaAggRequestFormat.getC3_30_3());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_4", deltaAggRequestFormat.getC3_30_4());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_5", deltaAggRequestFormat.getC3_30_5());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_6", deltaAggRequestFormat.getC3_30_6());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_7", deltaAggRequestFormat.getC3_30_7());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_8", deltaAggRequestFormat.getC3_30_8());
            amt_bins_idx.put("amount_bins_M_CNPUNSECURED_prev30days_9", deltaAggRequestFormat.getC3_30_9());
        } catch (Exception e) {
            logger.error("get_amount_bins_att method -------");
        }
        return amt_bins_idx;
    }

    /**
     * This is the method used for getting 30days hour type bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days hour type bins names and values
     */
    public Map<String, Double> get_hour_type_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> hour_type_bins_idx = new HashMap<>();
        hour_type_bins_idx.put("hour_type_ATM_prev30days_1", deltaAggRequestFormat.getH2_30());
        hour_type_bins_idx.put("hour_type_ATM_prev30days_2", deltaAggRequestFormat.getH3_30());
        hour_type_bins_idx.put("hour_type_ATM_prev30days_3", deltaAggRequestFormat.getH4_30());
        hour_type_bins_idx.put("hour_type_ATM_prev30days_4", deltaAggRequestFormat.getH5_30());
        hour_type_bins_idx.put("hour_type_prev30days_1", deltaAggRequestFormat.getH6_30());
        hour_type_bins_idx.put("hour_type_prev30days_2", deltaAggRequestFormat.getH7_30());
        hour_type_bins_idx.put("hour_type_prev30days_3", deltaAggRequestFormat.getH8_30());
        hour_type_bins_idx.put("hour_type_prev30days_4", deltaAggRequestFormat.getH9_30());
        hour_type_bins_idx.put("hour_type_POS_prev30days_3", deltaAggRequestFormat.getH8_P_30());
        hour_type_bins_idx.put("hour_type_POS_merchant_prev30days_4", deltaAggRequestFormat.getHM_30());
        hour_type_bins_idx.put("hour_type_POS_merchant_prev7days_4", deltaAggRequestFormat.getHM_7());
        hour_type_bins_idx.put("hour_type_CNPSECURED_prev30days_1", deltaAggRequestFormat.getHC1_30());
        hour_type_bins_idx.put("hour_type_CNPSECURED_prev30days_2", deltaAggRequestFormat.getHC2_30());
        hour_type_bins_idx.put("hour_type_CNPSECURED_prev30days_3", deltaAggRequestFormat.getHC3_30());
        hour_type_bins_idx.put("hour_type_CNPSECURED_prev30days_4", deltaAggRequestFormat.getHC4_30());
        hour_type_bins_idx.put("hour_type_CNPUNSECURED_prev30days_1", deltaAggRequestFormat.getHC5_30());
        hour_type_bins_idx.put("hour_type_CNPUNSECURED_prev30days_2", deltaAggRequestFormat.getHC6_30());
        hour_type_bins_idx.put("hour_type_CNPUNSECURED_prev30days_3", deltaAggRequestFormat.getHC7_30());
        hour_type_bins_idx.put("hour_type_CNPUNSECURED_prev30days_4", deltaAggRequestFormat.getHC8_30());
        hour_type_bins_idx.put("hour_type_merchant_prev30days_1", deltaAggRequestFormat.getHM1_30());
        hour_type_bins_idx.put("hour_type_merchant_prev30days_2", deltaAggRequestFormat.getHM2_30());
        hour_type_bins_idx.put("hour_type_merchant_prev30days_3", deltaAggRequestFormat.getHM3_30());
        hour_type_bins_idx.put("hour_type_merchant_prev30days_4", deltaAggRequestFormat.getHM4_30());
        return hour_type_bins_idx;
    }

    /**
     * This is the method used for getting 30days transaction code bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days transaction code bins names and values
     */
    public Map<String, Double> get_tran_cde_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tran_cde_bins_idx = new HashMap<>();
        try {
            tran_cde_bins_idx.put("tran_cde_type_ATM_BalInquiry_count_prev30days", deltaAggRequestFormat.getT1_30());
            tran_cde_bins_idx.put("tran_cde_type_ATM_PinChange_count_prev30days", deltaAggRequestFormat.getT2_30());
            tran_cde_bins_idx.put("tran_cde_type_ATM_PinInquiry_count_prev30days", deltaAggRequestFormat.getT3_30());
            tran_cde_bins_idx.put("tran_cde_type_BalInquiry_count_prev30days", deltaAggRequestFormat.getT5_30());
            tran_cde_bins_idx.put("tran_cde_type_PinChange_count_prev30days", deltaAggRequestFormat.getT7_30());
            tran_cde_bins_idx.put("tran_cde_type_PinInquiry_count_prev30days", deltaAggRequestFormat.getT8_30());
            tran_cde_bins_idx.put("tran_cde_type_Purchase_count_prev30days", deltaAggRequestFormat.getT9_30());
            tran_cde_bins_idx.put("tran_cde_type_MailOrder_count_prev30days", deltaAggRequestFormat.getT6_30());
            tran_cde_bins_idx.put("tran_cde_type_CNPSECURED_Purchase_count_prev30days", deltaAggRequestFormat.getTC_30());
            tran_cde_bins_idx.put("tran_cde_type_CNPUNSECURED_Purchase_count_prev30days", deltaAggRequestFormat.getTC1_30());
        } catch (Exception e) {
            logger.error("get_tran_cde_bins_att method -------");
        }
        return tran_cde_bins_idx;
    }

    /**
     * This is the method used for getting 30days response code bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days response code bins names and values
     */
    public Map<String, Double> get_sd_resp_cde_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> sd_resp_cde_bins_idx = new HashMap<>();
        try {
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_Block_Decline_H_count_prev30days", deltaAggRequestFormat.getS3_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_InsuffFunds_count_prev30days", deltaAggRequestFormat.getS5_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_InvalidData_count_prev30days", deltaAggRequestFormat.getS7_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_OtherDeclines_count_prev30days", deltaAggRequestFormat.getS8_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_Pickup_Capture_count_prev30days", deltaAggRequestFormat.getS9_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_PRM_Declined_count_prev30days", deltaAggRequestFormat.getS10_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_RestrictedCard_count_prev30days", deltaAggRequestFormat.getS11_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev30days", deltaAggRequestFormat.getS12_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_Block_Decline_H_count_prev30days", deltaAggRequestFormat.getS13_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_InsuffFunds_count_prev30days", deltaAggRequestFormat.getS15_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_IntlLimitExceeded_NA_count_prev30days", deltaAggRequestFormat.getS16_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_OtherDeclines_count_prev30days", deltaAggRequestFormat.getS18_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ExpiredCard_count_prev30days", deltaAggRequestFormat.getS14_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_InvalidData_count_prev30days", deltaAggRequestFormat.getS17_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_Pickup_Capture_count_prev30days", deltaAggRequestFormat.getS19_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_PRM_Declined_count_prev30days", deltaAggRequestFormat.getS20_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_RestrictedCard_count_prev30days", deltaAggRequestFormat.getS21_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_WithdrawalLimitExceeded_count_prev30days", deltaAggRequestFormat.getS22_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_ExpiredCard_count_prev30days", deltaAggRequestFormat.getSP4_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_InsuffFunds_count_prev30days", deltaAggRequestFormat.getSP5_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_InvalidData_count_prev30days", deltaAggRequestFormat.getSP7_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_OtherDeclines_count_prev30days", deltaAggRequestFormat.getSP8_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_Pickup_Capture_count_prev30days", deltaAggRequestFormat.getSP9_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_RestrictedCard_count_prev30days", deltaAggRequestFormat.getSP11_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_InvalidData_count_prev30days", deltaAggRequestFormat.getSC1_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_ExpiredCard_count_prev30days", deltaAggRequestFormat.getSC2_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_IntlLimitExceeded_NA_count_prev30days", deltaAggRequestFormat.getSC3_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_Pickup_Capture_count_prev30days", deltaAggRequestFormat.getSC4_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_OtherDeclines_count_prev30days", deltaAggRequestFormat.getSC5_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_RestrictedCard_count_prev30days", deltaAggRequestFormat.getSC6_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_Block_Decline_H_count_prev30days", deltaAggRequestFormat.getSC7_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_InsuffFunds_count_prev30days", deltaAggRequestFormat.getSC8_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPSECURED_PRM_Declined_count_prev30days", deltaAggRequestFormat.getSC9_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_InvalidData_count_prev30days", deltaAggRequestFormat.getSU1_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_ExpiredCard_count_prev30days", deltaAggRequestFormat.getSU2_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_IntlLimitExceeded_NA_count_prev30days", deltaAggRequestFormat.getSU3_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_Pickup_Capture_count_prev30days", deltaAggRequestFormat.getSU4_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_OtherDeclines_count_prev30days", deltaAggRequestFormat.getSU5_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_RestrictedCard_count_prev30days", deltaAggRequestFormat.getSU6_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_Block_Decline_H_count_prev30days", deltaAggRequestFormat.getSU7_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_InsuffFunds_count_prev30days", deltaAggRequestFormat.getSU8_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_PRM_Declined_count_prev30days", deltaAggRequestFormat.getSU9_30());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_CNPUNSECURED_WithdrawalLimitExceeded_count_prev30days", deltaAggRequestFormat.getSU10_30());
        } catch (Exception e) {
            logger.error("get_sd_resp_cde_bins_att method -------");
        }
        return sd_resp_cde_bins_idx;
    }

    /**
     * This is the method used for getting 30days real time rule status bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days real time rule status bins names and values
     */
    public Map<String, Double> get_rel_time_rule_status_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tran_type_bins_idx = new HashMap<>();
        try {
            tran_type_bins_idx.put("real_time_rule_status_Allowoverlimit_count_prev30days", deltaAggRequestFormat.getR1_30());
            tran_type_bins_idx.put("real_time_rule_status_Authorized_count_prev30days", deltaAggRequestFormat.getR2_30());
            tran_type_bins_idx.put("real_time_rule_status_Declined_count_prev30days", deltaAggRequestFormat.getR3_30());
        } catch (Exception e) {
            logger.error("get_rel_time_rule_status_bins_att method -------");
        }
        return tran_type_bins_idx;
    }

    /**
     * This is the method used for getting 30days token_srvc_POS_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days token bins names and values
     */
    public Map<String, Double> get_token_srvc_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> token_bins_idx = new HashMap<>();
        try {

            token_bins_idx.put("token_srvc_POS_SamsungPay_count_prev30days", deltaAggRequestFormat.getTS1_30());

        } catch (Exception e) {
            logger.error("get_token_srvc_bins_att_30days method -------");
        }
        return token_bins_idx;
    }


    /**
     * This is the method used for getting 30days mcc_POS_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days mcc bins bins names and values
     */
    public Map<String, Double> get_mcc_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> mcc_bins_idx = new HashMap<>();
        try {
            mcc_bins_idx.put("mcc_POS_4111_count_prev30days", deltaAggRequestFormat.getMP_30_1());
            mcc_bins_idx.put("mcc_POS_4812_count_prev30days", deltaAggRequestFormat.getMP_30_2());
            mcc_bins_idx.put("mcc_POS_5310_count_prev30days", deltaAggRequestFormat.getMP_30_3());
            mcc_bins_idx.put("mcc_POS_5311_count_prev30days", deltaAggRequestFormat.getMP_30_4());
            mcc_bins_idx.put("mcc_POS_5399_count_prev30days", deltaAggRequestFormat.getMP_30_5());
            mcc_bins_idx.put("mcc_POS_5411_count_prev30days", deltaAggRequestFormat.getMP_30_6());
            mcc_bins_idx.put("mcc_POS_5499_count_prev30days", deltaAggRequestFormat.getMP_30_7());
            mcc_bins_idx.put("mcc_POS_5542_count_prev30days", deltaAggRequestFormat.getMP_30_9());
            mcc_bins_idx.put("mcc_POS_5661_count_prev30days", deltaAggRequestFormat.getMP_30_10());
            mcc_bins_idx.put("mcc_POS_5691_count_prev30days", deltaAggRequestFormat.getMP_30_11());
            mcc_bins_idx.put("mcc_POS_5699_count_prev30days", deltaAggRequestFormat.getMP_30_12());
            mcc_bins_idx.put("mcc_POS_5732_count_prev30days", deltaAggRequestFormat.getMP_30_13());
            mcc_bins_idx.put("mcc_POS_5812_count_prev30days", deltaAggRequestFormat.getMP_30_14());
            mcc_bins_idx.put("mcc_POS_5813_count_prev30days", deltaAggRequestFormat.getMP_30_15());
            mcc_bins_idx.put("mcc_POS_5814_count_prev30days", deltaAggRequestFormat.getMP_30_16());
            mcc_bins_idx.put("mcc_POS_5912_count_prev30days", deltaAggRequestFormat.getMP_30_17());
            mcc_bins_idx.put("mcc_POS_5921_count_prev30days", deltaAggRequestFormat.getMP_30_18());
            mcc_bins_idx.put("mcc_POS_5944_count_prev30days", deltaAggRequestFormat.getMP_30_19());
            mcc_bins_idx.put("mcc_POS_5995_count_prev30days", deltaAggRequestFormat.getMP_30_20());
            mcc_bins_idx.put("mcc_CNPSECURED_4121_count_prev30days", deltaAggRequestFormat.getMC_30_1());
            mcc_bins_idx.put("mcc_CNPSECURED_4722_count_prev30days", deltaAggRequestFormat.getMC_30_2());
            mcc_bins_idx.put("mcc_CNPSECURED_4814_count_prev30days", deltaAggRequestFormat.getMC_30_3());
            mcc_bins_idx.put("mcc_CNPSECURED_4899_count_prev30days", deltaAggRequestFormat.getMC_30_4());
            mcc_bins_idx.put("mcc_CNPSECURED_4900_count_prev30days", deltaAggRequestFormat.getMC_30_5());
            mcc_bins_idx.put("mcc_CNPSECURED_5399_count_prev30days", deltaAggRequestFormat.getMC_30_6());
            mcc_bins_idx.put("mcc_CNPSECURED_5699_count_prev30days", deltaAggRequestFormat.getMC_30_7());
            mcc_bins_idx.put("mcc_CNPSECURED_5732_count_prev30days", deltaAggRequestFormat.getMC_30_8());
            mcc_bins_idx.put("mcc_CNPSECURED_5735_count_prev30days", deltaAggRequestFormat.getMC_30_9());
            mcc_bins_idx.put("mcc_CNPSECURED_5968_count_prev30days", deltaAggRequestFormat.getMC_30_10());
            mcc_bins_idx.put("mcc_CNPSECURED_6012_count_prev30days", deltaAggRequestFormat.getMC_30_11());
            mcc_bins_idx.put("mcc_CNPSECURED_6540_count_prev30days", deltaAggRequestFormat.getMC_30_12());
            mcc_bins_idx.put("mcc_CNPSECURED_7311_count_prev30days", deltaAggRequestFormat.getMC_30_13());
            mcc_bins_idx.put("mcc_CNPUNSECURED_4121_count_prev30days", deltaAggRequestFormat.getMU_30_1());
            mcc_bins_idx.put("mcc_CNPUNSECURED_4789_count_prev30days", deltaAggRequestFormat.getMU_30_2());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5311_count_prev30days", deltaAggRequestFormat.getMU_30_3());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5641_count_prev30days", deltaAggRequestFormat.getMU_30_4());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5734_count_prev30days", deltaAggRequestFormat.getMU_30_5());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5735_count_prev30days", deltaAggRequestFormat.getMU_30_6());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5812_count_prev30days", deltaAggRequestFormat.getMU_30_7());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5816_count_prev30days", deltaAggRequestFormat.getMU_30_8());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5818_count_prev30days", deltaAggRequestFormat.getMU_30_9());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5942_count_prev30days", deltaAggRequestFormat.getMU_30_10());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5967_count_prev30days", deltaAggRequestFormat.getMU_30_11());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5968_count_prev30days", deltaAggRequestFormat.getMU_30_12());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5995_count_prev30days", deltaAggRequestFormat.getMU_30_13());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5999_count_prev30days", deltaAggRequestFormat.getMU_30_14());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7311_count_prev30days", deltaAggRequestFormat.getMU_30_15());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7372_count_prev30days", deltaAggRequestFormat.getMU_30_16());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7399_count_prev30days", deltaAggRequestFormat.getMU_30_17());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7523_count_prev30days", deltaAggRequestFormat.getMU_30_18());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7829_count_prev30days", deltaAggRequestFormat.getMU_30_19());
            mcc_bins_idx.put("mcc_CNPUNSECURED_8398_count_prev30days", deltaAggRequestFormat.getMU_30_20());

        } catch (Exception e) {
            logger.error("get_mcc_bins_att_30days method -------");
        }
        return mcc_bins_idx;
    }

    /**
     * This is the method used for getting 30days mcc_count attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days frequency bins
     **/
    public Map<String, Double> get_count_mcc_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> mcc_count_bin = new HashMap<>();
        try {
            mcc_count_bin.put(BusinessConstant.COUNT_MCC_PREV30DAYS, deltaAggRequestFormat.getC9_30());
        } catch (Exception e) {
            logger.error("get_mcc_count_bin_att_30days method -------");
            logger.error(String.valueOf(e));
        }
        return mcc_count_bin;
    }


    /**
     * This is the method used for getting 30days mean_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days mean bins names and values
     */
    public Map<String, Double> get_mean_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> mean_bins_idx = new HashMap<>();
        try {
            mean_bins_idx.put("md_tran_amt1_M_POS_mean_prev30days", deltaAggRequestFormat.getMD_T1_30());
            mean_bins_idx.put("md_tran_amt1_M_mean_prev30days", deltaAggRequestFormat.getM6_30());
            mean_bins_idx.put("mean_tran_amt_mcc_prev30days", deltaAggRequestFormat.getM8_30());
            mean_bins_idx.put("md_tran_amt1_M_POS_contactlesscard_mean_prev30days", deltaAggRequestFormat.getMD_T3_30());
            mean_bins_idx.put("md_tran_amt1_M_CNPSECURED_mean_prev30days", deltaAggRequestFormat.getMC_T2_30());
            mean_bins_idx.put("md_tran_amt1_M_CNPUNSECURED_mean_prev30days", deltaAggRequestFormat.getMU_T2_30());
            mean_bins_idx.put("md_tran_amt1_M_mean_prev30days_merchant", deltaAggRequestFormat.getMR2_30());
        } catch (Exception e) {
            logger.error("get_mean_bins_att_30days method -------");
        }
        return mean_bins_idx;
    }

    /**
     * This is the method used for getting 30days min_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days min bins names and values
     */
    public Map<String, Double> get_min_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> min_bins_idx = new HashMap<>();
        try {
            min_bins_idx.put("md_tran_amt1_M_POS_min_prev30days", deltaAggRequestFormat.getMD_T2_30());
            min_bins_idx.put("md_tran_amt1_M_CNPSECURED_min_prev30days", deltaAggRequestFormat.getMC_T1_30());
            min_bins_idx.put("md_tran_amt1_M_CNPUNSECURED_min_prev30days", deltaAggRequestFormat.getMU_T1_30());
            min_bins_idx.put("md_tran_amt1_M_min_prev30days", deltaAggRequestFormat.getM7_30());
            min_bins_idx.put("md_tran_amt1_M_min_prev30days_merchant", deltaAggRequestFormat.getMR1_30());
        } catch (Exception e) {
            logger.error("get_min_bins_att_30days method -------");
        }
        return min_bins_idx;
    }

    /**
     * This is the method used for getting 30days max_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days max bins names and values
     */
    public Map<String, Double> get_max_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> max_bins_idx = new HashMap<>();
        try {
            max_bins_idx.put("md_tran_amt1_M_max_prev30days", deltaAggRequestFormat.getM5_30());
            max_bins_idx.put("max_tran_amt_mcc_prev30days", deltaAggRequestFormat.getM1_30());
            max_bins_idx.put("md_tran_amt1_M_CNPSECURED_max_prev30days", deltaAggRequestFormat.getMC_T3_30());
            max_bins_idx.put("md_tran_amt1_M_CNPUNSECURED_max_prev30days", deltaAggRequestFormat.getMU_T3_30());
            max_bins_idx.put("md_tran_amt1_M_POS_contactlesscard_max_prev30days", deltaAggRequestFormat.getMD_T4_30());
            max_bins_idx.put("md_tran_amt1_M_max_prev30days_merchant", deltaAggRequestFormat.getMR3_30());
        } catch (Exception e) {
            logger.error("get_max_bins_att_30days method -------");
        }
        return max_bins_idx;
    }

    /**
     * This is the method used for getting 30days sd response code bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days sd response code bins names and values
     */
    public Map<String, Double> get_sd_resp_cde_new_bins_att(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> sd_resp_cde_new_bins_idx = new HashMap<>();
        try {
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_PRM_Decline_count_prev30days", deltaAggRequestFormat.getS28_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Invalid_PIN_count_prev30days", deltaAggRequestFormat.getS29_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Not_Sufficient_Funds_count_prev30days", deltaAggRequestFormat.getS30_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_INTL_Flag_not_Enabled_count_prev30days", deltaAggRequestFormat.getS31_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Restricted_Card_count_prev30days", deltaAggRequestFormat.getS32_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Exceeds_Withdrawal_amount_limit_count_prev30days", deltaAggRequestFormat.getS33_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_External_Decline_count_prev30days", deltaAggRequestFormat.getS34_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_System_Issue_count_prev30days", deltaAggRequestFormat.getS35_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_otherDeclines_count_prev30days", deltaAggRequestFormat.getS36_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Bad_Track_Data_count_prev30days", deltaAggRequestFormat.getS37_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Format_Error_count_prev30days", deltaAggRequestFormat.getS38_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Enter_Lesser_Amount_count_prev30days", deltaAggRequestFormat.getS39_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Invalid_Country_code_count_prev30days", deltaAggRequestFormat.getS40_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Expired_Card_count_prev30days", deltaAggRequestFormat.getS41_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_TVR_Decline_count_prev30days", deltaAggRequestFormat.getS42_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Issuer_or_Switch_is_inoperative_count_prev30days", deltaAggRequestFormat.getS43_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Invalid_Transaction_count_prev30days", deltaAggRequestFormat.getS44_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Capture_count_prev30days", deltaAggRequestFormat.getS45_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_REQ_CRYPTOGRAM_FAILURE_count_prev30days", deltaAggRequestFormat.getS46_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_INTL_Limit_Exceeded_count_prev30days", deltaAggRequestFormat.getS47_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Unable_to_process_transaction_count_prev30days", deltaAggRequestFormat.getS48_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Invalid_Card_Number_count_prev30days", deltaAggRequestFormat.getS49_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Transaction_Not_Supported_count_prev30days", deltaAggRequestFormat.getS50_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Merchant_PIN_Bypass_count_prev30days", deltaAggRequestFormat.getS51_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Transaction_Not_Permitted_to_Cardholder_count_prev30days", deltaAggRequestFormat.getS52_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Invalid_transaction_date_count_prev30days", deltaAggRequestFormat.getS53_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_PIN_Tries_Exceeded_count_prev30days", deltaAggRequestFormat.getS54_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_Stolen_Card_or_pickup_count_prev30days", deltaAggRequestFormat.getS55_30());
            sd_resp_cde_new_bins_idx.put("sd_resp_cde_type_new_CAF_not_found_count_prev30days", deltaAggRequestFormat.getS56_30());
        } catch (Exception e) {
            logger.error("get_sd_resp_cde_bins_att method -------");
        }
        return sd_resp_cde_new_bins_idx;
    }

    /**
     * This is the method used for getting 3days mean_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days mean bins names and values
     */
    public Map<String, Double> get_mean_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> mean_bins_idx = new HashMap<>();
        try {
            mean_bins_idx.put("md_tran_amt1_M_POS_contactlesscard_mean_prev3days", deltaAggRequestFormat.getMD_T3_3());

        } catch (Exception e) {
            logger.error("get_mean_bins_att_3days method -------");
        }
        return mean_bins_idx;
    }

    /**
     * This is the method used for getting 3days max_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days max bins names and values
     */
    public Map<String, Double> get_max_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> max_bins_idx = new HashMap<>();
        try {
            max_bins_idx.put("md_tran_amt1_M_POS_contactlesscard_max_prev3days", deltaAggRequestFormat.getMD_T4_3());
        } catch (Exception e) {
            logger.error("get_max_bins_att_3days method -------");
        }
        return max_bins_idx;
    }

    /**
     * This is the method used for getting 30days and 7 days fraud_count_bins attribute for merchant
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days and 7days fraud_count_bins names and values
     */
    public Map<String, Double> get_fs_bins_att_merchant(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> fs_idx = new HashMap<>();
        fs_idx.put("fraud_count_prev30days_merchant", deltaAggRequestFormat.getFC_30());
        fs_idx.put("fraud_count_prev7days_merchant", deltaAggRequestFormat.getFC_7());
        fs_idx.put("fraud_count_prev3days_merchant", deltaAggRequestFormat.getFC_3());

        return fs_idx;
    }

    /**
     * This is the method used for getting 3days amount bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days amount bins names and values
     */
    public Map<String, Double> get_amount_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> amt_bins_idx = new HashMap<>();
        try {
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_0", deltaAggRequestFormat.getA2_3_0());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_2", deltaAggRequestFormat.getA2_3_2());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_3", deltaAggRequestFormat.getA2_3_3());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_4", deltaAggRequestFormat.getA2_3_4());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_5", deltaAggRequestFormat.getA2_3_5());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_6", deltaAggRequestFormat.getA2_3_6());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_7", deltaAggRequestFormat.getA2_3_7());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_8", deltaAggRequestFormat.getA2_3_8());
            amt_bins_idx.put("amount_bins_M_ATM_prev3days_9", deltaAggRequestFormat.getA2_3_9());
            amt_bins_idx.put("amount_bins_M_prev3days_1", deltaAggRequestFormat.getA1_3_1());
            amt_bins_idx.put("amount_bins_M_prev3days_3", deltaAggRequestFormat.getA1_3_3());
            amt_bins_idx.put("amount_bins_M_prev3days_4", deltaAggRequestFormat.getA1_3_4());
            amt_bins_idx.put("amount_bins_M_prev3days_6", deltaAggRequestFormat.getA1_3_6());
            amt_bins_idx.put("amount_bins_M_prev3days_7", deltaAggRequestFormat.getA1_3_7());
            amt_bins_idx.put("amount_bins_M_prev3days_8", deltaAggRequestFormat.getA1_3_8());
            amt_bins_idx.put("amount_bins_M_prev3days_10", deltaAggRequestFormat.getA1_3_10());
            amt_bins_idx.put("amount_bins_M_prev3days_11", deltaAggRequestFormat.getA1_3_11());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_1", deltaAggRequestFormat.getP2_3_1());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_2", deltaAggRequestFormat.getP2_3_2());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_3", deltaAggRequestFormat.getP2_3_3());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_4", deltaAggRequestFormat.getP2_3_4());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_5", deltaAggRequestFormat.getP2_3_5());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_6", deltaAggRequestFormat.getP2_3_6());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_7", deltaAggRequestFormat.getP2_3_7());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_8", deltaAggRequestFormat.getP2_3_8());
            amt_bins_idx.put("amount_bins_M_POS_prev3days_9", deltaAggRequestFormat.getP2_3_9());

        } catch (Exception e) {
            logger.error("get_amount_bins_att_3days method -------");
        }
        return amt_bins_idx;
    }

    /**
     * This is the method used for getting 3days hour type bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days hour type bins names and values
     */
    public Map<String, Double> get_hour_type_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> hour_type_bins_idx = new HashMap<>();
        try {
            hour_type_bins_idx.put("hour_type_ATM_prev3days_1", deltaAggRequestFormat.getH2_3());
            hour_type_bins_idx.put("hour_type_ATM_prev3days_2", deltaAggRequestFormat.getH3_3());
            hour_type_bins_idx.put("hour_type_ATM_prev3days_3", deltaAggRequestFormat.getH4_3());
            hour_type_bins_idx.put("hour_type_ATM_prev3days_4", deltaAggRequestFormat.getH5_3());
            hour_type_bins_idx.put("hour_type_prev3days_3", deltaAggRequestFormat.getH8_3());
            hour_type_bins_idx.put("hour_type_prev3days_4", deltaAggRequestFormat.getH9_3());
        } catch (Exception e) {
            logger.error("get_hour_type_bins_att_3days method -------");
        }
        return hour_type_bins_idx;
    }

    /**
     * This is the method used for getting 3days transaction code bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days transaction code bins names and values
     */
    public Map<String, Double> get_tran_cde_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tran_cde_bins_idx = new HashMap<>();
        try {
            tran_cde_bins_idx.put("tran_cde_type_ATM_BalInquiry_count_prev3days", deltaAggRequestFormat.getT1_3());
            tran_cde_bins_idx.put("tran_cde_type_ATM_PinChange_count_prev3days", deltaAggRequestFormat.getT2_3());
            tran_cde_bins_idx.put("tran_cde_type_ATM_PinInquiry_count_prev3days", deltaAggRequestFormat.getT3_3());
            tran_cde_bins_idx.put("tran_cde_type_MailOrder_count_prev3days", deltaAggRequestFormat.getT6_3());
        } catch (Exception e) {
            logger.error("get_tran_cde_bins_att_3days method -------");
        }
        return tran_cde_bins_idx;
    }

    /**
     * This is the method used for getting 3days response code bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days response code bins names and values
     */
    public Map<String, Double> get_sd_resp_cde_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> sd_resp_cde_bins_idx = new HashMap<>();
        try {
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_Block_Decline_H_count_prev3days", deltaAggRequestFormat.getS3_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_ExpiredCard_count_prev3days", deltaAggRequestFormat.getS4_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_InsuffFunds_count_prev3days", deltaAggRequestFormat.getS5_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_IntlLimitExceeded_NA_count_prev3days", deltaAggRequestFormat.getS6_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_InvalidData_count_prev3days", deltaAggRequestFormat.getS7_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_OtherDeclines_count_prev3days", deltaAggRequestFormat.getS8_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_Pickup_Capture_count_prev3days", deltaAggRequestFormat.getS9_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_PRM_Declined_count_prev3days", deltaAggRequestFormat.getS10_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_RestrictedCard_count_prev3days", deltaAggRequestFormat.getS11_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev3days", deltaAggRequestFormat.getS12_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_Block_Decline_H_count_prev3days", deltaAggRequestFormat.getS13_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_InsuffFunds_count_prev3days", deltaAggRequestFormat.getS15_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_IntlLimitExceeded_NA_count_prev3days", deltaAggRequestFormat.getS16_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_Pickup_Capture_count_prev3days", deltaAggRequestFormat.getS19_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_IntlLimitExceeded_NA_count_prev3days", deltaAggRequestFormat.getSP6_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_POS_PRM_Declined_count_prev3days", deltaAggRequestFormat.getSP10_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_InvalidData_count_prev3days", deltaAggRequestFormat.getS17_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_OtherDeclines_count_prev3days", deltaAggRequestFormat.getS18_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_ExpiredCard_count_prev3days", deltaAggRequestFormat.getS14_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_PRM_Declined_count_prev3days", deltaAggRequestFormat.getSP20_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_RestrictedCard_count_prev3days", deltaAggRequestFormat.getSP21_3());
            sd_resp_cde_bins_idx.put("sd_resp_cde_type_WithdrawalLimitExceeded_count_prev3days", deltaAggRequestFormat.getSP22_3());
        } catch (Exception e) {
            logger.error("get_sd_resp_cde_bins_att_3days method -------");
        }
        return sd_resp_cde_bins_idx;
    }

    /**
     * This is the method used for getting 3days real time rule status bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days real time rule status bins names and values
     */
    public Map<String, Double> get_rel_time_rule_status_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tran_type_bins_idx = new HashMap<>();
        try {
            tran_type_bins_idx.put("real_time_rule_status_Allowoverlimit_count_prev3days", deltaAggRequestFormat.getR1_3());
            tran_type_bins_idx.put("real_time_rule_status_Declined_count_prev3days", deltaAggRequestFormat.getR3_3());
        } catch (Exception e) {
            logger.error("get_rel_time_rule_status_bins_att_3days method -------");
        }
        return tran_type_bins_idx;
    }

    /**
     * This is the method used for getting 3days mcc_POS_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days mcc bins bins names and values
     */
    public Map<String, Double> get_mcc_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> mcc_bins_idx = new HashMap<>();
        try {
            mcc_bins_idx.put("mcc_POS_4111_count_prev3days", deltaAggRequestFormat.getMP_3_1());
            mcc_bins_idx.put("mcc_POS_4812_count_prev3days", deltaAggRequestFormat.getMP_3_2());
            mcc_bins_idx.put("mcc_POS_5310_count_prev3days", deltaAggRequestFormat.getMP_3_3());
            mcc_bins_idx.put("mcc_POS_5311_count_prev3days", deltaAggRequestFormat.getMP_3_4());
            mcc_bins_idx.put("mcc_POS_5399_count_prev3days", deltaAggRequestFormat.getMP_3_5());
            mcc_bins_idx.put("mcc_POS_5411_count_prev3days", deltaAggRequestFormat.getMP_3_6());
            mcc_bins_idx.put("mcc_POS_5499_count_prev3days", deltaAggRequestFormat.getMP_3_7());
            mcc_bins_idx.put("mcc_POS_5541_count_prev3days", deltaAggRequestFormat.getMP_3_8());
            mcc_bins_idx.put("mcc_POS_5542_count_prev3days", deltaAggRequestFormat.getMP_3_9());
            mcc_bins_idx.put("mcc_POS_5661_count_prev3days", deltaAggRequestFormat.getMP_3_10());
            mcc_bins_idx.put("mcc_POS_5691_count_prev3days", deltaAggRequestFormat.getMP_3_11());
            mcc_bins_idx.put("mcc_POS_5699_count_prev3days", deltaAggRequestFormat.getMP_3_12());
            mcc_bins_idx.put("mcc_POS_5732_count_prev3days", deltaAggRequestFormat.getMP_3_13());
            mcc_bins_idx.put("mcc_POS_5812_count_prev3days", deltaAggRequestFormat.getMP_3_14());
            mcc_bins_idx.put("mcc_POS_5813_count_prev3days", deltaAggRequestFormat.getMP_3_15());
            mcc_bins_idx.put("mcc_POS_5814_count_prev3days", deltaAggRequestFormat.getMP_3_16());
            mcc_bins_idx.put("mcc_POS_5912_count_prev3days", deltaAggRequestFormat.getMP_3_17());
            mcc_bins_idx.put("mcc_POS_5921_count_prev3days", deltaAggRequestFormat.getMP_3_18());
            mcc_bins_idx.put("mcc_POS_5944_count_prev3days", deltaAggRequestFormat.getMP_3_19());
            mcc_bins_idx.put("mcc_POS_5995_count_prev3days", deltaAggRequestFormat.getMP_3_20());
            mcc_bins_idx.put("mcc_CNPSECURED_4121_count_prev3days", deltaAggRequestFormat.getMC_3_1());
            mcc_bins_idx.put("mcc_CNPSECURED_4722_count_prev3days", deltaAggRequestFormat.getMC_3_2());
            mcc_bins_idx.put("mcc_CNPSECURED_4814_count_prev3days", deltaAggRequestFormat.getMC_3_3());
            mcc_bins_idx.put("mcc_CNPSECURED_4899_count_prev3days", deltaAggRequestFormat.getMC_3_4());
            mcc_bins_idx.put("mcc_CNPSECURED_4900_count_prev3days", deltaAggRequestFormat.getMC_3_5());
            mcc_bins_idx.put("mcc_CNPSECURED_5399_count_prev3days", deltaAggRequestFormat.getMC_3_6());
            mcc_bins_idx.put("mcc_CNPSECURED_5699_count_prev3days", deltaAggRequestFormat.getMC_3_7());
            mcc_bins_idx.put("mcc_CNPSECURED_5732_count_prev3days", deltaAggRequestFormat.getMC_3_8());
            mcc_bins_idx.put("mcc_CNPSECURED_5735_count_prev3days", deltaAggRequestFormat.getMC_3_9());
            mcc_bins_idx.put("mcc_CNPSECURED_5968_count_prev3days", deltaAggRequestFormat.getMC_3_10());
            mcc_bins_idx.put("mcc_CNPSECURED_6012_count_prev3days", deltaAggRequestFormat.getMC_3_11());
            mcc_bins_idx.put("mcc_CNPSECURED_6540_count_prev3days", deltaAggRequestFormat.getMC_3_12());
            mcc_bins_idx.put("mcc_CNPSECURED_7311_count_prev3days", deltaAggRequestFormat.getMC_3_13());
            mcc_bins_idx.put("mcc_CNPUNSECURED_4121_count_prev3days", deltaAggRequestFormat.getMU_3_1());
            mcc_bins_idx.put("mcc_CNPUNSECURED_4789_count_prev3days", deltaAggRequestFormat.getMU_3_2());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5311_count_prev3days", deltaAggRequestFormat.getMU_3_3());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5641_count_prev3days", deltaAggRequestFormat.getMU_3_4());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5734_count_prev3days", deltaAggRequestFormat.getMU_3_5());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5735_count_prev3days", deltaAggRequestFormat.getMU_3_6());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5812_count_prev3days", deltaAggRequestFormat.getMU_3_7());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5816_count_prev3days", deltaAggRequestFormat.getMU_3_8());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5818_count_prev3days", deltaAggRequestFormat.getMU_3_9());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5942_count_prev3days", deltaAggRequestFormat.getMU_3_10());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5967_count_prev3days", deltaAggRequestFormat.getMU_3_11());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5968_count_prev3days", deltaAggRequestFormat.getMU_3_12());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5995_count_prev3days", deltaAggRequestFormat.getMU_3_13());
            mcc_bins_idx.put("mcc_CNPUNSECURED_5999_count_prev3days", deltaAggRequestFormat.getMU_3_14());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7311_count_prev3days", deltaAggRequestFormat.getMU_3_15());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7372_count_prev3days", deltaAggRequestFormat.getMU_3_16());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7399_count_prev3days", deltaAggRequestFormat.getMU_3_17());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7523_count_prev3days", deltaAggRequestFormat.getMU_3_18());
            mcc_bins_idx.put("mcc_CNPUNSECURED_7829_count_prev3days", deltaAggRequestFormat.getMU_3_19());
            mcc_bins_idx.put("mcc_CNPUNSECURED_8398_count_prev3days", deltaAggRequestFormat.getMU_3_20());

        } catch (Exception e) {
            logger.error("get_mcc_bins_att_3days method -------");
        }
        return mcc_bins_idx;
    }

    /**
     * This is the method used for getting 3days token_srvc_POS_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days token bins names and values
     */
    public Map<String, Double> get_token_srvc_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> token_bins_idx = new HashMap<>();
        try {

            token_bins_idx.put("token_srvc_POS_SamsungPay_count_prev3days", deltaAggRequestFormat.getTS1_3());

        } catch (Exception e) {
            logger.error("get_token_srvc_bins_att_3days method -------");
        }
        return token_bins_idx;
    }


    /**
     * This is the method used for getting 3days fraud_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days fraud_count_prev3days names and values
     */
    public Map<String, Double> get_fs_bins_att_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> fs_bins_idx = new HashMap<>();
        try {

            fs_bins_idx.put("fraud_count_prev3days", deltaAggRequestFormat.getF3_3());

        } catch (Exception e) {
            logger.error("get_fs_bins_att_3days method -------");
        }
        return fs_bins_idx;
    }

    public Map<String, Double> get_avg_bins_amt_60days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> avg_bins_idx = new HashMap<>();
        try {
            avg_bins_idx.put("avg_tran_amt_prev60days", deltaAggRequestFormat.getWD_1_60());
        } catch (Exception e) {
            logger.error("get_avg_bins_amt_60days method -------");
        }
        return avg_bins_idx;
    }

    /**
     * This is the method used for getting 30days tran_type_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 30days tran_type_bins names and values
     */
    public Map<String, Double> get_tran_type_bins_att_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tran_bins_idx = new HashMap<>();
        try {

            tran_bins_idx.put("tran_type_merchant_prev30days_1", deltaAggRequestFormat.getTM1_30());
            tran_bins_idx.put("tran_type_merchant_prev30days_0", deltaAggRequestFormat.getTM2_30());

        } catch (Exception e) {
            logger.error("get_tran_type_bins_att_30days method -------");
        }
        return tran_bins_idx;
    }

    /**
     * This is the method used for getting trans_count_bins attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the 3days trans_count_prev3days names and values
     */
    public Map<String, Double> get_trans_count_att_merchant(DeltaAggRequestFormat deltaAggRequestFormat) {
        Map<String, Double> tranCountInd = new HashMap<>();
        try {

            tranCountInd.put("transaction_count_prev1days_merchant", deltaAggRequestFormat.getM1_1());
            tranCountInd.put("transaction_count_prev7days_merchant", deltaAggRequestFormat.getM1_7());

        } catch (Exception e) {
            logger.error("get_trans_count_att_merchant method -------");
        }
        return tranCountInd;
    }

    /**
     * This is the method used for getting current_tran_bins_30days attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the current_tran_bins_30days names and values
     */
//    public Map<String, Double> get_current_tran_bins_30days(DeltaAggRequestFormat deltaAggRequestFormat) {
//        Map<String, Double> currTranInd = new HashMap<>();
//        try {
//
//            currTranInd.put("current_tran_state_prev30days", deltaAggRequestFormat.getCP1_30());
//            currTranInd.put("current_tran_city_prev30days", deltaAggRequestFormat.getCP2_30());
//            currTranInd.put("current_tran_cntry_prev30days", deltaAggRequestFormat.getCP3_30());
//
//        } catch (Exception e) {
//            logger.error("get_current_tran_bins_30days method -------");
//        }
//        return currTranInd;
//    }


    /**
     * This is the method used for getting current_tran_bins_3days attribute
     *
     * @param deltaAggRequestFormat Delta aggregation Request format detail
     * @return a <code> Map of String,Double </code> specifying the current_tran_bins_3days names and values
     */
//    public Map<String, Double> get_current_tran_bins_3days(DeltaAggRequestFormat deltaAggRequestFormat) {
//        Map<String, Double> currTranIndex = new HashMap<>();
//        try {
//
//            currTranIndex.put("current_tran_state_prev3days", deltaAggRequestFormat.getCP1_3());
//            currTranIndex.put("current_tran_city_prev3days", deltaAggRequestFormat.getCP2_3());
//            currTranIndex.put("current_tran_cntry_prev3days", deltaAggRequestFormat.getCP3_3());
//
//        } catch (Exception e) {
//            logger.error("get_current_tran_bins_3days method -------");
//        }
//        return currTranIndex;
//    }
}
