package com.quadratyx.delta_aggregation.model;

/**
 * This is a model class to hold response information for Delta Aggregation Service
 *
 * @author Priyanka Gupta
 * @see Object
 */
public class DeltaAggResponseFormat {
    private String SD_PAN;
    private Integer status;

    /**
     * Gets the SD_PAN detail
     *
     * @return a <code> string </code>
     * specifying the SD_PAN detail
     */
    public String getSD_PAN() {
        return SD_PAN;
    }

    /**
     * Sets the SD_PAN detail
     *
     * @param SD_PAN the SD_PAN detail
     */
    public void setSD_PAN(String SD_PAN) {
        this.SD_PAN = SD_PAN;
    }

    /**
     * Gets the Status detail
     *
     * @return a <code> Integer </code>
     * specifying the Status detail
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * Sets the Status detail
     *
     * @param status the Status detail
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * Default Constructor
     */
    public DeltaAggResponseFormat() {

    }

    /**
     * Parameterized Constructor
     *
     * @param SD_PAN SD_PAN detail
     * @param status Status detail
     */
    public DeltaAggResponseFormat(String SD_PAN, Integer status) {
        this.SD_PAN = SD_PAN;
        this.status = status;
    }

    /**
     * Convert to standard string format
     *
     * @return a <code> string </code> representing DeltaAggResponseFormat in standard format
     */
    @Override
    public String toString() {
        return "DeltaAggResponseFormat{" +
                "SD_PAN='" + SD_PAN + '\'' +
                ", status=" + status +
                '}';
    }
}
