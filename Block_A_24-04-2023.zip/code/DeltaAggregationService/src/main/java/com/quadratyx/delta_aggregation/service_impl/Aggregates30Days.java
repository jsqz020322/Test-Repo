package com.quadratyx.delta_aggregation.service_impl;

import com.quadratyx.delta_aggregation.model.DeltaAggRequestFormat;
import com.quadratyx.delta_aggregation.util.BusinessConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the service module for 30Days Aggregates creation
 */
@Service
public class Aggregates30Days {

    private static final Logger logger = LoggerFactory.getLogger(Aggregates30Days.class);

    @Autowired
    private AggregateBins aggregateBins;

    @Autowired
    private AggregateFunctions aggregateFunctions;

    @Autowired
    private DeltaAggregatesMain deltaAggregatesMain;

    @Value("${spring.kafka.bootstrap.exceptionTopic}")
    private String exceptionTopic;

    @Autowired
    @Qualifier("config")
    private Map<String, List<String>> jsonMap;


    /**
     * This is the method used for updating ATM30DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessed_data     PreProcessed derived fields map detail
     * @param curr_agg_map          current aggregates map detail
     */
    public void updateATM30DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessed_data,
                                          Map<String, Object> curr_agg_map) {
        try {

//          Calculating ATM amount bin based on the derived amount_bin_index attribute for previous 30 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
            String key = "amount_bins_M_ATM_prev30days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, key,
                    curr_agg_map);

//          Country Type for current transaction
            String CntryType = deltaAggRequestFormat.getDA13();
            if (BusinessConstant.interNational.equals(CntryType)) {
                Double cntrytype_ATM_International_count_prev30days = deltaAggRequestFormat.getC6_30();
                curr_agg_map.put("C6_30", cntrytype_ATM_International_count_prev30days + 1);
            }

//          Adding hour type count based on hour_type_index for previous 30 days ATM transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            key = "hour_type_ATM_prev30days_";
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, key,
                    curr_agg_map);

//          Transaction code categorization for ATM transactions for prev 30 days
            String st = "tran_cde_type_ATM_";
            Map<String, Double> req_map = aggregateBins.get_tran_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating SD response code type for ATM transactions
            st = "sd_resp_cde_type_ATM_";
            req_map = aggregateBins.get_sd_resp_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating ATM approval count for country and transaction type
            String sd_resp_cde_type = String.valueOf(preprocessed_data.get("sd_res_code_type"));
            if (!sd_resp_cde_type.equals("Approved")) {
                Double atm_dec_w_count_cntrytype_prev30days = deltaAggRequestFormat.getA5_30_3();
                curr_agg_map.put("A5_30_3", atm_dec_w_count_cntrytype_prev30days + 1);
            }

//          Updating metro city ATM count previous 30 days
            Integer atm_term_city_class_numIndex = deltaAggRequestFormat.getDA14();
            if (atm_term_city_class_numIndex != null && atm_term_city_class_numIndex == 1) {
                Double metro_city_ATM_Metro_city_count_prev30days = deltaAggRequestFormat.getM15();
                curr_agg_map.put("M15", metro_city_ATM_Metro_city_count_prev30days + 1);
            }

//          Updating amount bin value for ATM type of transaction for previous 30 days
            Double atmwithdrawal_count_prev30days = deltaAggRequestFormat.getA3_30();
            curr_agg_map.put("A3_30", atmwithdrawal_count_prev30days + 1);

            Map<String, Double> avg_bins_idx = aggregateBins.get_avg_bins_amt_60days(deltaAggRequestFormat);
            String K = "avg_tran_amt_prev60days";
            aggregateFunctions.getAvgBinAggregates(deltaAggRequestFormat, avg_bins_idx, K,
                    curr_agg_map);

            aggregateFunctions.getMerchantSDAggregates(deltaAggRequestFormat, curr_agg_map);

//          Updating the count of maximum daily atm tran count for prev30days

            curr_agg_map.put("M9", deltaAggRequestFormat.getM9() + 1);
            curr_agg_map.put("M14", deltaAggRequestFormat.getM14() + 1);

        } catch (Exception e) {
            logger.error("Exception " +e.getMessage(), e);
            curr_agg_map = new HashMap<>();
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updateATM30DaysAggregates" + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating 30DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessed_data     PreProcessed derived fields map detail
     * @param curr_agg_map          current aggregates map detail
     */
    public void update30DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat, Map<String, Object> preprocessed_data,
                                       Map<String, Object> curr_agg_map) {
        try {

//          Calculating amount bin based on the derived amount_bin_index attribute for previous 30 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
            String key = "amount_bins_M_prev30days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, key,
                    curr_agg_map);

//          Country Type for current transaction
            String CntryType = deltaAggRequestFormat.getDA13();
            if (BusinessConstant.interNational.equals(CntryType)) {
                Double cntrytype_International_count_prev30days = deltaAggRequestFormat.getC8_30();
                curr_agg_map.put("C8_30", cntrytype_International_count_prev30days + 1);
            } else {
                Double cntrytype_Domestic_count_prev30days = deltaAggRequestFormat.getC7_30();
                curr_agg_map.put("C7_30", cntrytype_Domestic_count_prev30days + 1);
            }

//          Aggregate update for entry_mode_type
            String entry_mode_type = String.valueOf(preprocessed_data.get("entry_mode_type"));
            Double chipvalidated_count = deltaAggRequestFormat.getE1_30();
            Double contactlesscard_count = deltaAggRequestFormat.getE2_30();
            Double magstripe_count = deltaAggRequestFormat.getE3_30();
            switch (entry_mode_type) {
                case "chipvalidated" -> curr_agg_map.put("E1_30", chipvalidated_count + 1);
                case "contactlesscard" -> curr_agg_map.put("E2_30", contactlesscard_count + 1);
                case "magstripe" -> curr_agg_map.put("E3_30", magstripe_count + 1);
                default -> logger.debug("entry_mode_type for 30 days aggregates updation is not matching with expected values");
            }

//          Monetary updation
            Integer monetary_tran = deltaAggRequestFormat.getDA5();
            Double monetary_NM_count_prev30days = deltaAggRequestFormat.getS2_30();
            if (monetary_tran != null && monetary_tran != 1) {
                curr_agg_map.put("S2_30", monetary_NM_count_prev30days + 1);
            }

//          key entry flag updation
            String Key_entry_cde = deltaAggRequestFormat.getPontOfSrvcCondCode();
            String Key_entry_mde = deltaAggRequestFormat.getPontOfSrvceEntryMode();
            if ((("00").equals(Key_entry_cde)) && ("012".equals(Key_entry_mde))) {
                curr_agg_map.put("P27", 1);
            } else {
                curr_agg_map.put("P27", 0);
            }

//          Transaction code categorization for ATM transactions for prev 30 days
            String st = "tran_cde_type_";
            Map<String, Double> req_map = aggregateBins.get_tran_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating SD response code type for transactions
            st = "sd_resp_cde_type_";
            req_map = aggregateBins.get_sd_resp_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating SD response code type new aggregates for transactions
            st = "sd_resp_cde_type_new_";
            req_map = aggregateBins.get_sd_resp_cde_new_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeTypeNew(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating SD response code for transactions
            Integer prev_sd_resp_cde_type = (Integer) preprocessed_data.get(BusinessConstant.SD_RES_CODE);
            if (prev_sd_resp_cde_type == 1) {
                curr_agg_map.put("P21", 0);
                curr_agg_map.put("P23", 0);
            } else {
                curr_agg_map.put("P21", 1);
                curr_agg_map.put("P23", 1);
            }
            curr_agg_map.put("P8", prev_sd_resp_cde_type);

//          Real Time Status count updation
            st = "real_time_rule_status_";
            req_map = aggregateBins.get_rel_time_rule_status_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getRealtimeStatusUpdation(preprocessed_data, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);


//          Updating fall back status attribute for previous 30 days
            Integer fall_back_status = (Integer) preprocessed_data.get("fall_back_status");
            Double fall_back_status_count_prev30days = deltaAggRequestFormat.getF2_30();
            if (fall_back_status == 1) {
                curr_agg_map.put("F2_30", fall_back_status_count_prev30days + 1);
            }

//          Updating gasoline transaction count for previous 30 days
            Double gasoline_tran_count_prev3days = deltaAggRequestFormat.getG1_30();
            String SD_RETL_SIC_CDE = deltaAggRequestFormat.getRtlrSICCode();
            List<String> gasoline_tran_count = jsonMap.get("gasoline_tran_count");
            if (gasoline_tran_count.contains(SD_RETL_SIC_CDE)) {
                curr_agg_map.put("G1_30", gasoline_tran_count_prev3days + 1);
            }

//          Updating key entry flag count for previous 30 days
            String PontOfSrvcCondCode = deltaAggRequestFormat.getPontOfSrvcCondCode();
            String PontOfSrvceEntryMode = deltaAggRequestFormat.getPontOfSrvceEntryMode();
            List<String> srvc_cond_code = jsonMap.get("PontOfSrvcCondCode");
            List<String> srvc_entry_mode = jsonMap.get("PontOfSrvceEntryMode");

            if (srvc_cond_code.contains(PontOfSrvcCondCode) && srvc_entry_mode.contains(PontOfSrvceEntryMode)) {
                Double key_entry_tx_flag_key_entry_tx_count_prev30days = deltaAggRequestFormat.getK1_30();
                curr_agg_map.put("K1_30", key_entry_tx_flag_key_entry_tx_count_prev30days + 1);
            }

//          Location city mapping count updation
            if (deltaAggRequestFormat.getP36() != null && deltaAggRequestFormat.getTermCity() != null &&
                    deltaAggRequestFormat.getP36().strip().equals(deltaAggRequestFormat.getTermCity().strip())) {
                Double loc_city_mapping_prev30days = deltaAggRequestFormat.getL1();
                curr_agg_map.put("L1", loc_city_mapping_prev30days + 1);
            }

//          Updating postal code match count based on previous transaction data
            Double postal_code_mapping_prev30days = deltaAggRequestFormat.getP3_30();
            String TermPstlCode = deltaAggRequestFormat.getTermPstlCode();
            String prev_postal_code = deltaAggRequestFormat.getP39();
            if (TermPstlCode != null && TermPstlCode.equals(prev_postal_code)) {
                curr_agg_map.put("P3_30", postal_code_mapping_prev30days + 1);
            }

//          Adding hour type count based on hour_type_index for previous 30 days transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            key = "hour_type_prev30days_";
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, key,
                    curr_agg_map);

//          Transaction code categorization for transactions for prev 30 days
            String str = "tran_cde_type_";
            Map<String, Double> requiredMap = aggregateBins.get_tran_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessed_data, requiredMap, curr_agg_map, str, BusinessConstant.ED30DAYS);

//          Updating restaurant Transaction count
            List<String> sd_retl_sic_cde_restaurant = jsonMap.get("sd_retl_sic_cde_restaurant");
            if (sd_retl_sic_cde_restaurant.contains(SD_RETL_SIC_CDE)) {
                Double restuarant_tran_count_prev30days = deltaAggRequestFormat.getR4_30();
                curr_agg_map.put("R4_30", restuarant_tran_count_prev30days + 1);
            }

//          Updating Stores Transaction count
            List<String> sd_retl_sic_cde_storestran = jsonMap.get("sd_retl_sic_cde_storestran");
            if (sd_retl_sic_cde_storestran.contains(SD_RETL_SIC_CDE)) {
                Double storestran_count_prev30days = deltaAggRequestFormat.getS23_30();
                curr_agg_map.put("S23_30", storestran_count_prev30days + 1);
            }

//          Calculating mean bin count for the transaction amount for 30 days
            Map<String, Double> mean_bins_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            String K = "md_tran_amt1_M_mean_prev30days";
            aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_idx, K,
                    curr_agg_map);

//          Calculating min bin count for the transaction amount for 30 days
            Map<String, Double> min_bins_idx = aggregateBins.get_min_bins_att_30days(deltaAggRequestFormat);
            String MinKey = "md_tran_amt1_M_min_prev30days";
            aggregateFunctions.getMinBinAggregates(deltaAggRequestFormat, min_bins_idx, MinKey,
                    curr_agg_map);

//          Calculating POS mean bin count for the mcc transaction amount for 30 days
            Map<String, Double> mean_bin_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            String Ky = "mean_tran_amt_mcc_prev30days";
            aggregateFunctions.getMeanMccBinAggregates(deltaAggRequestFormat, mean_bin_idx, Ky, curr_agg_map);

//          Calculating max bin count for the transaction amount for 30 days
            Map<String, Double> max_bins_idx = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
            String MaxKey = "md_tran_amt1_M_max_prev30days";
            aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_idx, MaxKey, curr_agg_map);

//          Calculating max bin count for mcc for 30 days
            Map<String, Double> max_bin_idx = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
            String maxKey = "max_tran_amt_mcc_prev30days";
            aggregateFunctions.getMaxMccBinAggregates(deltaAggRequestFormat, max_bin_idx, maxKey, curr_agg_map);

//          Updating the transaction amount for 30 days
            Double tran_amt = deltaAggRequestFormat.getTranAmt1();
            curr_agg_map.put("P16", tran_amt);

//          Updating the amount bin index for 30 days
            Integer bin_idx = deltaAggRequestFormat.getI3();
            curr_agg_map.put("P4", bin_idx);

//          Updating the monetary bin type for 30 days
            Integer mntry_typ = deltaAggRequestFormat.getDA5();
            curr_agg_map.put("P28", mntry_typ);
            curr_agg_map.put("S1_30", mntry_typ);

//          Calculating POS mcc bins on the derived mcc_bin index attribute for previous 30 days
            Map<String, Double> mcc_count_bin_index = aggregateBins.get_count_mcc_bins_att_30days(deltaAggRequestFormat);
            aggregateFunctions.getMccCountBinAggregates(deltaAggRequestFormat, mcc_count_bin_index, curr_agg_map);

//          Updating the pin entered flag for 30 days
            String pinEnteredDomFlag = String.valueOf(preprocessed_data.get("pin_entered_dom_flag"));
            Double pin_flg = 0.0;
            if ("entered".equals(pinEnteredDomFlag)) {
                pin_flg = 1.0;
            }

            curr_agg_map.put("P29", pin_flg);

//          Updating transaction count previous 30 days
            Double trancount_prev30days_cm = deltaAggRequestFormat.getT14();
            curr_agg_map.put("T14", trancount_prev30days_cm + 1);
        } catch (Exception e) {
            logger.error("Exception " +e.getMessage(), e);
            curr_agg_map = new HashMap<>();
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "update30DaysAggregates " + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating POS30DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param curr_agg_map          current aggregates map detail
     */
    public void updatePOS30DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                          Map<String, Object> preprocessedData,
                                          Map<String, Object> curr_agg_map) {
        try {
//          Calculating POS amount bin based on the derived amount_bin_index attribute for previous 30 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
            String key = "amount_bins_M_POS_prev30days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, key, curr_agg_map);

//          Updating SD response code type for POS transactions for previous 30 days
            String st = "sd_resp_cde_type_POS_";
            Map<String, Double> req_map = aggregateBins.get_sd_resp_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);


//          Token type categorization for POS transactions for prev 30 days
            String Key = "token_srvc_POS_";
            Map<String, Double> token_bins_idx = aggregateBins.get_token_srvc_bins_att_30days(deltaAggRequestFormat);
            aggregateFunctions.getTokenSrvcBins(preprocessedData, token_bins_idx, curr_agg_map, Key, BusinessConstant.ED30DAYS);


//          Adding hour type count based on hour_type_index for previous 30 days POS transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            key = "hour_type_POS_prev30days_";
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, key,
                    curr_agg_map);

//          Country Type for current transaction for previous 30 days
            String CntryType = deltaAggRequestFormat.getDA13();
            if (BusinessConstant.interNational.equals(CntryType)) {
                Double cntrytype_POS_International_count_prev30days = deltaAggRequestFormat.getC8_P_30();
                curr_agg_map.put("C8_P_30", cntrytype_POS_International_count_prev30days + 1);
            }

//          Calculating POS mean bin count for the transaction amount for 30 days
            Map<String, Double> mean_bins_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            String K = "md_tran_amt1_M_POS_mean_prev30days";
            aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_idx, K, curr_agg_map);

//          Calculating POS min bin count for the transaction amount for 30 days
            Map<String, Double> min_bins_idx = aggregateBins.get_min_bins_att_30days(deltaAggRequestFormat);
            String MinKey = "md_tran_amt1_M_POS_min_prev30days";
            aggregateFunctions.getMinBinAggregates(deltaAggRequestFormat, min_bins_idx, MinKey, curr_agg_map);

//          Calculating POS mcc bin based on the derived mcc_bin_index attribute for previous 30 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_30days(deltaAggRequestFormat);
            String str = "mcc_POS_";
            String aggKey = "mcc_pos_retail_codes_30";
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, aggKey, str, BusinessConstant.ED30DAYS,
                    curr_agg_map);

//          Calculating mean bin count for the POS transaction amount and contactless card for 30 days
            String entry_mode_type = String.valueOf(preprocessedData.get("entry_mode_type"));
            if (entry_mode_type.equals("contactlesscard")) {
                Map<String, Double> mean_bins_index = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
                String meanKey = "md_tran_amt1_M_POS_contactlesscard_mean_prev30days";
                aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_index, meanKey,
                        curr_agg_map);

//          Calculating max bin count for the POS transaction amount and contactless card for 30 days
                Map<String, Double> max_bins_index = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
                String maxKey = "md_tran_amt1_M_POS_contactlesscard_max_prev30days";
                aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_index, maxKey,
                        curr_agg_map);
            }
        } catch (Exception e) {
            curr_agg_map = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating CNPSecured30DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param curr_agg_map          current aggregates map detail
     */
    public void updateCNPSecured30DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                 Map<String, Object> preprocessedData,
                                                 Map<String, Object> curr_agg_map) {
        try {
//          Calculating CNPSecured amount bin based on the derived amount_bin_index attribute for previous 30 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
            String key = "amount_bins_M_CNPSECURED_prev30days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, key,
                    curr_agg_map);

//          Adding hour type count based on hour_type_index for previous 30 days CNPSecured transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            key = "hour_type_CNPSECURED_prev30days_";
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, key,
                    curr_agg_map);

//          Updating SD response code type for CNPSecured transactions for previous 30 days
            String st = "sd_resp_cde_type_CNPSECURED_";
            Map<String, Double> req_map = aggregateBins.get_sd_resp_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, curr_agg_map, st, BusinessConstant.ED30DAYS);

//          Updating tran code type for CNPSecured transactions for previous 30 days
            String tranCde = "tran_cde_type_CNPSECURED_";
            Map<String, Double> tranType = aggregateBins.get_tran_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessedData, tranType, curr_agg_map, tranCde, BusinessConstant.ED30DAYS);

//          Calculating CNP Secured mcc bin based on the derived mcc_bin_index attribute for previous 30 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_30days(deltaAggRequestFormat);
            String str = "mcc_CNPSECURED_";
            String aggKey = "mcc_cnp_secured_retail_codes";
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, aggKey, str, BusinessConstant.ED30DAYS, curr_agg_map);

            String CntryType = deltaAggRequestFormat.getDA13();
            if (BusinessConstant.interNational.equals(CntryType)) {
                Double cntrytype_CNPSECURED_International_count_prev30days = deltaAggRequestFormat.getCC2_30();
                curr_agg_map.put("CC2_30", cntrytype_CNPSECURED_International_count_prev30days + 1);
            } else {
                Double cntrytype_CNPSECURED_Domestic_count_prev30days = deltaAggRequestFormat.getCC1_30();
                curr_agg_map.put("CC1_30", cntrytype_CNPSECURED_Domestic_count_prev30days + 1);
            }

//          Calculating CNP Secured mean bin count for the transaction amount for 30 days
            Map<String, Double> mean_bins_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            String meanKey = "md_tran_amt1_M_CNPSECURED_mean_prev30days";
            aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_idx, meanKey, curr_agg_map);

//          Calculating CNP Secured min bin count for the transaction amount for 30 days
            Map<String, Double> min_bins_idx = aggregateBins.get_min_bins_att_30days(deltaAggRequestFormat);
            String minKey = "md_tran_amt1_M_CNPSECURED_min_prev30days";
            aggregateFunctions.getMinBinAggregates(deltaAggRequestFormat, min_bins_idx, minKey, curr_agg_map);

//          Calculating CNP Secured max bin count for the transaction amount for 30 days
            Map<String, Double> max_bins_idx = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
            String maxKey = "md_tran_amt1_M_CNPSECURED_max_prev30days";
            aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_idx, maxKey, curr_agg_map);

//          Updating channel type CNPSecured count for prev 30 days
            Double C2_30 = deltaAggRequestFormat.getC2_30();
            C2_30 = C2_30 + 1;
            curr_agg_map.put("C2_30", C2_30);

//          Updating channel type CNPSecured count for prev 30 days
            Double C1_30 = deltaAggRequestFormat.getC1_30();
            Double C3_30 = deltaAggRequestFormat.getC3_30();
            Double C4_30 = deltaAggRequestFormat.getC4_30();

            Double cnpSecuredUsage = C2_30 / (C1_30 + C2_30 + C3_30 + C4_30);
            curr_agg_map.put("CS_30", cnpSecuredUsage);

//          Calculating Current trans state bins for previous 30 days

            String stateList = deltaAggRequestFormat.getC1_L();
            Integer aggVal = deltaAggRequestFormat.getCP1_30();
            aggregateFunctions.getCurrentStateCountBinAggregates(deltaAggRequestFormat, curr_agg_map, stateList, aggVal, BusinessConstant.stateListSecured);

//          Calculating Current trans city bins for previous 30 days
            String cityList = deltaAggRequestFormat.getC2_L();
            Integer agg_val = deltaAggRequestFormat.getCP2_30();
            aggregateFunctions.getCurrentCityCountBinAggregates(deltaAggRequestFormat, curr_agg_map, cityList, agg_val, BusinessConstant.current_city_list_secured);

//          Calculating Current trans country bins for previous 30 days
            String countryList = deltaAggRequestFormat.getC3_L();
            Integer AggVal = deltaAggRequestFormat.getCP3_30();
            aggregateFunctions.getCurrentCntryCountBinAggregates(deltaAggRequestFormat, curr_agg_map, countryList, AggVal, BusinessConstant.current_cntry_list_secured);


        } catch (Exception e) {
            curr_agg_map = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updatePOS30DaysAggregates " + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }

    /**
     * This is the method used for updating CNPUnsecured30DaysAggregates attributes
     *
     * @param deltaAggRequestFormat Delta Aggregates Request Format detail
     * @param preprocessedData      PreProcessed derived fields map detail
     * @param curr_agg_map          current aggregates map detail
     */
    public void updateCNPUnsecured30DaysAggregates(DeltaAggRequestFormat deltaAggRequestFormat,
                                                   Map<String, Object> preprocessedData,
                                                   Map<String, Object> curr_agg_map) {
        try {

//          Calculating CNPSecured amount bin based on the derived amount_bin_index attribute for previous 30 days
            Map<String, Double> amt_bins_idx = aggregateBins.get_amount_bins_att(deltaAggRequestFormat);
            String key = "amount_bins_M_CNPUNSECURED_prev30days_";
            aggregateFunctions.getAmountBinAggregates(deltaAggRequestFormat.getI3(), amt_bins_idx, key, curr_agg_map);

//          Adding hour type count based on hour_type_index for previous 30 days CNPSecured transactions
            Map<String, Double> hour_type_bins_idx = aggregateBins.get_hour_type_bins_att(deltaAggRequestFormat);
            key = "hour_type_CNPUNSECURED_prev30days_";
            aggregateFunctions.getHourTypeIndex(deltaAggRequestFormat.getI8(), hour_type_bins_idx, key, curr_agg_map);

//          Calculating CNP Unsecured mcc bin based on the derived mcc_bin_index attribute for previous 30 days
            Map<String, Double> mcc_bins_idx = aggregateBins.get_mcc_bins_att_30days(deltaAggRequestFormat);
            String str = "mcc_CNPUNSECURED_";
            String aggKey = "mcc_cnp_unsecured_retail_codes";
            aggregateFunctions.getMCCBinAggregates(deltaAggRequestFormat.getRtlrSICCode(), mcc_bins_idx, aggKey, str, BusinessConstant.ED30DAYS,
                    curr_agg_map);

//         Updating SD response code type for CNP Unsecured transactions for previous 30 days
            String st = "sd_resp_cde_type_CNPUNSECURED_";
            Map<String, Double> req_map = aggregateBins.get_sd_resp_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getSDResponseCodeType(preprocessedData, req_map, curr_agg_map,
                    st, BusinessConstant.ED30DAYS);

//          Calculating CNP Unsecured mean bin count for the transaction amount for 30 days
            Map<String, Double> mean_bins_idx = aggregateBins.get_mean_bins_att_30days(deltaAggRequestFormat);
            String meanKey = "md_tran_amt1_M_CNPUNSECURED_mean_prev30days";
            aggregateFunctions.getMeanBinAggregates(deltaAggRequestFormat.getTranAmt1(), mean_bins_idx, meanKey, curr_agg_map);

//          Calculating CNP Unsecured min bin count for the transaction amount for 30 days
            Map<String, Double> min_bins_idx = aggregateBins.get_min_bins_att_30days(deltaAggRequestFormat);
            String minKey = "md_tran_amt1_M_CNPUNSECURED_min_prev30days";
            aggregateFunctions.getMinBinAggregates(deltaAggRequestFormat, min_bins_idx, minKey,
                    curr_agg_map);

//          Calculating CNP Unsecured max bin count for the transaction amount for 30 days
            Map<String, Double> max_bins_idx = aggregateBins.get_max_bins_att_30days(deltaAggRequestFormat);
            String maxKey = "md_tran_amt1_M_CNPUNSECURED_max_prev30days";
            aggregateFunctions.getMaxBinAggregates(deltaAggRequestFormat, max_bins_idx, maxKey, curr_agg_map);

//          Updating channel type CNPUnsecured count for prev 30 days
            Double C3_30 = deltaAggRequestFormat.getC3_30();
            C3_30 = C3_30 + 1;
            curr_agg_map.put("C3_30", C3_30);

//          Updating tran code type for CNPUnsecured transactions for previous 30 days
            String tranCde = "tran_cde_type_CNPUNSECURED_";
            Map<String, Double> tranType = aggregateBins.get_tran_cde_bins_att(deltaAggRequestFormat);
            aggregateFunctions.getTranCodeBins(preprocessedData, tranType, curr_agg_map, tranCde, BusinessConstant.ED30DAYS);

            String CntryType = deltaAggRequestFormat.getDA13();
            if (BusinessConstant.interNational.equals(CntryType)) {
                Double cntrytype_CNPUNSECURED_International_count_prev30days = deltaAggRequestFormat.getCC4_30();
                curr_agg_map.put("CC4_30", cntrytype_CNPUNSECURED_International_count_prev30days + 1);
            } else {
                Double cntrytype_CNPUNSECURED_Domestic_count_prev30days = deltaAggRequestFormat.getCC3_30();
                curr_agg_map.put("CC3_30", cntrytype_CNPUNSECURED_Domestic_count_prev30days + 1);
            }

//          Updating channel type CNPUnsecured usage for prev 30 days
            Double C1_30 = deltaAggRequestFormat.getC1_30();
            Double C2_30 = deltaAggRequestFormat.getC2_30();
            Double C4_30 = deltaAggRequestFormat.getC4_30();

            Double cnpUnsecuredUsage = C3_30 / (C1_30 + C2_30 + C3_30 + C4_30);
            curr_agg_map.put("CU_30", cnpUnsecuredUsage);

//          Calculating Current trans state bins for previous 30 days

            String stateList = deltaAggRequestFormat.getCU1_L();
            Integer aggVal = deltaAggRequestFormat.getCP1_30();
            aggregateFunctions.getCurrentStateCountBinAggregates(deltaAggRequestFormat, curr_agg_map, stateList, aggVal, BusinessConstant.stateListUnsecured);


//          Calculating Current trans city bins for previous 30 days
            String cityList = deltaAggRequestFormat.getCU2_L();
            Integer agg_val = deltaAggRequestFormat.getCP2_30();
            aggregateFunctions.getCurrentCityCountBinAggregates(deltaAggRequestFormat, curr_agg_map, cityList, agg_val, BusinessConstant.current_city_list_unsecured);

//          Calculating Current trans country bins for previous 30 days
            String countryList = deltaAggRequestFormat.getCU3_L();
            Integer AggVal = deltaAggRequestFormat.getCP3_30();
            aggregateFunctions.getCurrentCntryCountBinAggregates(deltaAggRequestFormat, curr_agg_map, countryList, AggVal, BusinessConstant.current_cntry_list_unsecured);


        } catch (Exception e) {
            curr_agg_map = new HashMap<>();
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "updateCNPUnSecuredAggregates " + BusinessConstant.TIEBREAKER + deltaAggRequestFormat.getTiebreaker() + "\n" + sw.toString();
            deltaAggregatesMain.sendMessage(exception, exceptionTopic);
        }
    }
}