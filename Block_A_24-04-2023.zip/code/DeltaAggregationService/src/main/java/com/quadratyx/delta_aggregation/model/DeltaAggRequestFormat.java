package com.quadratyx.delta_aggregation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotBlank;

/**
 * This is a model class to hold request information for Delta Aggregation Service
 *
 * @see Object
 */
@JsonInclude(JsonInclude.Include.ALWAYS)
@Component
public class DeltaAggRequestFormat {

    @JsonProperty("Tiebreaker")
    @NotBlank
    private String tiebreaker;
    @JsonProperty("RecordSourceId")
    private Integer recordSourceId;
    @JsonProperty("PAN")
    private String pan;
    @JsonProperty("RETLID")
    private String retlid;
    @JsonProperty("AcctNum")
    private String acctNum;
    @JsonProperty("TERMID")
    private String termid;
    @JsonProperty("TranCode")
    private String tranCode;
    @JsonProperty("TranAmt1")
    private Double tranAmt1;
    @JsonProperty("MsgType")
    private String msgType;
    @JsonProperty("PontOfSrvcCondCode")
    private String pontOfSrvcCondCode;
    @JsonProperty("PontOfSrvceEntryMode")
    private String pontOfSrvceEntryMode;
    @JsonProperty("EComFlag")
    private String eComFlag;
    @JsonProperty("EMVTrmnlVrfyRslt")
    private String eMVTrmnlVrfyRslt;
    @JsonProperty("EMVUsrFlr")
    private String eMVUsrFlr;
    @JsonProperty("RtlrSICCode")
    private String rtlrSICCode;
    @JsonProperty("TermNameLoc")
    private String termNameLoc;
    @JsonProperty("TermCity")
    private String termCity;
    @JsonProperty("TermSt")
    private String termSt;
    @JsonProperty("TermCntr")
    private String termCntr;
    @JsonProperty("TermPstlCode")
    private String termPstlCode;
    @JsonProperty("CustTranAmt1")
    private Double custTranAmt1;
    @JsonProperty("CustTranAmt4")
    private Double custTranAmt4;
    @JsonProperty("PINTries")
    private String pINTries;
    @JsonProperty("AcqrInstIdNum")
    private String acqrInstIdNum;
    @JsonProperty("FrwdInstId")
    private String frwdInstId;
    @JsonProperty("TranAuthSrc")
    private String tranAuthSrc;
    @JsonProperty("CAVVAAV")
    private Integer cavvaav;
    @JsonProperty("AcctType")
    private String acctType;
    @JsonProperty("FIID")
    private String fiid;
    @JsonProperty("BIN")
    private String bin;
    @JsonProperty("PINIndx")
    private String pINIndx;
    @JsonProperty("MmbrNum")
    private String mmbrNum;
    @JsonProperty("CardPrdtType")
    private String cardPrdtType;
    @JsonProperty("CardStat")
    private String cardStat;
    @JsonProperty("CardBlckCode")
    private String cardBlckCode;
    @JsonProperty("TranDateTime")
    private Long tranDateTime;
    @JsonProperty("CardRqstDate")
    private Long cardRqstDate;
    @JsonProperty("CardPINChngDate")
    private Long cardPINChngDate;
    @JsonProperty("LastAdrsChngDate")
    private Long lastAdrsChngDate;
    @JsonProperty("IBK1InstIdNum")
    private String iBK1InstIdNum;
    @JsonProperty("ProdInd")
    private String prodInd;
    @JsonProperty("SqncNum")
    private String sqncNum;
    @JsonProperty("TranRsnCode")
    private String tranRsnCode;
    @JsonProperty("CardVrfyFlag")
    private String cardVrfyFlag;
    @JsonProperty("CVDPrsntFlag")
    private String cVDPrsntFlag;
    @JsonProperty("EMVCardVrfyRslts")
    private String eMVCardVrfyRslts;
    @JsonProperty("CustTranAmt2")
    private Double custTranAmt2;
    @JsonProperty("CustTranAmt3")
    private Double custTranAmt3;
    @JsonProperty("CustTranDate")
    private Long custTranDate;
    @JsonProperty("CredDebInd")
    private String credDebInd;
    @JsonProperty("CashInd")
    private String cashInd;
    @JsonProperty("OrgnlCrncyCode")
    private String orgnlCrncyCode;
    @JsonProperty("AchNum")
    private String achNum;
    @JsonProperty("ScndryAcctNmbr")
    private String scndryAcctNmbr;
    @JsonProperty("OrigWireAcctId")
    private String origWireAcctId;
    @JsonProperty("BenWireAcctId")
    private String benWireAcctId;
    @JsonProperty("TranAmt2")
    private Double tranAmt2;
    @JsonProperty("TranAmt3")
    private Double tranAmt3;
    @JsonProperty("SlsRjctCde")
    private String slsRjctCde;
    @JsonProperty("VisaAdvncAuthScor_Type")
    private String visaAdvncAuthScorType;
    @JsonProperty("AprvlCode")
    private String aprvlCode;
    @JsonProperty("RespCode")
    private String respCode;
    @JsonProperty("OrigWireInstIDNum")
    private String origWireInstIDNum;
    @JsonProperty("OrigWireCntryCode")
    private String origWireCntryCode;
    @JsonProperty("OrigWireCrncyCode")
    private String origWireCrncyCode;
    @JsonProperty("BenWireInstIdNum")
    private String benWireInstIdNum;
    @JsonProperty("BenWireCntryCode")
    private String benWireCntryCode;
    @JsonProperty("BenWireCrncyCode")
    private String benWireCrncyCode;
    @JsonProperty("RealTimeStat")
    private String realTimeStat;
    @JsonProperty("RealTimeDsps")
    private String realTimeDsps;
    @JsonProperty("RealTimeRuleFrd")
    private Integer realTimeRuleFrd;
    @JsonProperty("RealTimeRuleDsps")
    private String realTimeRuleDsps;
    @JsonProperty("RealTimeScore")
    private Integer realTimeScore;

    //Aggregate Attributes
    @JsonProperty("A1_30_0")
    private Double A1_30_0;
    @JsonProperty("A1_30_1")
    private Double A1_30_1;
    @JsonProperty("A1_3_1")
    private Double A1_3_1;
    @JsonProperty("A1_30_2")
    private Double A1_30_2;
    @JsonProperty("A1_30_3")
    private Double A1_30_3;
    @JsonProperty("A1_3_3")
    private Double A1_3_3;
    @JsonProperty("A1_30_4")
    private Double A1_30_4;
    @JsonProperty("A1_3_4")
    private Double A1_3_4;
    @JsonProperty("A1_30_5")
    private Double A1_30_5;
    @JsonProperty("A1_30_6")
    private Double A1_30_6;
    @JsonProperty("A1_3_6")
    private Double A1_3_6;
    @JsonProperty("A1_30_7")
    private Double A1_30_7;
    @JsonProperty("A1_3_7")
    private Double A1_3_7;
    @JsonProperty("A1_30_8")
    private Double A1_30_8;
    @JsonProperty("A1_3_8")
    private Double A1_3_8;
    @JsonProperty("A1_30_9")
    private Double A1_30_9;
    @JsonProperty("A1_30_10")
    private Double A1_30_10;
    @JsonProperty("A1_3_10")
    private Double A1_3_10;
    @JsonProperty("A1_30_11")
    private Double A1_30_11;
    @JsonProperty("A1_3_11")
    private Double A1_3_11;

    @JsonProperty("A2_30_0")
    private Double A2_30_0;
    @JsonProperty("A2_3_0")
    private Double A2_3_0;
    @JsonProperty("A2_30_2")
    private Double A2_30_2;
    @JsonProperty("A2_3_2")
    private Double A2_3_2;
    @JsonProperty("A2_30_3")
    private Double A2_30_3;
    @JsonProperty("A2_3_3")
    private Double A2_3_3;
    @JsonProperty("A2_30_4")
    private Double A2_30_4;
    @JsonProperty("A2_3_4")
    private Double A2_3_4;
    @JsonProperty("A2_30_5")
    private Double A2_30_5;
    @JsonProperty("A2_3_5")
    private Double A2_3_5;
    @JsonProperty("A2_30_6")
    private Double A2_30_6;
    @JsonProperty("A2_3_6")
    private Double A2_3_6;
    @JsonProperty("A2_30_7")
    private Double A2_30_7;
    @JsonProperty("A2_3_7")
    private Double A2_3_7;
    @JsonProperty("A2_30_8")
    private Double A2_30_8;
    @JsonProperty("A2_3_8")
    private Double A2_3_8;
    @JsonProperty("A2_30_9")
    private Double A2_30_9;
    @JsonProperty("A2_3_9")
    private Double A2_3_9;

    @JsonProperty("A5_30_3")
    private Double A5_30_3;
    @JsonProperty("A5_3_3")
    private Double A5_3_3;

    @JsonProperty("C1_30")
    private Double C1_30;
    @JsonProperty("C1_3")
    private Double C1_3;
    @JsonProperty("C2_30")
    private Double C2_30;
    @JsonProperty("C2_3")
    private Double C2_3;
    @JsonProperty("C3_30")
    private Double C3_30;
    @JsonProperty("C3_3")
    private Double C3_3;
    @JsonProperty("C4_30")
    private Double C4_30;
    @JsonProperty("C4_3")
    private Double C4_3;
    @JsonProperty("C5_3")
    private Double C5_3;
    @JsonProperty("C6_30")
    private Double C6_30;
    @JsonProperty("C6_3")
    private Double C6_3;
    @JsonProperty("C7_30")
    private Double C7_30;
    @JsonProperty("C8_30")
    private Double C8_30;
    @JsonProperty("C8_3")
    private Double C8_3;
    @JsonProperty("C8_P_30")
    private Double C8_P_30;
    @JsonProperty("C10")
    private Double C10;
    @JsonProperty("C11")
    private Double C11;

    @JsonProperty("D1")
    private Double D1;
    //@JsonProperty("D3")
    //private Long D3;
    @JsonProperty("E1_30")
    private Double E1_30;
    @JsonProperty("E1_3")
    private Double E1_3;
    @JsonProperty("E2_30")
    private Double E2_30;
    @JsonProperty("E2_3")
    private Double E2_3;
    @JsonProperty("E3_30")
    private Double E3_30;
    @JsonProperty("E3_3")
    private Double E3_3;
    @JsonProperty("F2_30")
    private Double F2_30;
    @JsonProperty("F2_3")
    private Double F2_3;
    @JsonProperty("G1_30")
    private Double G1_30;
    @JsonProperty("G2_3")
    private Double G2_3;
    @JsonProperty("H2_30")
    private Double H2_30;
    @JsonProperty("H2_3")
    private Double H2_3;
    @JsonProperty("H3_30")
    private Double H3_30;
    @JsonProperty("H3_3")
    private Double H3_3;
    @JsonProperty("H4_30")
    private Double H4_30;
    @JsonProperty("H4_3")
    private Double H4_3;
    @JsonProperty("H8_P_30")
    private Double H8_P_30;
    @JsonProperty("H5_30")
    private Double H5_30;
    @JsonProperty("H5_3")
    private Double H5_3;
    @JsonProperty("H7_30")
    private Double H7_30;
    @JsonProperty("H8_30")
    private Double H8_30;
    @JsonProperty("H6_30")
    private Double H6_30;
    @JsonProperty("H8_3")
    private Double H8_3;
    @JsonProperty("H9_30")
    private Double H9_30;
    @JsonProperty("H9_3")
    private Double H9_3;
    @JsonProperty("K1_30")
    private Double K1_30;
    @JsonProperty("K1_3")
    private Double K1_3;
    @JsonProperty("L1")
    private Double L1;
    @JsonProperty("M9")
    private Double M9;
    @JsonProperty("M14")
    private Double M14;
    @JsonProperty("M15")
    private Double M15;
    @JsonProperty("P3_30")
    private Double P3_30;
    @JsonProperty("R1_30")
    private Double R1_30;
    @JsonProperty("R1_3")
    private Double R1_3;
    @JsonProperty("R3_30")
    private Double R3_30;
    @JsonProperty("R3_3")
    private Double R3_3;
    @JsonProperty("R4_30")
    private Double R4_30;
    @JsonProperty("R4_3")
    private Double R4_3;
    @JsonProperty("S2_30")
    private Double S2_30;
    @JsonProperty("S2_3")
    private Double S2_3;
    @JsonProperty("S3_30")
    private Double S3_30;
    @JsonProperty("S3_3")
    private Double S3_3;
    @JsonProperty("S4_3")
    private Double S4_3;
    @JsonProperty("S5_30")
    private Double S5_30;
    @JsonProperty("S5_3")
    private Double S5_3;
    @JsonProperty("S6_3")
    private Double S6_3;
    @JsonProperty("S7_30")
    private Double S7_30;
    @JsonProperty("S7_3")
    private Double S7_3;
    @JsonProperty("S8_30")
    private Double S8_30;
    @JsonProperty("S8_3")
    private Double S8_3;
    @JsonProperty("S9_30")
    private Double S9_30;
    @JsonProperty("S9_3")
    private Double S9_3;
    @JsonProperty("S10_30")
    private Double S10_30;
    @JsonProperty("S10_3")
    private Double S10_3;
    @JsonProperty("S11_30")
    private Double S11_30;
    @JsonProperty("S11_3")
    private Double S11_3;
    @JsonProperty("S12_30")
    private Double S12_30;
    @JsonProperty("S12_3")
    private Double S12_3;
    @JsonProperty("S13_30")
    private Double S13_30;
    @JsonProperty("S13_3")
    private Double S13_3;
    @JsonProperty("S15_30")
    private Double S15_30;
    @JsonProperty("S15_3")
    private Double S15_3;
    @JsonProperty("S16_30")
    private Double S16_30;
    @JsonProperty("S16_3")
    private Double S16_3;
    @JsonProperty("S18_30")
    private Double S18_30;
    @JsonProperty("S19_3")
    private Double S19_3;
    @JsonProperty("S23_30")
    private Double S23_30;
    @JsonProperty("S23_3")
    private Double S23_3;
    @JsonProperty("S24")
    private String S24;
    @JsonProperty("S28_30")
    private Double S28_30;
    @JsonProperty("S29_30")
    private Double S29_30;
    @JsonProperty("S30_30")
    private Double S30_30;
    @JsonProperty("S31_30")
    private Double S31_30;
    @JsonProperty("S32_30")
    private Double S32_30;
    @JsonProperty("S33_30")
    private Double S33_30;
    @JsonProperty("S34_30")
    private Double S34_30;
    @JsonProperty("S35_30")
    private Double S35_30;
    @JsonProperty("S36_30")
    private Double S36_30;
    @JsonProperty("S37_30")
    private Double S37_30;
    @JsonProperty("S38_30")
    private Double S38_30;
    @JsonProperty("S39_30")
    private Double S39_30;
    @JsonProperty("S40_30")
    private Double S40_30;
    @JsonProperty("S41_30")
    private Double S41_30;
    @JsonProperty("S42_30")
    private Double S42_30;
    @JsonProperty("S43_30")
    private Double S43_30;
    @JsonProperty("S44_30")
    private Double S44_30;
    @JsonProperty("S45_30")
    private Double S45_30;
    @JsonProperty("S46_30")
    private Double S46_30;
    @JsonProperty("S47_30")
    private Double S47_30;
    @JsonProperty("S48_30")
    private Double S48_30;
    @JsonProperty("S49_30")
    private Double S49_30;
    @JsonProperty("S50_30")
    private Double S50_30;
    @JsonProperty("S51_30")
    private Double S51_30;
    @JsonProperty("S52_30")
    private Double S52_30;
    @JsonProperty("S53_30")
    private Double S53_30;
    @JsonProperty("S54_30")
    private Double S54_30;
    @JsonProperty("S55_30")
    private Double S55_30;
    @JsonProperty("S56_30")
    private Double S56_30;
    @JsonProperty("T1_30")
    private Double T1_30;
    @JsonProperty("T1_3")
    private Double T1_3;
    @JsonProperty("T2_30")
    private Double T2_30;
    @JsonProperty("T2_3")
    private Double T2_3;
    @JsonProperty("T3_30")
    private Double T3_30;
    @JsonProperty("T3_3")
    private Double T3_3;
    @JsonProperty("T6_30")
    private Double T6_30;
    @JsonProperty("T6_3")
    private Double T6_3;
    @JsonProperty("T9_30")
    private Double T9_30;
    @JsonProperty("T14")
    private Double T14;

    // Previous Transaction Aggregates
    @JsonProperty("P5")
    private Double P5;
    @JsonProperty("P7")
    private Integer P7;
    @JsonProperty("P9")
    private Integer P9;
    @JsonProperty("P10")
    private Integer P10;
    @JsonProperty("P11")
    private Integer P11;
    @JsonProperty("P12")
    private Integer P12;
    @JsonProperty("P13")
    private Integer P3;
    @JsonProperty("P14")
    private Integer P14;
    @JsonProperty("P15")
    private Integer P15;
    @JsonProperty("P17")
    private Double P17;
    @JsonProperty("P18")
    private Double P18;
    @JsonProperty("P19")
    private Double P19;
    @JsonProperty("P20")
    private Double P20;
    @JsonProperty("P22")
    private Double P22;
    @JsonProperty("P24")
    private Double P24;
    @JsonProperty("P25")
    private Double P25;
    @JsonProperty("P31")
    private Double P31;
    @JsonProperty("P32")
    private Double P32;
    @JsonProperty("P33")
    private Double P33;
    @JsonProperty("P34")
    private Long P34;
    @JsonProperty("P35")
    private String P35;
    @JsonProperty("P36")
    private String P36;
    @JsonProperty("P37")
    private String P37;
    @JsonProperty("P38")
    private String P38;
    @JsonProperty("P39")
    private String P39;
    @JsonProperty("P40")
    private String P40;
    @JsonProperty("P41")
    private String P41;
    @JsonProperty("P42")
    private String P42;
    @JsonProperty("CM_3")
    private String CM_3;

    //    Derived Attributes
    @JsonProperty("DA1")
    private Integer DA1;
    @JsonProperty("DA2")
    private Integer DA2;
    @JsonProperty("DA3")
    private Integer DA3;
    @JsonProperty("DA4")
    private Integer DA4;
    @JsonProperty("DA5")
    private Integer DA5;
    @JsonProperty("DA6")
    private Integer DA6;
    @JsonProperty("DA7")
    private Integer DA7;
    @JsonProperty("DA8")
    private Integer DA8;
    @JsonProperty("DA9")
    private Integer DA9;
    @JsonProperty("DA10")
    private Integer DA10;
    @JsonProperty("DA11")
    private Integer DA11;
    @JsonProperty("DA12")
    private Integer DA12;
    @JsonProperty("DA13")
    private String DA13;
    @JsonProperty("DA14")
    private Integer DA14;
    @JsonProperty("DA15")
    private Integer DA15;
    @JsonProperty("DA16")
    private Integer DA16;
    @JsonProperty("DA17")
    private Integer DA17;

    // Indexed attributes
    @JsonProperty("I1")
    private Integer I1;
    //@JsonProperty("I2")
    //private Integer I2;
    @JsonProperty("I3")
    private Integer I3;
    @JsonProperty("I4")
    private Integer I4;
    @JsonProperty("I5")
    private Integer I5;
    @JsonProperty("I6")
    private Integer I6;
    @JsonProperty("I7")
    private Integer I7;
    @JsonProperty("I8")
    private Integer I8;
    @JsonProperty("I9")
    private Integer I9;
    @JsonProperty("I10")
    private Integer I10;
    @JsonProperty("I11")
    private Integer I11;
    @JsonProperty("I12")
    private Integer I12;
    @JsonProperty("BL_1")
    private Integer BL_1;
    @JsonProperty("CL_1")
    private Integer CL_1;
    @JsonProperty("CL_2")
    private Double CL_2;
    @JsonProperty("WD_1")
    private Double WD_1;
    @JsonProperty("WD_2")
    private Integer WD_2;

    //    Raw Attributes
    @JsonProperty("RAW1")
    private Double RAW1;
    @JsonProperty("RAW2")
    private Double RAW2;
    @JsonProperty("RAW3")
    private Double RAW3;

    //POS Aggregate Attributes
    @JsonProperty("P2_3_1")
    private Double P2_3_1;
    @JsonProperty("P2_3_2")
    private Double P2_3_2;
    @JsonProperty("P2_3_3")
    private Double P2_3_3;
    @JsonProperty("P2_3_4")
    private Double P2_3_4;
    @JsonProperty("P2_3_5")
    private Double P2_3_5;
    @JsonProperty("P2_3_6")
    private Double P2_3_6;
    @JsonProperty("P2_3_7")
    private Double P2_3_7;
    @JsonProperty("P2_3_8")
    private Double P2_3_8;
    @JsonProperty("P2_3_9")
    private Double P2_3_9;

    @JsonProperty("P2_30_2")
    private Double P2_30_2;
    @JsonProperty("P2_30_3")
    private Double P2_30_3;
    @JsonProperty("P2_30_4")
    private Double P2_30_4;
    @JsonProperty("P2_30_5")
    private Double P2_30_5;
    @JsonProperty("P2_30_6")
    private Double P2_30_6;
    @JsonProperty("P2_30_7")
    private Double P2_30_7;
    @JsonProperty("P2_30_9")
    private Double P2_30_9;

    //MCC POS Attributes
    @JsonProperty("MP_3_1")
    private Double MP_3_1;
    @JsonProperty("MP_3_2")
    private Double MP_3_2;
    @JsonProperty("MP_3_3")
    private Double MP_3_3;
    @JsonProperty("MP_3_4")
    private Double MP_3_4;
    @JsonProperty("MP_3_5")
    private Double MP_3_5;
    @JsonProperty("MP_3_6")
    private Double MP_3_6;
    @JsonProperty("MP_3_7")
    private Double MP_3_7;
    @JsonProperty("MP_3_8")
    private Double MP_3_8;
    @JsonProperty("MP_3_9")
    private Double MP_3_9;
    @JsonProperty("MP_3_10")
    private Double MP_3_10;
    @JsonProperty("MP_3_11")
    private Double MP_3_11;
    @JsonProperty("MP_3_12")
    private Double MP_3_12;
    @JsonProperty("MP_3_13")
    private Double MP_3_13;
    @JsonProperty("MP_3_14")
    private Double MP_3_14;
    @JsonProperty("MP_3_15")
    private Double MP_3_15;
    @JsonProperty("MP_3_16")
    private Double MP_3_16;
    @JsonProperty("MP_3_17")
    private Double MP_3_17;
    @JsonProperty("MP_3_18")
    private Double MP_3_18;
    @JsonProperty("MP_3_19")
    private Double MP_3_19;
    @JsonProperty("MP_3_20")
    private Double MP_3_20;
    @JsonProperty("MP_30_1")
    private Double MP_30_1;
    @JsonProperty("MP_30_2")
    private Double MP_30_2;
    @JsonProperty("MP_30_3")
    private Double MP_30_3;
    @JsonProperty("MP_30_4")
    private Double MP_30_4;
    @JsonProperty("MP_30_5")
    private Double MP_30_5;
    @JsonProperty("MP_30_6")
    private Double MP_30_6;
    @JsonProperty("MP_30_7")
    private Double MP_30_7;
    @JsonProperty("MP_30_9")
    private Double MP_30_9;
    @JsonProperty("MP_30_10")
    private Double MP_30_10;
    @JsonProperty("MP_30_11")
    private Double MP_30_11;
    @JsonProperty("MP_30_12")
    private Double MP_30_12;
    @JsonProperty("MP_30_13")
    private Double MP_30_13;
    @JsonProperty("MP_30_14")
    private Double MP_30_14;
    @JsonProperty("MP_30_15")
    private Double MP_30_15;
    @JsonProperty("MP_30_16")
    private Double MP_30_16;
    @JsonProperty("MP_30_17")
    private Double MP_30_17;
    @JsonProperty("MP_30_18")
    private Double MP_30_18;
    @JsonProperty("MP_30_19")
    private Double MP_30_19;
    @JsonProperty("MP_30_20")
    private Double MP_30_20;


    //SD POS Attributes
    @JsonProperty("SP6_3")
    private Double SP6_3;
    @JsonProperty("SP10_3")
    private Double SP10_3;
    @JsonProperty("SP4_30")
    private Double SP4_30;
    @JsonProperty("SP5_30")
    private Double SP5_30;
    @JsonProperty("SP7_30")
    private Double SP7_30;
    @JsonProperty("SP8_30")
    private Double SP8_30;
    @JsonProperty("SP9_30")
    private Double SP9_30;
    @JsonProperty("SP11_30")
    private Double SP11_30;

    // token_service_POS
    @JsonProperty("TS1_3")
    private Double TS1_3;
    @JsonProperty("TS1_30")
    private Double TS1_30;
    //Fraud Score
    @JsonProperty("FS")
    private Integer FS;
    @JsonProperty("F3_3")
    private Double F3_3;

    //MEAN
    @JsonProperty("MD_T1_30")
    private Double MD_T1_30;

    @JsonProperty("A4")
    private Double A4;
    @JsonProperty("A3_30")
    private Double A3_30;
    @JsonProperty("C9_30")
    private Double C9_30;
    @JsonProperty("M1_30")
    private Double M1_30;
    @JsonProperty("MD_T2_30")
    private Double MD_T2_30;
    @JsonProperty("M5_30")
    private Double M5_30;
    @JsonProperty("M6_30")
    private Double M6_30;
    @JsonProperty("M7_30")
    private Double M7_30;
    @JsonProperty("M8_30")
    private Double M8_30;
    @JsonProperty("P4")
    private Integer P4;
    @JsonProperty("P6")
    private Double P6;
    @JsonProperty("P8")
    private Integer P8;
    @JsonProperty("P16")
    private Double P16;
    @JsonProperty("P21")
    private Double P21;
    @JsonProperty("P23")
    private Double P23;
    @JsonProperty("P27")
    private Double P27;
    @JsonProperty("P28")
    private Integer P28;
    @JsonProperty("P29")
    private Integer P29;
    @JsonProperty("R2_30")
    private Double R2_30;
    @JsonProperty("S1_30")
    private Integer S1_30;
    @JsonProperty("S14_3")
    private Double S14_3;
    @JsonProperty("S17_3")
    private Double S17_3;
    @JsonProperty("S18_3")
    private Double S18_3;
    @JsonProperty("SP20_3")
    private Double SP20_3;
    @JsonProperty("SP21_3")
    private Double SP21_3;
    @JsonProperty("SP22_3")
    private Double SP22_3;
    @JsonProperty("S14_30")
    private Double S14_30;
    @JsonProperty("S17_30")
    private Double S17_30;
    @JsonProperty("S19_30")
    private Double S19_30;
    @JsonProperty("S20_30")
    private Double S20_30;
    @JsonProperty("S21_30")
    private Double S21_30;
    @JsonProperty("S22_30")
    private Double S22_30;
    @JsonProperty("T5_30")
    private Double T5_30;
    @JsonProperty("T7_30")
    private Double T7_30;
    @JsonProperty("T8_30")
    private Double T8_30;
    @JsonProperty("M_L_30")
    private String M_L_30;

    @JsonProperty("FC_30")
    private Double FC_30;
    @JsonProperty("FC_7")
    private Double FC_7;
    @JsonProperty("FC_B7")
    private Double FC_B7;
    @JsonProperty("EM_30")
    private Double EM_30;
    @JsonProperty("EM_7")
    private Double EM_7;
    @JsonProperty("HM_30")
    private Double HM_30;
    @JsonProperty("HM_7")
    private Double HM_7;

    @JsonProperty("MD_T3_30")
    private Double MD_T3_30;
    @JsonProperty("MD_T3_3")
    private Double MD_T3_3;
    @JsonProperty("MD_T4_30")
    private Double MD_T4_30;
    @JsonProperty("MD_T4_3")
    private Double MD_T4_3;

    @JsonProperty("C2_30_3")
    private Double C2_30_3;
    @JsonProperty("C2_30_4")
    private Double C2_30_4;
    @JsonProperty("C2_30_5")
    private Double C2_30_5;
    @JsonProperty("C2_30_6")
    private Double C2_30_6;
    @JsonProperty("C2_30_7")
    private Double C2_30_7;
    @JsonProperty("C2_30_8")
    private Double C2_30_8;
    @JsonProperty("C2_30_9")
    private Double C2_30_9;
    @JsonProperty("C3_30_3")
    private Double C3_30_3;
    @JsonProperty("C3_30_4")
    private Double C3_30_4;
    @JsonProperty("C3_30_5")
    private Double C3_30_5;
    @JsonProperty("C3_30_6")
    private Double C3_30_6;
    @JsonProperty("C3_30_7")
    private Double C3_30_7;
    @JsonProperty("C3_30_8")
    private Double C3_30_8;
    @JsonProperty("C3_30_9")
    private Double C3_30_9;

    @JsonProperty("HC1_30")
    private Double HC1_30;
    @JsonProperty("HC2_30")
    private Double HC2_30;
    @JsonProperty("HC3_30")
    private Double HC3_30;
    @JsonProperty("HC4_30")
    private Double HC4_30;
    @JsonProperty("HC5_30")
    private Double HC5_30;
    @JsonProperty("HC6_30")
    private Double HC6_30;
    @JsonProperty("HC7_30")
    private Double HC7_30;
    @JsonProperty("HC8_30")
    private Double HC8_30;
    @JsonProperty("CC1_30")
    private Double CC1_30;
    @JsonProperty("CC2_30")
    private Double CC2_30;
    @JsonProperty("CC3_30")
    private Double CC3_30;
    @JsonProperty("CC4_30")
    private Double CC4_30;
    @JsonProperty("SC1_30")
    private Double SC1_30;
    @JsonProperty("SC2_30")
    private Double SC2_30;
    @JsonProperty("SC3_30")
    private Double SC3_30;
    @JsonProperty("SC4_30")
    private Double SC4_30;
    @JsonProperty("SC5_30")
    private Double SC5_30;
    @JsonProperty("SC6_30")
    private Double SC6_30;
    @JsonProperty("SC7_30")
    private Double SC7_30;
    @JsonProperty("SC8_30")
    private Double SC8_30;
    @JsonProperty("SC9_30")
    private Double SC9_30;
    @JsonProperty("SU1_30")
    private Double SU1_30;
    @JsonProperty("SU2_30")
    private Double SU2_30;
    @JsonProperty("SU3_30")
    private Double SU3_30;
    @JsonProperty("SU4_30")
    private Double SU4_30;
    @JsonProperty("SU5_30")
    private Double SU5_30;
    @JsonProperty("SU6_30")
    private Double SU6_30;
    @JsonProperty("SU7_30")
    private Double SU7_30;
    @JsonProperty("SU8_30")
    private Double SU8_30;
    @JsonProperty("SU9_30")
    private Double SU9_30;
    @JsonProperty("SU10_30")
    private Double SU10_30;
    @JsonProperty("MC_30_1")
    private Double MC_30_1;
    @JsonProperty("MC_30_2")
    private Double MC_30_2;
    @JsonProperty("MC_30_3")
    private Double MC_30_3;
    @JsonProperty("MC_30_4")
    private Double MC_30_4;
    @JsonProperty("MC_30_5")
    private Double MC_30_5;
    @JsonProperty("MC_30_6")
    private Double MC_30_6;
    @JsonProperty("MC_30_7")
    private Double MC_30_7;
    @JsonProperty("MC_30_8")
    private Double MC_30_8;
    @JsonProperty("MC_30_9")
    private Double MC_30_9;
    @JsonProperty("MC_30_10")
    private Double MC_30_10;
    @JsonProperty("MC_30_11")
    private Double MC_30_11;
    @JsonProperty("MC_30_12")
    private Double MC_30_12;
    @JsonProperty("MC_30_13")
    private Double MC_30_13;
    @JsonProperty("MC_3_1")
    private Double MC_3_1;
    @JsonProperty("MC_3_2")
    private Double MC_3_2;
    @JsonProperty("MC_3_3")
    private Double MC_3_3;
    @JsonProperty("MC_3_4")
    private Double MC_3_4;
    @JsonProperty("MC_3_5")
    private Double MC_3_5;
    @JsonProperty("MC_3_6")
    private Double MC_3_6;
    @JsonProperty("MC_3_7")
    private Double MC_3_7;
    @JsonProperty("MC_3_8")
    private Double MC_3_8;
    @JsonProperty("MC_3_9")
    private Double MC_3_9;
    @JsonProperty("MC_3_10")
    private Double MC_3_10;
    @JsonProperty("MC_3_11")
    private Double MC_3_11;
    @JsonProperty("MC_3_12")
    private Double MC_3_12;
    @JsonProperty("MC_3_13")
    private Double MC_3_13;
    @JsonProperty("MU_30_1")
    private Double MU_30_1;
    @JsonProperty("MU_30_2")
    private Double MU_30_2;
    @JsonProperty("MU_30_3")
    private Double MU_30_3;
    @JsonProperty("MU_30_4")
    private Double MU_30_4;
    @JsonProperty("MU_30_5")
    private Double MU_30_5;
    @JsonProperty("MU_30_6")
    private Double MU_30_6;
    @JsonProperty("MU_30_7")
    private Double MU_30_7;
    @JsonProperty("MU_30_8")
    private Double MU_30_8;
    @JsonProperty("MU_30_9")
    private Double MU_30_9;
    @JsonProperty("MU_30_10")
    private Double MU_30_10;
    @JsonProperty("MU_30_11")
    private Double MU_30_11;
    @JsonProperty("MU_30_12")
    private Double MU_30_12;
    @JsonProperty("MU_30_13")
    private Double MU_30_13;
    @JsonProperty("MU_30_14")
    private Double MU_30_14;
    @JsonProperty("MU_30_15")
    private Double MU_30_15;
    @JsonProperty("MU_30_16")
    private Double MU_30_16;
    @JsonProperty("MU_30_17")
    private Double MU_30_17;
    @JsonProperty("MU_30_18")
    private Double MU_30_18;
    @JsonProperty("MU_30_19")
    private Double MU_30_19;
    @JsonProperty("MU_30_20")
    private Double MU_30_20;
    @JsonProperty("MU_3_1")
    private Double MU_3_1;
    @JsonProperty("MU_3_2")
    private Double MU_3_2;
    @JsonProperty("MU_3_3")
    private Double MU_3_3;
    @JsonProperty("MU_3_4")
    private Double MU_3_4;
    @JsonProperty("MU_3_5")
    private Double MU_3_5;
    @JsonProperty("MU_3_6")
    private Double MU_3_6;
    @JsonProperty("MU_3_7")
    private Double MU_3_7;
    @JsonProperty("MU_3_8")
    private Double MU_3_8;
    @JsonProperty("MU_3_9")
    private Double MU_3_9;
    @JsonProperty("MU_3_10")
    private Double MU_3_10;
    @JsonProperty("MU_3_11")
    private Double MU_3_11;
    @JsonProperty("MU_3_12")
    private Double MU_3_12;
    @JsonProperty("MU_3_13")
    private Double MU_3_13;
    @JsonProperty("MU_3_14")
    private Double MU_3_14;
    @JsonProperty("MU_3_15")
    private Double MU_3_15;
    @JsonProperty("MU_3_16")
    private Double MU_3_16;
    @JsonProperty("MU_3_17")
    private Double MU_3_17;
    @JsonProperty("MU_3_18")
    private Double MU_3_18;
    @JsonProperty("MU_3_19")
    private Double MU_3_19;
    @JsonProperty("MU_3_20")
    private Double MU_3_20;
    @JsonProperty("MC_T1_30")
    private Double MC_T1_30;
    @JsonProperty("MC_T2_30")
    private Double MC_T2_30;
    @JsonProperty("MC_T3_30")
    private Double MC_T3_30;
    @JsonProperty("MU_T1_30")
    private Double MU_T1_30;
    @JsonProperty("MU_T2_30")
    private Double MU_T2_30;
    @JsonProperty("MU_T3_30")
    private Double MU_T3_30;
    @JsonProperty("FC_3")
    private Double FC_3;
    @JsonProperty("HM1_30")
    private Double HM1_30;
    @JsonProperty("HM2_30")
    private Double HM2_30;
    @JsonProperty("HM3_30")
    private Double HM3_30;
    @JsonProperty("HM4_30")
    private Double HM4_30;
    @JsonProperty("MR1_30")
    private Double MR1_30;
    @JsonProperty("MR2_30")
    private Double MR2_30;
    @JsonProperty("MR3_30")
    private Double MR3_30;
    @JsonProperty("TM1_30")
    private Double TM1_30;
    @JsonProperty("TM2_30")
    private Double TM2_30;
    @JsonProperty("PM")
    private Long PM;
    @JsonProperty("M1_1")
    private Double M1_1;
    @JsonProperty("M1_7")
    private Double M1_7;
    @JsonProperty("TC_30")
    private Double TC_30;
    @JsonProperty("TC1_30")
    private Double TC1_30;
    @JsonProperty("CP1_30")
    private Integer CP1_30;
    @JsonProperty("CP2_30")
    private Integer CP2_30;
    @JsonProperty("CP3_30")
    private Integer CP3_30;
    @JsonProperty("CP1_3")
    private Integer CP1_3;
    @JsonProperty("CP2_3")
    private Integer CP2_3;
    @JsonProperty("CP3_3")
    private Integer CP3_3;
    @JsonProperty("C1_L")
    private String C1_L;
    @JsonProperty("C2_L")
    private String C2_L;
    @JsonProperty("C3_L")
    private String C3_L;
    @JsonProperty("CS_30")
    private Double CS_30;
    @JsonProperty("CU_30")
    private Double CU_30;
    @JsonProperty("TC_1")
    private Double TC_1;

    @JsonProperty("WD_1_60")
    private Double WD_1_60;

    @JsonProperty("M_S_60")
    private String M_S_60;
    @JsonProperty("FM_60")
    private Double FM_60;

    @JsonProperty("CU1_L")
    private String CU1_L;
    @JsonProperty("CU2_L")
    private String CU2_L;
    @JsonProperty("CU3_L")
    private String CU3_L;

    @JsonProperty("TS1")
    private String TS1;

    /**
     * Gets the Tiebreaker detail
     *
     * @return a <code> string </code>
     * specifying the Tiebreaker detail
     */

    public String getTiebreaker() {
        return tiebreaker;
    }

    /**
     * Sets the Tiebreaker detail
     *
     * @param tiebreaker the Tiebreaker detail
     */
    public void setTiebreaker(String tiebreaker) {
        this.tiebreaker = tiebreaker;
    }

    /**
     * Gets the fraud count previous 30 days based on merchant aggregate detail
     *
     * @return a <code> string </code>
     * specifying the fraud count previous 30 days based on merchant aggregate detail
     */

    public Double getFC_30() {
        return FC_30;
    }

    /**
     * Sets the fraud count previous 30 days based on merchant aggregate detail
     *
     * @param FC_30 the fraud count previous 30 days based on merchant aggregate detail
     */

    public void setFC_30(Double FC_30) {
        this.FC_30 = FC_30;
    }

    /**
     * Gets the fraud count previous 7 days based on merchant aggregate detail
     *
     * @return a <code> string </code>
     * specifying the fraud count previous 7 days based on merchant aggregate detail
     */

    public Double getFC_7() {
        return FC_7;
    }

    /**
     * Sets the fraud count previous 7 days based on merchant aggregate detail
     *
     * @param FC_7 the fraud count previous 7 days based on merchant aggregate detail
     */

    public void setFC_7(Double FC_7) {
        this.FC_7 = FC_7;
    }

    /**
     * Gets the fraud binary flag previous 7 days based on merchant aggregate detail
     *
     * @return a <code> string </code>
     * specifying the fraud binary flag previous 7 days based on merchant aggregate detail
     */
    public Double getFC_B7() {
        return FC_B7;
    }

    /**
     * Sets the fraud binary flag previous 7 days based on merchant aggregate detail
     *
     * @param FC_B7 the fraud binary flag previous 7 days based on merchant aggregate detail
     */
    public void setFC_B7(Double FC_B7) {
        this.FC_B7 = FC_B7;
    }

    /**
     * Gets the RecordSourceId detail
     *
     * @return a <code> integer </code>
     * specifying the RecordSourceId detail
     */
    public Integer getRecordSourceId() {
        return recordSourceId;
    }

    /**
     * Sets the  RecordSourceId detail
     *
     * @param recordSourceId the RecordSourceId detail
     */
    public void setRecordSourceId(Integer recordSourceId) {
        this.recordSourceId = recordSourceId;
    }

    /**
     * Gets the PAN detail
     *
     * @return a <code> string </code>
     * specifying the PAN detail
     */
    public String getPan() {
        return pan;
    }

    /**
     * Sets the PAN detail
     *
     * @param pan the PAN detail
     */
    public void setPan(String pan) {
        this.pan = pan;
    }

    /**
     * Gets the RETLID detail
     *
     * @return a <code> string </code>
     * specifying the RETLID detail
     */
    public String getRetlid() {
        return retlid;
    }

    /**
     * Sets the RETLID detail
     *
     * @param retlid the RETLID detail
     */
    public void setRetlid(String retlid) {
        this.retlid = retlid;
    }

    /**
     * Gets the AcctNum detail
     *
     * @return a <code> string </code>
     * specifying the AcctNum detail
     */
    public String getAcctNum() {
        return acctNum;
    }

    /**
     * Sets the AcctNum detail
     *
     * @param acctNum the AcctNum detail
     */
    public void setAcctNum(String acctNum) {
        this.acctNum = acctNum;
    }

    /**
     * Gets the TERMID detail
     *
     * @return a <code> string </code>
     * specifying the TERMID detail
     */
    public String getTermid() {
        return termid;
    }

    /**
     * Sets the TERMID detail
     *
     * @param termid the TERMID detail
     */
    public void setTermid(String termid) {
        this.termid = termid;
    }

    /**
     * Gets the TranCode detail
     *
     * @return a <code> string </code>
     * specifying the TranCode detail
     */
    public String getTranCode() {
        return tranCode;
    }

    /**
     * Sets the TranCode detail
     *
     * @param tranCode the TranCode detail
     */
    public void setTranCode(String tranCode) {
        this.tranCode = tranCode;
    }

    /**
     * Gets the auth_src detail
     *
     * @return a <code> integer </code>
     * specifying the auth_src detail
     */
    public Integer getDA2() {
        return DA2;
    }

    /**
     * Sets the auth_src detail
     *
     * @param DA2 the auth_src detail
     */
    public void setDA2(Integer DA2) {
        this.DA2 = DA2;
    }

    /**
     * Gets the credit_card_flag detail
     *
     * @return a <code> integer </code>
     * specifying the credit_card_flag detail
     */
    public Integer getDA4() {
        return DA4;
    }

    /**
     * Sets the credit_card_flag detail
     *
     * @param DA4 the credit_card_flag detail
     */
    public void setDA4(Integer DA4) {
        this.DA4 = DA4;
    }

    /**
     * Gets the TranAmt1 detail
     *
     * @return a <code> double </code>
     * specifying the TranAmt1 detail
     */
    public Double getTranAmt1() {
        return tranAmt1;
    }

    /**
     * Sets the TranAmt1 detail
     *
     * @param tranAmt1 the TranAmt1 detail
     */
    public void setTranAmt1(Double tranAmt1) {
        this.tranAmt1 = tranAmt1;
    }

    /**
     * Gets the MsgType detail
     *
     * @return a <code> string </code>
     * specifying the MsgType detail
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * Sets the MsgType detail
     *
     * @param msgType the MsgType detail
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

//    /**
//     * Gets the crdreqstdays detail
//     *
//     * @return a <code> integer </code>
//     * specifying the crdreqstdays detail
//     */
//    public Long getD3() {
//        return D3;
//    }

//    /**
//     * Sets the crdreqstdays detail
//     *
//     * @param d3 the crdreqstdays detail
//     */
//    public void setD3(Long d3) {
//        D3 = d3;
//    }

    /**
     * Gets the prev_date detail
     *
     * @return a <code> integer </code>
     * specifying the prev_date detail
     */
    public Long getP34() {
        return P34;
    }

    /**
     * Sets the prev_date detail
     *
     * @param p34 the prev_date detail
     */
    public void setP34(Long p34) {
        P34 = p34;
    }

    /**
     * Gets the PontOfSrvcCondCode detail
     *
     * @return a <code> string </code>
     * specifying the PontOfSrvcCondCode detail
     */
    public String getPontOfSrvcCondCode() {
        return pontOfSrvcCondCode;
    }

    /**
     * Sets the PontOfSrvcCondCode detail
     *
     * @param pontOfSrvcCondCode the PontOfSrvcCondCode detail
     */
    public void setPontOfSrvcCondCode(String pontOfSrvcCondCode) {
        this.pontOfSrvcCondCode = pontOfSrvcCondCode;
    }

    /**
     * Gets the PontOfSrvceEntryMode detail
     *
     * @return a <code> string </code>
     * specifying the PontOfSrvceEntryMode detail
     */
    public String getPontOfSrvceEntryMode() {
        return pontOfSrvceEntryMode;
    }

    /**
     * Sets the PontOfSrvceEntryMode detail
     *
     * @param pontOfSrvceEntryMode the PontOfSrvceEntryMode detail
     */
    public void setPontOfSrvceEntryMode(String pontOfSrvceEntryMode) {
        this.pontOfSrvceEntryMode = pontOfSrvceEntryMode;
    }

    /**
     * Gets the EComFlag detail
     *
     * @return a <code> string </code>
     * specifying the EComFlag detail
     */
    public String geteComFlag() {
        return eComFlag;
    }

    /**
     * Sets the EComFlag detail
     *
     * @param eComFlag the EComFlag detail
     */
    public void seteComFlag(String eComFlag) {
        this.eComFlag = eComFlag;
    }

    /**
     * Gets the EMVTrmnlVrfyRslt detail
     *
     * @return a <code> string </code>
     * specifying the EMVTrmnlVrfyRslt detail
     */
    public String geteMVTrmnlVrfyRslt() {
        return eMVTrmnlVrfyRslt;
    }

    /**
     * Sets the EMVTrmnlVrfyRslt detail
     *
     * @param eMVTrmnlVrfyRslt the EMVTrmnlVrfyRslt detail
     */
    public void seteMVTrmnlVrfyRslt(String eMVTrmnlVrfyRslt) {
        this.eMVTrmnlVrfyRslt = eMVTrmnlVrfyRslt;
    }

    /**
     * Gets the EMVUsrFlr detail
     *
     * @return a <code> string </code>
     * specifying the EMVUsrFlr detail
     */
    public String geteMVUsrFlr() {
        return eMVUsrFlr;
    }

    /**
     * Sets the EMVUsrFlr detail
     *
     * @param eMVUsrFlr the EMVUsrFlr detail
     */
    public void seteMVUsrFlr(String eMVUsrFlr) {
        this.eMVUsrFlr = eMVUsrFlr;
    }

    /**
     * Gets the RtlrSICCode detail
     *
     * @return a <code> string </code>
     * specifying the RtlrSICCode detail
     */
    public String getRtlrSICCode() {
        return rtlrSICCode;
    }

    /**
     * Sets the RtlrSICCode detail
     *
     * @param rtlrSICCode the RtlrSICCode detail
     */
    public void setRtlrSICCode(String rtlrSICCode) {
        this.rtlrSICCode = rtlrSICCode;
    }

    /**
     * Gets the TermNameLoc detail
     *
     * @return a <code> string </code>
     * specifying the TermNameLoc detail
     */
    public String getTermNameLoc() {
        return termNameLoc;
    }

    /**
     * Sets the TermNameLoc detail
     *
     * @param termNameLoc the TermNameLoc detail
     */
    public void setTermNameLoc(String termNameLoc) {
        this.termNameLoc = termNameLoc;
    }

    /**
     * Gets the TermCity detail
     *
     * @return a <code> string </code>
     * specifying the TermCity detail
     */
    public String getTermCity() {
        return termCity;
    }

    /**
     * Sets the TermCity detail
     *
     * @param termCity the TermCity detail
     */
    public void setTermCity(String termCity) {
        this.termCity = termCity;
    }

    /**
     * Gets the TermSt detail
     *
     * @return a <code> string </code>
     * specifying the TermSt detail
     */
    public String getTermSt() {
        return termSt;
    }

    /**
     * Sets the TermSt detail
     *
     * @param termSt the TermSt detail
     */
    public void setTermSt(String termSt) {
        this.termSt = termSt;
    }

    /**
     * Gets the TermCntr detail
     *
     * @return a <code> string </code>
     * specifying the TermCntr detail
     */
    public String getTermCntr() {
        return termCntr;
    }

    /**
     * Sets the TermCntr detail
     *
     * @param termCntr the TermCntr detail
     */
    public void setTermCntr(String termCntr) {
        this.termCntr = termCntr;
    }

    /**
     * Gets the TermPstlCode detail
     *
     * @return a <code> string </code>
     * specifying the TermPstlCode detail
     */
    public String getTermPstlCode() {
        return termPstlCode;
    }

    /**
     * Sets the TermPstlCode detail
     *
     * @param termPstlCode the TermPstlCode detail
     */
    public void setTermPstlCode(String termPstlCode) {
        this.termPstlCode = termPstlCode;
    }

    /**
     * Gets the CustTranAmt1 detail
     *
     * @return a <code> string </code>
     * specifying the CustTranAmt1 detail
     */
    public Double getCustTranAmt1() {
        return custTranAmt1;
    }

    /**
     * Sets the CustTranAmt1 detail
     *
     * @param custTranAmt1 the CustTranAmt1 detail
     */
    public void setCustTranAmt1(Double custTranAmt1) {
        this.custTranAmt1 = custTranAmt1;
    }

    /**
     * Gets the CustTranAmt4 detail
     *
     * @return a <code> string </code>
     * specifying the CustTranAmt4 detail
     */
    public Double getCustTranAmt4() {
        return custTranAmt4;
    }

    /**
     * Sets the CustTranAmt4 detail
     *
     * @param custTranAmt4 the CustTranAmt4 detail
     */
    public void setCustTranAmt4(Double custTranAmt4) {
        this.custTranAmt4 = custTranAmt4;
    }

    /**
     * Gets the PINTries detail
     *
     * @return a <code> string </code>
     * specifying the PINTries detail
     */
    public String getpINTries() {
        return pINTries;
    }

    /**
     * Sets the PINTries details
     *
     * @param pINTries the PINTries details
     */
    public void setpINTries(String pINTries) {
        this.pINTries = pINTries;
    }

    /**
     * Gets the AcqrInstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the AcqrInstIdNum detail
     */
    public String getAcqrInstIdNum() {
        return acqrInstIdNum;
    }

    /**
     * Sets the AcqrInstIdNum detail
     *
     * @param acqrInstIdNum the AcqrInstIdNum detail
     */
    public void setAcqrInstIdNum(String acqrInstIdNum) {
        this.acqrInstIdNum = acqrInstIdNum;
    }

    /**
     * Gets the FrwdInstId detail
     *
     * @return a <code> string </code>
     * specifying the FrwdInstId detail
     */
    public String getFrwdInstId() {
        return frwdInstId;
    }

    /**
     * Sets the FrwdInstId detail
     *
     * @param frwdInstId the FrwdInstId detail
     */
    public void setFrwdInstId(String frwdInstId) {
        this.frwdInstId = frwdInstId;
    }

    /**
     * Gets the TranAuthSrc detail
     *
     * @return a <code> string </code>
     * specifying the TranAuthSrc detail
     */
    public String getTranAuthSrc() {
        return tranAuthSrc;
    }

    /**
     * Sets the TranAuthSrc detail
     *
     * @param tranAuthSrc the TranAuthSrc detail
     */
    public void setTranAuthSrc(String tranAuthSrc) {
        this.tranAuthSrc = tranAuthSrc;
    }

    /**
     * Gets the CAVVAAV detail
     *
     * @return a <code> integer </code>
     * specifying the CAVVAAV detail
     */
    public Integer getCavvaav() {
        return cavvaav;
    }

    /**
     * Sets the CAVVAAV detail
     *
     * @param cavvaav the CAVVAAV detail
     */
    public void setCavvaav(Integer cavvaav) {
        this.cavvaav = cavvaav;
    }

    /**
     * Gets the AcctType detail
     *
     * @return a <code> string </code>
     * specifying the AcctType detail
     */
    public String getAcctType() {
        return acctType;
    }

    /**
     * Sets the AcctType detail
     *
     * @param acctType the AcctType detail
     */
    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    /**
     * Gets the FIID detail
     *
     * @return a <code> string </code>
     * specifying the FIID detail
     */
    public String getFiid() {
        return fiid;
    }

    /**
     * Sets the FIID detail
     *
     * @param fiid the FIID detail
     */
    public void setFiid(String fiid) {
        this.fiid = fiid;
    }

    /**
     * Gets the BIN detail
     *
     * @return a <code> string </code>
     * specifying the BIN detail
     */
    public String getBin() {
        return bin;
    }

    /**
     * Sets the BIN detail
     *
     * @param bin the BIN detail
     */
    public void setBin(String bin) {
        this.bin = bin;
    }

    /**
     * Gets the PINIndx detail
     *
     * @return a <code> string </code>
     * specifying the PINIndx detail
     */
    public String getpINIndx() {
        return pINIndx;
    }

    /**
     * Sets the PINIndx detail
     *
     * @param pINIndx the PINIndx detail
     */
    public void setpINIndx(String pINIndx) {
        this.pINIndx = pINIndx;
    }

    /**
     * Gets the MmbrNum detail
     *
     * @return a <code> string </code>
     * specifying the MmbrNum detail
     */
    public String getMmbrNum() {
        return mmbrNum;
    }

    /**
     * Sets the MmbrNum detail
     *
     * @param mmbrNum the MmbrNum detail
     */
    public void setMmbrNum(String mmbrNum) {
        this.mmbrNum = mmbrNum;
    }

    /**
     * Gets the CardPrdtType detail
     *
     * @return a <code> string </code>
     * specifying the CardPrdtType detail
     */
    public String getCardPrdtType() {
        return cardPrdtType;
    }

    /**
     * Sets the CardPrdtType detail
     *
     * @param cardPrdtType the CardPrdtType detail
     */
    public void setCardPrdtType(String cardPrdtType) {
        this.cardPrdtType = cardPrdtType;
    }

    /**
     * Gets the CardStat detail
     *
     * @return a <code> string </code>
     * specifying the CardStat detail
     */
    public String getCardStat() {
        return cardStat;
    }

    /**
     * Sets the CardStat detail
     *
     * @param cardStat the CardStat detail
     */
    public void setCardStat(String cardStat) {
        this.cardStat = cardStat;
    }

    /**
     * Gets the CardBlckCode detail
     *
     * @return a <code> string </code>
     * specifying the CardBlckCode detail
     */
    public String getCardBlckCode() {
        return cardBlckCode;
    }

    /**
     * Sets the CardBlckCode detail
     *
     * @param cardBlckCode the CardBlckCode detail
     */
    public void setCardBlckCode(String cardBlckCode) {
        this.cardBlckCode = cardBlckCode;
    }

    /**
     * Gets the TranDateTime detail
     *
     * @return a <code> long </code>
     * specifying the TranDateTime detail
     */
    public Long getTranDateTime() {
        return tranDateTime;
    }

    /**
     * Sets the TranDateTime detail
     *
     * @param tranDateTime the TranDateTime detail
     */
    public void setTranDateTime(Long tranDateTime) {
        this.tranDateTime = tranDateTime;
    }

    /**
     * Gets the CardRqstDate detail
     *
     * @return a <code> long </code>
     * specifying the CardRqstDate detail
     */
    public Long getCardRqstDate() {
        return cardRqstDate;
    }

    /**
     * Sets the CardRqstDate detail
     *
     * @param cardRqstDate the CardRqstDate detail
     */
    public void setCardRqstDate(Long cardRqstDate) {
        this.cardRqstDate = cardRqstDate;
    }

    /**
     * Gets the CardPINChngDate detail
     *
     * @return a <code> long </code>
     * specifying the CardPINChngDate detail
     */
    public Long getCardPINChngDate() {
        return cardPINChngDate;
    }

    /**
     * Sets the CardPINChngDate detail
     *
     * @param cardPINChngDate the CardPINChngDate detail
     */
    public void setCardPINChngDate(Long cardPINChngDate) {
        this.cardPINChngDate = cardPINChngDate;
    }

    /**
     * Gets the LastAdrsChngDate detail
     *
     * @return a <code> long </code>
     * specifying the LastAdrsChngDate detail
     */
    public Long getLastAdrsChngDate() {
        return lastAdrsChngDate;
    }

    /**
     * Sets the LastAdrsChngDate detail
     *
     * @param lastAdrsChngDate the LastAdrsChngDate detail
     */
    public void setLastAdrsChngDate(Long lastAdrsChngDate) {
        this.lastAdrsChngDate = lastAdrsChngDate;
    }

    /**
     * Gets the IBK1InstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the IBK1InstIdNum detail
     */
    public String getiBK1InstIdNum() {
        return iBK1InstIdNum;
    }

    /**
     * Sets the IBK1InstIdNum detail
     *
     * @param iBK1InstIdNum the IBK1InstIdNum detail
     */
    public void setiBK1InstIdNum(String iBK1InstIdNum) {
        this.iBK1InstIdNum = iBK1InstIdNum;
    }

    /**
     * Gets the ProdInd detail
     *
     * @return a <code> string </code>
     * specifying the ProdInd detail
     */
    public String getProdInd() {
        return prodInd;
    }

    /**
     * Sets the ProdInd detail
     *
     * @param prodInd the ProdInd detail
     */
    public void setProdInd(String prodInd) {
        this.prodInd = prodInd;
    }

    /**
     * Gets the SqncNum detail
     *
     * @return a <code> string </code>
     * specifying the SqncNum detail
     */
    public String getSqncNum() {
        return sqncNum;
    }

    /**
     * Sets the SqncNum detail
     *
     * @param sqncNum the SqncNum detail
     */
    public void setSqncNum(String sqncNum) {
        this.sqncNum = sqncNum;
    }

    /**
     * Gets the TranRsnCode detail
     *
     * @return a <code> string </code>
     * specifying the TranRsnCode detail
     */
    public String getTranRsnCode() {
        return tranRsnCode;
    }

    /**
     * Sets the TranRsnCode detail
     *
     * @param tranRsnCode the TranRsnCode detail
     */
    public void setTranRsnCode(String tranRsnCode) {
        this.tranRsnCode = tranRsnCode;
    }

    /**
     * Gets the CardVrfyFlag detail
     *
     * @return a <code> string </code>
     * specifying the CardVrfyFlag detail
     */
    public String getCardVrfyFlag() {
        return cardVrfyFlag;
    }

    /**
     * Sets the CardVrfyFlag detail
     *
     * @param cardVrfyFlag the CardVrfyFlag detail
     */
    public void setCardVrfyFlag(String cardVrfyFlag) {
        this.cardVrfyFlag = cardVrfyFlag;
    }

    /**
     * Gets the CVDPrsntFlag detail
     *
     * @return a <code> string </code>
     * specifying the CVDPrsntFlag detail
     */
    public String getcVDPrsntFlag() {
        return cVDPrsntFlag;
    }

    /**
     * Sets the CVDPrsntFlag detail
     *
     * @param cVDPrsntFlag the CVDPrsntFlag detail
     */
    public void setcVDPrsntFlag(String cVDPrsntFlag) {
        this.cVDPrsntFlag = cVDPrsntFlag;
    }

    /**
     * Gets the EMVCardVrfyRslts detail
     *
     * @return a <code> string </code>
     * specifying the EMVCardVrfyRslts detail
     */
    public String geteMVCardVrfyRslts() {
        return eMVCardVrfyRslts;
    }

    /**
     * Sets the EMVCardVrfyRslts detail
     *
     * @param eMVCardVrfyRslts the EMVCardVrfyRslts detail
     */
    public void seteMVCardVrfyRslts(String eMVCardVrfyRslts) {
        this.eMVCardVrfyRslts = eMVCardVrfyRslts;
    }

    /**
     * Gets the CustTranAmt2 detail
     *
     * @return a <code> double </code>
     * specifying the CustTranAmt2 detail
     */
    public Double getCustTranAmt2() {
        return custTranAmt2;
    }

    /**
     * Sets the CustTranAmt2 detail
     *
     * @param custTranAmt2 the CustTranAmt2 detail
     */
    public void setCustTranAmt2(Double custTranAmt2) {
        this.custTranAmt2 = custTranAmt2;
    }

    /**
     * Gets the CustTranAmt3 detail
     *
     * @return a <code> double </code>
     * specifying the CustTranAmt3 detail
     */
    public Double getCustTranAmt3() {
        return custTranAmt3;
    }

    /**
     * Sets the CustTranAmt3 detail
     *
     * @param custTranAmt3 the CustTranAmt3 detail
     */
    public void setCustTranAmt3(Double custTranAmt3) {
        this.custTranAmt3 = custTranAmt3;
    }

    /**
     * Gets the CustTranDate detail
     *
     * @return a <code> long </code>
     * specifying the CustTranDate detail
     */
    public Long getCustTranDate() {
        return custTranDate;
    }

    /**
     * Sets the CustTranDate detail
     *
     * @param custTranDate the CustTranDate detail
     */
    public void setCustTranDate(Long custTranDate) {
        this.custTranDate = custTranDate;
    }

    /**
     * Gets the CredDebInd detail
     *
     * @return a <code> string </code>
     * specifying the CredDebInd detail
     */
    public String getCredDebInd() {
        return credDebInd;
    }

    /**
     * Sets the CredDebInd detail
     *
     * @param credDebInd the CredDebInd detail
     */
    public void setCredDebInd(String credDebInd) {
        this.credDebInd = credDebInd;
    }

    /**
     * Gets the CashInd detail
     *
     * @return a <code> string </code>
     * specifying the CashInd detail
     */
    public String getCashInd() {
        return cashInd;
    }

    /**
     * Sets the CashInd detail
     *
     * @param cashInd the CashInd detail
     */
    public void setCashInd(String cashInd) {
        this.cashInd = cashInd;
    }

    /**
     * Gets the OrgnlCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the OrgnlCrncyCode detail
     */
    public String getOrgnlCrncyCode() {
        return orgnlCrncyCode;
    }

    /**
     * Sets the OrgnlCrncyCode detail
     *
     * @param orgnlCrncyCode the OrgnlCrncyCode detail
     */
    public void setOrgnlCrncyCode(String orgnlCrncyCode) {
        this.orgnlCrncyCode = orgnlCrncyCode;
    }

    /**
     * Gets the AchNum detail
     *
     * @return a <code> string </code>
     * specifying the AchNum detail
     */
    public String getAchNum() {
        return achNum;
    }

    /**
     * Sets the AchNum detail
     *
     * @param achNum the AchNum detail
     */
    public void setAchNum(String achNum) {
        this.achNum = achNum;
    }

    /**
     * Gets the ScndryAcctNmbr detail
     *
     * @return a <code> string </code>
     * specifying the ScndryAcctNmbr detail
     */
    public String getScndryAcctNmbr() {
        return scndryAcctNmbr;
    }

    /**
     * Sets the ScndryAcctNmbr detail
     *
     * @param scndryAcctNmbr the ScndryAcctNmbr detail
     */
    public void setScndryAcctNmbr(String scndryAcctNmbr) {
        this.scndryAcctNmbr = scndryAcctNmbr;
    }

    /**
     * Gets the OrigWireAcctId detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireAcctId detail
     */
    public String getOrigWireAcctId() {
        return origWireAcctId;
    }

    /**
     * Sets the OrigWireAcctId detail
     *
     * @param origWireAcctId the OrigWireAcctId detail
     */
    public void setOrigWireAcctId(String origWireAcctId) {
        this.origWireAcctId = origWireAcctId;
    }

    /**
     * Gets the BenWireAcctId detail
     *
     * @return a <code> string </code>
     * specifying the BenWireAcctId detail
     */
    public String getBenWireAcctId() {
        return benWireAcctId;
    }

    /**
     * Sets the BenWireAcctId detail
     *
     * @param benWireAcctId the BenWireAcctId detail
     */
    public void setBenWireAcctId(String benWireAcctId) {
        this.benWireAcctId = benWireAcctId;
    }

    /**
     * Gets the TranAmt2 detail
     *
     * @return a <code> string </code>
     * specifying the TranAmt2 detail
     */
    public Double getTranAmt2() {
        return tranAmt2;
    }

    /**
     * Sets the TranAmt2 detail
     *
     * @param tranAmt2 the TranAmt2 detail
     */
    public void setTranAmt2(Double tranAmt2) {
        this.tranAmt2 = tranAmt2;
    }

    /**
     * Gets the TranAmt3 detail
     *
     * @return a <code> string </code>
     * specifying the TranAmt3 detail
     */
    public Double getTranAmt3() {
        return tranAmt3;
    }

    /**
     * Sets the TranAmt3 detail
     *
     * @param tranAmt3 the TranAmt3 detail
     */
    public void setTranAmt3(Double tranAmt3) {
        this.tranAmt3 = tranAmt3;
    }

    /**
     * Gets the SlsRjctCde detail
     *
     * @return a <code> string </code>
     * specifying the SlsRjctCde detail
     */
    public String getSlsRjctCde() {
        return slsRjctCde;
    }

    /**
     * Sets the SlsRjctCde detail
     *
     * @param slsRjctCde the SlsRjctCde detail
     */
    public void setSlsRjctCde(String slsRjctCde) {
        this.slsRjctCde = slsRjctCde;
    }

    /**
     * Gets the VisaAdvncAuthScor_Type detail
     *
     * @return a <code> string </code>
     * specifying the VisaAdvncAuthScor_Type detail
     */
    public String getVisaAdvncAuthScorType() {
        return visaAdvncAuthScorType;
    }

    /**
     * Sets the VisaAdvncAuthScor_Type detail
     *
     * @param visaAdvncAuthScorType the VisaAdvncAuthScor_Type detail
     */
    public void setVisaAdvncAuthScorType(String visaAdvncAuthScorType) {
        this.visaAdvncAuthScorType = visaAdvncAuthScorType;
    }

    /**
     * Gets the AprvlCode detail
     *
     * @return a <code> string </code>
     * specifying the AprvlCode detail
     */
    public String getAprvlCode() {
        return aprvlCode;
    }

    /**
     * Sets the AprvlCode detail
     *
     * @param aprvlCode the AprvlCode detail
     */
    public void setAprvlCode(String aprvlCode) {
        this.aprvlCode = aprvlCode;
    }

    /**
     * Gets the RespCode detail
     *
     * @return a <code> string </code>
     * specifying the RespCode detail
     */
    public String getRespCode() {
        return respCode;
    }

    /**
     * Sets the RespCode detail
     *
     * @param respCode the RespCode detail
     */
    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    /**
     * Gets the OrigWireInstIDNum detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireInstIDNum detail
     */
    public String getOrigWireInstIDNum() {
        return origWireInstIDNum;
    }

    /**
     * Sets the OrigWireInstIDNum detail
     *
     * @param origWireInstIDNum the OrigWireInstIDNum detail
     */
    public void setOrigWireInstIDNum(String origWireInstIDNum) {
        this.origWireInstIDNum = origWireInstIDNum;
    }

    /**
     * Gets the OrigWireCntryCode detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireCntryCode detail
     */
    public String getOrigWireCntryCode() {
        return origWireCntryCode;
    }

    /**
     * Sets the OrigWireCntryCode detail
     *
     * @param origWireCntryCode the OrigWireCntryCode detail
     */
    public void setOrigWireCntryCode(String origWireCntryCode) {
        this.origWireCntryCode = origWireCntryCode;
    }

    /**
     * Gets the OrigWireCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the OrigWireCrncyCode detail
     */
    public String getOrigWireCrncyCode() {
        return origWireCrncyCode;
    }

    /**
     * Sets the OrigWireCrncyCode detail
     *
     * @param origWireCrncyCode the OrigWireCrncyCode detail
     */
    public void setOrigWireCrncyCode(String origWireCrncyCode) {
        this.origWireCrncyCode = origWireCrncyCode;
    }

    /**
     * Gets the BenWireInstIdNum detail
     *
     * @return a <code> string </code>
     * specifying the BenWireInstIdNum detail
     */
    public String getBenWireInstIdNum() {
        return benWireInstIdNum;
    }

    /**
     * Sets the BenWireInstIdNum detail
     *
     * @param benWireInstIdNum the BenWireInstIdNum detail
     */
    public void setBenWireInstIdNum(String benWireInstIdNum) {
        this.benWireInstIdNum = benWireInstIdNum;
    }

    /**
     * Gets the BenWireCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the BenWireCrncyCode detail
     */
    public String getBenWireCntryCode() {
        return benWireCntryCode;
    }

    /**
     * Sets the BenWireCntryCode detail
     *
     * @param benWireCntryCode the BenWireCntryCode detail
     */
    public void setBenWireCntryCode(String benWireCntryCode) {
        this.benWireCntryCode = benWireCntryCode;
    }

    /**
     * Gets the BenWireCrncyCode detail
     *
     * @return a <code> string </code>
     * specifying the BenWireCrncyCode detail
     */
    public String getBenWireCrncyCode() {
        return benWireCrncyCode;
    }

    /**
     * Sets the BenWireCrncyCode detail
     *
     * @param benWireCrncyCode the BenWireCrncyCode detail
     */
    public void setBenWireCrncyCode(String benWireCrncyCode) {
        this.benWireCrncyCode = benWireCrncyCode;
    }

    /**
     * Gets the RealTimeStat detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeStat detail
     */
    public String getRealTimeStat() {
        return realTimeStat;
    }

    /**
     * Sets the RealTimeStat detail
     *
     * @param realTimeStat the RealTimeStat detail
     */
    public void setRealTimeStat(String realTimeStat) {
        this.realTimeStat = realTimeStat;
    }

    /**
     * Gets the RealTimeDsps detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeDsps detail
     */
    public String getRealTimeDsps() {
        return realTimeDsps;
    }

    /**
     * Sets the RealTimeDsps detail
     *
     * @param realTimeDsps the RealTimeDsps detail
     */
    public void setRealTimeDsps(String realTimeDsps) {
        this.realTimeDsps = realTimeDsps;
    }

    /**
     * Gets the RealTimeRuleFrd detail
     *
     * @return a <code> integer </code>
     * specifying the RealTimeRuleFrd detail
     */
    public Integer getRealTimeRuleFrd() {
        return realTimeRuleFrd;
    }

    /**
     * Sets the RealTimeRuleFrd detail
     *
     * @param realTimeRuleFrd the RealTimeRuleFrd detail
     */
    public void setRealTimeRuleFrd(Integer realTimeRuleFrd) {
        this.realTimeRuleFrd = realTimeRuleFrd;
    }

    /**
     * Gets the RealTimeRuleDsps detail
     *
     * @return a <code> string </code>
     * specifying the RealTimeRuleDsps detail
     */
    public String getRealTimeRuleDsps() {
        return realTimeRuleDsps;
    }

    /**
     * Sets the RealTimeRuleDsps detail
     *
     * @param realTimeRuleDsps the RealTimeRuleDsps detail
     */
    public void setRealTimeRuleDsps(String realTimeRuleDsps) {
        this.realTimeRuleDsps = realTimeRuleDsps;
    }

    /**
     * Gets the RealTimeScore detail
     *
     * @return a <code> integer </code>
     * specifying the RealTimeScore detail
     */
    public Integer getRealTimeScore() {
        return realTimeScore;
    }

    /**
     * Sets the RealTimeScore detail
     *
     * @param realTimeScore the RealTimeScore detail
     */
    public void setRealTimeScore(Integer realTimeScore) {
        this.realTimeScore = realTimeScore;
    }

    /**
     * Gets the amount_bins_M_0_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_0_count_prev30days detail
     */
    public Double getA1_30_0() {
        return A1_30_0;
    }

    /**
     * Sets the amount_bins_M_0_count_prev30days detail
     *
     * @param a1_30_0 the amount_bins_M_0_count_prev30days detail
     */
    public void setA1_30_0(Double a1_30_0) {
        A1_30_0 = a1_30_0;
    }

    /**
     * Gets the amount_bins_M_0_1_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_0_1_count_prev30days detail
     */
    public Double getA1_30_1() {
        return A1_30_1;
    }

    /**
     * Sets the amount_bins_M_0_1_count_prev30days detail
     *
     * @param a1_30_1 the amount_bins_M_0_1_count_prev30days detail
     */
    public void setA1_30_1(Double a1_30_1) {
        A1_30_1 = a1_30_1;
    }

    /**
     * Gets the amount_bins_M_1_500_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_1_500_count_prev30days detail
     */
    public Double getA1_30_2() {
        return A1_30_2;
    }

    /**
     * Sets the amount_bins_M_1_500_count_prev30days detail
     *
     * @param a1_30_2 the amount_bins_M_1_500_count_prev30days detail
     */
    public void setA1_30_2(Double a1_30_2) {
        A1_30_2 = a1_30_2;
    }

    /**
     * Gets the amount_bins_M_5001_10000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_5001_10000_count_prev30days detail
     */
    public Double getA1_30_5() {
        return A1_30_5;
    }

    /**
     * Sets the amount_bins_M_5001_10000_count_prev30days detail
     *
     * @param a1_30_5 the amount_bins_M_5001_10000_count_prev30days detail
     */
    public void setA1_30_5(Double a1_30_5) {
        A1_30_5 = a1_30_5;
    }


    /**
     * Gets the amount_bins_M_0_1_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_0_1_count_prev3days detail
     */
    public Double getA1_3_1() {
        return A1_3_1;
    }

    /**
     * Sets the amount_bins_M_0_1_count_prev3days detail
     *
     * @param a1_3_1 the amount_bins_M_0_1_count_prev3days detail
     */
    public void setA1_3_1(Double a1_3_1) {
        A1_3_1 = a1_3_1;
    }

    /**
     * Gets the amount_bins_M_501_2000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_501_2000_count_prev30days detail
     */
    public Double getA1_30_3() {
        return A1_30_3;
    }

    /**
     * Sets the amount_bins_M_501_2000_count_prev30days detail
     *
     * @param a1_30_3 the amount_bins_M_501_2000_count_prev30days detail
     */
    public void setA1_30_3(Double a1_30_3) {
        A1_30_3 = a1_30_3;
    }

    /**
     * Gets the amount_bins_M_501_2000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_501_2000_count_prev3days detail
     */
    public Double getA1_3_3() {
        return A1_3_3;
    }

    /**
     * Sets the amount_bins_M_501_2000_count_prev3days detail
     *
     * @param a1_3_3 the amount_bins_M_501_2000_count_prev3days detail
     */
    public void setA1_3_3(Double a1_3_3) {
        A1_3_3 = a1_3_3;
    }

    /**
     * Gets the amount_bins_M_2001_5000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_2001_5000_count_prev30days detail
     */
    public Double getA1_30_4() {
        return A1_30_4;
    }

    /**
     * Sets the amount_bins_M_2001_5000_count_prev30days detail
     *
     * @param a1_30_4 the amount_bins_M_2001_5000_count_prev30days detail
     */
    public void setA1_30_4(Double a1_30_4) {
        A1_30_4 = a1_30_4;
    }

    /**
     * Gets the amount_bins_M_2001_5000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_2001_5000_count_prev3days detail
     */
    public Double getA1_3_4() {
        return A1_3_4;
    }

    /**
     * Sets the amount_bins_M_2001_5000_count_prev3days detail
     *
     * @param a1_3_4 the amount_bins_M_2001_5000_count_prev3days detail
     */
    public void setA1_3_4(Double a1_3_4) {
        A1_3_4 = a1_3_4;
    }

    /**
     * Gets the amount_bins_M_10001_20000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_10001_20000_count_prev30days detail
     */
    public Double getA1_30_6() {
        return A1_30_6;
    }

    /**
     * Sets the amount_bins_M_10001_20000_count_prev30days detail
     *
     * @param a1_30_6 the amount_bins_M_10001_20000_count_prev30days detail
     */
    public void setA1_30_6(Double a1_30_6) {
        A1_30_6 = a1_30_6;
    }

    /**
     * Gets the amount_bins_M_10001_20000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_10001_20000_count_prev3days detail
     */
    public Double getA1_3_6() {
        return A1_3_6;
    }

    /**
     * Sets the amount_bins_M_10001_20000_count_prev3days detail
     *
     * @param a1_3_6 the amount_bins_M_10001_20000_count_prev3days detail
     */
    public void setA1_3_6(Double a1_3_6) {
        A1_3_6 = a1_3_6;
    }

    /**
     * Gets the amount_bins_M_20001_30000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_20001_30000_count_prev30days detail
     */
    public Double getA1_30_7() {
        return A1_30_7;
    }

    /**
     * Sets the amount_bins_M_20001_30000_count_prev30days detail
     *
     * @param a1_30_7 the amount_bins_M_20001_30000_count_prev30days detail
     */
    public void setA1_30_7(Double a1_30_7) {
        A1_30_7 = a1_30_7;
    }

    /**
     * Gets the amount_bins_M_20001_30000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_20001_30000_count_prev3days detail
     */
    public Double getA1_3_7() {
        return A1_3_7;
    }

    /**
     * Sets the amount_bins_M_20001_30000_count_prev3days detail
     *
     * @param a1_3_7 the amount_bins_M_20001_30000_count_prev3days detail
     */
    public void setA1_3_7(Double a1_3_7) {
        A1_3_7 = a1_3_7;
    }

    /**
     * Gets the amount_bins_M_30001_50000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_30001_50000_count_prev30days detail
     */
    public Double getA1_30_8() {
        return A1_30_8;
    }

    /**
     * Sets the amount_bins_M_30001_50000_count_prev30days detail
     *
     * @param a1_30_8 the amount_bins_M_30001_50000_count_prev30days detail
     */
    public void setA1_30_8(Double a1_30_8) {
        A1_30_8 = a1_30_8;
    }

    /**
     * Gets the amount_bins_M_30001_50000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_30001_50000_count_prev3days detail
     */
    public Double getA1_3_8() {
        return A1_3_8;
    }

    /**
     * Sets the amount_bins_M_30001_50000_count_prev3days detail
     *
     * @param a1_3_8 the amount_bins_M_30001_50000_count_prev3days detail
     */
    public void setA1_3_8(Double a1_3_8) {
        A1_3_8 = a1_3_8;
    }

    /**
     * Gets the amount_bins_M_50001_100000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_50001_100000_count_prev30days detail
     */
    public Double getA1_30_9() {
        return A1_30_9;
    }

    /**
     * Sets the amount_bins_M_50001_100000_count_prev30days detail
     *
     * @param a1_30_9 the amount_bins_M_50001_100000_count_prev30days detail
     */
    public void setA1_30_9(Double a1_30_9) {
        A1_30_9 = a1_30_9;
    }

    /**
     * Gets the amount_bins_M_100001_500000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_100001_500000_count_prev30days detail
     */
    public Double getA1_30_10() {
        return A1_30_10;
    }

    /**
     * Sets the amount_bins_M_100001_500000_count_prev30days detail
     *
     * @param a1_30_10 the amount_bins_M_100001_500000_count_prev30days detail
     */
    public void setA1_30_10(Double a1_30_10) {
        A1_30_10 = a1_30_10;
    }

    /**
     * Gets the amount_bins_M_100001_500000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_100001_500000_count_prev3days detail
     */
    public Double getA1_3_10() {
        return A1_3_10;
    }

    /**
     * Sets the amount_bins_M_100001_500000_count_prev3days detail
     *
     * @param a1_3_10 the amount_bins_M_100001_500000_count_prev3days detail
     */
    public void setA1_3_10(Double a1_3_10) {
        A1_3_10 = a1_3_10;
    }

    /**
     * Gets the amount_bins_M_500001_1000000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_500001_1000000_count_prev30days detail
     */
    public Double getA1_30_11() {
        return A1_30_11;
    }

    /**
     * Sets the amount_bins_M_500001_1000000_count_prev30days detail
     *
     * @param a1_30_11 the amount_bins_M_500001_1000000_count_prev30days detail
     */
    public void setA1_30_11(Double a1_30_11) {
        A1_30_11 = a1_30_11;
    }

    /**
     * Gets the aamount_bins_M_500001_1000000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_500001_1000000_count_prev3days detail
     */
    public Double getA1_3_11() {
        return A1_3_11;
    }

    /**
     * Sets the amount_bins_M_500001_1000000_count_prev3days detail
     *
     * @param a1_3_11 the amount_bins_M_500001_1000000_count_prev3days detail
     */
    public void setA1_3_11(Double a1_3_11) {
        A1_3_11 = a1_3_11;
    }

    /**
     * Gets the amount_bins_M_ATM_0_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_0_count_prev30days detail
     */
    public Double getA2_30_0() {
        return A2_30_0;
    }

    /**
     * Sets the amount_bins_M_ATM_0_count_prev30days detail
     *
     * @param a2_30_0 the amount_bins_M_ATM_0_count_prev30days detail
     */
    public void setA2_30_0(Double a2_30_0) {
        A2_30_0 = a2_30_0;
    }

    /**
     * Gets the amount_bins_M_ATM_0_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_0_count_prev3days detail
     */
    public Double getA2_3_0() {
        return A2_3_0;
    }

    /**
     * Sets the amount_bins_M_ATM_0_count_prev3days detail
     *
     * @param a2_3_0 the amount_bins_M_ATM_0_count_prev3days detail
     */
    public void setA2_3_0(Double a2_3_0) {
        A2_3_0 = a2_3_0;
    }

    /**
     * Gets the amount_bins_M_ATM_1_500_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_1_500_count_prev30days detail
     */
    public Double getA2_30_2() {
        return A2_30_2;
    }

    /**
     * Sets the amount_bins_M_ATM_1_500_count_prev30days detail
     *
     * @param a2_30_2 the amount_bins_M_ATM_1_500_count_prev30days detail
     */
    public void setA2_30_2(Double a2_30_2) {
        A2_30_2 = a2_30_2;
    }

    /**
     * Gets the amount_bins_M_ATM_1_500_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_1_500_count_prev3days detail
     */
    public Double getA2_3_2() {
        return A2_3_2;
    }

    /**
     * Sets the amount_bins_M_ATM_1_500_count_prev3days detail
     *
     * @param a2_3_2 the amount_bins_M_ATM_1_500_count_prev3days detail
     */
    public void setA2_3_2(Double a2_3_2) {
        A2_3_2 = a2_3_2;
    }

    /**
     * Gets the amount_bins_M_ATM_501_2000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_501_2000_count_prev30days detail
     */
    public Double getA2_30_3() {
        return A2_30_3;
    }

    /**
     * Sets the amount_bins_M_ATM_501_2000_count_prev30days detail
     *
     * @param a2_30_3 the amount_bins_M_ATM_501_2000_count_prev30days detail
     */
    public void setA2_30_3(Double a2_30_3) {
        A2_30_3 = a2_30_3;
    }

    /**
     * Gets the amount_bins_M_ATM_501_2000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_501_2000_count_prev3days detail
     */
    public Double getA2_3_3() {
        return A2_3_3;
    }

    /**
     * Sets the amount_bins_M_ATM_501_2000_count_prev3days detail
     *
     * @param a2_3_3 the amount_bins_M_ATM_501_2000_count_prev3days detail
     */
    public void setA2_3_3(Double a2_3_3) {
        A2_3_3 = a2_3_3;
    }

    /**
     * Gets the amount_bins_M_ATM_2001_5000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_2001_5000_count_prev30days detail
     */
    public Double getA2_30_4() {
        return A2_30_4;
    }

    /**
     * Sets the amount_bins_M_ATM_2001_5000_count_prev30days detail
     *
     * @param a2_30_4 the amount_bins_M_ATM_2001_5000_count_prev30days detail
     */
    public void setA2_30_4(Double a2_30_4) {
        A2_30_4 = a2_30_4;
    }

    /**
     * Gets the amount_bins_M_ATM_2001_5000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_2001_5000_count_prev3days detail
     */
    public Double getA2_3_4() {
        return A2_3_4;
    }

    /**
     * Sets the amount_bins_M_ATM_2001_5000_count_prev3days detail
     *
     * @param a2_3_4 the amount_bins_M_ATM_2001_5000_count_prev3days detail
     */
    public void setA2_3_4(Double a2_3_4) {
        A2_3_4 = a2_3_4;
    }

    /**
     * Gets the amount_bins_M_ATM_5001_10000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_5001_10000_count_prev30days detail
     */
    public Double getA2_30_5() {
        return A2_30_5;
    }

    /**
     * Sets the amount_bins_M_ATM_5001_10000_count_prev30days detail
     *
     * @param a2_30_5 the amount_bins_M_ATM_5001_10000_count_prev30days detail
     */
    public void setA2_30_5(Double a2_30_5) {
        A2_30_5 = a2_30_5;
    }

    /**
     * Gets the amount_bins_M_ATM_5001_10000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_5001_10000_count_prev3days detail
     */
    public Double getA2_3_5() {
        return A2_3_5;
    }

    /**
     * Sets the amount_bins_M_ATM_5001_10000_count_prev3days detail
     *
     * @param a2_3_5 the amount_bins_M_ATM_5001_10000_count_prev3days detail
     */
    public void setA2_3_5(Double a2_3_5) {
        A2_3_5 = a2_3_5;
    }

    /**
     * Gets the amount_bins_M_ATM_10001_20000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_10001_20000_count_prev30days detail
     */
    public Double getA2_30_6() {
        return A2_30_6;
    }

    /**
     * Sets the amount_bins_M_ATM_10001_20000_count_prev30days detail
     *
     * @param a2_30_6 the amount_bins_M_ATM_10001_20000_count_prev30days detail
     */
    public void setA2_30_6(Double a2_30_6) {
        A2_30_6 = a2_30_6;
    }

    /**
     * Gets the amount_bins_M_ATM_10001_20000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_10001_20000_count_prev3days detail
     */
    public Double getA2_3_6() {
        return A2_3_6;
    }

    /**
     * Sets the amount_bins_M_ATM_10001_20000_count_prev3days detail
     *
     * @param a2_3_6 the amount_bins_M_ATM_10001_20000_count_prev3days detail
     */
    public void setA2_3_6(Double a2_3_6) {
        A2_3_6 = a2_3_6;
    }

    /**
     * Gets the amount_bins_M_ATM_20001_30000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_20001_30000_count_prev30days detail
     */
    public Double getA2_30_7() {
        return A2_30_7;
    }

    /**
     * Sets the amount_bins_M_ATM_20001_30000_count_prev30days detail
     *
     * @param a2_30_7 the amount_bins_M_ATM_20001_30000_count_prev30days detail
     */
    public void setA2_30_7(Double a2_30_7) {
        A2_30_7 = a2_30_7;
    }

    /**
     * Gets the amount_bins_M_ATM_20001_30000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_20001_30000_count_prev3days detail
     */
    public Double getA2_3_7() {
        return A2_3_7;
    }

    /**
     * Sets the amount_bins_M_ATM_20001_30000_count_prev3days detail
     *
     * @param a2_3_7 the amount_bins_M_ATM_20001_30000_count_prev3days detail
     */
    public void setA2_3_7(Double a2_3_7) {
        A2_3_7 = a2_3_7;
    }

    /**
     * Gets the amount_bins_M_ATM_30001_50000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_30001_50000_count_prev30days detail
     */
    public Double getA2_30_8() {
        return A2_30_8;
    }

    /**
     * Sets the amount_bins_M_ATM_30001_50000_count_prev30days detail
     *
     * @param a2_30_8 the amount_bins_M_ATM_30001_50000_count_prev30days detail
     */
    public void setA2_30_8(Double a2_30_8) {
        A2_30_8 = a2_30_8;
    }

    /**
     * Gets the amount_bins_M_ATM_30001_50000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_30001_50000_count_prev3days detail
     */
    public Double getA2_3_8() {
        return A2_3_8;
    }

    /**
     * Sets the amount_bins_M_ATM_30001_50000_count_prev3days detail
     *
     * @param a2_3_8 the amount_bins_M_ATM_30001_50000_count_prev3days detail
     */
    public void setA2_3_8(Double a2_3_8) {
        A2_3_8 = a2_3_8;
    }

    /**
     * Gets the amount_bins_M_ATM_50001_100000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_50001_100000_count_prev30days detail
     */
    public Double getA2_30_9() {
        return A2_30_9;
    }

    /**
     * Sets the amount_bins_M_ATM_50001_100000_count_prev30days detail
     *
     * @param a2_30_9 the amount_bins_M_ATM_50001_100000_count_prev30days detail
     */
    public void setA2_30_9(Double a2_30_9) {
        A2_30_9 = a2_30_9;
    }

    /**
     * Gets the amount_bins_M_ATM_50001_100000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_ATM_50001_100000_count_prev3days detail
     */
    public Double getA2_3_9() {
        return A2_3_9;
    }

    /**
     * Sets the amount_bins_M_ATM_50001_100000_count_prev3days detail
     *
     * @param a2_3_9 the amount_bins_M_ATM_50001_100000_count_prev3days detail
     */
    public void setA2_3_9(Double a2_3_9) {
        A2_3_9 = a2_3_9;
    }

    /**
     * Gets the act_blk_st detail
     *
     * @return a <code> double </code>
     * specifying the act_blk_st detail
     */
    public Double getA4() {
        return A4;
    }

    /**
     * Sets the act_blk_st detail
     *
     * @param a4 the act_blk_st detail
     */
    public void setA4(Double a4) {
        A4 = a4;
    }

    /**
     * Gets the atm_dec_w_count_cntrytype_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the atm_dec_w_count_cntrytype_prev30days detail
     */
    public Double getA5_30_3() {
        return A5_30_3;
    }

    /**
     * Sets the atm_dec_w_count_cntrytype_prev30days detail
     *
     * @param a5_30_3 the atm_dec_w_count_cntrytype_prev30days detail
     */
    public void setA5_30_3(Double a5_30_3) {
        A5_30_3 = a5_30_3;
    }

    /**
     * Gets the atm_dec_w_count_cntrytype_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the atm_dec_w_count_cntrytype_prev3days detail
     */
    public Double getA5_3_3() {
        return A5_3_3;
    }

    /**
     * Sets the atm_dec_w_count_cntrytype_prev3days detail
     *
     * @param a5_3_3 the atm_dec_w_count_cntrytype_prev3days detail
     */
    public void setA5_3_3(Double a5_3_3) {
        A5_3_3 = a5_3_3;
    }

    /**
     * Gets the channeltype_ATM_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_ATM_count_prev30days detail
     */
    public Double getC1_30() {
        return C1_30;
    }

    /**
     * Sets the channeltype_ATM_count_prev30days detail
     *
     * @param c1_30 the channeltype_ATM_count_prev30days detail
     */
    public void setC1_30(Double c1_30) {
        C1_30 = c1_30;
    }

    /**
     * Gets the channeltype_ATM_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_ATM_count_prev3days detail
     */
    public Double getC1_3() {
        return C1_3;
    }

    /**
     * Sets the channeltype_ATM_count_prev3days detail
     *
     * @param c1_3 the channeltype_ATM_count_prev3days detail
     */
    public void setC1_3(Double c1_3) {
        C1_3 = c1_3;
    }

    /**
     * Gets the channeltype_CNPSECURED_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_CNPSECURED_count_prev30days detail
     */
    public Double getC2_30() {
        return C2_30;
    }

    /**
     * Sets the channeltype_CNPSECURED_count_prev30days detail
     *
     * @param c2_30 the channeltype_CNPSECURED_count_prev30days detail
     */
    public void setC2_30(Double c2_30) {
        C2_30 = c2_30;
    }

    /**
     * Gets the channeltype_CNPSECURED_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_CNPSECURED_count_prev30days detail
     */
    public Double getC2_3() {
        return C2_3;
    }

    /**
     * Sets the channeltype_CNPSECURED_count_prev3days detail
     *
     * @param c2_3 the channeltype_CNPSECURED_count_prev3days detail
     */
    public void setC2_3(Double c2_3) {
        C2_3 = c2_3;
    }

    /**
     * Gets the channeltype_CNPUNSECURED_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_CNPUNSECURED_count_prev30days detail
     */
    public Double getC3_30() {
        return C3_30;
    }

    /**
     * Sets the channeltype_CNPUNSECURED_count_prev30days detail
     *
     * @param c3_30 the channeltype_CNPUNSECURED_count_prev30days detail
     */
    public void setC3_30(Double c3_30) {
        C3_30 = c3_30;
    }

    /**
     * Gets the channeltype_CNPUNSECURED_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_CNPUNSECURED_count_prev3days detail
     */
    public Double getC3_3() {
        return C3_3;
    }

    /**
     * Sets the channeltype_CNPUNSECURED_count_prev3days detail
     *
     * @param c3_3 the channeltype_CNPUNSECURED_count_prev3days detail
     */
    public void setC3_3(Double c3_3) {
        C3_3 = c3_3;
    }

    /**
     * Gets the channeltype_POS_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_POS_count_prev30days detail
     */
    public Double getC4_30() {
        return C4_30;
    }

    /**
     * Sets the channeltype_POS_count_prev30days detail
     *
     * @param c4_30 the channeltype_POS_count_prev30days detail
     */
    public void setC4_30(Double c4_30) {
        C4_30 = c4_30;
    }

    /**
     * Gets the channeltype_POS_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the channeltype_POS_count_prev3days detail
     */
    public Double getC4_3() {
        return C4_3;
    }

    /**
     * Sets the channeltype_POS_count_prev3days detail
     *
     * @param c4_3 the channeltype_POS_count_prev3days detail
     */
    public void setC4_3(Double c4_3) {
        C4_3 = c4_3;
    }

    /**
     * Gets the cntrytype_ATM_Domestic_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_ATM_Domestic_count_prev3days detail
     */
    public Double getC5_3() {
        return C5_3;
    }

    /**
     * Sets the cntrytype_ATM_Domestic_count_prev3days detail
     *
     * @param c5_3 the cntrytype_ATM_Domestic_count_prev3days detail
     */
    public void setC5_3(Double c5_3) {
        C5_3 = c5_3;
    }

    /**
     * Gets the cntrytype_ATM_International_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_ATM_International_count_prev30days detail
     */
    public Double getC6_30() {
        return C6_30;
    }

    /**
     * Sets the cntrytype_ATM_International_count_prev30days detail
     *
     * @param c6_30 the cntrytype_ATM_International_count_prev30days detail
     */
    public void setC6_30(Double c6_30) {
        C6_30 = c6_30;
    }

    /**
     * Gets the cntrytype_ATM_International_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_ATM_International_count_prev3days detail
     */
    public Double getC6_3() {
        return C6_3;
    }

    /**
     * Sets the cntrytype_ATM_International_count_prev3days detail
     *
     * @param c6_3 the cntrytype_ATM_International_count_prev3days detail
     */
    public void setC6_3(Double c6_3) {
        C6_3 = c6_3;
    }

    /**
     * Gets the cntrytype_International_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_International_count_prev30days detail
     */
    public Double getC8_30() {
        return C8_30;
    }

    /**
     * Sets the cntrytype_International_count_prev30days detail
     *
     * @param c8_30 the cntrytype_International_count_prev30days detail
     */
    public void setC8_30(Double c8_30) {
        C8_30 = c8_30;
    }

    /**
     * Gets the cntrytype_International_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_International_count_prev30days detail
     */
    public Double getC8_P_30() {
        return C8_P_30;
    }

    /**
     * Sets the cntrytype_International_count_prev30days detail
     *
     * @param c8_p_30 the cntrytype_International_count_prev30days detail
     */
    public void setC8_P_30(Double c8_p_30) {
        C8_P_30 = c8_p_30;
    }

    /**
     * Gets the cntrytype_International_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the cntrytype_International_count_prev3days detail
     */
    public Double getC8_3() {
        return C8_3;
    }

    /**
     * Sets the cntrytype_International_count_prev3days detail
     *
     * @param c8_3 the cntrytype_International_count_prev3days detail
     */
    public void setC8_3(Double c8_3) {
        C8_3 = c8_3;
    }

    /**
     * Gets the current_day_atm_trancount detail
     *
     * @return a <code> double </code>
     * specifying the current_day_atm_trancount detail
     */
    public Double getC10() {
        return C10;
    }

    /**
     * Sets the current_day_atm_trancount detail
     *
     * @param c10 the current_day_atm_trancount detail
     */
    public void setC10(Double c10) {
        C10 = c10;
    }

    /**
     * Gets the current_week_atm_trancount detail
     *
     * @return a <code> double </code>
     * specifying the current_week_atm_trancount detail
     */
    public Double getC11() {
        return C11;
    }

    /**
     * Sets the current_week_atm_trancount detail
     *
     * @param c11 the current_week_atm_trancount detail
     */
    public void setC11(Double c11) {
        C11 = c11;
    }

    /**
     * Gets the distance_prevloc detail
     *
     * @return a <code> double </code>
     * specifying the distance_prevloc detail
     */
    public Double getD1() {
        return D1;
    }

    /**
     * Sets the distance_prevloc detail
     *
     * @param d1 the distance_prevloc detail
     */
    public void setD1(Double d1) {
        D1 = d1;
    }

    /**
     * Gets the entry_mde_type_chipvalidated_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_chipvalidated_count_prev30days detail
     */
    public Double getE1_30() {
        return E1_30;
    }

    /**
     * Sets the entry_mde_type_chipvalidated_count_prev30days detail
     *
     * @param e1_30 the entry_mde_type_chipvalidated_count_prev30days detail
     */
    public void setE1_30(Double e1_30) {
        E1_30 = e1_30;
    }

    /**
     * Gets the entry_mde_type_chipvalidated_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_chipvalidated_count_prev3days detail
     */
    public Double getE1_3() {
        return E1_3;
    }

    /**
     * Sets the entry_mde_type_chipvalidated_count_prev3days detail
     *
     * @param e1_3 the entry_mde_type_chipvalidated_count_prev3days detail
     */
    public void setE1_3(Double e1_3) {
        E1_3 = e1_3;
    }

    /**
     * Gets the entry_mde_type_contactlesscard_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_contactlesscard_count_prev30days detail
     */
    public Double getE2_30() {
        return E2_30;
    }

    /**
     * Sets the entry_mde_type_contactlesscard_count_prev30days detail
     *
     * @param e2_30 the entry_mde_type_contactlesscard_count_prev30days detail
     */
    public void setE2_30(Double e2_30) {
        E2_30 = e2_30;
    }

    /**
     * Gets the entry_mde_type_contactlesscard_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_contactlesscard_count_prev3days detail
     */
    public Double getE2_3() {
        return E2_3;
    }

    /**
     * Sets the entry_mde_type_contactlesscard_count_prev3days detail
     *
     * @param e2_3 the entry_mde_type_contactlesscard_count_prev3days detail
     */
    public void setE2_3(Double e2_3) {
        E2_3 = e2_3;
    }

    /**
     * Gets the entry_mde_type_magstripe_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_magstripe_count_prev30days detail
     */
    public Double getE3_30() {
        return E3_30;
    }

    /**
     * Sets the entry_mde_type_magstripe_count_prev30days detail
     *
     * @param e3_30 the entry_mde_type_magstripe_count_prev30days detail
     */
    public void setE3_30(Double e3_30) {
        E3_30 = e3_30;
    }

    /**
     * Gets the entry_mde_type_magstripe_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the entry_mde_type_magstripe_count_prev3days detail
     */
    public Double getE3_3() {
        return E3_3;
    }

    /**
     * Sets the entry_mde_type_magstripe_count_prev3days detail
     *
     * @param e3_3 the entry_mde_type_magstripe_count_prev3days detail
     */
    public void setE3_3(Double e3_3) {
        E3_3 = e3_3;
    }

    /**
     * Gets the fall_back_status_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the fall_back_status_count_prev30days detail
     */
    public Double getF2_30() {
        return F2_30;
    }

    /**
     * Sets the fall_back_status_count_prev30days detail
     *
     * @param f2_30 the fall_back_status_count_prev30days detail
     */
    public void setF2_30(Double f2_30) {
        F2_30 = f2_30;
    }

    /**
     * Gets the fall_back_status_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the fall_back_status_count_prev3days detail
     */
    public Double getF2_3() {
        return F2_3;
    }

    /**
     * Sets the fall_back_status_count_prev3days detail
     *
     * @param f2_3 the fall_back_status_count_prev3days detail
     */
    public void setF2_3(Double f2_3) {
        F2_3 = f2_3;
    }

    /**
     * Gets the gasoline_tran_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the gasoline_tran_count_prev30days detail
     */
    public Double getG1_30() {
        return G1_30;
    }

    /**
     * Sets the gasoline_tran_count_prev30days detail
     *
     * @param g1_30 the gasoline_tran_count_prev30days detail
     */
    public void setG1_30(Double g1_30) {
        G1_30 = g1_30;
    }

    /**
     * Gets the gasoline_tran_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the gasoline_tran_count_prev3days detail
     */
    public Double getG2_3() {
        return G2_3;
    }

    /**
     * Sets the gasoline_tran_count_prev3days detail
     *
     * @param g2_3 the gasoline_tran_count_prev3days detail
     */
    public void setG2_3(Double g2_3) {
        G2_3 = g2_3;
    }

    /**
     * Gets the hour_type_ATM_earlyMrng_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_earlyMrng_count_prev30days detail
     */
    public Double getH2_30() {
        return H2_30;
    }

    /**
     * Sets the hour_type_ATM_earlyMrng_count_prev30days detail
     *
     * @param h2_30 the hour_type_ATM_earlyMrng_count_prev30days detail
     */
    public void setH2_30(Double h2_30) {
        H2_30 = h2_30;
    }

    /**
     * Gets the hour_type_ATM_earlyMrng_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_earlyMrng_count_prev3days detail
     */
    public Double getH2_3() {
        return H2_3;
    }

    /**
     * Sets the hour_type_ATM_earlyMrng_count_prev3days detail
     *
     * @param h2_3 the hour_type_ATM_earlyMrng_count_prev3days detail
     */
    public void setH2_3(Double h2_3) {
        H2_3 = h2_3;
    }

    /**
     * Gets the hour_type_ATM_busHrs_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_busHrs_count_prev30days detail
     */
    public Double getH3_30() {
        return H3_30;
    }

    /**
     * Sets the hour_type_ATM_busHrs_count_prev30days detail
     *
     * @param h3_30 the hour_type_ATM_busHrs_count_prev30days detail
     */
    public void setH3_30(Double h3_30) {
        H3_30 = h3_30;
    }

    /**
     * Gets the hour_type_ATM_busHrs_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_busHrs_count_prev3days detail
     */
    public Double getH3_3() {
        return H3_3;
    }

    /**
     * Sets the hour_type_ATM_busHrs_count_prev3days detail
     *
     * @param h3_3 the hour_type_ATM_busHrs_count_prev3days detail
     */
    public void setH3_3(Double h3_3) {
        H3_3 = h3_3;
    }

    /**
     * Gets the hour_type_ATM_close_midnight_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_close_midnight_count_prev30days detail
     */
    public Double getH4_30() {
        return H4_30;
    }

    /**
     * Sets the hour_type_ATM_close_midnight_count_prev30days detail
     *
     * @param h4_30 the hour_type_ATM_close_midnight_count_prev30days detail
     */
    public void setH4_30(Double h4_30) {
        H4_30 = h4_30;
    }

    /**
     * Gets the hour_type_ATM_close_midnight_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_close_midnight_count_prev3days detail
     */
    public Double getH4_3() {
        return H4_3;
    }

    /**
     * Sets the hour_type_ATM_close_midnight_count_prev3days detail
     *
     * @param h4_3 the hour_type_ATM_close_midnight_count_prev3days detail
     */
    public void setH4_3(Double h4_3) {
        H4_3 = h4_3;
    }

    /**
     * Gets the hour_type_POS_close_midnight_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_POS_close_midnight_count_prev30days detail
     */
    public Double getH8_P_30() {
        return H8_P_30;
    }

    /**
     * Sets the hour_type_POS_close_midnight_count_prev30days detail
     *
     * @param h8_p_30 the hour_type_POS_close_midnight_count_prev30days detail
     */
    public void setH8_P_30(Double h8_p_30) {
        H8_P_30 = h8_p_30;
    }


    /**
     * Gets the hour_type_ATM_lateNight_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_lateNight_count_prev30days detail
     */
    public Double getH5_30() {
        return H5_30;
    }

    /**
     * Sets the hour_type_ATM_lateNight_count_prev30days detail
     *
     * @param h5_30 the hour_type_ATM_lateNight_count_prev30days detail
     */
    public void setH5_30(Double h5_30) {
        H5_30 = h5_30;
    }

    /**
     * Gets the hour_type_ATM_lateNight_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_ATM_lateNight_count_prev3days detail
     */
    public Double getH5_3() {
        return H5_3;
    }

    /**
     * Sets the hour_type_ATM_lateNight_count_prev3days detail
     *
     * @param h5_3 the hour_type_ATM_lateNight_count_prev3days detail
     */
    public void setH5_3(Double h5_3) {
        H5_3 = h5_3;
    }

    /**
     * Gets the hour_type_close_midnight_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_close_midnight_count_prev30days detail
     */
    public Double getH8_30() {
        return H8_30;
    }

    /**
     * Sets the hour_type_close_midnight_count_prev30days detail
     *
     * @param h8_30 the hour_type_close_midnight_count_prev30days detail
     */
    public void setH8_30(Double h8_30) {
        H8_30 = h8_30;
    }

    /**
     * Gets the hour_type_earlyMrng_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_earlyMrng_count_prev30days detail
     */
    public Double getH6_30() {
        return H6_30;
    }

    /**
     * Sets the hour_type_earlyMrng_count_prev30days detail
     *
     * @param h6_30 the hour_type_earlyMrng_count_prev30days detail
     */
    public void setH6_30(Double h6_30) {
        H6_30 = h6_30;
    }

    /**
     * Gets the hour_type_close_midnight_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_close_midnight_count_prev3days detail
     */
    public Double getH8_3() {
        return H8_3;
    }

    /**
     * Sets the hour_type_close_midnight_count_prev3days detail
     *
     * @param h8_3 the hour_type_close_midnight_count_prev3days detail
     */
    public void setH8_3(Double h8_3) {
        H8_3 = h8_3;
    }

    /**
     * Gets the hour_type_lateNight_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_lateNight_count_prev30days detail
     */
    public Double getH9_30() {
        return H9_30;
    }

    /**
     * Sets the hour_type_lateNight_count_prev30days detail
     *
     * @param h9_30 the hour_type_lateNight_count_prev30days detail
     */
    public void setH9_30(Double h9_30) {
        H9_30 = h9_30;
    }

    /**
     * Gets the hour_type_lateNight_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the hour_type_lateNight_count_prev3days detail
     */
    public Double getH9_3() {
        return H9_3;
    }

    /**
     * Sets the hour_type_lateNight_count_prev3days detail
     *
     * @param h9_3 the hour_type_lateNight_count_prev3days detail
     */
    public void setH9_3(Double h9_3) {
        H9_3 = h9_3;
    }

    /**
     * Gets the key_entry_tx_flag_key_entry_tx_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the key_entry_tx_flag_key_entry_tx_count_prev30days detail
     */
    public Double getK1_30() {
        return K1_30;
    }

    /**
     * Sets the key_entry_tx_flag_key_entry_tx_count_prev30days detail
     *
     * @param k1_30 the key_entry_tx_flag_key_entry_tx_count_prev30days detail
     */
    public void setK1_30(Double k1_30) {
        K1_30 = k1_30;
    }

    /**
     * Gets the key_entry_tx_flag_key_entry_tx_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the key_entry_tx_flag_key_entry_tx_count_prev3days detail
     */
    public Double getK1_3() {
        return K1_3;
    }

    /**
     * Sets the key_entry_tx_flag_key_entry_tx_count_prev3days detail
     *
     * @param k1_3 the key_entry_tx_flag_key_entry_tx_count_prev3days detail
     */
    public void setK1_3(Double k1_3) {
        K1_3 = k1_3;
    }

    /**
     * Gets the loc_city_mapping_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the loc_city_mapping_prev30days detail
     */
    public Double getL1() {
        return L1;
    }

    /**
     * Sets the loc_city_mapping_prev30days detail
     *
     * @param l1 the loc_city_mapping_prev30days detail
     */
    public void setL1(Double l1) {
        L1 = l1;
    }

    /**
     * Gets the max_daily_atm_tran_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the max_daily_atm_tran_count_prev30days detail
     */
    public Double getM9() {
        return M9;
    }

    /**
     * Sets the max_daily_atm_tran_count_prev30days detail
     *
     * @param m9 the max_daily_atm_tran_count_prev30days detail
     */
    public void setM9(Double m9) {
        M9 = m9;
    }

    /**
     * Gets the max_weekly_atm_tran_count_prev90days detail
     *
     * @return a <code> double </code>
     * specifying the max_weekly_atm_tran_count_prev90days detail
     */
    public Double getM14() {
        return M14;
    }

    /**
     * Sets the max_weekly_atm_tran_count_prev90days detail
     *
     * @param m14 the max_weekly_atm_tran_count_prev90days detail
     */
    public void setM14(Double m14) {
        M14 = m14;
    }

    /**
     * Gets the metro_city_ATM_Metro_city_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the metro_city_ATM_Metro_city_count_prev30days detail
     */
    public Double getM15() {
        return M15;
    }

    /**
     * Sets the metro_city_ATM_Metro_city_count_prev30days detail
     *
     * @param m15 the metro_city_ATM_Metro_city_count_prev30days detail
     */
    public void setM15(Double m15) {
        M15 = m15;
    }

    /**
     * Gets the postal_code_mapping_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the postal_code_mapping_prev30days detail
     */
    public Double getP3_30() {
        return P3_30;
    }

    /**
     * Sets the postal_code_mapping_prev30days detail
     *
     * @param p3_30 the postal_code_mapping_prev30days detail
     */
    public void setP3_30(Double p3_30) {
        P3_30 = p3_30;
    }


    /**
     * Gets the real_time_rule_status_Allowoverlimit_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the real_time_rule_status_Allowoverlimit_count_prev30days detail
     */
    public Double getR1_30() {
        return R1_30;
    }

    /**
     * Sets the real_time_rule_status_Allowoverlimit_count_prev30days detail
     *
     * @param r1_30 the real_time_rule_status_Allowoverlimit_count_prev30days detail
     */
    public void setR1_30(Double r1_30) {
        R1_30 = r1_30;
    }

    /**
     * Gets the real_time_rule_status_Allowoverlimit_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the real_time_rule_status_Allowoverlimit_count_prev3days detail
     */
    public Double getR1_3() {
        return R1_3;
    }

    /**
     * Sets the real_time_rule_status_Allowoverlimit_count_prev3days detail
     *
     * @param r1_3 the real_time_rule_status_Allowoverlimit_count_prev3days detail
     */
    public void setR1_3(Double r1_3) {
        R1_3 = r1_3;
    }

    /**
     * Gets the real_time_rule_status_Declined_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the real_time_rule_status_Declined_count_prev30days detail
     */
    public Double getR3_30() {
        return R3_30;
    }

    /**
     * Sets the real_time_rule_status_Declined_count_prev30days detail
     *
     * @param r3_30 the real_time_rule_status_Declined_count_prev30days detail
     */
    public void setR3_30(Double r3_30) {
        R3_30 = r3_30;
    }

    /**
     * Gets the real_time_rule_status_Declined_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the real_time_rule_status_Declined_count_prev3days detail
     */
    public Double getR3_3() {
        return R3_3;
    }

    /**
     * Sets the real_time_rule_status_Declined_count_prev3days detail
     *
     * @param r3_3 the real_time_rule_status_Declined_count_prev3days detail
     */
    public void setR3_3(Double r3_3) {
        R3_3 = r3_3;
    }

    /**
     * Gets the restuarant_tran_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the restuarant_tran_count_prev30days detail
     */
    public Double getR4_30() {
        return R4_30;
    }

    /**
     * Sets the restuarant_tran_count_prev30days detail
     *
     * @param r4_30 the restuarant_tran_count_prev30days detail
     */
    public void setR4_30(Double r4_30) {
        R4_30 = r4_30;
    }

    /**
     * Gets the restuarant_tran_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the restuarant_tran_count_prev3days detail
     */
    public Double getR4_3() {
        return R4_3;
    }

    /**
     * Sets the restuarant_tran_count_prev3days detail
     *
     * @param r4_3 the restuarant_tran_count_prev3days detail
     */
    public void setR4_3(Double r4_3) {
        R4_3 = r4_3;
    }

    /**
     * Gets the sd_monetary_NM_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_monetary_NM_count_prev30days detail
     */
    public Double getS2_30() {
        return S2_30;
    }

    /**
     * Sets the sd_monetary_NM_count_prev30days detail
     *
     * @param s2_30 the sd_monetary_NM_count_prev30days detail
     */
    public void setS2_30(Double s2_30) {
        S2_30 = s2_30;
    }

    /**
     * Gets the sd_monetary_NM_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_monetary_NM_count_prev3days detail
     */
    public Double getS2_3() {
        return S2_3;
    }

    /**
     * Sets the sd_monetary_NM_count_prev3days detail
     *
     * @param s2_3 the sd_monetary_NM_count_prev3days detail
     */
    public void setS2_3(Double s2_3) {
        S2_3 = s2_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_Block_Decline_H_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_Block_Decline_H_count_prev30days detail
     */
    public Double getS3_30() {
        return S3_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_Block_Decline_H_count_prev30days detail
     *
     * @param s3_30 the sd_resp_cde_type_ATM_Block_Decline_H_count_prev30days detail
     */
    public void setS3_30(Double s3_30) {
        S3_30 = s3_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_Block_Decline_H_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_Block_Decline_H_count_prev3days detail
     */
    public Double getS3_3() {
        return S3_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_Block_Decline_H_count_prev3days detail
     *
     * @param s3_3 the sd_resp_cde_type_ATM_Block_Decline_H_count_prev3days detail
     */
    public void setS3_3(Double s3_3) {
        S3_3 = s3_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_ExpiredCard_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_ExpiredCard_count_prev3days detail
     */
    public Double getS4_3() {
        return S4_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_ExpiredCard_count_prev3days detail
     *
     * @param s4_3 the sd_resp_cde_type_ATM_ExpiredCard_count_prev3days detail
     */
    public void setS4_3(Double s4_3) {
        S4_3 = s4_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_InsuffFunds_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_InsuffFunds_count_prev30days detail
     */
    public Double getS5_30() {
        return S5_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_InsuffFunds_count_prev30days detail
     *
     * @param s5_30 the sd_resp_cde_type_ATM_InsuffFunds_count_prev30days detail
     */
    public void setS5_30(Double s5_30) {
        S5_30 = s5_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_InsuffFunds_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_InsuffFunds_count_prev3days detail
     */
    public Double getS5_3() {
        return S5_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_InsuffFunds_count_prev3days detail
     *
     * @param s5_3 the sd_resp_cde_type_ATM_InsuffFunds_count_prev3days detail
     */
    public void setS5_3(Double s5_3) {
        S5_3 = s5_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_IntlLimitExceeded_NA_count_prev3days detail
     */
    public Double getS6_3() {
        return S6_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @param s6_3 the sd_resp_cde_type_ATM_IntlLimitExceeded_NA_count_prev3days detail
     */
    public void setS6_3(Double s6_3) {
        S6_3 = s6_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_InvalidData_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_InvalidData_count_prev30days detail
     */
    public Double getS7_30() {
        return S7_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_InvalidData_count_prev30days detail
     *
     * @param s7_30 the sd_resp_cde_type_ATM_InvalidData_count_prev30days detail
     */
    public void setS7_30(Double s7_30) {
        S7_30 = s7_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_InvalidData_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_InvalidData_count_prev3days detail
     */
    public Double getS7_3() {
        return S7_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_InvalidData_count_prev3days detail
     *
     * @param s7_3 the sd_resp_cde_type_ATM_InvalidData_count_prev3days detail
     */
    public void setS7_3(Double s7_3) {
        S7_3 = s7_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_OtherDeclines_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_OtherDeclines_count_prev30days detail
     */
    public Double getS8_30() {
        return S8_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_OtherDeclines_count_prev30days detail
     *
     * @param s8_30 the sd_resp_cde_type_ATM_OtherDeclines_count_prev30days detail
     */
    public void setS8_30(Double s8_30) {
        S8_30 = s8_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_OtherDeclines_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_OtherDeclines_count_prev3days detail
     */
    public Double getS8_3() {
        return S8_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_OtherDeclines_count_prev3days detail
     *
     * @param s8_3 the sd_resp_cde_type_ATM_OtherDeclines_count_prev3days detail
     */
    public void setS8_3(Double s8_3) {
        S8_3 = s8_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_Pickup_Capture_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_Pickup_Capture_count_prev30days detail
     */
    public Double getS9_30() {
        return S9_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_Pickup_Capture_count_prev30days detail
     *
     * @param s9_30 the sd_resp_cde_type_ATM_Pickup_Capture_count_prev30days detail
     */
    public void setS9_30(Double s9_30) {
        S9_30 = s9_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_Pickup_Capture_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_Pickup_Capture_count_prev3days detail
     */
    public Double getS9_3() {
        return S9_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_Pickup_Capture_count_prev3days detail
     *
     * @param s9_3 the sd_resp_cde_type_ATM_Pickup_Capture_count_prev3days detail
     */
    public void setS9_3(Double s9_3) {
        S9_3 = s9_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_PRM_Declined_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_PRM_Declined_count_prev30days detail
     */
    public Double getS10_30() {
        return S10_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_PRM_Declined_count_prev30days detail
     *
     * @param s10_30 the sd_resp_cde_type_ATM_PRM_Declined_count_prev30days detail
     */
    public void setS10_30(Double s10_30) {
        S10_30 = s10_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_PRM_Declined_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_PRM_Declined_count_prev3days detail
     */
    public Double getS10_3() {
        return S10_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_PRM_Declined_count_prev3days detail
     *
     * @param s10_3 the sd_resp_cde_type_ATM_PRM_Declined_count_prev3days detail
     */
    public void setS10_3(Double s10_3) {
        S10_3 = s10_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_RestrictedCard_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_RestrictedCard_count_prev30days detail
     */
    public Double getS11_30() {
        return S11_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_RestrictedCard_count_prev30days detail
     *
     * @param s11_30 the sd_resp_cde_type_ATM_RestrictedCard_count_prev30days detail
     */
    public void setS11_30(Double s11_30) {
        S11_30 = s11_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_RestrictedCard_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_RestrictedCard_count_prev3days detail
     */
    public Double getS11_3() {
        return S11_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_RestrictedCard_count_prev3days detail
     *
     * @param s11_3 the sd_resp_cde_type_ATM_RestrictedCard_count_prev3days detail
     */
    public void setS11_3(Double s11_3) {
        S11_3 = s11_3;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev30days detail
     */
    public Double getS12_30() {
        return S12_30;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev30days detail
     *
     * @param s12_30 the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev30days detail
     */
    public void setS12_30(Double s12_30) {
        S12_30 = s12_30;
    }

    /**
     * Gets the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev3days detail
     */
    public Double getS12_3() {
        return S12_3;
    }

    /**
     * Sets the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev3days detail
     *
     * @param s12_3 the sd_resp_cde_type_ATM_WithdrawalLimitExceeded_count_prev3days detail
     */
    public void setS12_3(Double s12_3) {
        S12_3 = s12_3;
    }

    /**
     * Gets the sd_resp_cde_type_Block_Decline_H_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_Block_Decline_H_count_prev30days detail
     */
    public Double getS13_30() {
        return S13_30;
    }

    /**
     * Sets the sd_resp_cde_type_Block_Decline_H_count_prev30days detail
     *
     * @param s13_30 the sd_resp_cde_type_Block_Decline_H_count_prev30days detail
     */
    public void setS13_30(Double s13_30) {
        S13_30 = s13_30;
    }

    /**
     * Gets the sd_resp_cde_type_Block_Decline_H_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_Block_Decline_H_count_prev3days detail
     */
    public Double getS13_3() {
        return S13_3;
    }

    /**
     * Sets the sd_resp_cde_type_Block_Decline_H_count_prev3days detail
     *
     * @param s13_3 the sd_resp_cde_type_Block_Decline_H_count_prev3days detail
     */
    public void setS13_3(Double s13_3) {
        S13_3 = s13_3;
    }

    /**
     * Gets the sd_resp_cde_type_InsuffFunds_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_InsuffFunds_count_prev30days detail
     */
    public Double getS15_30() {
        return S15_30;
    }

    /**
     * Sets the sd_resp_cde_type_InsuffFunds_count_prev30days detail
     *
     * @param s15_30 the sd_resp_cde_type_InsuffFunds_count_prev30days detail
     */
    public void setS15_30(Double s15_30) {
        S15_30 = s15_30;
    }

    /**
     * Gets the sd_resp_cde_type_InsuffFunds_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_InsuffFunds_count_prev3days detail
     */
    public Double getS15_3() {
        return S15_3;
    }

    /**
     * Sets the sd_resp_cde_type_InsuffFunds_count_prev3days detail
     *
     * @param s15_3 the sd_resp_cde_type_InsuffFunds_count_prev3days detail
     */
    public void setS15_3(Double s15_3) {
        S15_3 = s15_3;
    }

    /**
     * Gets the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev30days detail
     */
    public Double getS16_30() {
        return S16_30;
    }

    /**
     * Sets the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev30days detail
     *
     * @param s16_30 the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev30days detail
     */
    public void setS16_30(Double s16_30) {
        S16_30 = s16_30;
    }

    /**
     * Gets the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev3days detail
     */
    public Double getS16_3() {
        return S16_3;
    }

    /**
     * Sets the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @param s16_3 the sd_resp_cde_type_IntlLimitExceeded_NA_count_prev3days detail
     */
    public void setS16_3(Double s16_3) {
        S16_3 = s16_3;
    }

    /**
     * Gets the sd_resp_cde_type_OtherDeclines_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_OtherDeclines_count_prev30days detail
     */
    public Double getS18_30() {
        return S18_30;
    }

    /**
     * Sets the sd_resp_cde_type_OtherDeclines_count_prev30days detail
     *
     * @param s18_30 the sd_resp_cde_type_OtherDeclines_count_prev30days detail
     */
    public void setS18_30(Double s18_30) {
        S18_30 = s18_30;
    }

    /**
     * Gets the sd_resp_cde_type_Pickup_Capture_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_Pickup_Capture_count_prev3days detail
     */
    public Double getS19_3() {
        return S19_3;
    }

    /**
     * Sets the sd_resp_cde_type_Pickup_Capture_count_prev3days detail
     *
     * @param s19_3 the sd_resp_cde_type_Pickup_Capture_count_prev3days detail
     */
    public void setS19_3(Double s19_3) {
        S19_3 = s19_3;
    }

    /**
     * Gets the storestran_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the storestran_count_prev30days detail
     */
    public Double getS23_30() {
        return S23_30;
    }

    /**
     * Sets the storestran_count_prev30days detail
     *
     * @param s23_30 the storestran_count_prev30days detail
     */
    public void setS23_30(Double s23_30) {
        S23_30 = s23_30;
    }

    /**
     * Gets the storestran_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the storestran_count_prev3days detail
     */
    public Double getS23_3() {
        return S23_3;
    }

    /**
     * Sets the storestran_count_prev3days detail
     *
     * @param s23_3 the storestran_count_prev3days detail
     */
    public void setS23_3(Double s23_3) {
        S23_3 = s23_3;
    }

    /**
     * Gets the SM_CUST_MSTR_FLD2 detail
     *
     * @return a <code> string </code>
     * specifying the SM_CUST_MSTR_FLD2 detail
     */
    public String getS24() {
        return S24;
    }

    /**
     * Sets the SM_CUST_MSTR_FLD2 detail
     *
     * @param s24 the SM_CUST_MSTR_FLD2 detail
     */
    public void setS24(String s24) {
        S24 = s24;
    }

    /**
     * Gets the tran_cde_type_ATM_BalInquiry_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_BalInquiry_count_prev30days detail
     */
    public Double getT1_30() {
        return T1_30;
    }

    /**
     * Sets the tran_cde_type_ATM_BalInquiry_count_prev30days detail
     *
     * @param t1_30 the tran_cde_type_ATM_BalInquiry_count_prev30days detail
     */
    public void setT1_30(Double t1_30) {
        T1_30 = t1_30;
    }

    /**
     * Gets the tran_cde_type_ATM_BalInquiry_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_BalInquiry_count_prev3days detail
     */
    public Double getT1_3() {
        return T1_3;
    }

    /**
     * Sets the tran_cde_type_ATM_BalInquiry_count_prev3days detail
     *
     * @param t1_3 the tran_cde_type_ATM_BalInquiry_count_prev3days detail
     */
    public void setT1_3(Double t1_3) {
        T1_3 = t1_3;
    }

    /**
     * Gets the tran_cde_type_ATM_PinChange_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_PinChange_count_prev30days detail
     */
    public Double getT2_30() {
        return T2_30;
    }

    /**
     * Sets the tran_cde_type_ATM_PinChange_count_prev30days detail
     *
     * @param t2_30 the tran_cde_type_ATM_PinChange_count_prev30days detail
     */
    public void setT2_30(Double t2_30) {
        T2_30 = t2_30;
    }

    /**
     * Gets the tran_cde_type_ATM_PinChange_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_PinChange_count_prev3days detail
     */
    public Double getT2_3() {
        return T2_3;
    }

    /**
     * Sets the tran_cde_type_ATM_PinChange_count_prev3days detail
     *
     * @param t2_3 the tran_cde_type_ATM_PinChange_count_prev3days detail
     */
    public void setT2_3(Double t2_3) {
        T2_3 = t2_3;
    }

    /**
     * Gets the tran_cde_type_ATM_PinInquiry_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_PinInquiry_count_prev30days detail
     */
    public Double getT3_30() {
        return T3_30;
    }

    /**
     * Sets the tran_cde_type_ATM_PinInquiry_count_prev30days detail
     *
     * @param t3_30 the tran_cde_type_ATM_PinInquiry_count_prev30days detail
     */
    public void setT3_30(Double t3_30) {
        T3_30 = t3_30;
    }

    /**
     * Gets the tran_cde_type_ATM_PinInquiry_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_ATM_PinInquiry_count_prev3days detail
     */
    public Double getT3_3() {
        return T3_3;
    }

    /**
     * Sets the tran_cde_type_ATM_PinInquiry_count_prev3days detail
     *
     * @param t3_3 the tran_cde_type_ATM_PinInquiry_count_prev3days detail
     */
    public void setT3_3(Double t3_3) {
        T3_3 = t3_3;
    }

    /**
     * Gets the tran_cde_type_MailOrder_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_MailOrder_count_prev30days detail
     */
    public Double getT6_30() {
        return T6_30;
    }

    /**
     * Sets the tran_cde_type_MailOrder_count_prev30days detail
     *
     * @param t6_30 the tran_cde_type_MailOrder_count_prev30days detail
     */
    public void setT6_30(Double t6_30) {
        T6_30 = t6_30;
    }

    /**
     * Gets the tran_cde_type_MailOrder_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the tran_cde_type_MailOrder_count_prev3days detail
     */
    public Double getT6_3() {
        return T6_3;
    }

    /**
     * Sets the tran_cde_type_MailOrder_count_prev3days detail
     *
     * @param t6_3 the tran_cde_type_MailOrder_count_prev3days detail
     */
    public void setT6_3(Double t6_3) {
        T6_3 = t6_3;
    }

    /**
     * Gets the trancount_prev30days_cm detail
     *
     * @return a <code> double </code>
     * specifying the trancount_prev30days_cm detail
     */
    public Double getT14() {
        return T14;
    }

    /**
     * Sets the trancount_prev30days_cm detail
     *
     * @param t14 the trancount_prev30days_cm detail
     */
    public void setT14(Double t14) {
        T14 = t14;
    }

    /**
     * Gets the prev_hour_type detail
     *
     * @return a <code> double </code>
     * specifying the prev_hour_type detail
     */
    public Double getP5() {
        return P5;
    }

    /**
     * Sets the prev_hour_type detail
     *
     * @param p5 the prev_hour_type detail
     */
    public void setP5(Double p5) {
        P5 = p5;
    }

    /**
     * Gets the prev_postalcde_matching detail
     *
     * @return a <code> integer </code>
     * specifying the prev_postalcde_matching detail
     */
    public Integer getP7() {
        return P7;
    }

    /**
     * Sets the prev_postalcde_matching detail
     *
     * @param p7 the prev_postalcde_matching detail
     */
    public void setP7(Integer p7) {
        P7 = p7;
    }

    /**
     * Gets the prev_term_city_matching detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_city_matching detail
     */
    public Integer getP9() {
        return P9;
    }

    /**
     * Sets the prev_term_city_matching detail
     *
     * @param p9 the prev_term_city_matching detail
     */
    public void setP9(Integer p9) {
        P9 = p9;
    }

    /**
     * Gets the prev_term_city_matching_channelwise detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_city_matching_channelwise detail
     */
    public Integer getP10() {
        return P10;
    }

    /**
     * Sets the prev_term_city_matching_channelwise detail
     *
     * @param p10 the prev_term_city_matching_channelwise detail
     */
    public void setP10(Integer p10) {
        P10 = p10;
    }

    /**
     * Gets the prev_term_cntry_matching detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_cntry_matching detail
     */
    public Integer getP11() {
        return P11;
    }

    /**
     * Sets the prev_term_cntry_matching detail
     *
     * @param p11 the prev_term_cntry_matching detail
     */
    public void setP11(Integer p11) {
        P11 = p11;
    }

    /**
     * Gets the prev_term_cntry_matching_channelwise detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_cntry_matching_channelwise detail
     */
    public Integer getP12() {
        return P12;
    }

    /**
     * Sets the prev_term_cntry_matching_channelwise detail
     *
     * @param p12 the prev_term_cntry_matching_channelwise detail
     */
    public void setP12(Integer p12) {
        P12 = p12;
    }

    /**
     * Gets the prev_term_name_loc_matching detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_name_loc_matching detail
     */
    public Integer getP3() {
        return P3;
    }

    /**
     * Sets the prev_term_name_loc_matching detail
     *
     * @param p3 the prev_term_name_loc_matching detail
     */
    public void setP3(Integer p3) {
        P3 = p3;
    }

    /**
     * Gets the prev_term_state_matching detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_state_matching detail
     */
    public Integer getP14() {
        return P14;
    }

    /**
     * Sets the prev_term_state_matching detail
     *
     * @param p14 the prev_term_state_matching detail
     */
    public void setP14(Integer p14) {
        P14 = p14;
    }

    /**
     * Gets the prev_term_state_matching_channelwise detail
     *
     * @return a <code> integer </code>
     * specifying the prev_term_state_matching_channelwise detail
     */
    public Integer getP15() {
        return P15;
    }

    /**
     * Sets the prev_term_state_matching_channelwise detail
     *
     * @param p15 the prev_term_state_matching_channelwise detail
     */
    public void setP15(Integer p15) {
        P15 = p15;
    }

    /**
     * Gets the prev_tran_cde_type detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_cde_type detail
     */
    public Double getP17() {
        return P17;
    }

    /**
     * Sets the prev_tran_cde_type detail
     *
     * @param p17 the prev_tran_cde_type detail
     */
    public void setP17(Double p17) {
        P17 = p17;
    }

    /**
     * Gets the prev_tran_channel_type detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_channel_type detail
     */
    public Double getP18() {
        return P18;
    }

    /**
     * Sets the prev_tran_channel_type detail
     *
     * @param p18 the prev_tran_channel_type detail
     */
    public void setP18(Double p18) {
        P18 = p18;
    }

    /**
     * Gets the prev_tran_cntry_type detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_cntry_type detail
     */
    public Double getP19() {
        return P19;
    }

    /**
     * Sets the prev_tran_cntry_type detail
     *
     * @param p19 the prev_tran_cntry_type detail
     */
    public void setP19(Double p19) {
        P19 = p19;
    }

    /**
     * Gets the prev_tran_declined_flag_card detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_card detail
     */
    public Double getP20() {
        return P20;
    }

    /**
     * Sets the prev_tran_declined_flag_card detail
     *
     * @param p20 the prev_tran_declined_flag_card detail
     */
    public void setP20(Double p20) {
        P20 = p20;
    }

    /**
     * Gets the prev_tran_declined_flag_loc_card detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_loc_card detail
     */
    public Double getP22() {
        return P22;
    }

    /**
     * Sets the prev_tran_declined_flag_loc_card detail
     *
     * @param p22 the prev_tran_declined_flag_loc_card detail
     */
    public void setP22(Double p22) {
        P22 = p22;
    }

    /**
     * Gets the prev_tran_declined_flag_termloc detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_termloc detail
     */
    public Double getP24() {
        return P24;
    }

    /**
     * Sets the prev_tran_declined_flag_termloc detail
     *
     * @param p24 the prev_tran_declined_flag_termloc detail
     */
    public void setP24(Double p24) {
        P24 = p24;
    }

    /**
     * Gets the prev_tran_fall_back_flag detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_fall_back_flag detail
     */
    public Double getP25() {
        return P25;
    }

    /**
     * Sets the prev_tran_fall_back_flag detail
     *
     * @param p25 the prev_tran_fall_back_flag detail
     */
    public void setP25(Double p25) {
        P25 = p25;
    }

    /**
     * Gets the prev_atm_tran_days detail
     *
     * @return a <code> double </code>
     * specifying the prev_atm_tran_days detail
     */
    public Double getP31() {
        return P31;
    }

    /**
     * Sets the prev_atm_tran_days detail
     *
     * @param p31 the prev_atm_tran_days detail
     */
    public void setP31(Double p31) {
        P31 = p31;
    }

    /**
     * Gets the prev_tran_declined_flag_mer detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_mer detail
     */
    public Double getP32() {
        return P32;
    }

    /**
     * Sets the prev_tran_declined_flag_mer detail
     *
     * @param p32 the prev_tran_declined_flag_mer detail
     */
    public void setP32(Double p32) {
        P32 = p32;
    }

    /**
     * Gets the prev_tran_declined_flag_mer_card detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_mer_card detail
     */
    public Double getP33() {
        return P33;
    }

    /**
     * Sets the prev_tran_declined_flag_mer_card detail
     *
     * @param p33 the prev_tran_declined_flag_mer_card detail
     */
    public void setP33(Double p33) {
        P33 = p33;
    }

    /**
     * Gets the prev_term_location detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_location detail
     */
    public String getP35() {
        return P35;
    }

    /**
     * Sets the prev_term_location detail
     *
     * @param p35 the prev_term_location detail
     */
    public void setP35(String p35) {
        P35 = p35;
    }

    /**
     * Gets the prev_term_city detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_city detail
     */
    public String getP36() {
        return P36;
    }

    /**
     * Sets the prev_term_city detail
     *
     * @param p36 the prev_term_city detail
     */
    public void setP36(String p36) {
        P36 = p36;
    }

    /**
     * Gets the prev_term_state detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_state detail
     */
    public String getP37() {
        return P37;
    }

    /**
     * Sets the prev_term_state detail
     *
     * @param p37 the prev_term_state detail
     */
    public void setP37(String p37) {
        P37 = p37;
    }

    /**
     * Gets the prev_term_cntry detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_cntry detail
     */
    public String getP38() {
        return P38;
    }

    /**
     * Sets the prev_term_cntry detail
     *
     * @param p38 the prev_term_cntry detail
     */
    public void setP38(String p38) {
        P38 = p38;
    }

    /**
     * Gets the prev_postal_code detail
     *
     * @return a <code> string </code>
     * specifying the prev_postal_code detail
     */
    public String getP39() {
        return P39;
    }

    /**
     * Sets the prev_postal_code detail
     *
     * @param p39 the prev_postal_code detail
     */
    public void setP39(String p39) {
        P39 = p39;
    }

    /**
     * Gets the prev_term_city_channelwise detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_city_channelwise detail
     */
    public String getP40() {
        return P40;
    }

    /**
     * Sets the prev_term_city_channelwise detail
     *
     * @param p40 the prev_term_city_channelwise detail
     */
    public void setP40(String p40) {
        P40 = p40;
    }

    /**
     * Gets the prev_term_state_channelwise detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_state_channelwise detail
     */
    public String getP41() {
        return P41;
    }

    /**
     * Sets the prev_term_state_channelwise detail
     *
     * @param p41 the prev_term_state_channelwise detail
     */
    public void setP41(String p41) {
        P41 = p41;
    }

    /**
     * Gets the prev_term_cntry_channelwise detail
     *
     * @return a <code> string </code>
     * specifying the prev_term_cntry_channelwise detail
     */
    public String getP42() {
        return P42;
    }

    /**
     * Sets the prev_term_cntry_channelwise detail
     *
     * @param p42 the prev_term_cntry_channelwise detail
     */
    public void setP42(String p42) {
        P42 = p42;
    }

    /**
     * Gets the SM_USER_POSTAL_CDE detail
     *
     * @return a <code> string </code>
     * specifying the SM_USER_POSTAL_CDE detail
     */
    public String getCM_3() {
        return CM_3;
    }

    /**
     * Sets the SM_USER_POSTAL_CDE detail
     *
     * @param CM_3 the SM_USER_POSTAL_CDE detail
     */
    public void setCM_3(String CM_3) {
        this.CM_3 = CM_3;
    }

    /**
     * Gets the addrchangedays detail
     *
     * @return a <code> integer </code>
     * specifying the addrchangedays detail
     */
    public Integer getDA1() {
        return DA1;
    }

    /**
     * Sets the addrchangedays detail
     *
     * @param DA1 the addrchangedays detail
     */
    public void setDA1(Integer DA1) {
        this.DA1 = DA1;
    }

    /**
     * Gets the crdreqstdays detail
     *
     * @return a <code> integer </code>
     * specifying the crdreqstdays detail
     */
    public Integer getDA3() {
        return DA3;
    }

    /**
     * Sets the crdreqstdays detail
     *
     * @param DA3 the crdreqstdays detail
     */
    public void setDA3(Integer DA3) {
        this.DA3 = DA3;
    }

    /**
     * Gets the monetary_tran detail
     *
     * @return a <code> integer </code>
     * specifying the monetary_tran detail
     */
    public Integer getDA5() {
        return DA5;
    }

    /**
     * Sets the monetary_tran detail
     *
     * @param DA5 the monetary_tran detail
     */
    public void setDA5(Integer DA5) {
        this.DA5 = DA5;
    }

    /**
     * Gets the netbanking_reg_card_flag detail
     *
     * @return a <code> integer </code>
     * specifying the netbanking_reg_card_flag detail
     */
    public Integer getDA6() {
        return DA6;
    }

    /**
     * Sets the netbanking_reg_card_flag detail
     *
     * @param DA6 the netbanking_reg_card_flag detail
     */
    public void setDA6(Integer DA6) {
        this.DA6 = DA6;
    }

    /**
     * Gets the on_us_tran_flag detail
     *
     * @return a <code> integer </code>
     * specifying the on_us_tran_flag detail
     */
    public Integer getDA7() {
        return DA7;
    }

    /**
     * Sets the on_us_tran_flag detail
     *
     * @param DA7 the on_us_tran_flag detail
     */
    public void setDA7(Integer DA7) {
        this.DA7 = DA7;
    }

    /**
     * Gets the pinchangedays detail
     *
     * @return a <code> integer </code>
     * specifying the pinchangedays detail
     */
    public Integer getDA8() {
        return DA8;
    }

    /**
     * Sets the pinchangedays detail
     *
     * @param DA8 the pinchangedays detail
     */
    public void setDA8(Integer DA8) {
        this.DA8 = DA8;
    }

    /**
     * Gets the temp_blk_status detail
     *
     * @return a <code> integer </code>
     * specifying the temp_blk_status detail
     */
    public Integer getDA9() {
        return DA9;
    }

    /**
     * Sets the temp_blk_status detail
     *
     * @param DA9 the temp_blk_status detail
     */
    public void setDA9(Integer DA9) {
        this.DA9 = DA9;
    }

    /**
     * Gets the  distance_homeloc detail
     *
     * @return a <code> integer </code>
     * specifying the distance_homeloc detail
     */
    public Integer getDA10() {
        return DA10;
    }

    /**
     * Sets the distance_homeloc detail
     *
     * @param DA10 the distance_homeloc detail
     */
    public void setDA10(Integer DA10) {
        this.DA10 = DA10;
    }

    /**
     * Gets the dom_tran_flag detail
     *
     * @return a <code> integer </code>
     * specifying the dom_tran_flag detail
     */
    public Integer getDA11() {
        return DA11;
    }

    /**
     * Sets the dom_tran_flag detail
     *
     * @param DA11 the dom_tran_flag detail
     */
    public void setDA11(Integer DA11) {
        this.DA11 = DA11;
    }

    /**
     * Gets the hostpsot_country_flag_ind detail
     *
     * @return a <code> integer </code>
     * specifying the hostpsot_country_flag_ind detail
     */
    public Integer getDA12() {
        return DA12;
    }

    /**
     * Sets the hostpsot_country_flag_ind detail
     *
     * @param DA12 the hostpsot_country_flag_ind detail
     */
    public void setDA12(Integer DA12) {
        this.DA12 = DA12;
    }

    /**
     * Gets the cntry_type detail
     *
     * @return a <code> string </code>
     * specifying the cntry_type detail
     */
    public String getDA13() {
        return DA13;
    }

    /**
     * Sets the cntry_type detail
     *
     * @param DA13 the cntry_type detail
     */
    public void setDA13(String DA13) {
        this.DA13 = DA13;
    }

    /**
     * Gets the atm_term_city_class_numIndex detail
     *
     * @return a <code> integer </code>
     * specifying the atm_term_city_class_numIndex detail
     */
    public Integer getDA14() {
        return DA14;
    }

    /**
     * Sets the atm_term_city_class_numIndex detail
     *
     * @param DA14 the atm_term_city_class_numIndex detail
     */
    public void setDA14(Integer DA14) {
        this.DA14 = DA14;
    }

    /**
     * Gets the prev_tran_time_diff_mins detail
     *
     * @return a <code> integer </code>
     * specifying the prev_tran_time_diff_mins detail
     */
    public Integer getDA15() {
        return DA15;
    }

    /**
     * Sets the prev_tran_time_diff_mins detail
     *
     * @param DA15 the prev_tran_time_diff_mins detail
     */
    public void setDA15(Integer DA15) {
        this.DA15 = DA15;
    }

    public Integer getDA16() {
        return DA16;
    }

    public void setDA16(Integer DA16) {
        this.DA16 = DA16;
    }

    public Integer getDA17() {
        return DA17;
    }

    public void setDA17(Integer DA17) {
        this.DA17 = DA17;
    }

    /**
     * Gets the acct_type_Index detail
     *
     * @return a <code> integer </code>
     * specifying the acct_type_Index detail
     */
    public Integer getI1() {
        return I1;
    }

    /**
     * Sets the acct_type_Index detail
     *
     * @param i1 the acct_type_Index detail
     */
    public void setI1(Integer i1) {
        I1 = i1;
    }

//    /**
//     * Gets the age_bins_Index detail
//     *
//     * @return a <code> integer </code>
//     * specifying the age_bins_Index detail
//     */
//    public Integer getI2() {
//        return I2;
//    }

//    /**
//     * Sets the age_bins_Index detail
//     *
//     * @param i2 the age_bins_Index detail
//     */
//    public void setI2(Integer i2) {
//        I2 = i2;
//    }

    /**
     * Gets the amount_bins_Index detail
     *
     * @return a <code> integer </code>
     * specifying the amount_bins_Index detail
     */
    public Integer getI3() {
        return I3;
    }

    /**
     * Sets the amount_bins_Index detail
     *
     * @param i3 the amount_bins_Index detail
     */
    public void setI3(Integer i3) {
        I3 = i3;
    }

    /**
     * Gets the blkcde_Index detail
     *
     * @return a <code> integer </code>
     * specifying the blkcde_Index detail
     */
    public Integer getI4() {
        return I4;
    }

    /**
     * Sets the blkcde_Index detail
     *
     * @param i4 the blkcde_Index detail
     */
    public void setI4(Integer i4) {
        I4 = i4;
    }

    /**
     * Gets the channel_Index detail
     *
     * @return a <code> integer </code>
     * specifying the channel_Index detail
     */
    public Integer getI5() {
        return I5;
    }

    /**
     * Sets the channel_Index detail
     *
     * @param i5 the channel_Index detail
     */
    public void setI5(Integer i5) {
        I5 = i5;
    }

    /**
     * Gets the crd_stat_Index detail
     *
     * @return a <code> integer </code>
     * specifying the crd_stat_Index detail
     */
    public Integer getI6() {
        return I6;
    }

    /**
     * Sets the crd_stat_Index detail
     *
     * @param i6 the crd_stat_Index detail
     */
    public void setI6(Integer i6) {
        I6 = i6;
    }

    /**
     * Gets the entry_mde_numIndex detail
     *
     * @return a <code> integer </code>
     * specifying the entry_mde_numIndex detail
     */
    public Integer getI7() {
        return I7;
    }

    /**
     * Sets the entry_mde_numIndex detail
     *
     * @param i7 the entry_mde_numIndex detail
     */
    public void setI7(Integer i7) {
        I7 = i7;
    }

    /**
     * Gets the hour_type_Index detail
     *
     * @return a <code> integer </code>
     * specifying the hour_type_Index detail
     */
    public Integer getI8() {
        return I8;
    }

    /**
     * Sets the hour_type_Index detail
     *
     * @param i8 the hour_type_Index detail
     */
    public void setI8(Integer i8) {
        I8 = i8;
    }

    /**
     * Gets the msg_typ_numIndex detail
     *
     * @return a <code> integer </code>
     * specifying the msg_typ_numIndex detail
     */
    public Integer getI9() {
        return I9;
    }

    /**
     * Sets the msg_typ_numIndex detail
     *
     * @param i9 the msg_typ_numIndex detail
     */
    public void setI9(Integer i9) {
        I9 = i9;
    }

    /**
     * Gets the pinind_Index detail
     *
     * @return a <code> integer </code>
     * specifying the pinind_Index detail
     */
    public Integer getI10() {
        return I10;
    }

    /**
     * Sets the pinind_Index detail
     *
     * @param i10 the pinind_Index detail
     */
    public void setI10(Integer i10) {
        I10 = i10;
    }

    /**
     * Gets the tran_cde_numIndex detail
     *
     * @return a <code> integer </code>
     * specifying the tran_cde_numIndex detail
     */
    public Integer getI11() {
        return I11;
    }

    /**
     * Sets the tran_cde_numIndex detail
     *
     * @param i11 the tran_cde_numIndex detail
     */
    public void setI11(Integer i11) {
        I11 = i11;
    }

    /**
     * Gets the cond_cde_numIndex detail
     *
     * @return a <code> integer </code>
     * specifying the cond_cde_numIndex detail
     */
    public Integer getI12() {
        return I12;
    }

    /**
     * Sets the cond_cde_numIndex detail
     *
     * @param i12 the cond_cde_numIndex detail
     */
    public void setI12(Integer i12) {
        I12 = i12;
    }

    public Integer getBL_1() {
        return BL_1;
    }

    public void setBL_1(Integer BL_1) {
        this.BL_1 = BL_1;
    }

    public Integer getCL_1() {
        return CL_1;
    }

    public void setCL_1(Integer CL_1) {
        this.CL_1 = CL_1;
    }

    public Double getCL_2() {
        return CL_2;
    }

    public void setCL_2(Double CL_2) {
        this.CL_2 = CL_2;
    }

    public Double getWD_1() {
        return WD_1;
    }

    public void setWD_1(Double WD_1) {
        this.WD_1 = WD_1;
    }

    public Integer getWD_2() {
        return WD_2;
    }

    public void setWD_2(Integer WD_2) {
        this.WD_2 = WD_2;
    }

    /**
     * Gets the MD_TRAN_AMT1 detail
     *
     * @return a <code> double </code>
     * specifying the MD_TRAN_AMT1 detail
     */
    public Double getRAW1() {
        return RAW1;
    }

    /**
     * Sets the MD_TRAN_AMT1 detail
     *
     * @param RAW1 the MD_TRAN_AMT1 detail
     */
    public void setRAW1(Double RAW1) {
        this.RAW1 = RAW1;
    }

    /**
     * Gets the MD_CUST_TRAN_AMT1 detail
     *
     * @return a <code> double </code>
     * specifying the MD_CUST_TRAN_AMT1 detail
     */
    public Double getRAW2() {
        return RAW2;
    }

    /**
     * Sets the MD_CUST_TRAN_AMT1 detail
     *
     * @param RAW2 the MD_CUST_TRAN_AMT1 detail
     */
    public void setRAW2(Double RAW2) {
        this.RAW2 = RAW2;
    }

    /**
     * Gets the MD_CUST_TRAN_AMT4 detail
     *
     * @return a <code> double </code>
     * specifying the MD_CUST_TRAN_AMT4 detail
     */
    public Double getRAW3() {
        return RAW3;
    }

    /**
     * Sets the MD_CUST_TRAN_AMT4 detail
     *
     * @param RAW3 the MD_CUST_TRAN_AMT4 detail
     */
    public void setRAW3(Double RAW3) {
        this.RAW3 = RAW3;
    }

    /**
     * Gets the amount_bins_M_POS_0_1_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_0_1_count_prev3days detail
     */
    public Double getP2_3_1() {
        return P2_3_1;
    }

    /**
     * Sets the amount_bins_M_POS_0_1_count_prev3days detail
     *
     * @param p2_3_1 the amount_bins_M_ATM_0_1_count_prev3days detail
     */
    public void setP2_3_1(Double p2_3_1) {
        P2_3_1 = p2_3_1;
    }

    /**
     * Gets the amount_bins_M_POS_1_500_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_1_500_count_prev3days detail
     */
    public Double getP2_3_2() {
        return P2_3_2;
    }

    /**
     * Sets the amount_bins_M_POS_1_500_count_prev3days detail
     *
     * @param p2_3_2 the amount_bins_M_POS_1_500_count_prev3days detail
     */
    public void setP2_3_2(Double p2_3_2) {
        P2_3_2 = p2_3_2;
    }


    /**
     * Gets the amount_bins_M_POS_501_2000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_501_2000_count_prev3days detail
     */
    public Double getP2_3_3() {
        return P2_3_3;
    }

    /**
     * Sets the amount_bins_M_POS_501_2000_count_prev3days detail
     *
     * @param p2_3_3 the amount_bins_M_POS_501_2000_count_prev3days detail
     */
    public void setP2_3_3(Double p2_3_3) {
        P2_3_3 = p2_3_3;
    }

    /**
     * Gets the amount_bins_M_POS_2001_5000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_2001_5000_count_prev3days detail
     */
    public Double getP2_3_4() {
        return P2_3_4;
    }

    /**
     * Sets the amount_bins_M_POS_2001_5000_count_prev3days detail
     *
     * @param p2_3_4 the amount_bins_M_POS_2001_5000_count_prev3days detail
     */
    public void setP2_3_4(Double p2_3_4) {
        P2_3_4 = p2_3_4;
    }

    /**
     * Gets the amount_bins_M_POS_5001_10000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_5001_10000_count_prev3days detail
     */
    public Double getP2_3_5() {
        return P2_3_5;
    }

    /**
     * Sets the amount_bins_M_POS_5001_10000_count_prev3days detail
     *
     * @param p2_3_5 the amount_bins_M_POS_5001_10000_count_prev3days detail
     */
    public void setP2_3_5(Double p2_3_5) {
        P2_3_5 = p2_3_5;
    }

    /**
     * Gets the amount_bins_M_POS_10001_20000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_10001_20000_count_prev3days detail
     */
    public Double getP2_3_6() {
        return P2_3_6;
    }

    /**
     * Sets the amount_bins_M_POS_10001_20000_count_prev3days detail
     *
     * @param p2_3_6 the amount_bins_M_POS_10001_20000_count_prev3days detail
     */
    public void setP2_3_6(Double p2_3_6) {
        P2_3_6 = p2_3_6;
    }

    /**
     * Gets the amount_bins_M_POS_20001_30000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_20001_30000_count_prev3days detail
     */
    public Double getP2_3_7() {
        return P2_3_7;
    }

    /**
     * Sets the amount_bins_M_POS_20001_30000_count_prev3days detail
     *
     * @param p2_3_7 the amount_bins_M_POS_20001_30000_count_prev3days detail
     */
    public void setP2_3_7(Double p2_3_7) {
        P2_3_7 = p2_3_7;
    }

    /**
     * Gets the amount_bins_M_POS_30001_50000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_30001_50000_count_prev3days detail
     */
    public Double getP2_3_8() {
        return P2_3_8;
    }

    /**
     * Sets the amount_bins_M_POS_30001_50000_count_prev3days detail
     *
     * @param p2_3_8 the amount_bins_M_POS_30001_50000_count_prev3days detail
     */
    public void setP2_3_8(Double p2_3_8) {
        P2_3_8 = p2_3_8;
    }

    /**
     * Gets the amount_bins_M_POS_50001_100000_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_50001_100000_count_prev3days detail
     */
    public Double getP2_3_9() {
        return P2_3_9;
    }

    /**
     * Sets the amount_bins_M_POS_50001_100000_count_prev3days detail
     *
     * @param p2_3_9 the amount_bins_M_POS_50001_100000_count_prev3days detail
     */
    public void setP2_3_9(Double p2_3_9) {
        P2_3_9 = p2_3_9;
    }

    /**
     * Gets the amount_bins_M_POS_1_500_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_1_500_count_prev30days detail
     */
    public Double getP2_30_2() {
        return P2_30_2;
    }

    /**
     * Sets the amount_bins_M_POS_1_500_count_prev30days detail
     *
     * @param p2_30_2 the amount_bins_M_POS_1_500_count_prev30days detail
     */
    public void setP2_30_2(Double p2_30_2) {
        P2_30_2 = p2_30_2;
    }


    /**
     * Gets the amount_bins_M_POS_501_2000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_501_2000_count_prev30days detail
     */
    public Double getP2_30_3() {
        return P2_30_3;
    }

    /**
     * Sets the amount_bins_M_POS_501_2000_count_prev30days detail
     *
     * @param p2_30_3 the amount_bins_M_POS_501_2000_count_prev30days detail
     */
    public void setP2_30_3(Double p2_30_3) {
        P2_30_3 = p2_30_3;
    }

    /**
     * Gets the amount_bins_M_POS_2001_5000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_2001_5000_count_prev30days detail
     */
    public Double getP2_30_4() {
        return P2_30_4;
    }

    /**
     * Sets the amount_bins_M_POS_2001_5000_count_prev30days detail
     *
     * @param p2_30_4 the amount_bins_M_POS_2001_5000_count_prev30days detail
     */
    public void setP2_30_4(Double p2_30_4) {
        P2_30_4 = p2_30_4;
    }

    /**
     * Gets the amount_bins_M_POS_5001_10000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_5001_10000_count_prev30days detail
     */
    public Double getP2_30_5() {
        return P2_30_5;
    }

    /**
     * Sets the amount_bins_M_POS_5001_10000_count_prev30days detail
     *
     * @param p2_30_5 the amount_bins_M_POS_5001_10000_count_prev30days detail
     */
    public void setP2_30_5(Double p2_30_5) {
        P2_30_5 = p2_30_5;
    }

    /**
     * Gets the amount_bins_M_POS_10001_20000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_10001_20000_count_prev30days detail
     */
    public Double getP2_30_6() {
        return P2_30_6;
    }

    /**
     * Sets the amount_bins_M_POS_10001_20000_count_prev30days detail
     *
     * @param p2_30_6 the amount_bins_M_POS_10001_20000_count_prev30days detail
     */
    public void setP2_30_6(Double p2_30_6) {
        P2_30_6 = p2_30_6;
    }

    /**
     * Gets the amount_bins_M_POS_20001_30000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_20001_30000_count_prev30days detail
     */
    public Double getP2_30_7() {
        return P2_30_7;
    }

    /**
     * Sets the amount_bins_M_POS_20001_30000_count_prev30days detail
     *
     * @param p2_30_7 the amount_bins_M_POS_20001_30000_count_prev30days detail
     */
    public void setP2_30_7(Double p2_30_7) {
        P2_30_7 = p2_30_7;
    }

    /**
     * Gets the amount_bins_M_POS_50001_100000_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the amount_bins_M_POS_50001_100000_count_prev30days detail
     */
    public Double getP2_30_9() {
        return P2_30_9;
    }

    /**
     * Sets the amount_bins_M_POS_50001_100000_count_prev30days detail
     *
     * @param p2_30_9 the amount_bins_M_POS_50001_100000_count_prev30days detail
     */
    public void setP2_30_9(Double p2_30_9) {
        P2_30_9 = p2_30_9;
    }

    /**
     * Gets the sd_resp_cde_type_POS_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_IntlLimitExceeded_NA_count_prev3days detail
     */
    public Double getSP6_3() {
        return SP6_3;
    }

    /**
     * Sets the sd_resp_cde_type_POS_IntlLimitExceeded_NA_count_prev3days detail
     *
     * @param sp6_3 the sd_resp_cde_type_POS_IntlLimitExceeded_NA_count_prev3days detail
     */
    public void setSP6_3(Double sp6_3) {
        SP6_3 = sp6_3;
    }

    /**
     * Gets the sd_resp_cde_type_POS_PRM_Declined_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_PRM_Declined_count_prev3days detail
     */
    public Double getSP10_3() {
        return SP10_3;
    }

    /**
     * Sets the sd_resp_cde_type_POS_PRM_Declined_count_prev3days detail
     *
     * @param sp10_3 the sd_resp_cde_type_POS_PRM_Declined_count_prev3days detail
     */
    public void setSP10_3(Double sp10_3) {
        SP10_3 = sp10_3;
    }

    /**
     * Gets the sd_resp_cde_type_POS_ExpiredCard_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_ExpiredCard_count_prev30days detail
     */
    public Double getSP4_30() {
        return SP4_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_ExpiredCard_count_prev30days detail
     *
     * @param sp4_30 the sd_resp_cde_type_ATM_ExpiredCard_count_prev30days detail
     */
    public void setSP4_30(Double sp4_30) {
        SP4_30 = sp4_30;
    }

    /**
     * Gets the sd_resp_cde_type_POS_InsuffFunds_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_InsuffFunds_count_prev30days detail
     */
    public Double getSP5_30() {
        return SP5_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_InsuffFunds_count_prev30days detail
     *
     * @param sp5_30 the sd_resp_cde_type_POS_InsuffFunds_count_prev30days detail
     */
    public void setSP5_30(Double sp5_30) {
        SP5_30 = sp5_30;
    }

    /**
     * Gets the sd_resp_cde_type_POS_InvalidData_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_InvalidData_count_prev30days detail
     */
    public Double getSP7_30() {
        return SP7_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_InvalidData_count_prev30days detail
     *
     * @param sp7_30 the sd_resp_cde_type_POS_InvalidData_count_prev30days detail
     */
    public void setSP7_30(Double sp7_30) {
        SP7_30 = sp7_30;
    }

    /**
     * Gets the sd_resp_cde_type_POS_OtherDeclines_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_OtherDeclines_count_prev30days detail
     */
    public Double getSP8_30() {
        return SP8_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_OtherDeclines_count_prev30days detail
     *
     * @param sp8_30 the sd_resp_cde_type_POS_OtherDeclines_count_prev30days detail
     */
    public void setSP8_30(Double sp8_30) {
        SP8_30 = sp8_30;
    }

    /**
     * Gets the sd_resp_cde_type_POS_Pickup_Capture_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_Pickup_Capture_count_prev30days detail
     */
    public Double getSP9_30() {
        return SP9_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_Pickup_Capture_count_prev30days detail
     *
     * @param sp9_30 the sd_resp_cde_type_POS_Pickup_Capture_count_prev30days detail
     */
    public void setSP9_30(Double sp9_30) {
        SP9_30 = sp9_30;
    }

    /**
     * Gets the sd_resp_cde_type_POS_RestrictedCard_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_POS_RestrictedCard_count_prev30days detail
     */
    public Double getSP11_30() {
        return SP11_30;
    }

    /**
     * Sets the sd_resp_cde_type_POS_RestrictedCard_count_prev30days detail
     *
     * @param sp11_30 the sd_resp_cde_type_POS_RestrictedCard_count_prev30days detail
     */
    public void setSP11_30(Double sp11_30) {
        SP11_30 = sp11_30;
    }


    /**
     * Gets the mcc_POS_4111_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_4111_count_prev3days detail
     */
    public Double getMP_3_1() {
        return MP_3_1;
    }

    /**
     * Sets the mcc_POS_4111_count_prev3days detail
     *
     * @param mp_3_1 the mcc_POS_4111_count_prev3days detail
     */
    public void setMP_3_1(Double mp_3_1) {
        MP_3_1 = mp_3_1;
    }

    /**
     * Gets the mcc_POS_4812_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_4812_count_prev3days detail
     */
    public Double getMP_3_2() {
        return MP_3_2;
    }

    /**
     * Sets the mcc_POS_4812_count_prev3days detail
     *
     * @param mp_3_2 the mcc_POS_4812_count_prev3days detail
     */
    public void setMP_3_2(Double mp_3_2) {
        MP_3_2 = mp_3_2;
    }

    /**
     * Gets the mcc_POS_5310_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5310_count_prev3days detail
     */
    public Double getMP_3_3() {
        return MP_3_3;
    }

    /**
     * Sets the mcc_POS_5310_count_prev3days detail
     *
     * @param mp_3_3 the mcc_POS_5310_count_prev3days detail
     */
    public void setMP_3_3(Double mp_3_3) {
        MP_3_3 = mp_3_3;
    }

    /**
     * Gets the mcc_POS_5311_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5311_count_prev3days detail
     */
    public Double getMP_3_4() {
        return MP_3_4;
    }

    /**
     * Sets the mcc_POS_5311_count_prev3days detail
     *
     * @param mp_3_4 the mcc_POS_5311_count_prev3days detail
     */
    public void setMP_3_4(Double mp_3_4) {
        MP_3_4 = mp_3_4;
    }

    /**
     * Gets the mcc_POS_5399_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5399_count_prev3days detail
     */
    public Double getMP_3_5() {
        return MP_3_5;
    }

    /**
     * Sets the mcc_POS_5399_count_prev3days detail
     *
     * @param mp_3_5 the mcc_POS_5399_count_prev3days detail
     */
    public void setMP_3_5(Double mp_3_5) {
        MP_3_5 = mp_3_5;
    }

    /**
     * Gets the mcc_POS_5411_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5411_count_prev3days detail
     */
    public Double getMP_3_6() {
        return MP_3_6;
    }

    /**
     * Sets the mcc_POS_5411_count_prev3days detail
     *
     * @param mp_3_6 the mcc_POS_5411_count_prev3days detail
     */
    public void setMP_3_6(Double mp_3_6) {
        MP_3_6 = mp_3_6;
    }

    /**
     * Gets the mcc_POS_5499_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5499_count_prev3days detail
     */
    public Double getMP_3_7() {
        return MP_3_7;
    }

    /**
     * Sets the mcc_POS_5499_count_prev3days detail
     *
     * @param mp_3_7 the mcc_POS_5499_count_prev3days detail
     */
    public void setMP_3_7(Double mp_3_7) {
        MP_3_7 = mp_3_7;
    }

    /**
     * Gets the mcc_POS_5541_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5541_count_prev3days detail
     */
    public Double getMP_3_8() {
        return MP_3_8;
    }

    /**
     * Sets the mcc_POS_5541_count_prev3days detail
     *
     * @param mp_3_8 the mcc_POS_5541_count_prev3days detail
     */
    public void setMP_3_8(Double mp_3_8) {
        MP_3_8 = mp_3_8;
    }

    /**
     * Gets the mcc_POS_5542_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5542_count_prev3days detail
     */
    public Double getMP_3_9() {
        return MP_3_9;
    }

    /**
     * Sets the mcc_POS_5542_count_prev3days detail
     *
     * @param mp_3_9 the mcc_POS_5542_count_prev3days detail
     */
    public void setMP_3_9(Double mp_3_9) {
        MP_3_9 = mp_3_9;
    }

    /**
     * Gets the mcc_POS_5661_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5661_count_prev3days detail
     */
    public Double getMP_3_10() {
        return MP_3_10;
    }

    /**
     * Sets the mcc_POS_5661_count_prev3days detail
     *
     * @param mp_3_10 the mcc_POS_5661_count_prev3days detail
     */
    public void setMP_3_10(Double mp_3_10) {
        MP_3_10 = mp_3_10;
    }

    /**
     * Gets the mcc_POS_5691_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5691_count_prev3days detail
     */
    public Double getMP_3_11() {
        return MP_3_11;
    }

    /**
     * Sets the mcc_POS_5691_count_prev3days detail
     *
     * @param mp_3_11 the mcc_POS_5691_count_prev3days detail
     */
    public void setMP_3_11(Double mp_3_11) {
        MP_3_11 = mp_3_11;
    }

    /**
     * Gets the mcc_POS_5699_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5699_count_prev3days detail
     */
    public Double getMP_3_12() {
        return MP_3_12;
    }

    /**
     * Sets the mcc_POS_5699_count_prev3days detail
     *
     * @param mp_3_12 the mcc_POS_5699_count_prev3days detail
     */
    public void setMP_3_12(Double mp_3_12) {
        MP_3_12 = mp_3_12;
    }

    /**
     * Gets the mcc_POS_5732_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5732_count_prev3days detail
     */
    public Double getMP_3_13() {
        return MP_3_13;
    }

    /**
     * Sets the mcc_POS_5732_count_prev3days detail
     *
     * @param mp_3_13 the mcc_POS_5732_count_prev3days detail
     */
    public void setMP_3_13(Double mp_3_13) {
        MP_3_13 = mp_3_13;
    }

    /**
     * Gets the mcc_POS_5812_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5812_count_prev3days detail
     */
    public Double getMP_3_14() {
        return MP_3_14;
    }

    /**
     * Sets the mcc_POS_5812_count_prev3days detail
     *
     * @param mp_3_14 the mcc_POS_5812_count_prev3days detail
     */
    public void setMP_3_14(Double mp_3_14) {
        MP_3_14 = mp_3_14;
    }

    /**
     * Gets the mcc_POS_5813_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5813_count_prev3days detail
     */
    public Double getMP_3_15() {
        return MP_3_15;
    }

    /**
     * Sets the mcc_POS_5813_count_prev3days detail
     *
     * @param mp_3_15 the mcc_POS_5813_count_prev3days detail
     */
    public void setMP_3_15(Double mp_3_15) {
        MP_3_15 = mp_3_15;
    }

    /**
     * Gets the mcc_POS_5814_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5814_count_prev3days detail
     */
    public Double getMP_3_16() {
        return MP_3_16;
    }

    /**
     * Sets the mcc_POS_5814_count_prev3days detail
     *
     * @param mp_3_16 the mcc_POS_5814_count_prev3days detail
     */
    public void setMP_3_16(Double mp_3_16) {
        MP_3_16 = mp_3_16;
    }

    /**
     * Gets the mcc_POS_5912_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5912_count_prev3days detail
     */
    public Double getMP_3_17() {
        return MP_3_17;
    }

    /**
     * Sets the mcc_POS_5912_count_prev3days detail
     *
     * @param mp_3_17 the mcc_POS_5912_count_prev3days detail
     */
    public void setMP_3_17(Double mp_3_17) {
        MP_3_17 = mp_3_17;
    }

    /**
     * Gets the mcc_POS_5921_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5921_count_prev3days detail
     */
    public Double getMP_3_18() {
        return MP_3_18;
    }

    /**
     * Sets the mcc_POS_5921_count_prev3days detail
     *
     * @param mp_3_18 the mcc_POS_5921_count_prev3days detail
     */
    public void setMP_3_18(Double mp_3_18) {
        MP_3_18 = mp_3_18;
    }

    /**
     * Gets the mcc_POS_5944_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5944_count_prev3days detail
     */
    public Double getMP_3_19() {
        return MP_3_19;
    }

    /**
     * Sets the mcc_POS_5944_count_prev3days detail
     *
     * @param mp_3_19 the mcc_POS_5944_count_prev3days detail
     */
    public void setMP_3_19(Double mp_3_19) {
        MP_3_19 = mp_3_19;
    }

    /**
     * Gets the mcc_POS_5995_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5995_count_prev3days detail
     */
    public Double getMP_3_20() {
        return MP_3_20;
    }

    /**
     * Sets the mcc_POS_5995_count_prev3days detail
     *
     * @param mp_3_20 the mcc_POS_5995_count_prev3days detail
     */
    public void setMP_3_20(Double mp_3_20) {
        MP_3_20 = mp_3_20;
    }

    /**
     * Gets the mcc_POS_4111_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_4111_count_prev30days detail
     */
    public Double getMP_30_1() {
        return MP_30_1;
    }

    /**
     * Sets the mcc_POS_4111_count_prev30days detail
     *
     * @param mp_30_1 the mcc_POS_4111_count_prev30days detail
     */
    public void setMP_30_1(Double mp_30_1) {
        MP_30_1 = mp_30_1;
    }

    /**
     * Gets the mcc_POS_4812_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_4812_count_prev30days detail
     */
    public Double getMP_30_2() {
        return MP_30_2;
    }

    /**
     * Sets the mcc_POS_4812_count_prev30days detail
     *
     * @param mp_30_2 the mcc_POS_4812_count_prev30days detail
     */
    public void setMP_30_2(Double mp_30_2) {
        MP_30_2 = mp_30_2;
    }

    /**
     * Gets the mcc_POS_5310_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5310_count_prev30days detail
     */
    public Double getMP_30_3() {
        return MP_30_3;
    }

    /**
     * Sets the mcc_POS_5310_count_prev30days detail
     *
     * @param mp_30_3 the mcc_POS_5310_count_prev30days detail
     */
    public void setMP_30_3(Double mp_30_3) {
        MP_30_3 = mp_30_3;
    }

    /**
     * Gets the mcc_POS_5311_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5311_count_prev30days detail
     */
    public Double getMP_30_4() {
        return MP_30_4;
    }

    /**
     * Sets the mcc_POS_5311_count_prev30days detail
     *
     * @param mp_30_4 the mcc_POS_5311_count_prev30days detail
     */
    public void setMP_30_4(Double mp_30_4) {
        MP_30_4 = mp_30_4;
    }

    /**
     * Gets the mcc_POS_5399_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5399_count_prev30days detail
     */
    public Double getMP_30_5() {
        return MP_30_5;
    }

    /**
     * Sets the mcc_POS_5399_count_prev30days detail
     *
     * @param mp_30_5 the mcc_POS_5399_count_prev30days detail
     */
    public void setMP_30_5(Double mp_30_5) {
        MP_30_5 = mp_30_5;
    }

    /**
     * Gets the mcc_POS_5411_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5411_count_prev30days detail
     */
    public Double getMP_30_6() {
        return MP_30_6;
    }

    /**
     * Sets the mcc_POS_5411_count_prev30days detail
     *
     * @param mp_30_6 the mcc_POS_5411_count_prev30days detail
     */
    public void setMP_30_6(Double mp_30_6) {
        MP_30_6 = mp_30_6;
    }

    /**
     * Gets the mcc_POS_5499_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5499_count_prev30days detail
     */
    public Double getMP_30_7() {
        return MP_30_7;
    }

    /**
     * Sets the mcc_POS_5499_count_prev30days detail
     *
     * @param mp_30_7 the mcc_POS_5499_count_prev30days detail
     */
    public void setMP_30_7(Double mp_30_7) {
        MP_30_7 = mp_30_7;
    }

    /**
     * Gets the mcc_POS_5542_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5542_count_prev30days detail
     */
    public Double getMP_30_9() {
        return MP_30_9;
    }

    /**
     * Sets the mcc_POS_5542_count_prev30days detail
     *
     * @param mp_30_9 the mcc_POS_5542_count_prev30days detail
     */
    public void setMP_30_9(Double mp_30_9) {
        MP_30_9 = mp_30_9;
    }

    /**
     * Gets the mcc_POS_5661_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5661_count_prev30days detail
     */
    public Double getMP_30_10() {
        return MP_30_10;
    }

    /**
     * Sets the mcc_POS_5661_count_prev30days detail
     *
     * @param mp_30_10 the mcc_POS_5661_count_prev30days detail
     */
    public void setMP_30_10(Double mp_30_10) {
        MP_30_10 = mp_30_10;
    }

    /**
     * Gets the mcc_POS_5691_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5691_count_prev30days detail
     */
    public Double getMP_30_11() {
        return MP_30_11;
    }

    /**
     * Sets the mcc_POS_5691_count_prev30days detail
     *
     * @param mp_30_11 the mcc_POS_5691_count_prev30days detail
     */
    public void setMP_30_11(Double mp_30_11) {
        MP_30_11 = mp_30_11;
    }

    /**
     * Gets the mcc_POS_5699_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5699_count_prev30days detail
     */
    public Double getMP_30_12() {
        return MP_30_12;
    }

    /**
     * Sets the mcc_POS_5699_count_prev30days detail
     *
     * @param mp_30_12 the mcc_POS_5699_count_prev30days detail
     */
    public void setMP_30_12(Double mp_30_12) {
        MP_30_12 = mp_30_12;
    }

    /**
     * Gets the mcc_POS_5732_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5732_count_prev30days detail
     */
    public Double getMP_30_13() {
        return MP_30_13;
    }

    /**
     * Sets the mcc_POS_5732_count_prev30days detail
     *
     * @param mp_30_13 the mcc_POS_5732_count_prev30days detail
     */
    public void setMP_30_13(Double mp_30_13) {
        MP_30_13 = mp_30_13;
    }

    /**
     * Gets the mcc_POS_5812_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5812_count_prev30days detail
     */
    public Double getMP_30_14() {
        return MP_30_14;
    }

    /**
     * Sets the mcc_POS_5812_count_prev30days detail
     *
     * @param mp_30_14 the mcc_POS_5812_count_prev30days detail
     */
    public void setMP_30_14(Double mp_30_14) {
        MP_30_14 = mp_30_14;
    }

    /**
     * Gets the mcc_POS_5813_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5813_count_prev30days detail
     */
    public Double getMP_30_15() {
        return MP_30_15;
    }

    /**
     * Sets the mcc_POS_5813_count_prev30days detail
     *
     * @param mp_30_15 the mcc_POS_5813_count_prev30days detail
     */
    public void setMP_30_15(Double mp_30_15) {
        MP_30_15 = mp_30_15;
    }

    /**
     * Gets the mcc_POS_5814_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5814_count_prev30days detail
     */
    public Double getMP_30_16() {
        return MP_30_16;
    }

    /**
     * Sets the mcc_POS_5814_count_prev30days detail
     *
     * @param mp_30_16 the mcc_POS_5814_count_prev30days detail
     */
    public void setMP_30_16(Double mp_30_16) {
        MP_30_16 = mp_30_16;
    }

    /**
     * Gets the mcc_POS_5912_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5912_count_prev30days detail
     */
    public Double getMP_30_17() {
        return MP_30_17;
    }

    /**
     * Sets the mcc_POS_5912_count_prev30days detail
     *
     * @param mp_30_17 the mcc_POS_5912_count_prev30days detail
     */
    public void setMP_30_17(Double mp_30_17) {
        MP_30_17 = mp_30_17;
    }

    /**
     * Gets the mcc_POS_5921_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5921_count_prev30days detail
     */
    public Double getMP_30_18() {
        return MP_30_18;
    }

    /**
     * Sets the mcc_POS_5921_count_prev30days detail
     *
     * @param mp_30_18 the mcc_POS_5921_count_prev30days detail
     */
    public void setMP_30_18(Double mp_30_18) {
        MP_30_18 = mp_30_18;
    }

    /**
     * Gets the mcc_POS_5944_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5944_count_prev30days detail
     */
    public Double getMP_30_19() {
        return MP_30_19;
    }

    /**
     * Sets the mcc_POS_5944_count_prev30days detail
     *
     * @param mp_30_19 the mcc_POS_5944_count_prev30days detail
     */
    public void setMP_30_19(Double mp_30_19) {
        MP_30_19 = mp_30_19;
    }

    /**
     * Gets the mcc_POS_5995_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mcc_POS_5995_count_prev30days detail
     */
    public Double getMP_30_20() {
        return MP_30_20;
    }

    /**
     * Sets the mcc_POS_5995_count_prev30days detail
     *
     * @param mp_30_20 the mcc_POS_5995_count_prev30days detail
     */
    public void setMP_30_20(Double mp_30_20) {
        MP_30_20 = mp_30_20;
    }

    /**
     * Gets the token_srvc_POS_SamsungPay_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the token_srvc_POS_SamsungPay_count_prev3days detail
     */
    public Double getTS1_3() {
        return TS1_3;
    }

    /**
     * Sets the token_srvc_POS_SamsungPay_count_prev3days detail
     *
     * @param ts1_3 the token_srvc_POS_SamsungPay_count_prev3days detail
     */
    public void setTS1_3(Double ts1_3) {
        TS1_3 = ts1_3;
    }

    /**
     * Gets the token_srvc_POS_SamsungPay_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the token_srvc_POS_SamsungPay_count_prev30days detail
     */
    public Double getTS1_30() {
        return TS1_30;
    }

    /**
     * Sets the token_srvc_POS_SamsungPay_count_prev30days detail
     *
     * @param ts1_30 the token_srvc_POS_SamsungPay_count_prev30days detail
     */
    public void setTS1_30(Double ts1_30) {
        TS1_30 = ts1_30;
    }


    /**
     * Gets the fraud_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the fraud_count_prev3days detail
     */
    public Integer getFS() {
        return FS;
    }

    /**
     * Sets the fraud_count_prev3days detail
     *
     * @param fs the fraud_count_prev3days detail
     */
    public void setFS(Integer fs) {
        FS = fs;
    }

    /**
     * Gets the fraud_count_prev3days bin detail
     *
     * @return a <code> double </code>
     * specifying the fraud_count_prev3days bin detail
     */
    public Double getF3_3() {
        return F3_3;
    }

    /**
     * Sets the fraud_count_prev3days bin detail
     *
     * @param f3_3 the fraud_count_prev3days bin detail
     */
    public void setF3_3(Double f3_3) {
        F3_3 = f3_3;
    }

    /**
     * Gets the md_tran_amt1_M_POS_mean_prev30days bin detail
     *
     * @return a <code> double </code>
     * specifying the md_tran_amt1_M_POS_mean_prev30days bin detail
     */
    public Double getMD_T1_30() {
        return MD_T1_30;
    }

    /**
     * Sets the md_tran_amt1_M_POS_mean_prev30days bin detail
     *
     * @param md_t1_30 the md_tran_amt1_M_POS_mean_prev30days bin detail
     */
    public void setMD_T1_30(Double md_t1_30) {
        MD_T1_30 = md_t1_30;
    }

    /**
     * Gets the atmwithdrawal_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the atmwithdrawal_count_prev30days detail
     */
    public Double getA3_30() {
        return A3_30;
    }

    /**
     * Sets the atmwithdrawal_count_prev30days detail
     *
     * @param a3_30 the atmwithdrawal_count_prev30days detail
     */
    public void setA3_30(Double a3_30) {
        A3_30 = a3_30;
    }

    /**
     * Gets the count_mcc_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the count_mcc_prev30days detail
     */
    public Double getC9_30() {
        return C9_30;
    }

    /**
     * Sets the count_mcc_prev30days detail
     *
     * @param c9_30 the count_mcc_prev30days detail
     */
    public void setC9_30(Double c9_30) {
        C9_30 = c9_30;
    }

    /**
     * Gets the max_tran_amt_mcc_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the max_tran_amt_mcc_prev30days detail
     */
    public Double getM1_30() {
        return M1_30;
    }

    /**
     * Sets the max_tran_amt_mcc_prev30days detail
     *
     * @param m1_30 the max_tran_amt_mcc_prev30days detail
     */
    public void setM1_30(Double m1_30) {
        M1_30 = m1_30;
    }

    /**
     * Gets the md_tran_amt1_M_POS_min_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the md_tran_amt1_M_POS_min_prev30days detail
     */
    public Double getMD_T2_30() {
        return MD_T2_30;
    }

    /**
     * Sets the md_tran_amt1_M_POS_min_prev30days detail
     *
     * @param MD_T2_30 the md_tran_amt1_M_POS_min_prev30days detail
     */
    public void setMD_T2_30(Double MD_T2_30) {
        this.MD_T2_30 = MD_T2_30;
    }

    /**
     * Gets the md_tran_amt1_M_max_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the md_tran_amt1_M_max_prev30days detail
     */
    public Double getM5_30() {
        return M5_30;
    }

    /**
     * Sets the md_tran_amt1_M_max_prev30days detail
     *
     * @param m5_30 the md_tran_amt1_M_max_prev30days detail
     */
    public void setM5_30(Double m5_30) {
        M5_30 = m5_30;
    }


    /**
     * Gets the md_tran_amt1_M_mean_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the md_tran_amt1_M_mean_prev30days detail
     */
    public Double getM6_30() {
        return M6_30;
    }

    /**
     * Sets the md_tran_amt1_M_mean_prev30days detail
     *
     * @param m6_30 the md_tran_amt1_M_mean_prev30days detail
     */
    public void setM6_30(Double m6_30) {
        M6_30 = m6_30;
    }

    /**
     * Gets the md_tran_amt1_M_min_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the md_tran_amt1_M_min_prev30days detail
     */
    public Double getM7_30() {
        return M7_30;
    }

    /**
     * Sets the md_tran_amt1_M_min_prev30days detail
     *
     * @param m7_30 the md_tran_amt1_M_min_prev30days detail
     */
    public void setM7_30(Double m7_30) {
        M7_30 = m7_30;
    }

    /**
     * Gets the mean_tran_amt_mcc_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the mean_tran_amt_mcc_prev30days detail
     */
    public Double getM8_30() {
        return M8_30;
    }

    /**
     * Sets the mean_tran_amt_mcc_prev30days detail
     *
     * @param m8_30 the mean_tran_amt_mcc_prev30days detail
     */
    public void setM8_30(Double m8_30) {
        M8_30 = m8_30;
    }

    /**
     * Gets the prev_Amount_bins detail
     *
     * @return a <code> Integer </code>
     * specifying the prev_Amount_bins detail
     */
    public Integer getP4() {
        return P4;
    }

    /**
     * Sets the prev_Amount_bins detail
     *
     * @param p4 the prev_Amount_bins detail
     */
    public void setP4(Integer p4) {
        P4 = p4;
    }

    /**
     * Gets the prev_mcctype_matching_channelwise detail
     *
     * @return a <code> double </code>
     * specifying the prev_mcctype_matching_channelwise detail
     */
    public Double getP6() {
        return P6;
    }

    /**
     * Sets the prev_mcctype_matching_channelwise detail
     *
     * @param p6 the prev_mcctype_matching_channelwise detail
     */
    public void setP6(Double p6) {
        P6 = p6;
    }

    /**
     * Gets the prev_sd_resp_cde_type detail
     *
     * @return a <code> Integer </code>
     * specifying the prev_sd_resp_cde_type detail
     */
    public Integer getP8() {
        return P8;
    }

    /**
     * Sets the prev_sd_resp_cde_type detail
     *
     * @param p8 the prev_sd_resp_cde_type detail
     */
    public void setP8(Integer p8) {
        P8 = p8;
    }

    /**
     * Gets the prev_tran_amt detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_amt detail
     */
    public Double getP16() {
        return P16;
    }

    /**
     * Sets the prev_tran_amt detail
     *
     * @param p16 the prev_tran_amt detail
     */
    public void setP16(Double p16) {
        P16 = p16;
    }

    /**
     * Gets the prev_tran_declined_flag_channelwise detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_channelwise detail
     */
    public Double getP21() {
        return P21;
    }

    /**
     * Sets the prev_tran_declined_flag_channelwise detail
     *
     * @param p21 the prev_tran_declined_flag_channelwise detail
     */
    public void setP21(Double p21) {
        P21 = p21;
    }

    /**
     * Gets the prev_tran_declined_flag_mcc_card detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_declined_flag_mcc_card detail
     */
    public Double getP23() {
        return P23;
    }

    /**
     * Sets the prev_tran_declined_flag_mcc_card detail
     *
     * @param p23 the prev_tran_declined_flag_mcc_card detail
     */
    public void setP23(Double p23) {
        P23 = p23;
    }

    /**
     * Gets the prev_tran_keyentry_flag detail
     *
     * @return a <code> double </code>
     * specifying the prev_tran_keyentry_flag detail
     */
    public Double getP27() {
        return P27;
    }

    /**
     * Sets the prev_tran_keyentry_flag detail
     *
     * @param p27 the prev_tran_keyentry_flag detail
     */
    public void setP27(Double p27) {
        P27 = p27;
    }

    /**
     * Gets the prev_tran_monetary_type detail
     *
     * @return a <code> Integer </code>
     * specifying the prev_tran_monetary_type detail
     */
    public Integer getP28() {
        return P28;
    }

    /**
     * Sets the prev_tran_monetary_type detail
     *
     * @param p28 the prev_tran_monetary_type detail
     */
    public void setP28(Integer p28) {
        P28 = p28;
    }

    /**
     * Gets the prev_tran_pinentered_flag detail
     *
     * @return a <code> Integer </code>
     * specifying the prev_tran_pinentered_flag detail
     */
    public Integer getP29() {
        return P29;
    }

    /**
     * Sets the prev_tran_pinentered_flag detail
     *
     * @param p29 the prev_tran_pinentered_flag detail
     */
    public void setP29(Integer p29) {
        P29 = p29;
    }

    /**
     * Gets the real_time_rule_status_Authorized_count_prev30days detail
     *
     * @return a <code> double </code>
     * specifying the real_time_rule_status_Authorized_count_prev30days detail
     */
    public Double getR2_30() {
        return R2_30;
    }

    /**
     * Sets the real_time_rule_status_Authorized_count_prev30days detail
     *
     * @param r2_30 the real_time_rule_status_Authorized_count_prev30days detail
     */
    public void setR2_30(Double r2_30) {
        R2_30 = r2_30;
    }

    /**
     * Gets the sd_monetary_M_count_prev30days detail
     *
     * @return a <code> Integer </code>
     * specifying the sd_monetary_M_count_prev30days detail
     */
    public Integer getS1_30() {
        return S1_30;
    }

    /**
     * Sets the sd_monetary_M_count_prev30days detail
     *
     * @param s1_30 the sd_monetary_M_count_prev30days detail
     */
    public void setS1_30(Integer s1_30) {
        S1_30 = s1_30;
    }

    /**
     * Gets the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     */
    public Double getS14_3() {
        return S14_3;
    }

    /**
     * Sets the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     *
     * @param s14_3 the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     */
    public void setS14_3(Double s14_3) {
        S14_3 = s14_3;
    }

    /**
     * Gets the sd_resp_cde_type_InvalidData_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     */
    public Double getS17_3() {
        return S17_3;
    }

    /**
     * Sets the sd_resp_cde_type_InvalidData_count_prev3days detail
     *
     * @param s17_3 the sd_resp_cde_type_ExpiredCard_count_prev3days detail
     */
    public void setS17_3(Double s17_3) {
        S17_3 = s17_3;
    }

    /**
     * Gets the sd_resp_cde_type_OtherDeclines_count_prev3days detail
     *
     * @return a <code> double </code>
     * specifying the sd_resp_cde_type_OtherDeclines_count_prev3days detail
     */

    public Double getS18_3() {
        return S18_3;
    }

    /**
     * Sets the sd_resp_cde_type_OtherDeclines_count_prev3days detail
     *
     * @param s18_3 the sd_resp_cde_type_OtherDeclines_count_prev3days detail
     */

    public void setS18_3(Double s18_3) {
        S18_3 = s18_3;
    }

    public Double getSP20_3() {
        return SP20_3;
    }

    public void setSP20_3(Double SP20_3) {
        this.SP20_3 = SP20_3;
    }

    public Double getSP21_3() {
        return SP21_3;
    }

    public void setSP21_3(Double SP21_3) {
        this.SP21_3 = SP21_3;
    }

    public Double getSP22_3() {
        return SP22_3;
    }

    public void setSP22_3(Double SP22_3) {
        this.SP22_3 = SP22_3;
    }

    public Double getC7_30() {
        return C7_30;
    }

    public void setC7_30(Double c7_30) {
        C7_30 = c7_30;
    }

    public Double getH7_30() {
        return H7_30;
    }

    public void setH7_30(Double h7_30) {
        H7_30 = h7_30;
    }

    public Double getT9_30() {
        return T9_30;
    }

    public void setT9_30(Double t9_30) {
        T9_30 = t9_30;
    }

    public Double getS14_30() {
        return S14_30;
    }

    public void setS14_30(Double s14_30) {
        S14_30 = s14_30;
    }

    public Double getS17_30() {
        return S17_30;
    }

    public void setS17_30(Double s17_30) {
        S17_30 = s17_30;
    }

    public Double getS19_30() {
        return S19_30;
    }

    public void setS19_30(Double s19_30) {
        S19_30 = s19_30;
    }

    public Double getS20_30() {
        return S20_30;
    }

    public void setS20_30(Double s20_30) {
        S20_30 = s20_30;
    }

    public Double getS21_30() {
        return S21_30;
    }

    public void setS21_30(Double s21_30) {
        S21_30 = s21_30;
    }

    public Double getS22_30() {
        return S22_30;
    }

    public void setS22_30(Double s22_30) {
        S22_30 = s22_30;
    }

    public Double getT5_30() {
        return T5_30;
    }

    public void setT5_30(Double t5_30) {
        T5_30 = t5_30;
    }

    public Double getT7_30() {
        return T7_30;
    }

    public void setT7_30(Double t7_30) {
        T7_30 = t7_30;
    }

    public Double getT8_30() {
        return T8_30;
    }

    public void setT8_30(Double t8_30) {
        T8_30 = t8_30;
    }

    public String getM_L_30() {
        return M_L_30;
    }

    public void setM_L_30(String m_L_30) {
        M_L_30 = m_L_30;
    }

    public Double getEM_30() {
        return EM_30;
    }

    public void setEM_30(Double EM_30) {
        this.EM_30 = EM_30;
    }

    public Double getEM_7() {
        return EM_7;
    }

    public void setEM_7(Double EM_7) {
        this.EM_7 = EM_7;
    }

    public Double getHM_30() {
        return HM_30;
    }

    public void setHM_30(Double HM_30) {
        this.HM_30 = HM_30;
    }

    public Double getHM_7() {
        return HM_7;
    }

    public void setHM_7(Double HM_7) {
        this.HM_7 = HM_7;
    }

    public Double getMD_T3_30() {
        return MD_T3_30;
    }

    public void setMD_T3_30(Double MD_T3_30) {
        this.MD_T3_30 = MD_T3_30;
    }

    public Double getMD_T3_3() {
        return MD_T3_3;
    }

    public void setMD_T3_3(Double MD_T3_3) {
        this.MD_T3_3 = MD_T3_3;
    }

    public Double getMD_T4_30() {
        return MD_T4_30;
    }

    public void setMD_T4_30(Double MD_T4_30) {
        this.MD_T4_30 = MD_T4_30;
    }

    public Double getMD_T4_3() {
        return MD_T4_3;
    }

    public void setMD_T4_3(Double MD_T4_3) {
        this.MD_T4_3 = MD_T4_3;
    }

    public Double getS28_30() {
        return S28_30;
    }

    public void setS28_30(Double s28_30) {
        S28_30 = s28_30;
    }

    public Double getS29_30() {
        return S29_30;
    }

    public void setS29_30(Double s29_30) {
        S29_30 = s29_30;
    }

    public Double getS30_30() {
        return S30_30;
    }

    public void setS30_30(Double s30_30) {
        S30_30 = s30_30;
    }

    public Double getS31_30() {
        return S31_30;
    }

    public void setS31_30(Double s31_30) {
        S31_30 = s31_30;
    }

    public Double getS32_30() {
        return S32_30;
    }

    public void setS32_30(Double s32_30) {
        S32_30 = s32_30;
    }

    public Double getS33_30() {
        return S33_30;
    }

    public void setS33_30(Double s33_30) {
        S33_30 = s33_30;
    }

    public Double getS34_30() {
        return S34_30;
    }

    public void setS34_30(Double s34_30) {
        S34_30 = s34_30;
    }

    public Double getS35_30() {
        return S35_30;
    }

    public void setS35_30(Double s35_30) {
        S35_30 = s35_30;
    }

    public Double getS36_30() {
        return S36_30;
    }

    public void setS36_30(Double s36_30) {
        S36_30 = s36_30;
    }

    public Double getS37_30() {
        return S37_30;
    }

    public void setS37_30(Double s37_30) {
        S37_30 = s37_30;
    }

    public Double getS38_30() {
        return S38_30;
    }

    public void setS38_30(Double s38_30) {
        S38_30 = s38_30;
    }

    public Double getS39_30() {
        return S39_30;
    }

    public void setS39_30(Double s39_30) {
        S39_30 = s39_30;
    }

    public Double getS40_30() {
        return S40_30;
    }

    public void setS40_30(Double s40_30) {
        S40_30 = s40_30;
    }

    public Double getS41_30() {
        return S41_30;
    }

    public void setS41_30(Double s41_30) {
        S41_30 = s41_30;
    }

    public Double getS42_30() {
        return S42_30;
    }

    public void setS42_30(Double s42_30) {
        S42_30 = s42_30;
    }

    public Double getS43_30() {
        return S43_30;
    }

    public void setS43_30(Double s43_30) {
        S43_30 = s43_30;
    }

    public Double getS44_30() {
        return S44_30;
    }

    public void setS44_30(Double s44_30) {
        S44_30 = s44_30;
    }

    public Double getS45_30() {
        return S45_30;
    }

    public void setS45_30(Double s45_30) {
        S45_30 = s45_30;
    }

    public Double getS46_30() {
        return S46_30;
    }

    public void setS46_30(Double s46_30) {
        S46_30 = s46_30;
    }

    public Double getS47_30() {
        return S47_30;
    }

    public void setS47_30(Double s47_30) {
        S47_30 = s47_30;
    }

    public Double getS48_30() {
        return S48_30;
    }

    public void setS48_30(Double s48_30) {
        S48_30 = s48_30;
    }

    public Double getS49_30() {
        return S49_30;
    }

    public void setS49_30(Double s49_30) {
        S49_30 = s49_30;
    }

    public Double getS50_30() {
        return S50_30;
    }

    public void setS50_30(Double s50_30) {
        S50_30 = s50_30;
    }

    public Double getS51_30() {
        return S51_30;
    }

    public void setS51_30(Double s51_30) {
        S51_30 = s51_30;
    }

    public Double getS52_30() {
        return S52_30;
    }

    public void setS52_30(Double s52_30) {
        S52_30 = s52_30;
    }

    public Double getS53_30() {
        return S53_30;
    }

    public void setS53_30(Double s53_30) {
        S53_30 = s53_30;
    }

    public Double getS54_30() {
        return S54_30;
    }

    public void setS54_30(Double s54_30) {
        S54_30 = s54_30;
    }

    public Double getS55_30() {
        return S55_30;
    }

    public void setS55_30(Double s55_30) {
        S55_30 = s55_30;
    }

    public Double getS56_30() {
        return S56_30;
    }

    public void setS56_30(Double s56_30) {
        S56_30 = s56_30;
    }

    public Double getC2_30_3() {
        return C2_30_3;
    }

    public void setC2_30_3(Double c2_30_3) {
        C2_30_3 = c2_30_3;
    }

    public Double getC2_30_4() {
        return C2_30_4;
    }

    public void setC2_30_4(Double c2_30_4) {
        C2_30_4 = c2_30_4;
    }

    public Double getC2_30_5() {
        return C2_30_5;
    }

    public void setC2_30_5(Double c2_30_5) {
        C2_30_5 = c2_30_5;
    }

    public Double getC2_30_6() {
        return C2_30_6;
    }

    public void setC2_30_6(Double c2_30_6) {
        C2_30_6 = c2_30_6;
    }

    public Double getC2_30_7() {
        return C2_30_7;
    }

    public void setC2_30_7(Double c2_30_7) {
        C2_30_7 = c2_30_7;
    }

    public Double getC2_30_8() {
        return C2_30_8;
    }

    public void setC2_30_8(Double c2_30_8) {
        C2_30_8 = c2_30_8;
    }

    public Double getC2_30_9() {
        return C2_30_9;
    }

    public void setC2_30_9(Double c2_30_9) {
        C2_30_9 = c2_30_9;
    }

    public Double getHC1_30() {
        return HC1_30;
    }

    public void setHC1_30(Double HC1_30) {
        this.HC1_30 = HC1_30;
    }

    public Double getHC2_30() {
        return HC2_30;
    }

    public void setHC2_30(Double HC2_30) {
        this.HC2_30 = HC2_30;
    }

    public Double getHC3_30() {
        return HC3_30;
    }

    public void setHC3_30(Double HC3_30) {
        this.HC3_30 = HC3_30;
    }

    public Double getHC4_30() {
        return HC4_30;
    }

    public void setHC4_30(Double HC4_30) {
        this.HC4_30 = HC4_30;
    }

    public Double getCC1_30() {
        return CC1_30;
    }

    public void setCC1_30(Double CC1_30) {
        this.CC1_30 = CC1_30;
    }

    public Double getCC2_30() {
        return CC2_30;
    }

    public void setCC2_30(Double CC2_30) {
        this.CC2_30 = CC2_30;
    }

    public Double getSC1_30() {
        return SC1_30;
    }

    public void setSC1_30(Double SC1_30) {
        this.SC1_30 = SC1_30;
    }

    public Double getSC2_30() {
        return SC2_30;
    }

    public void setSC2_30(Double SC2_30) {
        this.SC2_30 = SC2_30;
    }

    public Double getSC3_30() {
        return SC3_30;
    }

    public void setSC3_30(Double SC3_30) {
        this.SC3_30 = SC3_30;
    }

    public Double getSC4_30() {
        return SC4_30;
    }

    public void setSC4_30(Double SC4_30) {
        this.SC4_30 = SC4_30;
    }

    public Double getSC5_30() {
        return SC5_30;
    }

    public void setSC5_30(Double SC5_30) {
        this.SC5_30 = SC5_30;
    }

    public Double getSC6_30() {
        return SC6_30;
    }

    public void setSC6_30(Double SC6_30) {
        this.SC6_30 = SC6_30;
    }

    public Double getSC7_30() {
        return SC7_30;
    }

    public void setSC7_30(Double SC7_30) {
        this.SC7_30 = SC7_30;
    }

    public Double getSC8_30() {
        return SC8_30;
    }

    public void setSC8_30(Double SC8_30) {
        this.SC8_30 = SC8_30;
    }

    public Double getSC9_30() {
        return SC9_30;
    }

    public void setSC9_30(Double SC9_30) {
        this.SC9_30 = SC9_30;
    }

    public Double getSU1_30() {
        return SU1_30;
    }

    public void setSU1_30(Double SU1_30) {
        this.SU1_30 = SU1_30;
    }

    public Double getSU2_30() {
        return SU2_30;
    }

    public void setSU2_30(Double SU2_30) {
        this.SU2_30 = SU2_30;
    }

    public Double getSU3_30() {
        return SU3_30;
    }

    public void setSU3_30(Double SU3_30) {
        this.SU3_30 = SU3_30;
    }

    public Double getSU4_30() {
        return SU4_30;
    }

    public void setSU4_30(Double SU4_30) {
        this.SU4_30 = SU4_30;
    }

    public Double getSU5_30() {
        return SU5_30;
    }

    public void setSU5_30(Double SU5_30) {
        this.SU5_30 = SU5_30;
    }

    public Double getSU6_30() {
        return SU6_30;
    }

    public void setSU6_30(Double SU6_30) {
        this.SU6_30 = SU6_30;
    }

    public Double getSU7_30() {
        return SU7_30;
    }

    public void setSU7_30(Double SU7_30) {
        this.SU7_30 = SU7_30;
    }

    public Double getSU8_30() {
        return SU8_30;
    }

    public void setSU8_30(Double SU8_30) {
        this.SU8_30 = SU8_30;
    }

    public Double getSU9_30() {
        return SU9_30;
    }

    public void setSU9_30(Double SU9_30) {
        this.SU9_30 = SU9_30;
    }

    public Double getSU10_30() {
        return SU10_30;
    }

    public void setSU10_30(Double SU10_30) {
        this.SU10_30 = SU10_30;
    }

    public Double getMC_30_1() {
        return MC_30_1;
    }

    public void setMC_30_1(Double MC_30_1) {
        this.MC_30_1 = MC_30_1;
    }

    public Double getMC_30_2() {
        return MC_30_2;
    }

    public void setMC_30_2(Double MC_30_2) {
        this.MC_30_2 = MC_30_2;
    }

    public Double getMC_30_3() {
        return MC_30_3;
    }

    public void setMC_30_3(Double MC_30_3) {
        this.MC_30_3 = MC_30_3;
    }

    public Double getMC_30_4() {
        return MC_30_4;
    }

    public void setMC_30_4(Double MC_30_4) {
        this.MC_30_4 = MC_30_4;
    }

    public Double getMC_30_5() {
        return MC_30_5;
    }

    public void setMC_30_5(Double MC_30_5) {
        this.MC_30_5 = MC_30_5;
    }

    public Double getMC_30_6() {
        return MC_30_6;
    }

    public void setMC_30_6(Double MC_30_6) {
        this.MC_30_6 = MC_30_6;
    }

    public Double getMC_30_7() {
        return MC_30_7;
    }

    public void setMC_30_7(Double MC_30_7) {
        this.MC_30_7 = MC_30_7;
    }

    public Double getMC_30_8() {
        return MC_30_8;
    }

    public void setMC_30_8(Double MC_30_8) {
        this.MC_30_8 = MC_30_8;
    }

    public Double getMC_30_9() {
        return MC_30_9;
    }

    public void setMC_30_9(Double MC_30_9) {
        this.MC_30_9 = MC_30_9;
    }

    public Double getMC_30_10() {
        return MC_30_10;
    }

    public void setMC_30_10(Double MC_30_10) {
        this.MC_30_10 = MC_30_10;
    }

    public Double getMC_30_11() {
        return MC_30_11;
    }

    public void setMC_30_11(Double MC_30_11) {
        this.MC_30_11 = MC_30_11;
    }

    public Double getMC_30_12() {
        return MC_30_12;
    }

    public void setMC_30_12(Double MC_30_12) {
        this.MC_30_12 = MC_30_12;
    }

    public Double getMC_30_13() {
        return MC_30_13;
    }

    public void setMC_30_13(Double MC_30_13) {
        this.MC_30_13 = MC_30_13;
    }

    public Double getMC_3_1() {
        return MC_3_1;
    }

    public void setMC_3_1(Double MC_3_1) {
        this.MC_3_1 = MC_3_1;
    }

    public Double getMC_3_2() {
        return MC_3_2;
    }

    public void setMC_3_2(Double MC_3_2) {
        this.MC_3_2 = MC_3_2;
    }

    public Double getMC_3_3() {
        return MC_3_3;
    }

    public void setMC_3_3(Double MC_3_3) {
        this.MC_3_3 = MC_3_3;
    }

    public Double getMC_3_4() {
        return MC_3_4;
    }

    public void setMC_3_4(Double MC_3_4) {
        this.MC_3_4 = MC_3_4;
    }

    public Double getMC_3_5() {
        return MC_3_5;
    }

    public void setMC_3_5(Double MC_3_5) {
        this.MC_3_5 = MC_3_5;
    }

    public Double getMC_3_6() {
        return MC_3_6;
    }

    public void setMC_3_6(Double MC_3_6) {
        this.MC_3_6 = MC_3_6;
    }

    public Double getMC_3_7() {
        return MC_3_7;
    }

    public void setMC_3_7(Double MC_3_7) {
        this.MC_3_7 = MC_3_7;
    }

    public Double getMC_3_8() {
        return MC_3_8;
    }

    public void setMC_3_8(Double MC_3_8) {
        this.MC_3_8 = MC_3_8;
    }

    public Double getMC_3_9() {
        return MC_3_9;
    }

    public void setMC_3_9(Double MC_3_9) {
        this.MC_3_9 = MC_3_9;
    }

    public Double getMC_3_10() {
        return MC_3_10;
    }

    public void setMC_3_10(Double MC_3_10) {
        this.MC_3_10 = MC_3_10;
    }

    public Double getMC_3_11() {
        return MC_3_11;
    }

    public void setMC_3_11(Double MC_3_11) {
        this.MC_3_11 = MC_3_11;
    }

    public Double getMC_3_12() {
        return MC_3_12;
    }

    public void setMC_3_12(Double MC_3_12) {
        this.MC_3_12 = MC_3_12;
    }

    public Double getMC_3_13() {
        return MC_3_13;
    }

    public void setMC_3_13(Double MC_3_13) {
        this.MC_3_13 = MC_3_13;
    }

    public Double getMU_30_1() {
        return MU_30_1;
    }

    public void setMU_30_1(Double MU_30_1) {
        this.MU_30_1 = MU_30_1;
    }

    public Double getMU_30_2() {
        return MU_30_2;
    }

    public void setMU_30_2(Double MU_30_2) {
        this.MU_30_2 = MU_30_2;
    }

    public Double getMU_30_3() {
        return MU_30_3;
    }

    public void setMU_30_3(Double MU_30_3) {
        this.MU_30_3 = MU_30_3;
    }

    public Double getMU_30_4() {
        return MU_30_4;
    }

    public void setMU_30_4(Double MU_30_4) {
        this.MU_30_4 = MU_30_4;
    }

    public Double getMU_30_5() {
        return MU_30_5;
    }

    public void setMU_30_5(Double MU_30_5) {
        this.MU_30_5 = MU_30_5;
    }

    public Double getMU_30_6() {
        return MU_30_6;
    }

    public void setMU_30_6(Double MU_30_6) {
        this.MU_30_6 = MU_30_6;
    }

    public Double getMU_30_7() {
        return MU_30_7;
    }

    public void setMU_30_7(Double MU_30_7) {
        this.MU_30_7 = MU_30_7;
    }

    public Double getMU_30_8() {
        return MU_30_8;
    }

    public void setMU_30_8(Double MU_30_8) {
        this.MU_30_8 = MU_30_8;
    }

    public Double getMU_30_9() {
        return MU_30_9;
    }

    public void setMU_30_9(Double MU_30_9) {
        this.MU_30_9 = MU_30_9;
    }

    public Double getMU_30_10() {
        return MU_30_10;
    }

    public void setMU_30_10(Double MU_30_10) {
        this.MU_30_10 = MU_30_10;
    }

    public Double getMU_30_11() {
        return MU_30_11;
    }

    public void setMU_30_11(Double MU_30_11) {
        this.MU_30_11 = MU_30_11;
    }

    public Double getMU_30_12() {
        return MU_30_12;
    }

    public void setMU_30_12(Double MU_30_12) {
        this.MU_30_12 = MU_30_12;
    }

    public Double getMU_30_13() {
        return MU_30_13;
    }

    public void setMU_30_13(Double MU_30_13) {
        this.MU_30_13 = MU_30_13;
    }

    public Double getMU_30_14() {
        return MU_30_14;
    }

    public void setMU_30_14(Double MU_30_14) {
        this.MU_30_14 = MU_30_14;
    }

    public Double getMU_30_15() {
        return MU_30_15;
    }

    public void setMU_30_15(Double MU_30_15) {
        this.MU_30_15 = MU_30_15;
    }

    public Double getMU_30_16() {
        return MU_30_16;
    }

    public void setMU_30_16(Double MU_30_16) {
        this.MU_30_16 = MU_30_16;
    }

    public Double getMU_30_17() {
        return MU_30_17;
    }

    public void setMU_30_17(Double MU_30_17) {
        this.MU_30_17 = MU_30_17;
    }

    public Double getMU_30_18() {
        return MU_30_18;
    }

    public void setMU_30_18(Double MU_30_18) {
        this.MU_30_18 = MU_30_18;
    }

    public Double getMU_30_19() {
        return MU_30_19;
    }

    public void setMU_30_19(Double MU_30_19) {
        this.MU_30_19 = MU_30_19;
    }

    public Double getMU_30_20() {
        return MU_30_20;
    }

    public void setMU_30_20(Double MU_30_20) {
        this.MU_30_20 = MU_30_20;
    }

    public Double getMU_3_1() {
        return MU_3_1;
    }

    public void setMU_3_1(Double MU_3_1) {
        this.MU_3_1 = MU_3_1;
    }

    public Double getMU_3_2() {
        return MU_3_2;
    }

    public void setMU_3_2(Double MU_3_2) {
        this.MU_3_2 = MU_3_2;
    }

    public Double getMU_3_3() {
        return MU_3_3;
    }

    public void setMU_3_3(Double MU_3_3) {
        this.MU_3_3 = MU_3_3;
    }

    public Double getMU_3_4() {
        return MU_3_4;
    }

    public void setMU_3_4(Double MU_3_4) {
        this.MU_3_4 = MU_3_4;
    }

    public Double getMU_3_5() {
        return MU_3_5;
    }

    public void setMU_3_5(Double MU_3_5) {
        this.MU_3_5 = MU_3_5;
    }

    public Double getMU_3_6() {
        return MU_3_6;
    }

    public void setMU_3_6(Double MU_3_6) {
        this.MU_3_6 = MU_3_6;
    }

    public Double getMU_3_7() {
        return MU_3_7;
    }

    public void setMU_3_7(Double MU_3_7) {
        this.MU_3_7 = MU_3_7;
    }

    public Double getMU_3_8() {
        return MU_3_8;
    }

    public void setMU_3_8(Double MU_3_8) {
        this.MU_3_8 = MU_3_8;
    }

    public Double getMU_3_9() {
        return MU_3_9;
    }

    public void setMU_3_9(Double MU_3_9) {
        this.MU_3_9 = MU_3_9;
    }

    public Double getMU_3_10() {
        return MU_3_10;
    }

    public void setMU_3_10(Double MU_3_10) {
        this.MU_3_10 = MU_3_10;
    }

    public Double getMU_3_11() {
        return MU_3_11;
    }

    public void setMU_3_11(Double MU_3_11) {
        this.MU_3_11 = MU_3_11;
    }

    public Double getMU_3_12() {
        return MU_3_12;
    }

    public void setMU_3_12(Double MU_3_12) {
        this.MU_3_12 = MU_3_12;
    }

    public Double getMU_3_13() {
        return MU_3_13;
    }

    public void setMU_3_13(Double MU_3_13) {
        this.MU_3_13 = MU_3_13;
    }

    public Double getMU_3_14() {
        return MU_3_14;
    }

    public void setMU_3_14(Double MU_3_14) {
        this.MU_3_14 = MU_3_14;
    }

    public Double getMU_3_15() {
        return MU_3_15;
    }

    public void setMU_3_15(Double MU_3_15) {
        this.MU_3_15 = MU_3_15;
    }

    public Double getMU_3_16() {
        return MU_3_16;
    }

    public void setMU_3_16(Double MU_3_16) {
        this.MU_3_16 = MU_3_16;
    }

    public Double getMU_3_17() {
        return MU_3_17;
    }

    public void setMU_3_17(Double MU_3_17) {
        this.MU_3_17 = MU_3_17;
    }

    public Double getMU_3_18() {
        return MU_3_18;
    }

    public void setMU_3_18(Double MU_3_18) {
        this.MU_3_18 = MU_3_18;
    }

    public Double getMU_3_19() {
        return MU_3_19;
    }

    public void setMU_3_19(Double MU_3_19) {
        this.MU_3_19 = MU_3_19;
    }

    public Double getMU_3_20() {
        return MU_3_20;
    }

    public void setMU_3_20(Double MU_3_20) {
        this.MU_3_20 = MU_3_20;
    }

    public Double getMC_T1_30() {
        return MC_T1_30;
    }

    public void setMC_T1_30(Double MC_T1_30) {
        this.MC_T1_30 = MC_T1_30;
    }

    public Double getMC_T2_30() {
        return MC_T2_30;
    }

    public void setMC_T2_30(Double MC_T2_30) {
        this.MC_T2_30 = MC_T2_30;
    }

    public Double getMC_T3_30() {
        return MC_T3_30;
    }

    public void setMC_T3_30(Double MC_T3_30) {
        this.MC_T3_30 = MC_T3_30;
    }

    public Double getMU_T1_30() {
        return MU_T1_30;
    }

    public void setMU_T1_30(Double MU_T1_30) {
        this.MU_T1_30 = MU_T1_30;
    }

    public Double getMU_T2_30() {
        return MU_T2_30;
    }

    public void setMU_T2_30(Double MU_T2_30) {
        this.MU_T2_30 = MU_T2_30;
    }

    public Double getMU_T3_30() {
        return MU_T3_30;
    }

    public void setMU_T3_30(Double MU_T3_30) {
        this.MU_T3_30 = MU_T3_30;
    }

    public Double getFC_3() {
        return FC_3;
    }

    public void setFC_3(Double FC_3) {
        this.FC_3 = FC_3;
    }

    public Double getHM1_30() {
        return HM1_30;
    }

    public void setHM1_30(Double HM1_30) {
        this.HM1_30 = HM1_30;
    }

    public Double getHM2_30() {
        return HM2_30;
    }

    public void setHM2_30(Double HM2_30) {
        this.HM2_30 = HM2_30;
    }

    public Double getHM3_30() {
        return HM3_30;
    }

    public void setHM3_30(Double HM3_30) {
        this.HM3_30 = HM3_30;
    }

    public Double getHM4_30() {
        return HM4_30;
    }

    public void setHM4_30(Double HM4_30) {
        this.HM4_30 = HM4_30;
    }

    public Double getMR1_30() {
        return MR1_30;
    }

    public void setMR1_30(Double MR1_30) {
        this.MR1_30 = MR1_30;
    }

    public Double getMR2_30() {
        return MR2_30;
    }

    public void setMR2_30(Double MR2_30) {
        this.MR2_30 = MR2_30;
    }

    public Double getMR3_30() {
        return MR3_30;
    }

    public void setMR3_30(Double MR3_30) {
        this.MR3_30 = MR3_30;
    }

    public Double getTM1_30() {
        return TM1_30;
    }

    public void setTM1_30(Double TM1_30) {
        this.TM1_30 = TM1_30;
    }

    public Double getTM2_30() {
        return TM2_30;
    }

    public void setTM2_30(Double TM2_30) {
        this.TM2_30 = TM2_30;
    }

    public Long getPM() {
        return PM;
    }

    public void setPM(Long PM) {
        this.PM = PM;
    }

    public Double getM1_1() {
        return M1_1;
    }

    public void setM1_1(Double m1_1) {
        M1_1 = m1_1;
    }

    public Double getM1_7() {
        return M1_7;
    }

    public void setM1_7(Double m1_7) {
        M1_7 = m1_7;
    }

    public Double getTC_30() {
        return TC_30;
    }

    public void setTC_30(Double TC_30) {
        this.TC_30 = TC_30;
    }

    public Integer getCP1_30() {
        return CP1_30;
    }

    public void setCP1_30(Integer CP1_30) {
        this.CP1_30 = CP1_30;
    }

    public Integer getCP2_30() {
        return CP2_30;
    }

    public void setCP2_30(Integer CP2_30) {
        this.CP2_30 = CP2_30;
    }

    public Integer getCP3_30() {
        return CP3_30;
    }

    public void setCP3_30(Integer CP3_30) {
        this.CP3_30 = CP3_30;
    }

    public Integer getCP1_3() {
        return CP1_3;
    }

    public void setCP1_3(Integer CP1_3) {
        this.CP1_3 = CP1_3;
    }

    public Integer getCP2_3() {
        return CP2_3;
    }

    public void setCP2_3(Integer CP2_3) {
        this.CP2_3 = CP2_3;
    }

    public Integer getCP3_3() {
        return CP3_3;
    }

    public void setCP3_3(Integer CP3_3) {
        this.CP3_3 = CP3_3;
    }

    public String getC1_L() {
        return C1_L;
    }

    public void setC1_L(String c1_L) {
        C1_L = c1_L;
    }

    public String getC2_L() {
        return C2_L;
    }

    public void setC2_L(String c2_L) {
        C2_L = c2_L;
    }

    public String getC3_L() {
        return C3_L;
    }

    public void setC3_L(String c3_L) {
        C3_L = c3_L;
    }

    public Double getCS_30() {
        return CS_30;
    }

    public void setCS_30(Double CS_30) {
        this.CS_30 = CS_30;
    }

    public Double getTC_1() {
        return TC_1;
    }

    public void setTC_1(Double TC_1) {
        this.TC_1 = TC_1;
    }

    public Double getC3_30_3() {
        return C3_30_3;
    }

    public void setC3_30_3(Double c3_30_3) {
        C3_30_3 = c3_30_3;
    }

    public Double getC3_30_4() {
        return C3_30_4;
    }

    public void setC3_30_4(Double c3_30_4) {
        C3_30_4 = c3_30_4;
    }

    public Double getC3_30_5() {
        return C3_30_5;
    }

    public void setC3_30_5(Double c3_30_5) {
        C3_30_5 = c3_30_5;
    }

    public Double getC3_30_6() {
        return C3_30_6;
    }

    public void setC3_30_6(Double c3_30_6) {
        C3_30_6 = c3_30_6;
    }

    public Double getC3_30_7() {
        return C3_30_7;
    }

    public void setC3_30_7(Double c3_30_7) {
        C3_30_7 = c3_30_7;
    }

    public Double getC3_30_8() {
        return C3_30_8;
    }

    public void setC3_30_8(Double c3_30_8) {
        C3_30_8 = c3_30_8;
    }

    public Double getC3_30_9() {
        return C3_30_9;
    }

    public void setC3_30_9(Double c3_30_9) {
        C3_30_9 = c3_30_9;
    }

    public Double getHC5_30() {
        return HC5_30;
    }

    public void setHC5_30(Double HC5_30) {
        this.HC5_30 = HC5_30;
    }

    public Double getHC6_30() {
        return HC6_30;
    }

    public void setHC6_30(Double HC6_30) {
        this.HC6_30 = HC6_30;
    }

    public Double getHC7_30() {
        return HC7_30;
    }

    public void setHC7_30(Double HC7_30) {
        this.HC7_30 = HC7_30;
    }

    public Double getHC8_30() {
        return HC8_30;
    }

    public void setHC8_30(Double HC8_30) {
        this.HC8_30 = HC8_30;
    }

    public Double getCC3_30() {
        return CC3_30;
    }

    public void setCC3_30(Double CC3_30) {
        this.CC3_30 = CC3_30;
    }

    public Double getCC4_30() {
        return CC4_30;
    }

    public void setCC4_30(Double CC4_30) {
        this.CC4_30 = CC4_30;
    }

    public Double getTC1_30() {
        return TC1_30;
    }

    public void setTC1_30(Double TC1_30) {
        this.TC1_30 = TC1_30;
    }

    public Double getCU_30() {
        return CU_30;
    }

    public void setCU_30(Double CU_30) {
        this.CU_30 = CU_30;
    }

    public Double getWD_1_60() {
        return WD_1_60;
    }

    public void setWD_1_60(Double WD_1_60) {
        this.WD_1_60 = WD_1_60;
    }

    public String getM_S_60() {
        return M_S_60;
    }

    public void setM_S_60(String m_S_60) {
        M_S_60 = m_S_60;
    }

    public Double getFM_60() {
        return FM_60;
    }

    public void setFM_60(Double FM_60) {
        this.FM_60 = FM_60;
    }

    public String getCU1_L() {
        return CU1_L;
    }

    public void setCU1_L(String CU1_L) {
        this.CU1_L = CU1_L;
    }

    public String getCU2_L() {
        return CU2_L;
    }

    public void setCU2_L(String CU2_L) {
        this.CU2_L = CU2_L;
    }

    public String getCU3_L() {
        return CU3_L;
    }

    public void setCU3_L(String CU3_L) {
        this.CU3_L = CU3_L;
    }

    public String getTS1() {
        return TS1;
    }

    public void setTS1(String TS1) {
        this.TS1 = TS1;
    }

}