#!/bin/sh
java -jar RTRequest.jar --spring.config.location=/config/application.properties
