package com.quadratyx.rtrequest.serviceImpl;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.time.Instant;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
public class PreProcessingFunctionsTest {

    @Autowired
    private PreProcessingFunctions preProcessingFunctions;

    @Test
    public void derivedFunction() throws ExecutionException, InterruptedException, IOException {


        //preProcessingFunctions.initilize();
        //CompletableFuture<String> cntry = preProcessingFunctions.CntryType("IN");
        //assertThat(cntry.get()).isEqualTo("Domestic");
        String dddate = "1581338136720";
        Long lddDate = Long.parseLong(dddate);
        Instant iddDate = Instant.ofEpochMilli(lddDate);

        CompletableFuture<Integer> channel = preProcessingFunctions.ChannelType("01", null, "6011", "051");
        assertThat(channel.get()).isEqualTo(2);


        CompletableFuture<Integer> monetary_train = preProcessingFunctions.monetary_tran("10");
        assertThat(monetary_train.get()).isEqualTo(1);

        Integer trans_type = preProcessingFunctions.Transtype("00000300038");
        assertThat(trans_type).isEqualTo(-1);

        Integer pin_change_days = preProcessingFunctions.diff_days(null, iddDate);
        assertThat(pin_change_days).isEqualTo(-1);

        Integer addr_change_days = preProcessingFunctions.diff_days(null, iddDate);
        assertThat(addr_change_days).isEqualTo(-1);

        Integer crd_reqst_days = preProcessingFunctions.diff_days(null, iddDate);
        assertThat(crd_reqst_days).isEqualTo(-1);

        CompletableFuture<Integer> hour_type = preProcessingFunctions.hour_classify(lddDate);
        assertThat(hour_type.get()).isEqualTo(2);

        Integer sd_fid = preProcessingFunctions.credit_card_flag("HDFC");
        assertThat(sd_fid).isEqualTo(0);

        Integer auth_src = preProcessingFunctions.auth_src("H");
        assertThat(auth_src).isEqualTo(1);

        CompletableFuture<Integer> temp_blk_card = preProcessingFunctions.temp_blk_card("HDFC", "1", "0");
        assertThat(temp_blk_card.get()).isEqualTo(0);

//        Integer amount_bins = preProcessingFunctions.AmountBins(7000.0000,monetary_train);
//        assertThat(amount_bins).isEqualTo(5);

//        Integer dom_tran_flag = preProcessingFunctions.domTranFlag(cntry);
//       assertThat(dom_tran_flag).isEqualTo(1);

        Integer is_hot_spot_country = preProcessingFunctions.hotspotCountryFlag("IN");
        assertThat(is_hot_spot_country).isEqualTo(0);

        Double distance_prevloc = preProcessingFunctions.distance_prevloc(null, "25.0168-85.6328");
        Integer dist_prevloc = distance_prevloc.intValue();
        assertThat(dist_prevloc).isEqualTo(-1);

        Double distance_home_loc = preProcessingFunctions.distance_prevloc("22.4839-88.3038", "25.0168-85.6328");
        Integer dist_home_loc = distance_home_loc.intValue();
        assertThat(dist_home_loc).isEqualTo(391);

        //CompletableFuture<Integer> age_bins = preProcessingFunctions.age_bins("132969600", iddDate);
        //assertThat(age_bins.get()).isEqualTo(6);

        Integer netbanking_reg_card_flag = preProcessingFunctions.netbanking_reg("0000");
        assertThat(netbanking_reg_card_flag).isEqualTo(0);

        Integer prev_tran_time_diff_mins = preProcessingFunctions.prev_tran_time_diff_mins(lddDate, "1581440396");
        assertThat(prev_tran_time_diff_mins).isEqualTo(-13187);

        Integer blkcde_Index = preProcessingFunctions.crd_blk_cde("HDFC", "0");
        assertThat(blkcde_Index).isEqualTo(1);

        Integer atm_term_city_class_numIndex = preProcessingFunctions.metro_flag("Ved Rd Katargam Surat    ");
        assertThat(atm_term_city_class_numIndex).isEqualTo(0);

        Integer prev_postalcde_matching = preProcessingFunctions.prev_current_term_matching("805110", null);
        assertThat(prev_postalcde_matching).isEqualTo(-1);

        Integer prev_term_city_matching = preProcessingFunctions.prev_current_term_matching("NAWADA       ", "   Surat     ");
        assertThat(prev_term_city_matching).isEqualTo(0);

        Integer prev_term_cntry_matching = preProcessingFunctions.prev_current_term_matching("IN ", "IN ");
        assertThat(prev_term_cntry_matching).isEqualTo(1);

        Integer prev_term_name_loc_matching = preProcessingFunctions.prev_current_term_matching("SAGARMALS                ", "Ved Rd Katargam Surat    ");
        assertThat(prev_term_name_loc_matching).isEqualTo(0);

        Integer prev_term_state_matching = preProcessingFunctions.prev_current_term_matching("IND", "GJ ");
        assertThat(prev_term_state_matching).isEqualTo(0);

        Integer prev_term_city_matching_channelwise = preProcessingFunctions.prev_current_term_matching("NAWADA       ", "   Surat     ");
        assertThat(prev_term_city_matching_channelwise).isEqualTo(0);

        Integer prev_term_cntry_matching_channelwise = preProcessingFunctions.prev_current_term_matching("IN ", "IN");
        assertThat(prev_term_cntry_matching_channelwise).isEqualTo(1);

        Integer prev_term_state_matching_channelwise = preProcessingFunctions.prev_current_term_matching("BR ", "GJ");
        assertThat(prev_term_state_matching_channelwise).isEqualTo(0);

    }
}
