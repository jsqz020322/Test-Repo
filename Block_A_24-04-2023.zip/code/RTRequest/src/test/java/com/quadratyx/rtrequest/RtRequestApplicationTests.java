package com.quadratyx.rtrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class RtRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
