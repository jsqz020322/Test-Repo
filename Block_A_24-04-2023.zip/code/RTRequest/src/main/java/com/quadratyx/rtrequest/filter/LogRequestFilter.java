package com.quadratyx.rtrequest.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Component
public class LogRequestFilter extends OncePerRequestFilter implements Ordered {
    private static final Logger loggerRequest = LoggerFactory.getLogger(LogRequestFilter.class);

    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE - 8;
    }

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String tid = "";
        Instant start = Instant.now();
        try {

            ContentCachingRequestWrapper wrapperedRequest = new ContentCachingRequestWrapper(request);
            ContentCachingResponseWrapper wrapperResponse = new ContentCachingResponseWrapper(response);

            String remoteHost = request.getHeader("X-FORWARDED-FOR");
            if (remoteHost == null || "".equals(remoteHost)) {
                remoteHost = request.getRemoteAddr();
            }
            filterChain.doFilter(request, wrapperResponse);

            String requestURI = wrapperedRequest.getRequestURI();
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            if (requestURI.startsWith("/fetchrtscore")) {
                byte[] buf = wrapperResponse.getContentAsByteArray();
                Map<String, String> responseMap = new ObjectMapper().readValue(buf, HashMap.class);
                tid = responseMap.get("Tiebreaker");
                httpResponse.setHeader("tid", tid);
                httpResponse.getOutputStream().write(buf);
            } else {
                httpResponse.getOutputStream().write(wrapperResponse.getContentAsByteArray());
            }
        } finally {
            loggerRequest.info("RT Res t for tid {} {} ms ", tid, Duration.between(start, Instant.now()).toMillis());
        }
    }
}
