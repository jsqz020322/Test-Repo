package com.quadratyx.rtrequest.util;

import com.quadratyx.rtrequest.model.RTRequestFormat;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CommanCode {

    /**
     * This is the common method used for putting all the derived and aggregates fields into a Map
     *
     * @param rtRequestFormat                     the transaction request details
     * @param ChannelType                          the ChannelType details
     * @param monetary_train                       the monetary train details
     * @param trans_type                           the trans type details
     * @param pin_change_days                      the pin change days details
     * @param addr_change_days                     the address change days details
     * @param crd_reqst_days                       the card request days details
     * @param hour_type                            the hour type  details
     * @param sd_fid                               the sd fid details
     * @param auth_src                             the auth src details
     * @param cntryType                            the country type details
     * @param temp_blk_status                      the temp block card details
     * @param amount_bins                          the amount bins details
     * @param distance_prevlocation                the distance from previous location details
     * @param dist_from_home_loc                   the distance from home location details
     * @param netbanking_reg_card_flag             the net banking reg card flag details
     * @param dom_tran_flag                        the domestic transaction flag details
     * @param prev_tran_time_diff_mins             the previous transaction time difference in mins details
     * @param blkcde_Index                         the block code Index details
     * @param atm_term_city_class_numIndex         the atm term city class numIndex details
     * @param pre_postalcde_matching               the previous postal code matching details
     * @param prev_term_city_matching              the previous term city matching details
     * @param prev_term_cntry_matching             the previous term country matching details
     * @param prev_term_name_loc_matching          the previous term name location matching details
     * @param prev_term_state_matching             the previous term name state matching details
     * @param prev_term_city_matching_channelwise  the previous term city matching channel wise details
     * @param prev_term_cntry_matching_channelwise the previous term country matching channel wise  details
     * @param prev_term_state_matching_channelwise the previous term state matching channel wise details
     * @param is_hot_spot_country                  the is hotspot country details
     * @param cacheMap                             the redis aggregates map details
     * @throws ExecutionException   in case of any execution exception
     * @throws InterruptedException in case of any interruption
     */
    public void utilFunc(RTRequestFormat rtRequestFormat, int ChannelType, int monetary_train, int trans_type,
                         int pin_change_days, int addr_change_days, int crd_reqst_days,
                         CompletableFuture<Integer> hour_type, int sd_fid, int auth_src, String cntryType,
                         CompletableFuture<Integer> temp_blk_status, int amount_bins, int distance_prevlocation,
                         int dist_from_home_loc, int netbanking_reg_card_flag,
                         int dom_tran_flag, int prev_tran_time_diff_mins, int blkcde_Index,
                         int atm_term_city_class_numIndex, int insufficient_bal_flag, int pre_postalcde_matching,
                         int prev_term_city_matching, int prev_term_cntry_matching,
                         int prev_term_name_loc_matching, int prev_term_state_matching,
                         int prev_term_city_matching_channelwise, int prev_term_cntry_matching_channelwise,
                         int prev_term_state_matching_channelwise, int is_hot_spot_country, int mbrNumCardType,
                         int balanceAmountBinsIndex, int cardTypeIndex, Double limits, CompletableFuture<Double> maxWithdrawalAmtPerDay,
                         int withdrawAmtExceedFlag, int frequentMerchantFlag, int MerchantFlag, int current_city_mapping,
                         int current_state_mapping, int current_country_mapping, Map<String, Object> cacheMap)
            throws ExecutionException, InterruptedException {

        try {
            cacheMap.put("I1", Integer.parseInt(rtRequestFormat.getAcctType().trim()));
        } catch (Exception e) {
            cacheMap.put("I1", 0);
        }

        //cacheMap.put("I2", age_bins.get());
        cacheMap.put("I3", amount_bins);
        cacheMap.put("I4", blkcde_Index);

        try {
            cacheMap.put("I6", Integer.parseInt(rtRequestFormat.getCardStat().trim()));
        } catch (Exception e) {
            cacheMap.put("I6", 0);
        }
        try {
            cacheMap.put("I7", Integer.parseInt(rtRequestFormat.getPontOfSrvceEntryMode().trim()));
        } catch (Exception e) {
            cacheMap.put("I7", 0);
        }
        cacheMap.put("I8", hour_type.get());
        try {
            cacheMap.put("I9", Integer.parseInt(rtRequestFormat.getMsgType().trim()));
        } catch (Exception e) {
            cacheMap.put("I9", 200);
        }

        try {
            cacheMap.put("I10", Integer.parseInt(rtRequestFormat.getPINIndx().trim()));
        } catch (Exception e) {
            cacheMap.put("I10", 0);
        }
        try {
            cacheMap.put("I11", Integer.parseInt(rtRequestFormat.getTranCode().trim()));
        } catch (Exception e) {
            cacheMap.put("I11", 0);
        }

        try {
            cacheMap.put("I12", Integer.parseInt(rtRequestFormat.getPontOfSrvcCondCode().trim()));
        } catch (Exception e) {
            cacheMap.put("I12", 0);
        }

        cacheMap.put("RAW1", rtRequestFormat.getTranAmt1());
        cacheMap.put("RAW2", rtRequestFormat.getCustTranAmt1());
        cacheMap.put("RAW3", rtRequestFormat.getCustTranAmt4());
        cacheMap.put("DA2", auth_src);
        cacheMap.put("DA4", sd_fid);
        cacheMap.put("DA10", dist_from_home_loc);
        cacheMap.put("D1", distance_prevlocation);
        cacheMap.put("DA11", dom_tran_flag);
        cacheMap.put("DA5", monetary_train);
        cacheMap.put("DA6", netbanking_reg_card_flag);
        cacheMap.put("DA8", pin_change_days);
        cacheMap.put("P7", pre_postalcde_matching);
        cacheMap.put("P9", prev_term_city_matching);
        cacheMap.put("P10", prev_term_city_matching_channelwise);
        cacheMap.put("P11", prev_term_cntry_matching);
        cacheMap.put("P12", prev_term_cntry_matching_channelwise);
        cacheMap.put("P13", prev_term_name_loc_matching);
        cacheMap.put("P14", prev_term_state_matching);
        cacheMap.put("P15", prev_term_state_matching_channelwise);
        cacheMap.put("DA15", prev_tran_time_diff_mins);
        cacheMap.put("DA9", temp_blk_status.get());
        cacheMap.put("DA12", is_hot_spot_country);

        //needed for Delta Aggregates Service
        cacheMap.put("DA13", cntryType);
        cacheMap.put("I5", ChannelType);
        cacheMap.put("DA3", crd_reqst_days);
        cacheMap.put("DA1", addr_change_days);
        cacheMap.put("DA7", trans_type);
        cacheMap.put("DA14", atm_term_city_class_numIndex);
        cacheMap.put("DA16", insufficient_bal_flag);
        cacheMap.put("BL_1", balanceAmountBinsIndex);
        cacheMap.put("CL_1", cardTypeIndex);
        cacheMap.put("CL_2", limits);
        if (maxWithdrawalAmtPerDay != null) {
            cacheMap.put("WD_1", maxWithdrawalAmtPerDay.get());
        }
        cacheMap.put("WD_2", withdrawAmtExceedFlag);
        cacheMap.put("FM_60", frequentMerchantFlag);
        cacheMap.put("P6", MerchantFlag);
        cacheMap.put("DA17", mbrNumCardType);
        cacheMap.put("CP1_3", current_state_mapping);
        cacheMap.put("CP1_30", current_state_mapping);
        cacheMap.put("CP2_3", current_city_mapping);
        cacheMap.put("CP2_30", current_city_mapping);
        cacheMap.put("CP3_3", current_country_mapping);
        cacheMap.put("CP3_30", current_country_mapping);
    }
}