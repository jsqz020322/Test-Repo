package com.quadratyx.rtrequest.globlehandler;

import com.quadratyx.rtrequest.model.RTRequestFormat;
import com.quadratyx.rtrequest.model.RTResponseFormat;
import com.quadratyx.rtrequest.util.BusinessConstant;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {


    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders httpHeaders, HttpStatus httpStatus, WebRequest request) {
        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.METHOD_NOT_ALLOWED);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.METHOD_NOT_ALLOWED);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.UNSUPPORTED_MEDIA_TYPE);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }


    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.NOT_FOUND);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.NOT_FOUND);

    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.BAD_REQUEST);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.BAD_REQUEST);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.BAD_REQUEST);
    }
    @Override
    protected ResponseEntity<Object> handleAsyncRequestTimeoutException(
            AsyncRequestTimeoutException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        RTResponseFormat responseFormat = new RTResponseFormat();
        RTRequestFormat req = new RTRequestFormat();
        String tId = req.getTiebreaker();
        req.setTiebreaker(tId);
        responseFormat.setTiebreaker(tId);
        responseFormat.setStatus(BusinessConstant.SERVICE_UNAVAILABLE);
        return new ResponseEntity<>(responseFormat.toResponse(), HttpStatus.SERVICE_UNAVAILABLE);
    }
}























































