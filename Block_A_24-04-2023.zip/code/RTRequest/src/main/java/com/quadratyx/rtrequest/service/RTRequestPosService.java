package com.quadratyx.rtrequest.service;
import java.util.Map;

import com.quadratyx.rtrequest.model.RTResponseFormat;
import com.quadratyx.rtrequest.model.RTRequestFormat;

public interface RTRequestPosService {
    public int rtScorePosService(String tId, Map<String, Object> cacheMap);

}