package com.quadratyx.rtrequest.model;

import java.util.HashMap;
import java.util.Map;

public class RTResponseFormat  {

    private String tiebreaker;
    private Integer status;
    private Integer realTimeScore;

    public RTResponseFormat() {
        //Default Constructor
    }

    public String getTiebreaker() {
        return tiebreaker;
    }

    public void setTiebreaker(String tiebreaker) {
        this.tiebreaker = tiebreaker;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getRealTimeScore() {
        return realTimeScore;
    }

    public void setRealTimeScore(Integer realTimeScore) {
        this.realTimeScore = realTimeScore;
    }

    public Map<String, Object> toResponse(){
        Map<String, Object> response = new HashMap<>();
        response.put("Tiebreaker",tiebreaker);
        response.put("status",status);
        return response;
    }
}