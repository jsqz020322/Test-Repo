package com.quadratyx.rtrequest.service;

import java.util.Map;

/**
 * An interface for NRTRequest CNP Secured Service
 */
public interface RTRequestCNPSecuredService {

    /**
     * This is the unimplemented method for NRT Request CNPSecured Service
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return NRTResponseFormat object
     * @throws Exception in case of invalid format
     */
    public int rtScoreCNPSecuredService(String tId, Map<String, Object> cacheMap);
}
