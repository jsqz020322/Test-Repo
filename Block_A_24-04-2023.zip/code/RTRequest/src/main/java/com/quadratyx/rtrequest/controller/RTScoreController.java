package com.quadratyx.rtrequest.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.rtrequest.model.RTRequestFormat;
import com.quadratyx.rtrequest.service.RTRequestAtmService;
import com.quadratyx.rtrequest.service.RTRequestCNPSecuredService;
import com.quadratyx.rtrequest.service.RTRequestCNPUnsecuredService;
import com.quadratyx.rtrequest.service.RTRequestPosService;
import com.quadratyx.rtrequest.serviceImpl.PreProcessingFunctions;
import com.quadratyx.rtrequest.serviceImpl.RedisCacheService;
import com.quadratyx.rtrequest.util.BusinessConstant;
import com.quadratyx.rtrequest.util.CommanCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
public class RTScoreController {
    private static final Logger logger = LoggerFactory.getLogger(RTScoreController.class);

    @Autowired
    private RTRequestAtmService rtRequestAtmService;

    @Autowired
    private RTRequestPosService rtRequestPosService;

    @Autowired
    private PreProcessingFunctions preProcessingservice;

    @Autowired
    private RTRequestCNPSecuredService rtRequestCNPSecuredService;

    @Autowired
    private RTRequestCNPUnsecuredService rtRequestCNPUnsecuredService;

    @Autowired
    private RedisCacheService cacheService;

    @Autowired
    @Qualifier("config")
    private Map<String, String> cityPostCdesDict;

    @Autowired
    @Qualifier("config1")
    private Map<String, String> postCdeDict;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @Autowired
    @Qualifier("defaultAggregate")
    private Map<String, Object> defaultAggregate;

    @Autowired
    @Qualifier("merchantDefaultAggregate")
    private Map<String, Object> merchantDefaultAggregate;

    @PostMapping(value = "/fetchrtscore", headers = "Accept=application/json")
    public Map<String, Object> rtRequest(@Valid @RequestBody RTRequestFormat rtRequestFormat) throws Exception {

        long st = System.currentTimeMillis();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss.SSS");
        String s_time = LocalDateTime.now().format(dateTimeFormatter);
        Map<String, Object> jsonOut = new HashMap<>();

        String key = rtRequestFormat.getPan().toString();
        String tId = rtRequestFormat.getTiebreaker();
        jsonOut.put("Tiebreaker", tId);
        String status = "status";
		String realTimeScore = "RealTimeScore";

        try {
            String sdFiid = rtRequestFormat.getFiid();
            CompletableFuture<Integer> channelType = preProcessingservice.ChannelType(rtRequestFormat.getProdInd(), rtRequestFormat.getEComFlag(), rtRequestFormat.getRtlrSICCode(), rtRequestFormat.getPontOfSrvceEntryMode());
            CompletableFuture<Integer> monetaryTrain = preProcessingservice.monetary_tran(rtRequestFormat.getTranCode());
            CompletableFuture<Integer> tempBlkCard = preProcessingservice.temp_blk_card(sdFiid, rtRequestFormat.getCardStat(), rtRequestFormat.getCardBlckCode());
            CompletableFuture<String> cardType = preProcessingservice.cardType(rtRequestFormat.getBin(), rtRequestFormat.getFiid());

            Long lddDate = rtRequestFormat.getTranDateTime();
            String ddDate = Long.toString(lddDate);
            Instant iddDate = Instant.ofEpochMilli(lddDate);

            CompletableFuture<Integer> hourType = preProcessingservice.hour_classify(lddDate);
            int transType = preProcessingservice.Transtype(rtRequestFormat.getAcqrInstIdNum());
            int pinChangeDays = preProcessingservice.diff_days(String.valueOf(rtRequestFormat.getCardPINChngDate()), iddDate);
            int addrChangeDays = preProcessingservice.diff_days(String.valueOf(rtRequestFormat.getLastAdrsChngDate()), iddDate);
            int crdReqstDays = preProcessingservice.diff_days(String.valueOf(rtRequestFormat.getCardRqstDate()), iddDate);
            int sdFid = preProcessingservice.credit_card_flag(sdFiid);
            int authSrc = preProcessingservice.auth_src(rtRequestFormat.getTranAuthSrc());
            int isHotSpotCountry = preProcessingservice.hotspotCountryFlag(rtRequestFormat.getTermCntr());

            Map<String, Object> cacheMap = new HashMap<>(cacheService.getCachedata(key, tId, defaultAggregate));

            Double tranAmt1 = rtRequestFormat.getTranAmt1();
            Double custTranAmt1 = rtRequestFormat.getCustTranAmt1();
            String SD_TERM_POSTAL_CDE = (String) cacheMap.get("P39");

            //CompletableFuture<Integer> ageBins = preProcessingservice.age_bins(String.valueOf(cacheMap.get("D3")), iddDate);
            CompletableFuture<Double> maxWithdrawalAmtPerDay = preProcessingservice.maxWithdrawalAmtPerDay(ddDate, String.valueOf(cacheMap.get("P34")), (Double) cacheMap.get("WD_1"), tranAmt1);

            CompletableFuture<Integer> result = channelType.thenApply(cType -> cType);
            int cType = result.get();
            if (cType == -1) {
                logger.error("transaction {} for  unknown channel", tId);
                String value = "Tiebreaker: " + tId + "\n" + "ProdInd: " + rtRequestFormat.getProdInd() + " " + "RtlrSICCode: " + rtRequestFormat.getRtlrSICCode() + " " + "EComFlag: " + rtRequestFormat.getEComFlag() + " " + "EntryMode: " + rtRequestFormat.getPontOfSrvceEntryMode();
                rtRequestAtmService.sendMessage(value, exceptionTopic);

                jsonOut.put(realTimeScore, 0);
                jsonOut.put(status, BusinessConstant.OK);
            } else {
                int current_state_mapping = 0;
                int current_city_mapping = 0;
                int current_country_mapping = 0;
                String merchantKey = rtRequestFormat.getTermid();
                switch (cType) {
                    case 1 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);
                    }
                    case 3 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);

                        current_state_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C1_L"), rtRequestFormat.getTermSt());
                        current_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C2_L"), rtRequestFormat.getTermCity());
                        current_country_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("C3_L"), rtRequestFormat.getTermCntr());
                    }
                    case 4 -> {
                        Map<String, Object> merchantMap = cacheService.getMerchantData(merchantKey, tId, merchantDefaultAggregate);
                        cacheMap.putAll(merchantMap);

                        current_state_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU1_L"), rtRequestFormat.getTermSt());
                        current_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU2_L"), rtRequestFormat.getTermCity());
                        current_country_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("CU3_L"), rtRequestFormat.getTermCntr());
                    }
                }

                CompletableFuture<Integer> monetaryTrainResult = monetaryTrain.thenApply(mTrain -> mTrain);
                int mTrain = monetaryTrainResult.get();

                String cntryType = preProcessingservice.CntryType(rtRequestFormat.getTermCntr());
                int amountBins = preProcessingservice.AmountBins(tranAmt1, mTrain);
                int domTranFlag = preProcessingservice.domTranFlag(cntryType);

                String termPostalCode = preProcessingservice.term_postal_code(rtRequestFormat.getTermPstlCode());
                CompletableFuture<String> postalCdeCleaned = preProcessingservice.clean_post_cde_rem_char(termPostalCode, cntryType);
                String checkPostalCode = preProcessingservice.check_postal_cde(postalCdeCleaned, cntryType, postCdeDict);
                String fillPostalCde = preProcessingservice.fill_postal_cde(rtRequestFormat.getTermCity(), checkPostalCode, cntryType, cityPostCdesDict);
                String locLatLong = preProcessingservice.fill_lat_long(fillPostalCde, cntryType, postCdeDict);
                CompletableFuture<String> prevPostalCdeCleaned = preProcessingservice.clean_post_cde_rem_char(SD_TERM_POSTAL_CDE, cntryType);
                String prevPostalCode = preProcessingservice.check_postal_cde(prevPostalCdeCleaned, cntryType, postCdeDict);
                String prevLatLong = preProcessingservice.fill_lat_long(prevPostalCode, cntryType, postCdeDict);
                Double distancePrevloc = preProcessingservice.distance_prevloc(locLatLong, prevLatLong);
                int distancePrevlocation = distancePrevloc.intValue();

                CompletableFuture<String> userPostalCdeCleaned = preProcessingservice.clean_post_cde_rem_char((String) cacheMap.get("CM_3"), cntryType);
                String userCheckPostalCode = preProcessingservice.check_postal_cde(userPostalCdeCleaned, cntryType, postCdeDict);
                String userLocLatLong = preProcessingservice.fill_lat_long(userCheckPostalCode, cntryType, postCdeDict);
                String userPrevLatLong = preProcessingservice.fill_lat_long(prevPostalCode, cntryType, postCdeDict);
                Double distanceHomeLoc = preProcessingservice.distance_prevloc(userLocLatLong, userPrevLatLong);
                int distFromHomeLoc = distanceHomeLoc.intValue();

                int netbankingRegCardFlag = preProcessingservice.netbanking_reg((String) cacheMap.get("S24"));
                int prevTranTimeDiffMins = preProcessingservice.prev_tran_time_diff_mins(lddDate, String.valueOf(cacheMap.get("P34")));
                int blkcdeIndex = preProcessingservice.crd_blk_cde(rtRequestFormat.getFiid(), rtRequestFormat.getCardBlckCode());
                int atmTermCityClassNumIndex = preProcessingservice.metro_flag(rtRequestFormat.getTermNameLoc());
                int insufficientBalFlag = preProcessingservice.insufficientBalFlag(custTranAmt1, tranAmt1);
                int prePostalcdeMatching = preProcessingservice.prev_current_term_matching(SD_TERM_POSTAL_CDE, rtRequestFormat.getTermPstlCode());
                int prevTermCityMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P36"), rtRequestFormat.getTermCity());
                int prevTermCntryMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P38"), rtRequestFormat.getTermCntr());
                int prevTermNameLocMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P35"), rtRequestFormat.getTermNameLoc());
                int prevTermStateMatching = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P37"), rtRequestFormat.getTermSt());
                int prevTermCityMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P40"), rtRequestFormat.getTermCity());
                int prevTermCntryMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P42"), rtRequestFormat.getTermCntr());
                int prevTermStateMatchingChannelwise = preProcessingservice.prev_current_term_matching((String) cacheMap.get("P41"), rtRequestFormat.getTermSt());

                Double balAmount = preProcessingservice.bal_amount(tranAmt1, custTranAmt1, mTrain);
                String balAmountBins = preProcessingservice.balAmountBins(balAmount, mTrain);
                int balanceAmountBinsIndex = preProcessingservice.balanceAmountBinsIndex(balAmountBins);

                int cardTypeIndex = preProcessingservice.cardTypeIndex(cardType);
                Double limits = preProcessingservice.limits(cardType, custTranAmt1);
                int withdrawAmtExceedFlag = preProcessingservice.withdrawAmtExceedFlag(maxWithdrawalAmtPerDay, limits);
                int frequentMerchantFlag = preProcessingservice.frequentMerchantFlag(String.valueOf(cacheMap.get("M_S_60")), rtRequestFormat.getTermid());
                int MerchantFlag = preProcessingservice.MerchantFlagPOS(String.valueOf(cacheMap.get("M_L_30")), rtRequestFormat.getRtlrSICCode());
                int mbrNumCardType = preProcessingservice.mbrNumCardType(rtRequestFormat.getMmbrNum());

                int loc_city_mapping = 0;
                if (rtRequestFormat.getTermCity() != null) {
                    loc_city_mapping = preProcessingservice.isCurrentexistinPrevData((String) cacheMap.get("P36"), rtRequestFormat.getTermCity());
                }
                cacheMap.put("L1", loc_city_mapping);

                CommanCode commanCode = new CommanCode();
                commanCode.utilFunc(rtRequestFormat, cType, mTrain, transType, pinChangeDays, addrChangeDays, crdReqstDays,
                        hourType, sdFid, authSrc, cntryType, tempBlkCard, amountBins, distancePrevlocation,
                        distFromHomeLoc, netbankingRegCardFlag, domTranFlag, prevTranTimeDiffMins, blkcdeIndex,
                        atmTermCityClassNumIndex, insufficientBalFlag, prePostalcdeMatching, prevTermCityMatching,
                        prevTermCntryMatching, prevTermNameLocMatching, prevTermStateMatching,
                        prevTermCityMatchingChannelwise, prevTermCntryMatchingChannelwise, prevTermStateMatchingChannelwise,
                        isHotSpotCountry, mbrNumCardType, balanceAmountBinsIndex, cardTypeIndex, limits, maxWithdrawalAmtPerDay,
                        withdrawAmtExceedFlag, frequentMerchantFlag, MerchantFlag, current_city_mapping, current_state_mapping,
                        current_country_mapping, cacheMap);

                int mScore = -1;
                switch (cType) {
                    case 1 -> mScore = rtRequestPosService.rtScorePosService(tId, cacheMap);
                    case 2 -> mScore = rtRequestAtmService.rtScoreAtmService(tId, cacheMap);
                    case 3 -> mScore = rtRequestCNPSecuredService.rtScoreCNPSecuredService(tId, cacheMap);
                    case 4 -> mScore = rtRequestCNPUnsecuredService.rtScoreCNPUnsecuredService(tId, cacheMap);
                }

                if (mScore == -1) {
                    jsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
                } else {
                    jsonOut.put(realTimeScore, mScore);
                    jsonOut.put(status, BusinessConstant.OK);
                }
            }

        } catch (Exception e) {
            logger.error("Exception is " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Error in Controller Tiebreaker: " + tId + "\n" + sw.toString();
            rtRequestAtmService.sendMessage(exception, exceptionTopic);
            jsonOut.put(status, BusinessConstant.INTERNAL_SERVER_ERROR);
        } finally {
            Map<String, Object> logJsonOut = new HashMap<>(jsonOut);
            logJsonOut.put("s_time", s_time);
            logJsonOut.put("t_ms", (System.currentTimeMillis() - st));
            logJsonOut.put("e_time", LocalDateTime.now().format(dateTimeFormatter));
            rtRequestAtmService.logTrace(rtRequestFormat, logJsonOut);
        }
        return jsonOut;
    }
}