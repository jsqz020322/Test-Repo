package com.quadratyx.rtrequest.serviceImpl;

import com.quadratyx.rtrequest.service.RTRequestAtmService;
import com.quadratyx.rtrequest.service.RTRequestCNPSecuredService;
import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.FieldValue;
import org.jpmml.evaluator.InputField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This service module is used for prediction of model score for POS NRT Transactions
 */
@Service
public class RTRequestCNPSecuredServiceImpl implements RTRequestCNPSecuredService {

    private static final Logger logger = LoggerFactory.getLogger(RTRequestCNPSecuredServiceImpl.class);

    @Autowired
    @Qualifier("cnpSecuredMapping")
    private Evaluator evaluator;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @Autowired
    private RTRequestAtmService rtRequestAtmService;

    /**
     * This is the implemented method used for prediction of model score for NRT POS Transactions
     *
     * @param tId      the transaction request details
     * @param cacheMap the final set of map details required for model
     * @return NRTResponseFormat object
     * @throws Exception in case of any exception
     */
    public int rtScoreCNPSecuredService(String tId, Map<String, Object> cacheMap) {
        int score = -1;
        Map<String, FieldValue> arguments = null;
        try {
            List<InputField> inputFields = evaluator.getInputFields();
            arguments = new HashMap<>();

            for (InputField inputField : inputFields) {
                String inputName = inputField.getName();
                Object rawValue = cacheMap.get(inputName);
                FieldValue inputValue = inputField.prepare(rawValue);
                arguments.put(inputName, inputValue);
            }
            //Instant start = Instant.now();
            Map<String, Object> results = (Map<String, Object>) evaluator.evaluate(arguments);
            //logger.debug("cnpSe tid {} {} ms ", tId, Duration.between(start, Instant.now()).toMillis());
            Double sc = (Double) results.get("probability(1)") * 100;
            score = (int) Math.round(sc);
        } catch (Exception e) {
            score = -1;
//            logger.error("Exception " + e.getMessage(), e);
//            logger.error("arguments ==" + arguments.toString());
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "Tiebreaker: " + tId + "\n" + sw.toString() + arguments;
            rtRequestAtmService.sendMessage(exception, exceptionTopic);
        }
        return score;
    }
}
