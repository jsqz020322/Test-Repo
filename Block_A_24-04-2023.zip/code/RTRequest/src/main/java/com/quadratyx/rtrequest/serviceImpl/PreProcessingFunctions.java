package com.quadratyx.rtrequest.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * This is the service module for Pre Processing functions (Derived Fields)
 */
@Service
public class PreProcessingFunctions {

    //private static final Logger logger = LoggerFactory.getLogger(PreProcessingFunctions.class);

    private String domestic = "Domestic";
    private String na = "NA-NA";

    @Autowired
    @Qualifier("config2")
    private Map<String, List<String>> jsonMap;

    /**
     * This is the method used for computing Amount bins Derived column
     *
     * @param MD_TRAN_AMT1  transaction amount detail
     * @param monetaryTrain monetary transaction detail
     * @return a <code> integer </code> specifying amount bins value
     * @throws InterruptedException in case of a thread interrupt
     * @throws ExecutionException   in case of execution exception
     */
    public Integer AmountBins(Double MD_TRAN_AMT1, Integer monetaryTrain) {
        int result = -1;
        try {
            if (monetaryTrain == 1) {
                if (MD_TRAN_AMT1 <= 0) {
                    result = 0;
                } else if (MD_TRAN_AMT1 <= 1) {
                    result = 1;
                } else if ((1 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 500)) {
                    result = 2;
                } else if ((500 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 2000)) {
                    result = 3;
                } else if ((2000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 5000)) {
                    result = 4;
                } else if ((5000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 10000)) {
                    result = 5;
                } else if ((10000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 20000)) {
                    result = 6;
                } else if ((20000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 30000)) {
                    result = 7;
                } else if ((30000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 50000)) {
                    result = 8;
                } else if ((50000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 100000)) {
                    result = 9;
                } else if ((100000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 500000)) {
                    result = 10;
                } else if ((500000 < MD_TRAN_AMT1) && (MD_TRAN_AMT1 <= 1000000)) {
                    result = 11;
                } else if ((MD_TRAN_AMT1 > 1000000)) {
                    result = 12;
                }
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing Channel Type Derived column
     *
     * @param sd_prod_ind      product indicator detail
     * @param sd_ecom_flag     electronic commerce flag detail
     * @param sd_retl_sic_code retailed sic code detail
     * @param sd_pt_entry_mde  transaction entry mode detail
     * @return a <code> CompletableFuture integer </code> specifying the Channel type
     */
    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<Integer> ChannelType(String sd_prod_ind, String sd_ecom_flag, String sd_retl_sic_code, String sd_pt_entry_mde) {
        int result = -1;
        List<String> list = jsonMap.get("channel_type_atm_sd_retl_sic_code");
        List<String> list1 = jsonMap.get("channel_type_atm_sd_pt_entry_mde");
        List<String> list2 = jsonMap.get("channel_type_pos_sd_pt_entry_mde");
        List<String> list3 = jsonMap.get("channel_type_sd_ecom_flag");
        List<String> list4 = jsonMap.get("channel_type_cnp_secured_sd_pt_entry_mde");
        List<String> list5 = jsonMap.get("channel_type_cnp_unsecured_sd_pt_entry_mde");

        try {
            if (("01".equals(sd_prod_ind.trim())) || ((list.contains(sd_retl_sic_code)) && (list1.contains(sd_pt_entry_mde.substring(0, 2))))) {
                result = 2;
            } else if (("02".equals(sd_prod_ind.trim())) && (!(list.contains(sd_retl_sic_code)) && (list2.contains(sd_pt_entry_mde.substring(0, 2))))) {
                result = 1;
            } else if (("02".equals(sd_prod_ind.trim())) && ((list3.contains(sd_ecom_flag)) && (list4.contains(sd_pt_entry_mde.substring(0, 2))))) {
                result = 3;
            } else if (("02".equals(sd_prod_ind.trim())) && (!(list3.contains(sd_ecom_flag)) && (list5.contains(sd_pt_entry_mde.substring(0, 2))))) {
                result = 4;
            }
        } catch (Exception e) {
            result = -1;
        }
        return CompletableFuture.completedFuture(result);
    }

    /**
     * This is the asynchronous method used for computing monetary tran derived column
     *
     * @param SD_TRAN_CDE transaction code detail
     * @return a <code> CompletableFuture integer</code> specifying the monetary tran
     */
    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<Integer> monetary_tran(String SD_TRAN_CDE) {
        int result = -1;
        List<String> list6 = jsonMap.get("monetary_tran_sd_tran_cde");
        try {
            if (("na").equals(SD_TRAN_CDE.trim()) || list6.contains(SD_TRAN_CDE.trim())) {
                result = 0;
            } else result = 1;
        } catch (Exception e) {
            result = -1;
        }
        return CompletableFuture.completedFuture(result);
    }

    /**
     * This is the asynchronous method used for computing Transaction type derived column
     *
     * @param SD_ACQ_INST_ID_NUM issuer identifier number detail
     * @return a <code> CompletableFuture integer </code> specifying the transaction type
     */
    public int Transtype(String SD_ACQ_INST_ID_NUM) {
        int result = 0;
        List<String> list7 = jsonMap.get("tran_type_sd_acq_inst_id_num");
        try {
            if (list7.contains(SD_ACQ_INST_ID_NUM)) {
                result = 1;
            } else result = 0;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing difference between days derived column
     *
     * @param day1    date and time details
     * @param iddDate transaction date and time details
     * @return a <code> CompletableFuture integer </code> specifying the days difference
     */
    public int diff_days(String day1, Instant iddDate) {
        int result = 0;
        try {
            Long d = Long.parseLong(day1);
            Instant instant = Instant.ofEpochMilli(d);
            Long day = ChronoUnit.DAYS.between(instant, iddDate);
            Integer days = day.intValue();

            if (days > 0) result = days;
            else result = -1;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing hour type derived column
     *
     * @param dd_date transaction date and time detail
     * @return a <code> CompletableFuture integer </code> specifying the hour type
     */
    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<Integer> hour_classify(Long dd_date) {
        int result1 = -1;
        try {
            List<String> list9 = jsonMap.get("hour_classify_busHrs");
            List<String> list10 = jsonMap.get("hour_classify_close_midnight");
            List<String> list11 = jsonMap.get("hour_classify_lateNight");
            ZoneId zone = ZoneId.of("Asia/Kolkata");

            LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(dd_date), zone);
            int hours = dateTime.getHour();
            String hour = Integer.toString(hours);

            if (list9.contains(hour)) result1 = 2;
            else if (list10.contains(hour)) result1 = 3;
            else if (list11.contains(hour)) result1 = 4;
            else result1 = 1;

        } catch (Exception e) {
            result1 = -1;
        }
        return CompletableFuture.completedFuture(result1);
    }

    /**
     * This is the asynchronous method used for computing credit card flag derived column
     *
     * @param sd_fiid financial institution identifier detail
     * @return a <code> CompletableFuture integer </code> specifying the credit card flag
     */
    public int credit_card_flag(String sd_fiid) {
        int result = 0;
        try {
            if (sd_fiid == null) {
                result = -1;
            } else {
                if (sd_fiid.equals("HDFB"))
                    result = 1;
                else
                    result = 0;
            }

        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing authorization derived column
     *
     * @param sd_auth_src transaction authorization detail
     * @return a <code> CompletableFuture integer </code> specifying the authorization code
     */
    public int auth_src(String sd_auth_src) {
        int result = 0;
        try {
            if (sd_auth_src == null) {
                result = -1;
            } else {
                if (sd_auth_src.trim().equals("B"))
                    result = 0;
                else if (sd_auth_src.trim().equals("H"))
                    result = 1;
                else
                    result = 2;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing temp block card
     *
     * @param sd_fiid        financial institution identifier detail
     * @param sd_crd_stat    card state detail
     * @param sd_crd_blk_cde card block code detail
     * @return a <code> CompletableFuture integer </code> specifying the temp block card
     */
    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<Integer> temp_blk_card(String sd_fiid, String sd_crd_stat, String sd_crd_blk_cde) {
        int result = 0;
        List<String> list12 = jsonMap.get("temp_blk_card_sd_crd_stat");
        List<String> list13 = jsonMap.get("temp_blk_card_sd_crd_blk_cde");
        try {
            if ((("HDFC").equals(sd_fiid.trim()) && (sd_crd_stat != null) && (list12.contains(sd_crd_stat.trim())))
                    || (("HDFB").equals(sd_fiid.trim()) && (sd_crd_blk_cde != null) && (!(list13.contains(sd_crd_blk_cde.trim()))))) {
                result = 1;
            }
        } catch (Exception e) {
            result = -1;
        }
        return CompletableFuture.completedFuture(result);
    }

    /**
     * This is the asynchronous method used for computing country type
     *
     * @param sd_term_cntry country detail
     * @return a <code> CompletableFuture integer </code> specifying the country type
     */
    public String CntryType(String sd_term_cntry) {
        String result = "NA";
        try {
            if (sd_term_cntry == null) {
                result = "NA";
            } else {
                String termcntry = sd_term_cntry.trim();
                if (termcntry.equals("")) {
                    result = domestic;
                }
                if (termcntry.equals("IN")) {
                    result = domestic;
                }
                if (!(termcntry).equals("IN")) {
                    result = "International";
                }
            }

        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for computing term postal code
     *
     * @param term_postal_cde postal code detail
     * @return a <code> string </code> specifying the term postal code
     */
    public String term_postal_code(String term_postal_cde) {

        String result = null;
        try {
            if (term_postal_cde == null) {
                result = "NA";
            } else {
                if (!term_postal_cde.trim().equals("null")) {
                    result = term_postal_cde;
                } else {
                    result = "NA";
                }
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    /**
     * This is the method used for cleaning postal code
     *
     * @param SD_TERM_POSTAL_CDE postal code detail
     * @param CntryType          country detail
     * @return a <code> string </code> specifying the cleaned postal code
     * @throws ExecutionException   in case of execution exception
     * @throws InterruptedException in case of a thread interrupt
     */
    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<String> clean_post_cde_rem_char(String SD_TERM_POSTAL_CDE, String CntryType) throws ExecutionException, InterruptedException {
        String result = "NA";
        if (!(domestic).equals(CntryType.trim())) {
            result = SD_TERM_POSTAL_CDE;
        } else {
            if (SD_TERM_POSTAL_CDE != null) {
                SD_TERM_POSTAL_CDE = SD_TERM_POSTAL_CDE.trim();
                String postal_cde_clean = SD_TERM_POSTAL_CDE.replaceAll("[^\\d.]", "");
                int len_post_cde = postal_cde_clean.length();
                if (len_post_cde == 6) {
                    if (!String.valueOf(postal_cde_clean.charAt(0)).equals("0")) {
                        result = postal_cde_clean;
                    }
                } else if (len_post_cde > 6) {
                    String sub_str = postal_cde_clean.substring(0, len_post_cde - 6);
                    String check_z = String.join("", Collections.nCopies((len_post_cde - 6), "0"));
                    if (sub_str.equals(check_z) && (!String.valueOf(postal_cde_clean.substring(len_post_cde - 6, len_post_cde).charAt(0)).equals("0"))) {
                        result = postal_cde_clean.substring(len_post_cde - 6, len_post_cde);
                    }
                }
            }
        }
        return CompletableFuture.completedFuture(result);
    }

    /**
     * This is the method used for check postal code
     *
     * @param postal_cde_cleaned cleaned postal code detail
     * @param CntryType          country detail
     * @param post_cde_dict      json map with postal code details
     * @return a <code> string </code> specifying the check postal code
     * @throws ExecutionException   in case of execution exception
     * @throws InterruptedException in case of a thread interrupt
     */
    public String check_postal_cde(CompletableFuture<String> postal_cde_cleaned, String CntryType, Map<String, String> post_cde_dict) throws ExecutionException, InterruptedException {

        String result = null;
        if (!(domestic).equals(CntryType.trim())) {
            result = postal_cde_cleaned.get();
        } else {
            int pc_len = postal_cde_cleaned.get().length();
            if (pc_len == 6) {
                try {
                    String value = post_cde_dict.get(postal_cde_cleaned);
                    result = postal_cde_cleaned.get();
                } catch (Exception e) {
                    result = "NA";
                }
            } else
                return postal_cde_cleaned.get();
        }
        return result;
    }

    /**
     * This is the method used for filling postal code
     *
     * @param SD_TERM_CITY        terminal city detail
     * @param postal_cde_cleaned  cleaned postal code detail
     * @param CntryType           country type detail
     * @param city_post_cdes_dict a json map for city postal code detail
     * @return a <code> string </code> specifying the filled postal code
     * @throws ExecutionException   in case of execution exception
     * @throws InterruptedException in case of a thread interrupt
     */
    public String fill_postal_cde(String SD_TERM_CITY, String postal_cde_cleaned, String CntryType, Map<String, String> city_post_cdes_dict) throws ExecutionException, InterruptedException {
        String result = null;
        if (!(domestic).equals(CntryType.trim())) {
            result = postal_cde_cleaned;
        } else {
            if (!("NA").equals(postal_cde_cleaned)) {
                result = postal_cde_cleaned;
            } else {
                try {
                    String v = city_post_cdes_dict.get(SD_TERM_CITY.trim());
                    result = v;

                    if (result == null || result.isEmpty()) {
                        if (SD_TERM_CITY.trim().equals("BANGALORE"))
                            result = "560001";
                        if (SD_TERM_CITY.trim().equals("MUM"))
                            result = "400004";
                        if (SD_TERM_CITY.trim().equals("DEL"))
                            result = "110003";
                    }
                } catch (Exception e) {
                    result = "NA";
                }
            }
        }
        return result;
    }

    /**
     * This is the method used for filling latitude longitude
     *
     * @param postal_cde_cleaned cleaned postal code detail
     * @param CntryType          country type detail
     * @param post_cde_dict      a json map for postal code detail
     * @return a <code> string </code> specifying the filled latitude longitude
     * @throws ExecutionException   in case of execution exception
     * @throws InterruptedException in case of a thread interrupt
     */
    public String fill_lat_long(String postal_cde_cleaned, String CntryType, Map<String, String> post_cde_dict) {
        String result = na;
        try {
            if ((domestic).equals(CntryType)) {
                String value = post_cde_dict.get(postal_cde_cleaned);
                result = value;
            }
        } catch (Exception e) {
            result = na;
        }
        return result;
    }

    /**
     * This is the method used for computing distance between two location
     *
     * @param loc1 First location detail
     * @param loc2 Second location detail
     * @return a <code> double </code> specifying the distance between two locations
     */
    public Double distance_prevloc(String loc1, String loc2) {

        Double result = 0.0;
        try {
            if (!na.equals(loc1) && !na.equals(loc2)) {
                String lat1 = loc1.split("-")[0];
                String long1 = loc1.split("-")[1];
                String lat2 = loc2.split("-")[0];
                String long2 = loc2.split("-")[1];
                float f1 = Float.parseFloat(lat1);
                float f2 = Float.parseFloat(long1);
                float f3 = Float.parseFloat(lat2);
                float f4 = Float.parseFloat(long2);
                String unit = "K";

                Double d = distance(f1, f2, f3, f4, unit);
                result = d;
            } else result = -1.0;
        } catch (Exception e) {
            result = -1.0;
        }
        return result;
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

    private double distance(double lat1, double lon1, double lat2, double lon2, String unit) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        if (unit.equals("K")) {
            dist = dist * 1.609344;
        } else if (unit.equals("N")) {
            dist = dist * 0.8684;
        }
        return (dist);
    }

    /**
     * This is the asynchronous method used for computing age bins
     *
     * @param DM_USER_DOB User Date of Birth detail
     * @param iddDate     Transaction data and time detail
     * @return a <code> CompletableFuture Integer </code> specifying the age bins
     */
//    @Async("rtThreadPoolTaskExecutor")
//    public CompletableFuture<Integer> age_bins(String DM_USER_DOB, Instant iddDate) {
//        int result = 0;
//        try {
//            if (!DM_USER_DOB.equals("0")) {
//                Long d = Long.parseLong(DM_USER_DOB);
//                Instant instant = Instant.ofEpochMilli(d);
//                Long day = ChronoUnit.DAYS.between(instant, iddDate);
//                Integer days = day.intValue();
//                int age = days / 365;
//
//                if (age <= 18) {
//                    result = 0;
//                } else if (age <= 25) {
//                    result = 1;
//                } else if (age <= 28) {
//                    result = 2;
//                } else if (age <= 33) {
//                    result = 3;
//                } else if (age <= 39) {
//                    result = 4;
//                } else if (age <= 45) {
//                    result = 5;
//                } else if (age <= 60) {
//                    result = 6;
//                } else if (age <= 65) {
//                    result = 7;
//                } else if (age <= 70) {
//                    result = 8;
//                } else if (age <= 75) {
//                    result = 9;
//                } else if (age <= 79) {
//                    result = 10;
//                } else if (age <= 84) {
//                    result = 11;
//                } else {
//                    result = 12;
//                }
//            }
//        } catch (Exception e) {
//            result = -1;
//        }
//        return CompletableFuture.completedFuture(result);
//    }

    /**
     * This is the method used for net banking registration
     *
     * @param SM_CUST_MSTR_FLD2_cm SM_CUST_MSTR_FLD2_cm detail
     * @return a <code> integer </code> specifying the net banking registration
     */
    public int netbanking_reg(String SM_CUST_MSTR_FLD2_cm) {
        int result = 0;
        List<String> list14 = jsonMap.get("netbanking_reg_sm_cust_mstr_fld2_cm");
        List<String> list15 = jsonMap.get("netbanking_reg_sm_cust_mstr_fld2_cm1");
        try {
            if (list14.contains(SM_CUST_MSTR_FLD2_cm.trim())) {
                result = 0;
            } else if (list15.contains(SM_CUST_MSTR_FLD2_cm.trim())) {
                result = 1;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the asynchronous method used for computing hotspot country flag
     *
     * @param TermCntry term country details
     * @return a <code> CompletableFuture Integer </code> specifying the hotspot country flag
     */
    public int hotspotCountryFlag(String TermCntry) {
        int result = 0;
        List<String> list16 = jsonMap.get("sd_term_cntry");
        try {
            if (list16.contains(TermCntry)) {
                result = 1;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method used for computing domestic transaction flag
     *
     * @param cntryType country type details
     * @return a <code> integer </code> specifying the domestic transaction flag
     */
    public int domTranFlag(String cntryType) {
        int result = 0;
        try {
            if (cntryType.equals(domestic)) {
                result = 1;
            } else
                result = 0;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method used for computing difference between current transaction date time and previous transaction date time in minutes
     *
     * @param dd_date      current transaction date time detail
     * @param prev_dd_date previous  transaction date time detail
     * @return a <code> integer </code> specifying the minutes difference
     */
    public int prev_tran_time_diff_mins(Long dd_date, String prev_dd_date) {
        int result = 0;

        try {
            Long d2 = Long.parseLong(prev_dd_date);
            result = (int) (dd_date - d2) / 60000;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This the method used of computing card block code flag
     *
     * @param sd_fiid        financial institution identifier detail
     * @param sd_crd_blk_cde card block code detail
     * @return a <code> integer </code> specifying the card block code flag value
     */
    public int crd_blk_cde(String sd_fiid, String sd_crd_blk_cde) {
        int result = 0;
        try {
            if (("HDFB").equals(sd_fiid.trim())) {
                if (sd_crd_blk_cde.equals("null") || sd_crd_blk_cde.equals("P") || sd_crd_blk_cde.equals("B")) {
                    result = 0;
                } else {
                    result = 2;
                }

            }
            if (("HDFC").equals(sd_fiid.trim())) {
                result = 1;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;

    }

    /**
     * This is the method used for computing metro flag value
     *
     * @param sd_term_name_loc term name location detail
     * @return a <code> integer </code> specifying the metro flag value
     */
    public int metro_flag(String sd_term_name_loc) {
        int result = 0;
        try {
            if (sd_term_name_loc == null) {
                result = -1;
            } else {
                String sd_term = sd_term_name_loc.trim();
                if (String.valueOf(sd_term.charAt(0)).equals("+")) {
                    result = 1;
                } else {
                    result = 0;
                }
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method used for checking insufficient balance flag
     *
     * @param mdCustTranAmt1 user customized transaction amount details
     * @param mdTranAmt1     transaction amount details
     * @return a <code> integer </code> specifying the matched postal code value
     */
    public int insufficientBalFlag(Double mdCustTranAmt1, Double mdTranAmt1) {
        int result = 0;
        try {
            if (mdCustTranAmt1 < mdTranAmt1) {
                result = 1;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    public int prev_current_term_matching(String prev_term, String current_term) {
        int result = 0;
        try {
            if (prev_term.trim().equals(current_term.trim())) {
                result = 1;
            } else {
                result = 0;
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }


    public Double bal_amount(Double mdTranAmt1, Double mdCustTranAmt1, Integer sdMonetary) {
        Double result = 0.0;
        try {
            if (sdMonetary == 1) {
                if (mdCustTranAmt1 - mdTranAmt1 >= 0.0) {
                    result = mdCustTranAmt1 - mdTranAmt1;
                } else {
                    result = mdCustTranAmt1 - mdTranAmt1;
                }
            } else {
                if (mdCustTranAmt1 > 0.0) result = mdCustTranAmt1;
                else result = 0.0;
            }
        } catch (Exception e) {
            result = -1.0;
        }
        return result;
    }

    public String balAmountBins(Double balAmt, Integer sdMonetary) {
        String result = "NA";
        try {
            if (sdMonetary == 1) {
                if ((-5001 <= balAmt) && (balAmt < 0)) {
                    result = "-(0_5000)";
                } else if ((-10001 <= balAmt) && (balAmt < -5001)) {
                    result = "-(5000_10000)";
                } else if ((-30000 <= balAmt) && (balAmt < -10001)) {
                    result = "-(10000_30000)";
                } else if ((-50000 <= balAmt) && (balAmt < -30001)) {
                    result = "-(30000_50000)";
                } else if ((-100000 <= balAmt) && (balAmt < -50001)) {
                    result = "-(50000_100000)";
                } else if (balAmt <= -100001) {
                    result = "-(gt1,00,000)";
                } else if (balAmt == 0) {
                    result = "0";
                } else if ((0 < balAmt) && (balAmt <= 1)) {
                    result = "0_1";
                } else if ((1 < balAmt) && (balAmt <= 500)) {
                    result = "1_500";
                } else if ((500 < balAmt) && (balAmt <= 2000)) {
                    result = "501_2000";
                } else if ((2000 < balAmt) && (balAmt <= 5000)) {
                    result = "2001_5000";
                } else if ((5000 < balAmt) && (balAmt <= 10000)) {
                    result = "5001_10000";
                } else if ((10000 < balAmt) && (balAmt <= 20000)) {
                    result = "10001_20000";
                } else if ((20000 < balAmt) && (balAmt <= 30000)) {
                    result = "20001_30000";
                } else if ((30000 < balAmt) && (balAmt <= 50000)) {
                    result = "30001_50000";
                } else if ((50000 < balAmt) && (balAmt <= 100000)) {
                    result = "50001_100000";
                } else if ((100000 < balAmt) && (balAmt <= 500000)) {
                    result = "100001_500000";
                } else if ((500000 < balAmt) && (balAmt <= 1000000)) {
                    result = "500001_1000000";
                } else if (balAmt > 1000000) {
                    result = "gt10,00,000";
                } else result = "NA";
            } else {
                result = "NM";
            }
        } catch (Exception e) {
            result = "NA";
        }
        return result;
    }

    public int balanceAmountBinsIndex(String balanceAmountBins) {
        int result = 0;
        try {
            if (balanceAmountBins.equals("0")) result = 0;
            else if (balanceAmountBins.equals("-(0_5000)")) result = 1;
            else if (balanceAmountBins.equals("-(5000_10000)")) result = 2;
            else if (balanceAmountBins.equals("-(10000_30000)")) result = 3;
            else if (balanceAmountBins.equals("-(30000_50000)")) result = 4;
            else if (balanceAmountBins.equals("-(50000_100000)")) result = 5;
            else if (balanceAmountBins.equals("-(gt1,00,000)")) result = 6;
            else if (balanceAmountBins.equals("0_1")) result = 7;
            else if (balanceAmountBins.equals("1_500")) result = 8;
            else if (balanceAmountBins.equals("501_2000")) result = 9;
            else if (balanceAmountBins.equals("2001_5000")) result = 10;
            else if (balanceAmountBins.equals("5001_10000")) result = 11;
            else if (balanceAmountBins.equals("10001_20000")) result = 13;
            else if (balanceAmountBins.equals("20001_30000")) result = 14;
            else if (balanceAmountBins.equals("30001_50000")) result = 15;
            else if (balanceAmountBins.equals("50001_100000")) result = 16;
            else if (balanceAmountBins.equals("100001_500000")) result = 17;
            else if (balanceAmountBins.equals("500001_1000000")) result = 18;
            else if (balanceAmountBins.equals("gt10,00,000")) result = 19;
            else if (balanceAmountBins.equals("NM")) result = 20;
            else result = 21;
        } catch (Exception e) {
            result = 0;
        }
        return result;
    }

    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<String> cardType(String sd_bin, String sd_fiid) {
        String result = "NA";
        String sdBin = sd_bin.trim();
        String sdFiid = sd_fiid.trim();
        try {
            List<String> list17 = jsonMap.get("sd_bin_infiniti");
            List<String> list18 = jsonMap.get("sd_bin_platinum");
            List<String> list19 = jsonMap.get("sd_bin_times");
            List<String> list20 = jsonMap.get("sd_bin_millenia");
            List<String> list21 = jsonMap.get("sd_bin_rewards");
            List<String> list22 = jsonMap.get("sd_bin_jet_privilage");
            List<String> list23 = jsonMap.get("sd_bin_money_back");
            List<String> list24 = jsonMap.get("sd_bin_business");
            List<String> list25 = jsonMap.get("sd_bin_womens_advantage");
            List<String> list26 = jsonMap.get("sd_bin_rupay_premium");
            List<String> list27 = jsonMap.get("sd_bin_rupay_nro");
            if (sdFiid.equals("HDFC")) {
                if (list17.contains(sdBin)) result = "Infiniti_Debit_card";
                else if (list18.contains(sdBin)) result = "Platinum_Debit_card";
                else if (list19.contains(sdBin)) result = "Times_Debit_Card";
                else if (list20.contains(sdBin)) result = "Millenia_Debit_card";
                else if (list21.contains(sdBin)) result = "Rewards_Debit_Card";
                else if (list22.contains(sdBin)) result = "Jet_Privilage_Debit_card";
                else if (list23.contains(sdBin)) result = "MoneyBack_Debit_card";
                else if (list24.contains(sdBin)) result = "Business_Debit_card";
                else if (list25.contains(sdBin)) result = "Womens_Advantage_Debit_card";
                else if (list26.contains(sdBin)) result = "Rupay_Premium_Debit_Card";
                else if (list27.contains(sdBin)) result = "Rupay_NRO_Debit_Card";
                else result = "Other_Debit_Card";
            } else {
                result = "CreditCard";
            }
        } catch (Exception e) {
            result = "NA";
        }
        return CompletableFuture.completedFuture(result);
    }

    public Double limits(CompletableFuture<String> cardCategory, Double mdCustTranAmt1) throws InterruptedException, ExecutionException {
        Double result = 0.0;
        String category = cardCategory.get();
        try {
            if (category.equals("Infiniti_Debit_card")) result = 200000.00;
            else if (category.equals("Platinum_Debit_card")) result = 100000.00;
            else if (category.equals("Times_Debit_Card")) result = 100000.00;
            else if (category.equals("Millenia_Debit_card")) result = 50000.00;
            else if (category.equals("Rewards_Debit_Card")) result = 50000.00;
            else if (category.equals("Jet_Privilage_Debit_card")) result = 100000.00;
            else if (category.equals("MoneyBack_Debit_card")) result = 25000.00;
            else if (category.equals("Business_Debit_card")) result = 100000.00;
            else if (category.equals("Womens_Advantage_Debit_card")) result = 25000.00;
            else if (category.equals("Rupay_Premium_Debit_Card")) result = 25000.00;
            else if (category.equals("Rupay_NRO_Debit_Card")) result = 25000.00;
            else if (category.equals("Other_Debit_Card")) result = 25000.00;
            else {
                if (mdCustTranAmt1 > 0.0) result = mdCustTranAmt1 * 0.4;
                else result = 0.0;
            }
        } catch (Exception e) {
            result = -1.0;
        }
        return result;
    }

    public int cardTypeIndex(CompletableFuture<String> cardCategory) throws InterruptedException, ExecutionException {
        int result = 0;
        String category = cardCategory.get();
        try {
            if (category.equals("Infiniti_Debit_card"))
                result = 1;
            else if (category.equals("Platinum_Debit_card"))
                result = 2;
            else if (category.equals("Times_Debit_Card"))
                result = 3;
            else if (category.equals("Millenia_Debit_card"))
                result = 4;
            else if (category.equals("Rewards_Debit_Card"))
                result = 5;
            else if (category.equals("Jet_Privilage_Debit_card"))
                result = 6;
            else if (category.equals("MoneyBack_Debit_card"))
                result = 7;
            else if (category.equals("Business_Debit_card"))
                result = 8;
            else if (category.equals("Womens_Advantage_Debit_card"))
                result = 9;
            else if (category.equals("Rupay_Premium_Debit_Card"))
                result = 10;
            else if (category.equals("Rupay_NRO_Debit_Card"))
                result = 11;
            else if (category.equals("Other_Debit_Card"))
                result = 12;
            else if (category.equals("CreditCard"))
                result = 13;
            else
                result = 0;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    @Async("rtThreadPoolTaskExecutor")
    public CompletableFuture<Double> maxWithdrawalAmtPerDay(String ddDate, String prevDdDate, Double sumAmount, Double mdTranAmt1) {
        Double result = 0.0;
        ZoneId zone = ZoneId.of("Asia/Kolkata");

        try {
            if (prevDdDate == null || prevDdDate.isEmpty() || prevDdDate.equals("0")) {
                result = mdTranAmt1;
            } else {
                LocalDate dateTime = LocalDate.ofInstant(Instant.ofEpochMilli(Long.parseLong(ddDate)), zone);
                LocalDate prevDate = LocalDate.ofInstant(Instant.ofEpochMilli(Long.parseLong(prevDdDate)), zone);

                if (dateTime.equals(prevDate)) {
                    result = sumAmount + mdTranAmt1;
                } else {
                    result = mdTranAmt1;
                }
            }
        } catch (Exception e) {
            result = -1.0;
        }
        return CompletableFuture.completedFuture(result);
    }

    public int withdrawAmtExceedFlag(CompletableFuture<Double> maxWithdrawalAmtPerDay, Double dailyCardLimit) {
        int result = 0;

        try {
            if (maxWithdrawalAmtPerDay.get() < dailyCardLimit) {
                result = 0;
            } else result = 1;
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    public int isCurrentexistinPrevData(String prev, String current) {
        int result = 0;
        try {
            if (prev != null && !"NA".equals(prev) && current != null) {
                List<String> reqlist = new ArrayList<String>(Arrays.asList(prev.trim().split("_")));
                if (reqlist.contains(current.trim())) {
                    result = 1;
                }
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    public int frequentMerchantFlag(String freqMerchantList, String termId) {
        int result = 0;
        try {
            if (freqMerchantList != null && !"NA".equals(termId) && termId != null) {
                List<String> reqlist = new ArrayList<String>(Arrays.asList(freqMerchantList.split("_")));
                if (reqlist.contains(termId.trim())) {
                    result = 1;
                }
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    public int MerchantFlagPOS(String MerchantList, String Rtlsc) {
        int result = 0;

        try {
            if (MerchantList != null && Rtlsc != null) {
                String[] requiredValues = MerchantList.split("_");
                List<String> reqlist = new ArrayList<String>(Arrays.asList(requiredValues));
                if (!Rtlsc.equals("NA") && (reqlist.contains(Rtlsc))) {
                    result = 1;
                }
            }
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }

    /**
     * This is the method used for creating mbr_num_cardtype field
     *
     * @param sdMbrNum individual holders for same card
     * @return a <code> integer </code> specifying the individual holders for same card value
     */
    public int mbrNumCardType(String sdMbrNum) {
        int result = 0;
        if (sdMbrNum != null && "001".equals(sdMbrNum.trim())) {
            result = 1;
        }
        return result;
    }
}
