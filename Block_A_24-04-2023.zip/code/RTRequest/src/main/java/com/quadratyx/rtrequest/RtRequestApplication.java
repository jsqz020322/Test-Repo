package com.quadratyx.rtrequest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jpmml.evaluator.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.boot.web.embedded.tomcat.ConfigurableTomcatWebServerFactory;
import org.springframework.boot.autoconfigure.web.embedded.TomcatWebServerFactoryCustomizer;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.apache.catalina.core.StandardHost;
import com.quadratyx.rtrequest.monitoring.BlankTomcatErrorValve;


import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

@SpringBootApplication
@EnableAsync
@Component
public class RtRequestApplication implements CommandLineRunner{
	private static final Logger logger = LoggerFactory.getLogger(RtRequestApplication.class);

	@Value("${model.atmpmmlfile.path}")
	private String atmPmmlFilePath;

	@Value("${model.pospmmlfile.path}")
	private String posPmmlFilePath;

	@Value("${model.cnpsecuredpmmlfile.path}")
	private String cnpsecuredPmmlFilePath;

	@Value("${model.cnpunsecuredpmmlfile.path}")
	private String cnpunsecuredPmmlFilePath;

	@Value("${city_post_cdes_dict.path}")
	private String cityPostCode;

	@Value("${post_cde_lat_long.path}")
	private String postCodeLatLong;

	@Value("${default_key_path.path}")
	private String defaultKey;

	@Value("${merchant_default_key_path.path}")
	private String merchantDefaultKey;
	@Value("${jsonfile.path}")
	private String filePath;

	public RtRequestApplication() throws IOException {
		// Default constructor
	}

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(RtRequestApplication.class, args);
		DispatcherServlet dispatcherServlet = (DispatcherServlet)ctx.getBean("dispatcherServlet");
		dispatcherServlet.setThrowExceptionIfNoHandlerFound(true);
	}

	@Override
	public void run(String... args){
		try {
			logger.info("RT Request Application is running.................");

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Bean
	public TomcatWebServerFactoryCustomizer blankErrorValveTomcatWebServerFactoryCustomizer(Environment environment,
																							ServerProperties serverProperties,
																							final TomcatWebServerFactoryCustomizer tomcatWebServerFactoryCustomizer) {
		return new TomcatWebServerFactoryCustomizer(environment, serverProperties) {
			public void customize(ConfigurableTomcatWebServerFactory factory) {
				factory.addContextCustomizers(context -> {
					if (context.getParent() instanceof StandardHost standardHost) {
						standardHost.getPipeline().addValve(new com.quadratyx.rtrequest.monitoring.BlankTomcatErrorValve());
						standardHost.setErrorReportValveClass(com.quadratyx.rtrequest.monitoring.BlankTomcatErrorValve.class.getName());
					}
				});
			}

			public int getOrder() {
				return tomcatWebServerFactoryCustomizer.getOrder() + 1;
			}
		};
	}

	/**
	 * This is the method used for reading model pmml file from properties file and loading it
	 *
	 * @return a <code> Evaluator </code> for evaluation of model prediction
	 * @throws IOException                    in case of any IO Exception
	 * @throws SAXException                   in case of any SAXException
	 * @throws jakarta.xml.bind.JAXBException in case of any JAXBException
	 */
	@Bean(name = "atmMapping")
	public Evaluator getAtmMapping() throws IOException, SAXException, jakarta.xml.bind.JAXBException {
		Evaluator evaluator;
		logger.info("................. Loading ATM Model .................");
		long st = System.currentTimeMillis();
		evaluator = new LoadingModelEvaluatorBuilder()
				.setLocatable(false)
				.load(new File(atmPmmlFilePath))
				.build();
		logger.info("................. Evaluator Build ................. {}", (System.currentTimeMillis() - st));
		return evaluator;
	}

	@Bean(name = "posMapping")
	public Evaluator getPosMapping() throws IOException, SAXException, jakarta.xml.bind.JAXBException {
		Evaluator evaluator;
		logger.info("................. Loading POS Model .................");
		long st = System.currentTimeMillis();
		evaluator = new LoadingModelEvaluatorBuilder()
				.setLocatable(false)
				.load(new File(posPmmlFilePath))
				.build();
		logger.info("................. Evaluator Build ................. {}", (System.currentTimeMillis() - st));
		return evaluator;
	}

	@Bean(name = "cnpSecuredMapping")
	public Evaluator getCNPSecuredMapping() throws IOException, SAXException, jakarta.xml.bind.JAXBException {
		Evaluator evaluator;
		logger.info("................. Loading CNP Secured Model .................");
		long st = System.currentTimeMillis();
		evaluator = new LoadingModelEvaluatorBuilder()
				.setLocatable(false)
				.load(new File(cnpsecuredPmmlFilePath))
				.build();
		logger.info("................. Evaluator Build ................. {}", (System.currentTimeMillis() - st));
		return evaluator;
	}

	@Bean(name = "cnpUnsecuredMapping")
	public Evaluator getCNPUnsecuredMapping() throws IOException, SAXException, jakarta.xml.bind.JAXBException {
		Evaluator evaluator;
		logger.info("................. Loading CNP Unsecured Model .................");
		long st = System.currentTimeMillis();
		evaluator = new LoadingModelEvaluatorBuilder()
				.setLocatable(false)
				.load(new File(cnpunsecuredPmmlFilePath))
				.build();
		logger.info("................. Evaluator Build ................. {}", (System.currentTimeMillis() - st));
		return evaluator;
	}

	/**
	 * This is the method used for reading city postal code file from properties file
	 *
	 * @return a <code> Map of String,String </code> specifying the city post code details
	 * @throws IOException in case of any error while reading file
	 */
	@Bean(name = "config")
	public Map<String, String> getCityPostCode() throws IOException {
		File file = new File(cityPostCode);
		return new ObjectMapper().readValue(file, HashMap.class);
	}

	/**
	 * This is the method used for reading postal code latitude longitude file from properties file
	 *
	 * @return a <code> Map of String,String </code> specifying the post code latitude longitude values
	 * @throws IOException in case of any error while reading file
	 */
	@Bean(name = "config1")
	public Map<String, String> getPostCodeLatLong() throws IOException {
		File file = new File(postCodeLatLong);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		return objectMapper.readValue(file, HashMap.class);
	}

	/**
	 * This is the method used for reading default key file from properties file
	 *
	 * @return a <code> Map of String,Object </code> specifying the aggregate values
	 * @throws IOException in case of any error while reading file
	 */
	@Bean(name = "merchantDefaultAggregate")
	public Map<String, Object> getMerchantDefaultKey() throws IOException {
		File file = new File(merchantDefaultKey);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		return objectMapper.readValue(file, HashMap.class);
	}

	/**
	 * This is the method used for reading default key file from properties file
	 *
	 * @return a <code> Map of String,Object </code> specifying the aggregate values
	 * @throws IOException in case of any error while reading file
	 */
	@Bean(name = "defaultAggregate")
	public Map<String, Object> getDefaultKey() throws IOException {
		File file = new File(defaultKey);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		return objectMapper.readValue(file, HashMap.class);
	}

	/**
	 * This is method used for reading the config file from path
	 *
	 * @return a <code> map </code> object specifying the list of values
	 * @throws IOException in case of an invalid file path
	 */
	@Bean(name = "config2")
	public Map<String, List<String>> loadJsonConfig() throws IOException {
		File file = new File(filePath);
		Map<String, List<String>> cacheMap = new ObjectMapper().readValue(file, HashMap.class);
		return cacheMap;
	}
}
