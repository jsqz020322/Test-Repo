package com.quadratyx.rtrequest.serviceImpl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quadratyx.rtrequest.service.RTRequestAtmService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

@Service
public class RedisCacheService {

    private static final Logger logger = LoggerFactory.getLogger(RedisCacheService.class);

    @Autowired
    @Qualifier("redisClusterConfiguration")
    private JedisCluster jedisCluster;

//    @Autowired
//    @Qualifier("redisSentinelConnection")
//    private Jedis jedisCluster;

    @Value("${spring.kafka.bootstrap.exceptiontopic}")
    private String exceptionTopic;

    @Autowired
    private RTRequestAtmService rtRequestAtmService;


    /**
     * This is the method used for getting aggregates data from redis cluster
     *
     * @param key redis key detail
     * @return a <code> Map of String,Object </code> specifying the redis data for a key
     */
    public Map<String, Object> getCachedata(String key, String tId, Map<String, Object> defaultAggregate) {
        Map<String, Object> redisMap = null;
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        try {
            String redisAggregates = jedisCluster.get(key);
            if (redisAggregates != null) {
                redisMap = objectMapper.readValue(redisAggregates, HashMap.class);
            } else {
                redisMap = (Map<String, Object>) defaultAggregate.get("defaultAggregate");
            }
        } catch (Exception e) {
            redisMap = (Map<String, Object>) defaultAggregate.get("defaultAggregate");
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "getCachedata Tiebreaker : " + tId + "\n" + sw.toString();
            rtRequestAtmService.sendMessage(exception, exceptionTopic);
        }
        return redisMap;
    }

    /**
     * This is the method used for getting merchant based aggregates data from redis cluster
     *
     * @param key redis key detail
     * @return a <code> Map of String,Object </code> specifying the redis data for a key
     */
    public Map<String, Object> getMerchantData(String key, String tId, Map<String, Object> merchantDefaultAggregate) {
        Map<String, Object> merchantMap = null;
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        try {
            if (key == null) {
                merchantMap = (Map<String, Object>) merchantDefaultAggregate.get("merchantDefaultAggregate");
            } else {
                String merchantAggregates = jedisCluster.get(key.trim());
                if (merchantAggregates != null) {
                    merchantMap = objectMapper.readValue(merchantAggregates, HashMap.class);
                } else {
                    merchantMap = (Map<String, Object>) merchantDefaultAggregate.get("merchantDefaultAggregate");
                }
            }
        } catch (Exception e) {
            merchantMap = (Map<String, Object>) merchantDefaultAggregate.get("merchantDefaultAggregate");
            logger.error("Exception " + e.getMessage(), e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exception = "getMerchantData Tiebreaker : " + tId + "\n" + sw.toString();
            rtRequestAtmService.sendMessage(exception, exceptionTopic);
        }
        return merchantMap;
    }
}
