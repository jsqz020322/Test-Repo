package com.quadratyx.rtrequest.util;

public class BusinessConstant {

	private BusinessConstant() {
		//Default constructor
	}

	public static final Integer OK = 20;
	public static final Integer BAD_REQUEST = 40;
	public static final Integer FORBIDDEN = 43;
	public static final Integer NOT_FOUND = 44;
	public static final Integer METHOD_NOT_ALLOWED = 45;
	public static final Integer UNSUPPORTED_MEDIA_TYPE = 46;
	public static final Integer INTERNAL_SERVER_ERROR = 50;
	public static final Integer SERVICE_UNAVAILABLE = 53;
}
