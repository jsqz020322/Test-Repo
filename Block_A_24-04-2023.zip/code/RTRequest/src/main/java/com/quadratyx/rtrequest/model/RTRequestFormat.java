package com.quadratyx.rtrequest.model;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"Tiebreaker",
		"RecordSourceId",
		"PAN",
		"RETLID",
		"AcctNum",
		"TERMID",
		"TranCode",
		"TranAmt1",
		"MsgType",
		"PontOfSrvcCondCode",
		"PontOfSrvceEntryMode",
		"EComFlag",
		"EMVTrmnlVrfyRslt",
		"EMVUsrFlr",
		"RtlrSICCode",
		"TermNameLoc",
		"TermCity",
		"TermSt",
		"TermCntr",
		"TermPstlCode",
		"CustTranAmt1",
		"CustTranAmt4",
		"PINTries",
		"AcqrInstIdNum",
		"FrwdInstId",
		"TranAuthSrc",
		"CAVVAAV",
		"AcctType",
		"FIID",
		"BIN",
		"PINIndx",
		"MmbrNum",
		"CardPrdtType",
		"CardStat",
		"CardBlckCode",
		"TranDateTime",
		"CardRqstDate",
		"CardPINChngDate",
		"LastAdrsChngDate",
		"IBK1InstIdNum",
		"ProdInd",
		"SqncNum",
		"TranRsnCode",
		"CardVrfyFlag",
		"CVDPrsntFlag",
		"EMVCardVrfyRslts",
		"CustTranAmt2",
		"CustTranAmt3",
		"CustTranDate",
		"CredDebInd",
		"CashInd",
		"OrgnlCrncyCode",
		"AchNum",
		"ScndryAcctNmbr",
		"OrigWireAcctId",
		"BenWireAcctId",
		"TranAmt2",
		"TranAmt3",
		"SlsRjctCde",
		"VisaAdvncAuthScor_Type"
})
public class RTRequestFormat {

	@NotNull
	@JsonProperty("Tiebreaker")
	private String tiebreaker;
	@JsonProperty("RecordSourceId")
	private Integer recordSourceId;
	@JsonProperty("PAN")
	private String pan;
	@JsonProperty("RETLID")
	private String retlid;
	@JsonProperty("AcctNum")
	private String acctNum;
	@JsonProperty("TERMID")
	private String termid;
	@JsonProperty("TranCode")
	private String tranCode;
	@JsonProperty("TranAmt1")
	private Double tranAmt1;
	@JsonProperty("MsgType")
	private String msgType;
	@JsonProperty("PontOfSrvcCondCode")
	private String pontOfSrvcCondCode;
	@JsonProperty("PontOfSrvceEntryMode")
	private String pontOfSrvceEntryMode;
	@JsonProperty("EComFlag")
	private String eComFlag;
	@JsonProperty("EMVTrmnlVrfyRslt")
	private String eMVTrmnlVrfyRslt;
	@JsonProperty("EMVUsrFlr")
	private String eMVUsrFlr;
	@JsonProperty("RtlrSICCode")
	private String rtlrSICCode;
	@JsonProperty("TermNameLoc")
	private String termNameLoc;
	@JsonProperty("TermCity")
	private String termCity;
	@JsonProperty("TermSt")
	private String termSt;
	@JsonProperty("TermCntr")
	private String termCntr;
	@JsonProperty("TermPstlCode")
	private String termPstlCode;
	@JsonProperty("CustTranAmt1")
	private Double custTranAmt1;
	@JsonProperty("CustTranAmt4")
	private Double custTranAmt4;
	@JsonProperty("PINTries")
	private String pINTries;
	@JsonProperty("AcqrInstIdNum")
	private String acqrInstIdNum;
	@JsonProperty("FrwdInstId")
	private String frwdInstId;
	@JsonProperty("TranAuthSrc")
	private String tranAuthSrc;
	@JsonProperty("CAVVAAV")
	private Integer cavvaav;
	@JsonProperty("AcctType")
	private String acctType;
	@JsonProperty("FIID")
	private String fiid;
	@JsonProperty("BIN")
	private String bin;
	@JsonProperty("PINIndx")
	private String pINIndx;
	@JsonProperty("MmbrNum")
	private String mmbrNum;
	@JsonProperty("CardPrdtType")
	private String cardPrdtType;
	@JsonProperty("CardStat")
	private String cardStat;
	@JsonProperty("CardBlckCode")
	private String cardBlckCode;
	@JsonProperty("TranDateTime")
	private Long tranDateTime;
	@JsonProperty("CardRqstDate")
	private Long cardRqstDate;
	@JsonProperty("CardPINChngDate")
	private Long cardPINChngDate;
	@JsonProperty("LastAdrsChngDate")
	private Long lastAdrsChngDate;
	@JsonProperty("IBK1InstIdNum")
	private String iBK1InstIdNum;
	@JsonProperty("ProdInd")
	private String prodInd;
	@JsonProperty("SqncNum")
	private String sqncNum;
	@JsonProperty("TranRsnCode")
	private String tranRsnCode;
	@JsonProperty("CardVrfyFlag")
	private String cardVrfyFlag;
	@JsonProperty("CVDPrsntFlag")
	private String cVDPrsntFlag;
	@JsonProperty("EMVCardVrfyRslts")
	private String eMVCardVrfyRslts;
	@JsonProperty("CustTranAmt2")
	private Double custTranAmt2;
	@JsonProperty("CustTranAmt3")
	private Double custTranAmt3;
	@JsonProperty("CustTranDate")
	private Long custTranDate;
	@JsonProperty("CredDebInd")
	private String credDebInd;
	@JsonProperty("CashInd")
	private String cashInd;
	@JsonProperty("OrgnlCrncyCode")
	private String orgnlCrncyCode;
	@JsonProperty("AchNum")
	private String achNum;
	@JsonProperty("ScndryAcctNmbr")
	private String scndryAcctNmbr;
	@JsonProperty("OrigWireAcctId")
	private String origWireAcctId;
	@JsonProperty("BenWireAcctId")
	private String benWireAcctId;
	@JsonProperty("TranAmt2")
	private Double tranAmt2;
	@JsonProperty("TranAmt3")
	private Double tranAmt3;
	@JsonProperty("SlsRjctCde")
	private String slsRjctCde;
	@JsonProperty("VisaAdvncAuthScor_Type")
	private String visaAdvncAuthScorType;

	@JsonProperty("Tiebreaker")
	public String getTiebreaker() {
		return tiebreaker;
	}

	@JsonProperty("Tiebreaker")
	public void setTiebreaker(String tiebreaker) {
		this.tiebreaker = tiebreaker;
	}

	@JsonProperty("RecordSourceId")
	public Integer getRecordSourceId() {
		return recordSourceId;
	}

	@JsonProperty("RecordSourceId")
	public void setRecordSourceId(Integer recordSourceId) {
		this.recordSourceId = recordSourceId;
	}

	@JsonProperty("PAN")
	public UUID getPan() {
		return generateType5UUID(pan);
	}

	@JsonProperty("PAN")
	public void setPan(String pan) throws Exception {
		Pattern p = Pattern.compile("^[0-9]{13,19}$");
		Matcher m = p.matcher(pan);
		if(!m.find())
			throw (new Exception ("Invalid value !! Except digit between 13 to 19 "));
		this.pan = pan;
	}

	@JsonProperty("RETLID")
	public String getRetlid() {
		return retlid;
	}

	@JsonProperty("RETLID")
	public void setRetlid(String retlid) {
		this.retlid = retlid;
	}

	@JsonProperty("AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	@JsonProperty("AcctNum")
	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@JsonProperty("TERMID")
	public String getTermid() {
		return termid;
	}

	@JsonProperty("TERMID")
	public void setTermid(String termid) {
		this.termid = termid;
	}

	@JsonProperty("TranCode")
	public String getTranCode() {
		return tranCode;
	}

	@JsonProperty("TranCode")
	public void setTranCode(String tranCode) {
		this.tranCode = tranCode;
	}

	@JsonProperty("TranAmt1")
	public Double getTranAmt1() {
		return tranAmt1;
	}

	@JsonProperty("TranAmt1")
	public void setTranAmt1(Double tranAmt1) {
		this.tranAmt1 = tranAmt1;
	}

	@JsonProperty("MsgType")
	public String getMsgType() {
		return msgType;
	}

	@JsonProperty("MsgType")
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	@JsonProperty("PontOfSrvcCondCode")
	public String getPontOfSrvcCondCode() {
		return pontOfSrvcCondCode;
	}

	@JsonProperty("PontOfSrvcCondCode")
	public void setPontOfSrvcCondCode(String pontOfSrvcCondCode) {
		this.pontOfSrvcCondCode = pontOfSrvcCondCode;
	}

	@JsonProperty("PontOfSrvceEntryMode")
	public String getPontOfSrvceEntryMode() {
		return pontOfSrvceEntryMode;
	}

	@JsonProperty("PontOfSrvceEntryMode")
	public void setPontOfSrvceEntryMode(String pontOfSrvceEntryMode) {
		this.pontOfSrvceEntryMode = pontOfSrvceEntryMode;
	}

	@JsonProperty("EComFlag")
	public String getEComFlag() {
		return eComFlag;
	}

	@JsonProperty("EComFlag")
	public void setEComFlag(String eComFlag) {
		this.eComFlag = eComFlag;
	}

	@JsonProperty("EMVTrmnlVrfyRslt")
	public String getEMVTrmnlVrfyRslt() {
		return eMVTrmnlVrfyRslt;
	}

	@JsonProperty("EMVTrmnlVrfyRslt")
	public void setEMVTrmnlVrfyRslt(String eMVTrmnlVrfyRslt) {
		this.eMVTrmnlVrfyRslt = eMVTrmnlVrfyRslt;
	}

	@JsonProperty("EMVUsrFlr")
	public String getEMVUsrFlr() {
		return eMVUsrFlr;
	}

	@JsonProperty("EMVUsrFlr")
	public void setEMVUsrFlr(String eMVUsrFlr) {
		this.eMVUsrFlr = eMVUsrFlr;
	}

	@JsonProperty("RtlrSICCode")
	public String getRtlrSICCode() {
		return rtlrSICCode;
	}

	@JsonProperty("RtlrSICCode")
	public void setRtlrSICCode(String rtlrSICCode) {
		this.rtlrSICCode = rtlrSICCode;
	}

	@JsonProperty("TermNameLoc")
	public String getTermNameLoc() {
		return termNameLoc;
	}

	@JsonProperty("TermNameLoc")
	public void setTermNameLoc(String termNameLoc) {
		this.termNameLoc = termNameLoc;
	}

	@JsonProperty("TermCity")
	public String getTermCity() {
		return termCity;
	}

	@JsonProperty("TermCity")
	public void setTermCity(String termCity) {
		this.termCity = termCity;
	}

	@JsonProperty("TermSt")
	public String getTermSt() {
		return termSt;
	}

	@JsonProperty("TermSt")
	public void setTermSt(String termSt) {
		this.termSt = termSt;
	}

	@JsonProperty("TermCntr")
	public String getTermCntr() {
		return termCntr;
	}

	@JsonProperty("TermCntr")
	public void setTermCntr(String termCntr) {
		this.termCntr = termCntr;
	}

	@JsonProperty("TermPstlCode")
	public String getTermPstlCode() {
		return termPstlCode;
	}

	@JsonProperty("TermPstlCode")
	public void setTermPstlCode(String termPstlCode) {
		this.termPstlCode = termPstlCode;
	}

	@JsonProperty("CustTranAmt1")
	public Double getCustTranAmt1() {
		return custTranAmt1;
	}

	@JsonProperty("CustTranAmt1")
	public void setCustTranAmt1(Double custTranAmt1) {
		this.custTranAmt1 = custTranAmt1;
	}

	@JsonProperty("CustTranAmt4")
	public Double getCustTranAmt4() {
		return custTranAmt4;
	}

	@JsonProperty("CustTranAmt4")
	public void setCustTranAmt4(Double custTranAmt4) {
		this.custTranAmt4 = custTranAmt4;
	}

	@JsonProperty("PINTries")
	public String getPINTries() {
		return pINTries;
	}

	@JsonProperty("PINTries")
	public void setPINTries(String pINTries) {
		this.pINTries = pINTries;
	}

	@JsonProperty("AcqrInstIdNum")
	public String getAcqrInstIdNum() {
		return acqrInstIdNum;
	}

	@JsonProperty("AcqrInstIdNum")
	public void setAcqrInstIdNum(String acqrInstIdNum) {
		this.acqrInstIdNum = acqrInstIdNum;
	}

	@JsonProperty("FrwdInstId")
	public String getFrwdInstId() {
		return frwdInstId;
	}

	@JsonProperty("FrwdInstId")
	public void setFrwdInstId(String frwdInstId) {
		this.frwdInstId = frwdInstId;
	}

	@JsonProperty("TranAuthSrc")
	public String getTranAuthSrc() {
		return tranAuthSrc;
	}

	@JsonProperty("TranAuthSrc")
	public void setTranAuthSrc(String tranAuthSrc) {
		this.tranAuthSrc = tranAuthSrc;
	}

	@JsonProperty("CAVVAAV")
	public Integer getCavvaav() {
		return cavvaav;
	}

	@JsonProperty("CAVVAAV")
	public void setCavvaav(Integer cavvaav) {
		this.cavvaav = cavvaav;
	}

	@JsonProperty("AcctType")
	public String getAcctType() {
		return acctType;
	}

	@JsonProperty("AcctType")
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	@JsonProperty("FIID")
	public String getFiid() {
		return fiid;
	}

	@JsonProperty("FIID")
	public void setFiid(String fiid) {
		this.fiid = fiid;
	}

	@JsonProperty("BIN")
	public String getBin() {
		return bin;
	}

	@JsonProperty("BIN")
	public void setBin(String bin) {
		this.bin = bin;
	}

	@JsonProperty("PINIndx")
	public String getPINIndx() {
		return pINIndx;
	}

	@JsonProperty("PINIndx")
	public void setPINIndx(String pINIndx) {
		this.pINIndx = pINIndx;
	}

	@JsonProperty("MmbrNum")
	public String getMmbrNum() {
		return mmbrNum;
	}

	@JsonProperty("MmbrNum")
	public void setMmbrNum(String mmbrNum) {
		this.mmbrNum = mmbrNum;
	}

	@JsonProperty("CardPrdtType")
	public String getCardPrdtType() {
		return cardPrdtType;
	}

	@JsonProperty("CardPrdtType")
	public void setCardPrdtType(String cardPrdtType) {
		this.cardPrdtType = cardPrdtType;
	}

	@JsonProperty("CardStat")
	public String getCardStat() {
		return cardStat;
	}

	@JsonProperty("CardStat")
	public void setCardStat(String cardStat) {
		this.cardStat = cardStat;
	}

	@JsonProperty("CardBlckCode")
	public String getCardBlckCode() {
		return cardBlckCode;
	}

	@JsonProperty("CardBlckCode")
	public void setCardBlckCode(String cardBlckCode) {
		this.cardBlckCode = cardBlckCode;
	}

	@JsonProperty("TranDateTime")
	public Long getTranDateTime() {
		return tranDateTime;
	}

	@JsonProperty("TranDateTime")
	public void setTranDateTime(Long tranDateTime) {
		this.tranDateTime = tranDateTime;
	}

	@JsonProperty("CardRqstDate")
	public Long getCardRqstDate() {
		return cardRqstDate;
	}

	@JsonProperty("CardRqstDate")
	public void setCardRqstDate(Long cardRqstDate) {
		this.cardRqstDate = cardRqstDate;
	}

	@JsonProperty("CardPINChngDate")
	public Long getCardPINChngDate() {
		return cardPINChngDate;
	}

	@JsonProperty("CardPINChngDate")
	public void setCardPINChngDate(Long cardPINChngDate) {
		this.cardPINChngDate = cardPINChngDate;
	}

	@JsonProperty("LastAdrsChngDate")
	public Long getLastAdrsChngDate() {
		return lastAdrsChngDate;
	}

	@JsonProperty("LastAdrsChngDate")
	public void setLastAdrsChngDate(Long lastAdrsChngDate) {
		this.lastAdrsChngDate = lastAdrsChngDate;
	}

	@JsonProperty("IBK1InstIdNum")
	public String getIBK1InstIdNum() {
		return iBK1InstIdNum;
	}

	@JsonProperty("IBK1InstIdNum")
	public void setIBK1InstIdNum(String iBK1InstIdNum) {
		this.iBK1InstIdNum = iBK1InstIdNum;
	}

	@JsonProperty("ProdInd")
	public String getProdInd() {
		return prodInd;
	}

	@JsonProperty("ProdInd")
	public void setProdInd(String prodInd) {
		this.prodInd = prodInd;
	}

	@JsonProperty("SqncNum")
	public String getSqncNum() {
		return sqncNum;
	}

	@JsonProperty("SqncNum")
	public void setSqncNum(String sqncNum) {
		this.sqncNum = sqncNum;
	}

	@JsonProperty("TranRsnCode")
	public String getTranRsnCode() {
		return tranRsnCode;
	}

	@JsonProperty("TranRsnCode")
	public void setTranRsnCode(String tranRsnCode) {
		this.tranRsnCode = tranRsnCode;
	}

	@JsonProperty("CardVrfyFlag")
	public String getCardVrfyFlag() {
		return cardVrfyFlag;
	}

	@JsonProperty("CardVrfyFlag")
	public void setCardVrfyFlag(String cardVrfyFlag) {
		this.cardVrfyFlag = cardVrfyFlag;
	}

	@JsonProperty("CVDPrsntFlag")
	public String getCVDPrsntFlag() {
		return cVDPrsntFlag;
	}

	@JsonProperty("CVDPrsntFlag")
	public void setCVDPrsntFlag(String cVDPrsntFlag) {
		this.cVDPrsntFlag = cVDPrsntFlag;
	}

	@JsonProperty("EMVCardVrfyRslts")
	public String getEMVCardVrfyRslts() {
		return eMVCardVrfyRslts;
	}

	@JsonProperty("EMVCardVrfyRslts")
	public void setEMVCardVrfyRslts(String eMVCardVrfyRslts) {
		this.eMVCardVrfyRslts = eMVCardVrfyRslts;
	}

	@JsonProperty("CustTranAmt2")
	public Double getCustTranAmt2() {
		return custTranAmt2;
	}

	@JsonProperty("CustTranAmt2")
	public void setCustTranAmt2(Double custTranAmt2) {
		this.custTranAmt2 = custTranAmt2;
	}

	@JsonProperty("CustTranAmt3")
	public Double getCustTranAmt3() {
		return custTranAmt3;
	}

	@JsonProperty("CustTranAmt3")
	public void setCustTranAmt3(Double custTranAmt3) {
		this.custTranAmt3 = custTranAmt3;
	}

	@JsonProperty("CustTranDate")
	public Long getCustTranDate() {
		return custTranDate;
	}

	@JsonProperty("CustTranDate")
	public void setCustTranDate(Long custTranDate) {
		this.custTranDate = custTranDate;
	}

	@JsonProperty("CredDebInd")
	public String getCredDebInd() {
		return credDebInd;
	}

	@JsonProperty("CredDebInd")
	public void setCredDebInd(String credDebInd) {
		this.credDebInd = credDebInd;
	}

	@JsonProperty("CashInd")
	public String getCashInd() {
		return cashInd;
	}

	@JsonProperty("CashInd")
	public void setCashInd(String cashInd) {
		this.cashInd = cashInd;
	}

	@JsonProperty("OrgnlCrncyCode")
	public String getOrgnlCrncyCode() {
		return orgnlCrncyCode;
	}

	@JsonProperty("OrgnlCrncyCode")
	public void setOrgnlCrncyCode(String orgnlCrncyCode) {
		this.orgnlCrncyCode = orgnlCrncyCode;
	}

	@JsonProperty("AchNum")
	public String getAchNum() {
		return achNum;
	}

	@JsonProperty("AchNum")
	public void setAchNum(String achNum) {
		this.achNum = achNum;
	}

	@JsonProperty("ScndryAcctNmbr")
	public String getScndryAcctNmbr() {
		return scndryAcctNmbr;
	}

	@JsonProperty("ScndryAcctNmbr")
	public void setScndryAcctNmbr(String scndryAcctNmbr) {
		this.scndryAcctNmbr = scndryAcctNmbr;
	}

	@JsonProperty("OrigWireAcctId")
	public String getOrigWireAcctId() {
		return origWireAcctId;
	}

	@JsonProperty("OrigWireAcctId")
	public void setOrigWireAcctId(String origWireAcctId) {
		this.origWireAcctId = origWireAcctId;
	}

	@JsonProperty("BenWireAcctId")
	public String getBenWireAcctId() {
		return benWireAcctId;
	}

	@JsonProperty("BenWireAcctId")
	public void setBenWireAcctId(String benWireAcctId) {
		this.benWireAcctId = benWireAcctId;
	}

	@JsonProperty("TranAmt2")
	public Double getTranAmt2() {
		return tranAmt2;
	}

	@JsonProperty("TranAmt2")
	public void setTranAmt2(Double tranAmt2) {
		this.tranAmt2 = tranAmt2;
	}

	@JsonProperty("TranAmt3")
	public Double getTranAmt3() {
		return tranAmt3;
	}

	@JsonProperty("TranAmt3")
	public void setTranAmt3(Double tranAmt3) {
		this.tranAmt3 = tranAmt3;
	}

	@JsonProperty("SlsRjctCde")
	public String getSlsRjctCde() {
		return slsRjctCde;
	}

	@JsonProperty("SlsRjctCde")
	public void setSlsRjctCde(String slsRjctCde) {
		this.slsRjctCde = slsRjctCde;
	}

	@JsonProperty("VisaAdvncAuthScor_Type")
	public String getVisaAdvncAuthScorType() {
		return visaAdvncAuthScorType;
	}

	@JsonProperty("VisaAdvncAuthScor_Type")
	public void setVisaAdvncAuthScorType(String visaAdvncAuthScorType) {
		this.visaAdvncAuthScorType = visaAdvncAuthScorType;
	}

	public static UUID generateType5UUID(String name){
		try{
			final byte[] bytes = name.getBytes(StandardCharsets.UTF_8);
			final MessageDigest md = MessageDigest.getInstance("SHA-256");
			final byte[] hash = md.digest(bytes);
			long msb = getLeastAndMostSignificantBitsVersion5(hash,0);
			long lsb = getLeastAndMostSignificantBitsVersion5(hash,8);

			//Set the version field
			msb &= ~(0xfL << 12);
			msb |= 5L << 12;

			//Set the variant field to 2
			lsb &= ~(0x3L << 62);
			lsb |= 2L << 62;
			return new UUID(msb,lsb);
		}
		catch(NoSuchAlgorithmException e){
			throw new AssertionError(e);
		}
	}

	private static long getLeastAndMostSignificantBitsVersion5(final byte[] src, final int offset){
		long ans = 0;
		for(int i = offset + 7; i >= offset; i -= 1 ){
			ans <<= 8;
			ans |= src[i] & 0xffL;
		}
		return ans;
	}

	@Override
	public String toString() {
		return "RTRequestFormat{" +
				"tiebreaker='" + tiebreaker + '\'' +
				", recordSourceId=" + recordSourceId +
				", pan='" + getPan() + '\'' +
				", retlid='" + retlid + '\'' +
				", acctNum='" + acctNum + '\'' +
				", termid='" + termid + '\'' +
				", tranCode='" + tranCode + '\'' +
				", tranAmt1=" + tranAmt1 +
				", msgType='" + msgType + '\'' +
				", pontOfSrvcCondCode='" + pontOfSrvcCondCode + '\'' +
				", pontOfSrvceEntryMode='" + pontOfSrvceEntryMode + '\'' +
				", eComFlag='" + eComFlag + '\'' +
				", eMVTrmnlVrfyRslt='" + eMVTrmnlVrfyRslt + '\'' +
				", eMVUsrFlr='" + eMVUsrFlr + '\'' +
				", rtlrSICCode='" + rtlrSICCode + '\'' +
				", termNameLoc='" + termNameLoc + '\'' +
				", termCity='" + termCity + '\'' +
				", termSt='" + termSt + '\'' +
				", termCntr='" + termCntr + '\'' +
				", termPstlCode='" + termPstlCode + '\'' +
				", custTranAmt1=" + custTranAmt1 +
				", custTranAmt4=" + custTranAmt4 +
				", pINTries='" + pINTries + '\'' +
				", acqrInstIdNum='" + acqrInstIdNum + '\'' +
				", frwdInstId='" + frwdInstId + '\'' +
				", tranAuthSrc='" + tranAuthSrc + '\'' +
				", cavvaav=" + cavvaav +
				", acctType='" + acctType + '\'' +
				", fiid='" + fiid + '\'' +
				", bin='" + bin + '\'' +
				", pINIndx='" + pINIndx + '\'' +
				", mmbrNum='" + mmbrNum + '\'' +
				", cardPrdtType='" + cardPrdtType + '\'' +
				", cardStat='" + cardStat + '\'' +
				", cardBlckCode='" + cardBlckCode + '\'' +
				", tranDateTime=" + tranDateTime +
				", cardRqstDate=" + cardRqstDate +
				", cardPINChngDate=" + cardPINChngDate +
				", lastAdrsChngDate=" + lastAdrsChngDate +
				", iBK1InstIdNum='" + iBK1InstIdNum + '\'' +
				", prodInd='" + prodInd + '\'' +
				", sqncNum='" + sqncNum + '\'' +
				", tranRsnCode='" + tranRsnCode + '\'' +
				", cardVrfyFlag='" + cardVrfyFlag + '\'' +
				", cVDPrsntFlag='" + cVDPrsntFlag + '\'' +
				", eMVCardVrfyRslts='" + eMVCardVrfyRslts + '\'' +
				", custTranAmt2=" + custTranAmt2 +
				", custTranAmt3=" + custTranAmt3 +
				", custTranDate=" + custTranDate +
				", credDebInd='" + credDebInd + '\'' +
				", cashInd='" + cashInd + '\'' +
				", orgnlCrncyCode='" + orgnlCrncyCode + '\'' +
				", achNum='" + achNum + '\'' +
				", scndryAcctNmbr='" + scndryAcctNmbr + '\'' +
				", origWireAcctId='" + origWireAcctId + '\'' +
				", benWireAcctId='" + benWireAcctId + '\'' +
				", tranAmt2=" + tranAmt2 +
				", tranAmt3=" + tranAmt3 +
				", slsRjctCde='" + slsRjctCde + '\'' +
				", visaAdvncAuthScorType='" + visaAdvncAuthScorType + '\'' +
				'}';
	}
}



