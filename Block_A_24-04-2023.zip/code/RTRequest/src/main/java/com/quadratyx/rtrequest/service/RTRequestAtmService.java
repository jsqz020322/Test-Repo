package com.quadratyx.rtrequest.service;
import java.util.Map;

import com.quadratyx.rtrequest.model.RTResponseFormat;
import com.quadratyx.rtrequest.model.RTRequestFormat;

public interface RTRequestAtmService {

    public int rtScoreAtmService(String tId, Map<String, Object> cacheMap);

    void sendMessage(String message, String topicName);

    void logTrace(RTRequestFormat rtRequestFormat, Map<String, Object> jsonOut);
}

